/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "a2a9d3c2841e"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BADGE_MAIN_TONAL: () => (/* binding */ BADGE_MAIN_TONAL),
/* harmony export */   BADGE_SCHEMES: () => (/* binding */ BADGE_SCHEMES),
/* harmony export */   BADGE_SCHEME_ALIASES: () => (/* binding */ BADGE_SCHEME_ALIASES),
/* harmony export */   BADGE_SIZES: () => (/* binding */ BADGE_SIZES),
/* harmony export */   BADGE_TYPES: () => (/* binding */ BADGE_TYPES),
/* harmony export */   BADGE_VARIANTS: () => (/* binding */ BADGE_VARIANTS),
/* harmony export */   canonicalBadgeScheme: () => (/* binding */ canonicalBadgeScheme),
/* harmony export */   isRetiredMain: () => (/* binding */ isRetiredMain),
/* harmony export */   normalizeBadgeContract: () => (/* binding */ normalizeBadgeContract)
/* harmony export */ });
const BADGE_TYPES = Object.freeze(['main', 'tonal', 'outline']);
const BADGE_SCHEMES = Object.freeze(['neutral', 'primary', 'secondary', 'tertiary', 'info', 'success', 'warning', 'error', 'on-surface']); // Former scheme names that still draw: `danger` was this component's word for
// the error status before the shared vocabulary (contracts/public-api-axes.json,
// journal class-status-aliases, until 2026-12-01). It is read as `error`, so the
// Native constructor emits the canonical class, as sf-badge does; the
// stylesheet matches `.sf-badge--danger` beside it for markup written by hand.

const BADGE_SCHEME_ALIASES = Object.freeze({
  danger: 'error'
});
const BADGE_SIZES = Object.freeze(['1/3', '1/2', '1']); // The default look is tonal (owner decision C140 (1), badges study BG-1): a
// badge without an appearance is the calm grey mark. It was main, the dark
// grey fill nobody chose.

const DEFAULT_BADGE_TYPE = 'tonal';
const DEFAULT_BADGE_SCHEME = 'neutral';
const DEFAULT_BADGE_SIZE = '1/3';

const normalizeEnum = (value, allowed, fallback) => {
  const normalized = String(value ?? fallback).trim().toLowerCase();
  return allowed.includes(normalized) ? normalized : fallback;
}; // The canonical scheme for a name, a former one included; '' when the name is
// not a badge scheme.


function canonicalBadgeScheme(value) {
  const name = String(value ?? '').trim().toLowerCase();
  const canonical = BADGE_SCHEME_ALIASES[name] ?? name;
  return BADGE_SCHEMES.includes(canonical) ? canonical : '';
} // The looks that are drawn: tonal and outline in every colour, main only with
// the error status (C140 (4)).

const BADGE_VARIANTS = Object.freeze(BADGE_SCHEMES.flatMap(scheme => BADGE_TYPES.filter(type => type !== 'main' || scheme === 'error').flatMap(type => BADGE_SIZES.map(size => Object.freeze({
  type,
  scheme,
  size
}))))); // The filled look is the attention count's alone (owner decision C140 (4)):
// main with the error status. main with any other colour draws tonal; the
// spelling keeps working until this date and each use is noted in
// SF.deprecations (journal value-badge-appearance-main-to-tonal).

const BADGE_MAIN_TONAL = Object.freeze({
  since: '2026-11-14',
  remove_after: '2027-01-01'
}); // True when an appearance asked for is the filled one on a colour that draws
// it tonal: the caller notes the old spelling.

function isRetiredMain({
  type,
  scheme
} = {}) {
  const requested = String(type ?? '').trim().toLowerCase();
  return requested === 'main' && (canonicalBadgeScheme(scheme ?? DEFAULT_BADGE_SCHEME) || DEFAULT_BADGE_SCHEME) !== 'error';
}
function normalizeBadgeContract({
  type,
  scheme,
  size
} = {}) {
  let normalizedType = normalizeEnum(type, BADGE_TYPES, DEFAULT_BADGE_TYPE);
  const normalizedScheme = canonicalBadgeScheme(scheme ?? DEFAULT_BADGE_SCHEME) || DEFAULT_BADGE_SCHEME;
  const normalizedSize = normalizeEnum(size, BADGE_SIZES, DEFAULT_BADGE_SIZE); // main is the attention count's: with any other colour it is tonal. The
  // tonal on-surface badge is the grey tonal one (the stylesheet draws
  // sf-badge--on-surface tonal as neutral); it was drawn main, filled.

  if (normalizedType === 'main' && normalizedScheme !== 'error') {
    normalizedType = 'tonal';
  }

  return {
    type: normalizedType,
    scheme: normalizedScheme,
    size: normalizedSize
  };
}

/***/ },

/***/ "1412c5875b4d"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RELATIVE: () => (/* binding */ RELATIVE),
/* harmony export */   densityOf: () => (/* binding */ densityOf),
/* harmony export */   drawing: () => (/* binding */ drawing),
/* harmony export */   followDensity: () => (/* binding */ followDensity),
/* harmony export */   markRelativeSizes: () => (/* binding */ markRelativeSizes),
/* harmony export */   noteAuthored: () => (/* binding */ noteAuthored),
/* harmony export */   sizeOf: () => (/* binding */ sizeOf),
/* harmony export */   sizeStep: () => (/* binding */ sizeStep),
/* harmony export */   sizedBefore: () => (/* binding */ sizedBefore)
/* harmony export */ });
// Density (owner decision C22, 2026-11-09). data-sf-density="compact" on the
// root or on a container moves every component one ladder step down; the CSS
// does it (core/scss/_sf_css__density.scss): each step variable holds the step
// below. An explicit size is a step on the region's ladder (owner decision
// C79, 2026-11-12, changing C22): it comes down with the region, and only
// data-sf-density="normal" takes the normal ladder back.
//
// A size a component's template gives an element it draws (sf-input's clear
// button, a pager's buttons, a submenu) is relative to the component's own
// size; those are still marked data-sf-size-relative once the component has
// drawn. Since C79 the density CSS treats both alike; the mark stays a
// published runtime mark (host-runtime-marks) for hosts that read it.
//
// What a component holds of the page's own (captured slot content, children
// left in place) keeps its size explicit. The store is on the shared global:
// every bundle carries its own copy of this module.
const store = () => {
  const SF = globalThis.SF = globalThis.SF || {};
  const internal = SF.__internal || (SF.__internal = {});
  return internal.density ||= {
    authored: new WeakSet(),
    depth: 0
  };
};

const RELATIVE = 'data-sf-size-relative'; // Page content a component captured to place in its own drawing. Content a
// template hands to a child while it draws is the template's, not the page's.

function noteAuthored(nodes) {
  const state = store();
  if (state.depth > 0) return;

  for (const node of nodes) if (node && typeof node === 'object') state.authored.add(node);
}
function drawing(callback) {
  const state = store();
  state.depth += 1;

  try {
    return callback();
  } finally {
    state.depth -= 1;
  }
} // The sized elements present before a host first draws are the page's.
// A printed first-paint picture is the drawing's, not the page's.

function sizedBefore(host) {
  return new Set(Array.from(host.querySelectorAll?.('[size]') ?? []).filter(element => {
    const picture = element.closest('[data-sf-static]');
    return !picture || !host.contains(picture);
  }));
} // After a host drew: every sized element its drawing holds that is not the
// page's is relative to the host.

function markRelativeSizes(host, before = null) {
  const {
    authored
  } = store();

  for (const element of host.querySelectorAll?.('[size]') ?? []) {
    if (element.hasAttribute(RELATIVE) || before?.has(element)) continue;
    let node = element;
    let page = false;

    while (node && node !== host) {
      if (authored.has(node)) {
        page = true;
        break;
      }

      node = node.parentNode;
    }

    if (!page) element.setAttribute(RELATIVE, '');
  }
} // A popup a component builds itself and places outside its own box (a menu on
// <body>, in an open dialog): sized from the component, so relative, and in
// the component's density, not the density of where it was placed.

function followDensity(element, from) {
  if (!element?.setAttribute) return element;
  if (element.hasAttribute('size')) element.setAttribute(RELATIVE, '');
  const density = densityOf(from);
  if (density) element.setAttribute('data-sf-density', density);else element.removeAttribute('data-sf-density');
  return element;
} // The density an element stands in: the nearest region's (an explicit size
// follows its region since C79); null outside any.

function densityOf(from) {
  for (let node = from; node?.nodeType === 1; node = node.parentElement) {
    if (node.hasAttribute('data-sf-density')) return node.getAttribute('data-sf-density');
  }

  return null;
} // The size step of the control a popup opens from (owner remark 2026-11-15:
// the row menu of a table of size 1 opened at 1/2). A popup a component
// builds outside itself -- a menu on <body> or in the open dialog -- stood on
// the default step whatever opened it. The step is the first size written
// from the opener up: the opener's own (a row's «⋯», the native button an
// sf-button draws), else its component's, else the Smart component that
// holds it (sf-view-table size="1"). A size a template gave a part it draws
// (data-sf-size-relative) follows its host, so the walk goes on past it. It
// ends on the default step (null) at the second custom element without a
// size: the opener's own component may stand on its default, the host
// holding it decides.

function sizeOf(from) {
  let own = true;

  for (let node = from; node?.nodeType === 1; node = node.parentElement) {
    if (node.hasAttribute('size')) {
      if (!node.hasAttribute(RELATIVE)) return node.getAttribute('size');
      continue;
    }

    if (!node.localName.includes('-')) continue;
    if (!own) return null;
    own = false;
  }

  return null;
} // A size step as a number of the ladder ("1/2" is 0.5, "2" is 2); NaN for
// anything else.

function sizeStep(size) {
  const [top, bottom = '1'] = String(size ?? '').trim().split('/');
  const step = Number(top) / Number(bottom);
  return top !== '' && Number.isFinite(step) && step > 0 ? step : Number.NaN;
}

/***/ },

/***/ "e577837dd70a"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   calendarDayOffset: () => (/* binding */ calendarDayOffset),
/* harmony export */   formatDate: () => (/* binding */ formatDate),
/* harmony export */   knownTimeZone: () => (/* binding */ knownTimeZone),
/* harmony export */   msUntilNextDay: () => (/* binding */ msUntilNextDay),
/* harmony export */   timeZoneOffset: () => (/* binding */ timeZoneOffset),
/* harmony export */   toDate: () => (/* reexport safe */ _format_intl_js__WEBPACK_IMPORTED_MODULE_0__.toDate)
/* harmony export */ });
/* harmony import */ var _format_intl_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("15b4e93ff6ed");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_format_intl_js__WEBPACK_IMPORTED_MODULE_0__]);
var __webpack_async_dependencies_result__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
_format_intl_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_async_dependencies_result__[0];
// Dates in the page's language: formatDate, the calendar day offset and the
// next midnight, with no top-level side effects (format-intl.js). The same
// functions as core/js/format.js and SF.format; relative days and times are
// format-relative.js, so a bundle that writes a date does not carry them.


const DAY_MS = 86400000;

function hasDateStyle(style) {
  return style === 'short' || style === 'medium' || style === 'long' || style === 'full';
}
/**
 * A date, a time or both in the locale.
 *
 *   formatDate(at)                          3 нояб. 2026 г.  /  Nov 3, 2026
 *   formatDate(at, {date: 'short'})         03.11.2026       /  11/3/26
 *   formatDate(at, {date: 'long'})          3 ноября 2026 г. /  November 3, 2026
 *   formatDate(at, {time: 'short'})         3 нояб. 2026 г., 14:05
 *   formatDate(at, {date: null, time: 'short'})   14:05   /  2:05 PM
 *
 * `date` and `time` are Intl styles (short, medium, long, full); `intl` gives
 * Intl.DateTimeFormat options outright, for a form the styles do not name (a
 * chart's tick, «14:05» with two-digit hours). `timeZone` (an IANA name,
 * Europe/Moscow) writes the moment on that zone's clock instead of the
 * reader's (owner decision C183 (3): a product that knows the person's zone).
 * Anything that is not a date is `gap`, '' by default.
 */


function formatDate(value, {
  date = 'medium',
  time = null,
  intl = null,
  timeZone = '',
  gap = '',
  ...where
} = {}) {
  const moment = (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.toDate)(value);
  if (!moment) return gap;
  let options = intl;

  if (!options) {
    options = {};
    if (hasDateStyle(date)) options.dateStyle = date;
    if (hasDateStyle(time)) options.timeStyle = time;
    if (!options.dateStyle && !options.timeStyle) options.dateStyle = 'medium';
  }

  if (knownTimeZone(timeZone)) options = { ...options,
    timeZone
  };
  return (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('DateTimeFormat', (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.formatLocale)(where), options).format(moment);
}
/**
 * Whether the platform knows an IANA time zone name (Europe/Moscow, UTC). An
 * empty or unknown name is the reader's own zone everywhere here.
 */

function knownTimeZone(timeZone) {
  const name = String(timeZone ?? '').trim();
  if (!name) return false;
  const root = typeof globalThis !== 'undefined' ? globalThis : {};
  if (!(root.__sfTimeZones instanceof Map)) root.__sfTimeZones = new Map();
  if (root.__sfTimeZones.has(name)) return root.__sfTimeZones.get(name);
  let known = true;

  try {
    new Intl.DateTimeFormat('en', {
      timeZone: name
    });
  } catch {
    known = false;
  }

  if (root.__sfTimeZones.size < 64) root.__sfTimeZones.set(name, known);
  return known;
} // The calendar date and the clock of a moment in a zone, as numbers: the
// reader's own when the zone is none.

function wallClock(moment, timeZone) {
  if (!knownTimeZone(timeZone)) {
    return {
      year: moment.getFullYear(),
      month: moment.getMonth(),
      day: moment.getDate(),
      hour: moment.getHours(),
      minute: moment.getMinutes(),
      second: moment.getSeconds()
    };
  }

  const parts = {};

  for (const part of (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('DateTimeFormat', 'en-US', {
    timeZone,
    hourCycle: 'h23',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric'
  }).formatToParts(moment)) {
    if (part.type !== 'literal') parts[part.type] = Number(part.value);
  }

  return {
    year: parts.year,
    month: parts.month - 1,
    day: parts.day,
    hour: parts.hour % 24,
    minute: parts.minute,
    second: parts.second
  };
}
/**
 * The zone's offset from UTC at a moment, in minutes (Moscow +180, New York
 * -300 in winter); the reader's own when the zone is none.
 */


function timeZoneOffset(value, {
  timeZone = ''
} = {}) {
  const moment = (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.toDate)(value);
  if (!moment) return Number.NaN;
  if (!knownTimeZone(timeZone)) return -moment.getTimezoneOffset();
  const clock = wallClock(moment, timeZone);
  const asUtc = Date.UTC(clock.year, clock.month, clock.day, clock.hour, clock.minute, clock.second);
  return Math.round((asUtc - Math.floor(moment.getTime() / 1000) * 1000) / 60000);
}
/**
 * Calendar days from `now` to the value in the reader's time zone (or
 * `timeZone`'s): 0 today, -1 yesterday, 1 tomorrow; NaN when the value is no
 * date. Counted on calendar dates, not 24-hour spans, so 23:59 yesterday is
 * -1 at 00:01 and a day of a clock change is still one day.
 */

function calendarDayOffset(value, {
  now = new Date(),
  timeZone = ''
} = {}) {
  const moment = (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.toDate)(value);
  const today = (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.toDate)(now);
  if (!moment || !today) return Number.NaN;
  const at = wallClock(moment, timeZone);
  const from = wallClock(today, timeZone);
  const day = Date.UTC(at.year, at.month, at.day);
  const base = Date.UTC(from.year, from.month, from.day);
  return Math.round((day - base) / DAY_MS);
}
/**
 * Milliseconds from `now` to the reader's next midnight, when every relative
 * day on the screen moves by one. A component that shows them sets a timer
 * for this long (plus a second's margin, so it wakes in the new day) and
 * draws them again; «сегодня» said yesterday is wrong by morning.
 */

function msUntilNextDay(now = new Date(), {
  timeZone = ''
} = {}) {
  const today = (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.toDate)(now) ?? new Date();

  if (!knownTimeZone(timeZone)) {
    const next = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
    return next.getTime() - today.getTime();
  } // In a named zone: the time left on its clock until 24:00, corrected by a
  // change of its offset before then (a clock change at night).


  const clock = wallClock(today, timeZone);
  const left = DAY_MS - ((clock.hour * 60 + clock.minute) * 60 + clock.second) * 1000 - today.getMilliseconds();
  const shift = timeZoneOffset(today, {
    timeZone
  }) - timeZoneOffset(new Date(today.getTime() + left), {
    timeZone
  });
  return Math.max(1, left + shift * 60000);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "15b4e93ff6ed"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatLocale: () => (/* binding */ formatLocale),
/* harmony export */   intlFormatter: () => (/* binding */ intlFormatter),
/* harmony export */   toDate: () => (/* binding */ toDate)
/* harmony export */ });
/* harmony import */ var _page_language_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("43090d1c8307");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_page_language_js__WEBPACK_IMPORTED_MODULE_0__]);
var __webpack_async_dependencies_result__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
_page_language_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_async_dependencies_result__[0];
/* harmony import */ var _page_language_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_page_language_js__WEBPACK_IMPORTED_MODULE_0__);
// The part every format module shares (core/js/format.js says what the
// helpers are): the locale a call formats in, a Date from what a host gives,
// and the Intl formatters, kept on a global every copy of these modules shares
// (bundles each carry their own module copy; page-language.js says why).
//
// No top-level side effects, here or in format-number.js, format-date.js,
// format-relative.js and format-file-size.js (ui-chart, 2026-11-05): a bundle
// that imports one function carries that function and what it calls, nothing
// else. The global is made on the first format, not on load, and SF.format is
// published by core's entry (index.js, publishFormat in format.js).

/** The locale a call formats in: the one it names, else its node's page language. */

function formatLocale({
  locale,
  node
} = {}) {
  return String(locale || '').trim() || (0,_page_language_js__WEBPACK_IMPORTED_MODULE_0__.pageLocale)(node);
}
/** A Date from a Date, a time in milliseconds or a date string; null when it is none. */

function toDate(value) {
  if (value === null || value === undefined || value === '') return null;
  const date = value instanceof Date ? new Date(value.getTime()) : new Date(typeof value === 'string' && /^\d+$/u.test(value) ? Number(value) : value);
  return Number.isNaN(date.getTime()) ? null : date;
} // The formatters every copy shares, made on the first call.

function formatterCache() {
  const root = typeof globalThis !== 'undefined' ? globalThis : {};
  if (!root.__sfFormat) root.__sfFormat = {
    formatters: new Map()
  };
  return root.__sfFormat.formatters;
} // One formatter per kind, locale and options. An unknown locale falls back to
// the browser's, and options the platform refuses (an unknown unit or
// currency) to a plain number, so a typo in a page never throws at a reader.


function intlFormatter(kind, locale, options) {
  const key = `${kind}|${locale}|${JSON.stringify(options)}`;
  const cache = formatterCache();
  if (cache.has(key)) return cache.get(key);
  const Make = Intl[kind];
  let made;

  try {
    made = new Make(locale || undefined, options);
  } catch {
    try {
      made = new Make(undefined, options);
    } catch {
      made = new Make(locale || undefined, kind === 'NumberFormat' ? {
        maximumFractionDigits: 2
      } : {});
    }
  } // A page that formats in many locales does not grow the cache for ever.


  if (cache.size >= 256) cache.delete(cache.keys().next().value);
  cache.set(key, made);
  return made;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "c9ce0852ac73"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatNumber: () => (/* binding */ formatNumber),
/* harmony export */   numberOptions: () => (/* binding */ numberOptions),
/* harmony export */   percentSign: () => (/* binding */ percentSign),
/* harmony export */   percentText: () => (/* binding */ percentText)
/* harmony export */ });
/* harmony import */ var _format_intl_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("15b4e93ff6ed");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_format_intl_js__WEBPACK_IMPORTED_MODULE_0__]);
var __webpack_async_dependencies_result__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
_format_intl_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_async_dependencies_result__[0];
// Numbers in the page's language by a format word: formatNumber and
// numberOptions alone, with no top-level side effects (format-intl.js). The
// same functions as core/js/format.js and SF.format.number; a bundle that
// formats numbers only imports them from here.

/**
 * The Intl options of a number format word (ui-chart's words, kept so a page
 * writes a format as an attribute):
 *
 *   number (default)  1 234,5   as many digits as `step` needs, at most 6; 2 without one
 *   integer           1 235
 *   decimal-<n>       n digits after the point, always (0 to 20)
 *   share             a share 0..1 as 12 % (0.125 is 12,5 %)
 *   percent           the same share: the charts' word, kept
 *   unit-percent      a value that already is the percent (12.5 is 12,5 %),
 *                     as the property type `percent` stores it
 *   compact           1,2 тыс.  /  1.2K
 *   currency-<CODE>   1 234,50 ₽ (an ISO 4217 code)
 *   unit-<unit>       45,3 ГБ (an Intl unit: gigabyte, megabit-per-second)
 *
 * Anything else reads as number. Words join with a space: a kind (currency-,
 * unit-, percent) and a precision (integer, decimal-<n>, compact), so
 * «currency-RUB integer» is 1 235 ₽, «currency-RUB decimal-2» 1 234,50 ₽ and
 * «currency-RUB compact» 1,1 млн ₽. The precision wins whatever the order.
 */

function numberOptions(format = 'number', step = 0) {
  const words = String(format || 'number').trim().split(/\s+/u).filter(Boolean);

  if (words.length > 1) {
    const PRECISION = /^(?:integer|compact|decimal-\d{1,2})$/u;
    const kinds = words.filter(one => !PRECISION.test(one));
    const precision = words.filter(one => PRECISION.test(one));
    return [...kinds, ...precision].reduce((options, one) => ({ ...options,
      ...numberOptions(one, step)
    }), {});
  }

  const word = words[0] ?? 'number';
  if (word === 'integer') return {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }; // Two meanings of «percent» met in the Framework (C294, MP-4): this word
  // multiplies a share by 100, while the property type `percent` holds the
  // percent itself. `share` says which one it is; `percent` stays its alias for
  // the charts that write it, and `unit-percent` is the percent itself.

  if (word === 'share' || word === 'percent') return {
    style: 'percent',
    maximumFractionDigits: 1
  };
  if (word === 'compact') return {
    notation: 'compact',
    maximumFractionDigits: 1
  };
  const decimal = /^decimal-(\d{1,2})$/u.exec(word);

  if (decimal) {
    const digits = Math.min(20, Number(decimal[1]));
    return {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits
    };
  }

  const unit = /^unit-([a-z]+(?:-per-[a-z]+)?)$/u.exec(word);
  if (unit) return {
    style: 'unit',
    unit: unit[1],
    unitDisplay: 'short',
    maximumFractionDigits: 1
  };
  const currency = /^currency-([A-Z]{3})$/u.exec(word);
  if (currency) return {
    style: 'currency',
    currency: currency[1]
  };
  const digits = step > 0 && step < 1 ? Math.min(6, Math.ceil(-Math.log10(step) - 1e-9)) : 2;
  return {
    maximumFractionDigits: digits
  };
}
/**
 * A number in the locale by a format word (numberOptions). `grouping: false`
 * writes it without thousands marks («2026»), `step` sets the digits of
 * `number`, and a value that is not a finite number is `gap`, '' by default
 * (a chart passes '—').
 */

function formatNumber(value, format = 'number', {
  step = 0,
  gap = '',
  grouping = true,
  ...where
} = {}) {
  const number = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
  if (typeof number !== 'number' || !Number.isFinite(number)) return gap;
  const options = numberOptions(format, step);
  if (grouping === false) options.useGrouping = false;
  const text = (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('NumberFormat', (0,_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.formatLocale)(where), options).format(number);
  return options.style === 'percent' || options.unit === 'percent' ? percentSign(text) : text;
}
/**
 * One spelling of a per cent in every language (owner decision C203 (3), DEV
 * msg-913fd9e4, 2026-11-15): the number, a no-break space (U+00A0) and «%» --
 * «72 %», «12,5 %», and «72 %» in English too, where Intl writes «72%». A
 * language that writes the sign first («%72») keeps its order.
 */

function percentSign(text) {
  // A right-to-left language writes direction marks around the sign («12.5‎%‎»
  // in Arabic); they go with the space it had, and the number keeps the mark
  // it starts with (C294).
  return String(text).replace(/[\s\u00a0\u202f\u200e\u200f\u061c]*%[\u200e\u200f\u061c]*$/u, '\u00a0%');
}
/**
 * A value that already is a per cent (0..100, «72», «72.5») as the progress
 * family shows and says it (owner decision C203 (3), IM-3): the number in the
 * language of the node's part of the page, as many digits as it has (up to
 * 2), a no-break space and «%» -- «72 %», «72,5 %».
 */

function percentText(value, node) {
  const number = Number(value);
  return percentSign(`${formatNumber(Number.isFinite(number) ? number : 0, 'number', {
    node,
    grouping: false
  })}%`);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "8d229b7c92e9"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   menuOpen: () => (/* binding */ menuOpen),
/* harmony export */   publishMenu: () => (/* binding */ publishMenu)
/* harmony export */ });
/* harmony import */ var _density_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1412c5875b4d");
// SF.menu.open: the page's one menu of actions (owner decision C184 (4),
// 2026-11-14; the public name is the owner's; study control/research/
// 2026-11-14-toolbar-menu-open.md, K-03).
//
// A row's «⋯», a toolbar's «Ещё», the right button and the menu key on a row
// all open the standard menu -- sf-menu-context -- and every component used to
// place its own and wait for it (nine in SIMAI Pro, more in the Framework).
// Now one call opens the one menu of the page:
//
//   const choice = await SF.menu.open({anchor, entries, label});
//   const choice = await SF.menu.open({x, y, entries, label, returnTo: row});
//   // choice: {id, entry} of the row chosen, or null (closed without one)
//
// - anchor: the control the menu hangs from (a press on the same control
//   while its menu is open closes it, as a toggle); or x, y: a point in the
//   window -- where a right-click was, or a row's corner for Shift+F10 -- the
//   menu's corner exactly there;
// - entries: the rows, as sf-menu-context takes them;
// - label: the menu's name, read by a screen reader;
// - size: the menu's size step, as sf-menu-context's size attribute; left
//   out, the step of what opens it (the anchor's, its component's or the
//   Smart component holding it: a row menu of a table of size 1 is size 1);
// - returnTo: where the focus goes when the menu closes (the row it acted
//   on); left out, the menu gives the focus back to where it was, or to the
//   anchor.
//
// The menu is fetched by the Loader the first time (SF.Loader.ensure), one on
// the page -- on the body, or in the open modal dialog the anchor is in, since
// a modal dialog makes the rest of the page inert. A second opening while one
// is open closes the first, which answers null. The answer never rejects:
// without a menu (no Loader, no sf-menu-context) it is null.
//
// Every bundle may carry a copy of this module (bundles each carry their own
// module copy), so the one menu and its pending answer live behind the shared
// global: the first copy to run publishes SF.menu.open and every other copy
// calls the published one.

const SHARED = 'data-sf-menu-shared';

function installMenuOpen() {
  let pending = null;
  let point = null; // The opening the menu belongs to now, kept past its answer: a choice
  // answers before the menu closes, and the focus goes back on closing.

  let shown = null;

  const settle = value => {
    const waiting = pending;
    pending = null;
    waiting?.resolve(value);
    return waiting;
  };

  function sharedMenu(anchor) {
    const doc = globalThis.document;
    let menu = doc.querySelector(`[${SHARED}]`);

    if (!menu) {
      menu = doc.createElement('sf-menu-context');
      menu.setAttribute('popup', '');
      menu.setAttribute(SHARED, '');
      menu.addEventListener('sf-menu-context-select', event => {
        if (event.target !== menu) return;
        settle({
          id: event.detail?.id ?? null,
          entry: event.detail?.entry ?? null
        });
      });
      menu.addEventListener('sf-menu-context-closed', event => {
        if (event.target !== menu) return;
        settle(null);
        const opening = shown;
        shown = null;
        const back = opening?.returnTo;
        if (!back?.isConnected) return; // After the menu's own return: the row the person acted on, when the
        // focus fell to the page, stayed in the closed menu or went back to
        // the «⋯» that opened it (a pointer's control, not a Tab stop).

        const anchor = opening.anchor;
        setTimeout(() => {
          const active = doc.activeElement;

          if (!active || active === doc.body || active === doc.documentElement || menu.contains(active) || anchor && (active === anchor || anchor.contains?.(active))) {
            back.focus?.({
              preventScroll: true
            });
          }
        }, 0);
      });
    } // In the open modal dialog the opener is in, or on the body.


    const home = anchor?.closest?.('dialog[open]') || doc.body;
    if (menu.parentNode !== home && !menu.isOpen) home.append(menu);
    return menu;
  } // A point in the window as an anchor of no size: sf-menu-context hangs its
  // corner exactly there and reads the page under it (density, focus back).


  function pointAnchor(x, y, near) {
    const doc = globalThis.document;

    if (!point?.isConnected) {
      point = doc.createElement('span');
      point.setAttribute('aria-hidden', 'true');
      point.setAttribute('data-sf-menu-point', '');
    }

    const home = near?.closest?.('dialog[open]') || doc.body;
    if (point.parentNode !== home) home.append(point);
    point.style.cssText = `position:fixed;left:${x}px;top:${y}px;inline-size:0;block-size:0;pointer-events:none;overflow:hidden`;
    return point;
  }

  return async function open(options = {}) {
    const {
      anchor = null,
      x,
      y,
      entries = [],
      label = '',
      size = '',
      returnTo = null
    } = options || {};
    const atPoint = !(anchor instanceof Element);
    if (atPoint && !(Number.isFinite(Number(x)) && Number.isFinite(Number(y)))) return null;
    const doc = globalThis.document;
    if (!doc) return null;
    await globalThis.SF?.Loader?.ensure?.(['sf-menu-context']);
    if (!globalThis.customElements?.get('sf-menu-context')) return null;
    const menu = sharedMenu(atPoint ? returnTo : anchor); // The same control again: its open menu closes (a toggle).

    if (!atPoint && menu.isOpen && pending?.anchor === anchor) {
      menu.close({
        reason: 'api'
      });
      return null;
    }

    if (menu.isOpen) {
      settle(null);
      shown = null;
      menu.close({
        restoreFocus: false,
        reason: 'api',
        ask: false
      });
    }

    if (label) menu.setAttribute('aria-label', label);else menu.removeAttribute('aria-label');
    if (size) menu.setAttribute('size', String(size));else {
      menu.removeAttribute('size');
      menu.removeAttribute(_density_js__WEBPACK_IMPORTED_MODULE_0__.RELATIVE);
    } // In the density of the control or the row it opens from (C22, C79), not
    // of the body it stands on.

    (0,_density_js__WEBPACK_IMPORTED_MODULE_0__.followDensity)(menu, atPoint ? returnTo : anchor);
    menu.search = null;
    menu.entries = Array.isArray(entries) ? entries : [];
    return new Promise(resolve => {
      pending = {
        resolve,
        anchor,
        returnTo: returnTo instanceof Element ? returnTo : null
      };
      shown = pending;
      const mine = pending;
      const opening = atPoint ? typeof menu.openAt === 'function' ? menu.openAt(Number(x), Number(y), {
        target: returnTo ?? undefined
      }) : menu.openFor(pointAnchor(Number(x), Number(y), returnTo), {
        side: 'block-end',
        align: 'start',
        focus: 'first'
      }) : menu.openFor(anchor, {
        side: 'block-end',
        align: 'start',
        focus: 'first'
      });
      Promise.resolve(opening).then(answer => {
        // Refused (a listener kept it closed) or no surface: nothing chosen.
        if (pending === mine && answer && answer !== true && answer.outcome !== 'applied') settle(null);
      }, () => {
        if (pending === mine) settle(null);
      });
    });
  };
} // The published one, or this copy published.


function publishMenu() {
  const SF = globalThis.SF = globalThis.SF || {};
  SF.menu = SF.menu || {};
  if (typeof SF.menu.open !== 'function') SF.menu.open = installMenuOpen();
  return SF.menu;
}
function menuOpen(options) {
  return publishMenu().open(options);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (menuOpen);

/***/ },

/***/ "51250bf01ab0"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createPreferences: () => (/* binding */ createPreferences),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// SF.Preferences: what a person changes about how a thing looks -- column
// order, widths, sort, density, a menu's column widths -- kept one way for
// every component (owner, 2026-10-14; ui-control
// control/designs/2026-10-14-view-preferences.md).
//
// - A preference is a plain JSON value under a key `<component>/<instance>`,
//   e.g. `sf-table/cms.solutions`. No key, nothing is kept.
// - It is read synchronously, so a component applies it before its first
//   paint: the skeleton is already in the person's order.
// - The browser keeps a copy always (localStorage `sf-pref:<key>`), the cache
//   a first paint can read. A host that keeps preferences for its user
//   (Larena) plugs in with useHost(); its values win over the cache, and every
//   write goes to it as well, debounced per key.
// - A page can preload the host's values: preload({key: value}), or a
//   <script type="application/json" data-sf-preferences> (or id
//   "sf-preferences") in the page, read before the first value is.
//
// The registry lives on globalThis.SF: every bundle carries its own copy of
// this module, and two copies with two caches would disagree.
const PREFIX = 'sf-pref:';
const DELAY = 400;
const KEY = /^[\w.*:-]+(?:\/[\w.*:/-]+)?$/u;

function storage() {
  try {
    return globalThis.localStorage ?? null;
  } catch {
    return null;
  }
}

function validKey(key) {
  return typeof key === 'string' && key.length > 0 && key.length <= 200 && KEY.test(key);
}

function same(a, b) {
  try {
    return JSON.stringify(a) === JSON.stringify(b);
  } catch {
    return false;
  }
}

function plain(value) {
  return value === null || value === undefined ? null : JSON.parse(JSON.stringify(value));
}

function createPreferences() {
  const host = {
    adapter: null,
    values: new Map()
  };
  const listeners = new Map();
  const timers = new Map(); // The page's own block of the host's values, read once, before the first
  // read: a component may connect before this module's start-up ran.

  let inlineRead = false;

  const readInline = () => {
    if (inlineRead) return;
    const node = globalThis.document?.querySelector?.('script[type="application/json"][data-sf-preferences], script#sf-preferences[type="application/json"]');
    if (!node) return;
    inlineRead = true;

    try {
      api.preload(JSON.parse(node.textContent || '{}'));
    } catch {
      /* not JSON: ignored */
    }
  };

  const notify = (key, value) => {
    for (const listener of listeners.get(key) ?? []) {
      try {
        listener(plain(value), key);
      } catch (error) {
        console.error('SF.Preferences listener failed', key, error);
      }
    }
  };

  const readCache = key => {
    const store = storage();
    if (!store) return null;

    try {
      const raw = store.getItem(PREFIX + key);
      return raw === null ? null : JSON.parse(raw);
    } catch {
      return null;
    }
  };

  const writeCache = (key, value) => {
    const store = storage();
    if (!store) return;

    try {
      if (value === null) store.removeItem(PREFIX + key);else store.setItem(PREFIX + key, JSON.stringify(value));
    } catch {// A full or refused storage keeps the value for this page only.
    }
  };

  const saveToHost = key => {
    clearTimeout(timers.get(key));
    timers.delete(key);
    const adapter = host.adapter;
    if (!adapter) return;
    const value = host.values.has(key) ? host.values.get(key) : readCache(key);

    try {
      const answer = value === null ? adapter.remove?.(key) : adapter.save?.(key, plain(value));
      Promise.resolve(answer).catch(error => console.warn('SF.Preferences: the host did not keep', key, error));
    } catch (error) {
      console.warn('SF.Preferences: the host did not keep', key, error);
    }
  };

  const schedule = key => {
    if (!host.adapter) return;
    clearTimeout(timers.get(key));
    timers.set(key, setTimeout(() => saveToHost(key), DELAY));
  };

  const api = {
    // The value for a key: the host's when it gave one, else this browser's.
    read(key) {
      if (!validKey(key)) return null;
      readInline();
      if (host.values.has(key)) return plain(host.values.get(key));
      return plain(readCache(key));
    },

    // Several keys from the most general to the most particular, merged field
    // by field: `sf-table/*` (the person's tables) under `sf-table/<instance>`.
    readMerged(...keys) {
      const merged = {};
      let found = false;

      for (const key of keys.flat()) {
        const value = api.read(key);

        if (value && typeof value === 'object' && !Array.isArray(value)) {
          Object.assign(merged, value);
          found = true;
        }
      }

      return found ? merged : null;
    },

    write(key, value) {
      if (!validKey(key)) return false;
      const next = plain(value); // The value already kept is not written again: a component restoring
      // what the host gave it (sf-resizer's value) sent it back to the host on
      // every load (docs trial 5).

      if (JSON.stringify(api.read(key)) === JSON.stringify(next)) return true;
      if (host.values.has(key)) host.values.set(key, next);
      writeCache(key, next);
      schedule(key);
      return true;
    },

    // «Сбросить вид»: gone from both.
    remove(key) {
      if (!validKey(key)) return false;
      if (host.values.has(key)) host.values.set(key, null);
      writeCache(key, null);
      schedule(key);
      notify(key, null);
      return true;
    },

    subscribe(key, listener) {
      if (!validKey(key) || typeof listener !== 'function') return () => {};
      if (!listeners.has(key)) listeners.set(key, new Set());
      listeners.get(key).add(listener);
      return () => listeners.get(key)?.delete(listener);
    },

    // The host's values for this person. Each that differs from this
    // browser's copy replaces it and is announced, so a component re-applies.
    preload(values) {
      if (!values || typeof values !== 'object') return;

      for (const [key, value] of Object.entries(values)) {
        if (!validKey(key)) continue;
        const next = plain(value);
        const before = api.read(key);
        host.values.set(key, next);
        writeCache(key, next);
        if (!same(before, next)) notify(key, next);
      }
    },

    // {save(key, value), remove(key), load?(keys) → Promise<{key: value}>}.
    useHost(adapter) {
      if (!adapter || typeof adapter.save !== 'function') throw new TypeError('A preferences host saves: {save(key, value)}');
      host.adapter = adapter;
      return api;
    },

    // Asks the host for keys it has not given yet (a component that appears
    // after the page loaded).
    async load(keys) {
      const wanted = [].concat(keys).filter(key => validKey(key) && !host.values.has(key));
      if (!wanted.length || typeof host.adapter?.load !== 'function') return;

      try {
        api.preload(await host.adapter.load(wanted));
      } catch (error) {
        console.warn('SF.Preferences: the host did not answer', wanted, error);
      }
    },

    get hosted() {
      return Boolean(host.adapter);
    },

    // Writes still waiting go now (a page that is leaving).
    flush() {
      for (const key of [...timers.keys()]) saveToHost(key);
    }

  }; // Another tab changed a preference.

  globalThis.addEventListener?.('storage', event => {
    if (!event.key?.startsWith(PREFIX) || event.storageArea !== storage()) return;
    const key = event.key.slice(PREFIX.length);
    if (host.values.has(key)) return;
    let value = null;

    try {
      value = event.newValue === null ? null : JSON.parse(event.newValue);
    } catch {
      value = null;
    }

    notify(key, value);
  });
  globalThis.addEventListener?.('pagehide', () => api.flush());
  readInline();
  return Object.freeze(api);
}

if (typeof globalThis !== 'undefined') {
  globalThis.SF = globalThis.SF || {};
  if (!globalThis.SF.Preferences) globalThis.SF.Preferences = createPreferences();
}

const Preferences = globalThis.SF?.Preferences;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Preferences);


/***/ },

/***/ "557c99eb8f3a"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   focusTarget: () => (/* binding */ focusTarget),
/* harmony export */   roving: () => (/* binding */ roving)
/* harmony export */ });
// One Tab stop for a row of controls, and the arrows between them (owner
// decision C184 (1)-(3), 2026-11-14; study control/research/2026-11-14-
// toolbar-menu-open.md, K-02). A toolbar is not a component of its own
// (C155 (8): no sf-toolbar): it is ordinary sf-button-icon groups, 4 apart
// inside a group and a separator between groups (C144), and this helper gives
// them the keyboard of the WAI-ARIA toolbar pattern:
//
// - the row is one Tab stop; Tab comes back to the control the person left
//   (memory, C184 (3)), or to the first one (memory: false);
// - the arrows of the row's orientation move between the controls, in the
//   row's direction (right-to-left reverses ← and →), Home and End go to the
//   ends, and the walk wraps;
// - a control that cannot be used now (aria-disabled) stays in the walk,
//   dimmed by its component, with its reason as a tooltip (C184 (2), as
//   C164 (4) does for a menu row); disabled: 'skip' leaves it out. A control
//   with the native disabled attribute cannot take the focus and is skipped;
// - a control inside «Ещё» (the C155 row engine marks the part that left the
//   row with .out or [hidden]) is not in the walk;
// - ↓ (↑) on a menu button of a horizontal row opens its menu, as the
//   pattern's menu button does.
//
// It is also the list's keyboard (C184 (5)): a list is one Tab stop and ↑ ↓
// move between its rows (orientation 'vertical').
//
// roving(container, options) -> {refresh, set, current, items, destroy}.
// The look stays with the components; this module holds no state of its own
// outside the controller it returns, so every bundle may carry its own copy.
const NATIVE_FOCUSABLE = 'button, a[href], input, select, textarea, [tabindex], [contenteditable=""], [contenteditable="true"]';
const OUT = '.out, [hidden], [data-sf-out], [inert]'; // The element that takes the focus for an item: the item itself when it can
// (a <button>, a row with a tabindex), else the control inside it -- an
// sf-button-icon host draws a <button> and is display: contents.

function focusTarget(item) {
  if (!item) return null;
  if (item.matches?.(NATIVE_FOCUSABLE)) return item;
  return item.querySelector?.('button, a[href], [role="button"], [tabindex]') ?? item;
}

const isUnavailable = target => target.getAttribute?.('aria-disabled') === 'true';

const isDisabled = target => Boolean(target.disabled) || target.matches?.(':disabled');

function roving(container, {
  items: itemsOf = 'button',
  orientation = 'horizontal',
  wrap = true,
  disabled = 'focusable',
  memory = true,
  out = OUT,
  onMove = null,
  observe = true
} = {}) {
  let current = null; // Every item of the row, in order, as the targets that take the focus.

  const all = () => {
    const found = typeof itemsOf === 'function' ? itemsOf() : [...container.querySelectorAll(itemsOf)];
    const targets = [];

    for (const item of found) {
      const target = focusTarget(item);
      if (!target || !container.contains(target) || targets.includes(target)) continue; // Out of the row: a part inside it that left (into «Ещё») or is
      // hidden. The row itself being hidden for now does not count.

      const away = target.closest(out);
      if (away && away !== container && container.contains(away)) continue;
      targets.push(target);
    }

    return targets;
  }; // The items the walk stops on.


  const items = () => all().filter(target => !isDisabled(target) && (disabled === 'focusable' || !isUnavailable(target)));

  function set(element) {
    const target = focusTarget(element);
    const every = all();
    if (!target || !every.includes(target)) return;
    current = target;

    for (const other of every) {
      const next = other === target ? '0' : '-1';
      if (other.getAttribute('tabindex') !== next) other.setAttribute('tabindex', next);
    }
  } // After a drawing or a change of the row: the one Tab stop is the item
  // remembered, or the first one when it is gone (or the row forgets).


  function refresh() {
    const list = items();

    if (!list.length) {
      // Nothing to stop on: no item keeps a stop either (a disabled field's
      // toolbar is not a Tab stop).
      for (const other of all()) if (other.getAttribute('tabindex') !== '-1') other.setAttribute('tabindex', '-1');

      current = null;
      return;
    }

    set(current && list.includes(current) ? current : list[0]);
  }

  const vertical = orientation === 'vertical';
  const both = orientation === 'both';

  function onKeydown(event) {
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    const list = items();
    const target = list.find(one => one === event.target || one.contains(event.target));
    if (!target) return; // A field inside an item (a link's address) keeps its own keys.

    if (event.target !== target && event.target.matches?.('input, textarea, select, [contenteditable="true"], [contenteditable=""]')) return;
    const rtl = getComputedStyle(container).direction === 'rtl';
    const forward = vertical ? ['ArrowDown'] : both ? ['ArrowDown', rtl ? 'ArrowLeft' : 'ArrowRight'] : [rtl ? 'ArrowLeft' : 'ArrowRight'];
    const back = vertical ? ['ArrowUp'] : both ? ['ArrowUp', rtl ? 'ArrowRight' : 'ArrowLeft'] : [rtl ? 'ArrowRight' : 'ArrowLeft'];
    const at = list.indexOf(target);
    let next = null;

    if (!vertical && !both && (event.key === 'ArrowDown' || event.key === 'ArrowUp') && target.getAttribute('aria-haspopup') === 'menu' && !isUnavailable(target)) {
      event.preventDefault();
      target.click();
      return;
    }

    if (forward.includes(event.key)) next = at + 1 < list.length ? list[at + 1] : wrap ? list[0] : null;else if (back.includes(event.key)) next = at > 0 ? list[at - 1] : wrap ? list[list.length - 1] : null;else if (event.key === 'Home') next = list[0];else if (event.key === 'End') next = list[list.length - 1];else return;
    event.preventDefault();
    if (!next || next === target) return;
    set(next);
    next.focus();
    onMove?.(next, event.key);
  }

  function onFocusIn(event) {
    const target = all().find(one => one === event.target);
    if (!target || target === current) return;
    set(target);
    onMove?.(target, 'focus');
  }

  function onFocusOut(event) {
    if (memory || container.contains(event.relatedTarget)) return;
    const list = items();
    if (list.length) set(list[0]);
  }

  container.addEventListener('keydown', onKeydown);
  container.addEventListener('focusin', onFocusIn);
  container.addEventListener('focusout', onFocusOut); // Items drawn later -- a host that draws its <button> on its own schedule
  // (sf-button-icon), a row added -- join the walk with tabindex -1 at once:
  // the row stays one Tab stop whatever draws when.

  let queued = false;
  const watcher = observe && typeof MutationObserver === 'function' ? new MutationObserver(() => {
    if (queued) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      refresh();
    });
  }) : null;
  watcher?.observe(container, {
    childList: true,
    subtree: true
  });
  refresh();
  return {
    refresh,
    set,
    items,

    get current() {
      return current;
    },

    destroy() {
      watcher?.disconnect();
      container.removeEventListener('keydown', onKeydown);
      container.removeEventListener('focusin', onFocusIn);
      container.removeEventListener('focusout', onFocusOut);
    }

  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (roving);

/***/ },

/***/ "c11c730f061a"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DATE_FUTURE_PERIODS: () => (/* binding */ DATE_FUTURE_PERIODS),
/* harmony export */   DATE_PERIODS: () => (/* binding */ DATE_PERIODS),
/* harmony export */   LEGACY_DATE_OPERATORS: () => (/* binding */ LEGACY_DATE_OPERATORS),
/* harmony export */   LEGACY_DATE_OPERATORS_UNTIL: () => (/* binding */ LEGACY_DATE_OPERATORS_UNTIL),
/* harmony export */   buildFilterRequest: () => (/* binding */ buildFilterRequest),
/* harmony export */   dateConditionLabel: () => (/* binding */ dateConditionLabel),
/* harmony export */   dateConditionOf: () => (/* binding */ dateConditionOf),
/* harmony export */   dateConditionPhrase: () => (/* binding */ dateConditionPhrase),
/* harmony export */   dateConditionValue: () => (/* binding */ dateConditionValue),
/* harmony export */   dateFilterChipText: () => (/* binding */ dateFilterChipText),
/* harmony export */   dateFilterConditions: () => (/* binding */ dateFilterConditions),
/* harmony export */   dateFilterKind: () => (/* binding */ dateFilterKind),
/* harmony export */   dateGroupLabel: () => (/* binding */ dateGroupLabel),
/* harmony export */   filterRequestContext: () => (/* binding */ filterRequestContext),
/* harmony export */   isEmptyFilterEntry: () => (/* binding */ isEmptyFilterEntry),
/* harmony export */   normalizeFilterEntry: () => (/* binding */ normalizeFilterEntry),
/* harmony export */   resolveDatePeriod: () => (/* binding */ resolveDatePeriod)
/* harmony export */ });
/* harmony import */ var _core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("43090d1c8307");
/* harmony import */ var _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("d3818183b14c");
/* harmony import */ var _input_date_js_locale_calendar_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("c4779e51fee1");
/* harmony import */ var _lang_index_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("354525e80715");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__, _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_1__]);
([_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__, _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* harmony import */ var _core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_1__);
// The date filter's conditions, its server contract and its words (owner
// decision C293, 2026-11-17; study ui-control
// prototypes/date-filter-conditions-study.html, notes
// control/research/2026-11-17-date-filter/README.md).
//
// A field holds one date (a date, or a date and time) or a period (a start and
// an end). The filter is a condition first and then exactly what the condition
// needs: nothing, one day, two days, a number of days, or -- for a period
// field -- a period by name or two days. One condition per field travels to the
// server as {operator, value}:
//
//   one date    eq, lt, gt, gte, lte          value: "yyyy-mm-dd"
//               between                       value: ["yyyy-mm-dd", "yyyy-mm-dd"], both days in
//               period                        value: a period's name (DATE_PERIODS)
//               last-days, next-days          value: a whole number of days, today counted
//   a period    overlaps, within, starts, ends   value: a period's name or two days
//               contains                      value: "yyyy-mm-dd"
//   both        empty, not-empty              value: true
//
// The request carries the context the server resolves the periods in,
// {timeZone, weekStart} (weekStart 0 Sunday .. 6 Saturday, as Date#getDay
// counts): «this week» is the server's to work out, by name, so a saved view
// stays «this week» and the browser's clock is not trusted. A date and time is
// compared by its day in that time zone.
//
// The operators today, week and month (fix/date-pd) are read as the periods
// today, this-week and this-month until 2027-01-01 (contracts/changes/journal.json
// value-date-filter-period-operators).
//
// No DOM here and no Lit: the table, a record view and a server-side test read
// the same rules.




const SET_NAME = 'sf-field-renderers'; // Whole calendar periods (this week is Monday to Sunday where the week starts
// on Monday, this month to its last day, this year to 31 December) and the
// rolling «last 7 days», today and the six days before it.

const DATE_PERIODS = Object.freeze(['today', 'yesterday', 'this-week', 'last-week', 'last-7-days', 'this-month', 'last-month', 'this-year']); // A deadline field (filter.future: true) also looks forward. «Overdue» is not
// a date condition: it depends on the record's status.

const DATE_FUTURE_PERIODS = Object.freeze(['tomorrow', 'next-week', 'next-month']);
const LEGACY_DATE_OPERATORS = Object.freeze({
  today: 'today',
  week: 'this-week',
  month: 'this-month'
});
const LEGACY_DATE_OPERATORS_UNTIL = '2027-01-01'; // What a condition needs: none | day | days | count | when (a period's name or
// two days).

const DAY_OPERATORS = ['eq', 'lt', 'gt', 'gte', 'lte'];
const PERIOD_FIELD_OPERATORS = ['overlaps', 'within', 'starts', 'ends'];

function condition(operator, need, group, period = '') {
  return Object.freeze({
    key: period ? `period:${period}` : operator,
    operator,
    need,
    group,
    ...(period ? {
      period
    } : {})
  });
}

function singleConditions(future) {
  return [condition('eq', 'day', 'date'), condition('between', 'days', 'date'), condition('lt', 'day', 'date'), condition('gt', 'day', 'date'), condition('gte', 'day', 'date'), condition('lte', 'day', 'date'), ...DATE_PERIODS.map(name => condition('period', 'none', 'period', name)), condition('last-days', 'count', 'period'), ...(future ? [condition('period', 'none', 'period', 'tomorrow'), condition('period', 'none', 'period', 'next-week'), condition('next-days', 'count', 'period'), condition('period', 'none', 'period', 'next-month')] : []), condition('empty', 'none', 'filled'), condition('not-empty', 'none', 'filled')];
}

function periodFieldConditions() {
  return [...PERIOD_FIELD_OPERATORS.map(operator => condition(operator, 'when', 'range')), condition('contains', 'day', 'range'), condition('empty', 'none', 'filled'), condition('not-empty', 'none', 'filled')];
} // A field is a period when it says so: its property type or control is
// `period`, or its filter's kind is. Every other date field holds one date.


function dateFilterKind(field = {}) {
  const asked = [field.filter?.kind, field.filter?.control, field.propertyType, field.type];
  return asked.includes('period') ? 'period' : 'date';
}

function isDueField(field = {}) {
  return field.filter?.future === true || field.future === true;
} // The conditions the field's filter offers, in the order of the list. A host's
// filter.operators narrows them: an operator it names stays, `period` keeps
// every period, and the old today, week and month keep every period and «last
// N days» (they were the list's periods).


function dateFilterConditions(field = {}) {
  const all = dateFilterKind(field) === 'period' ? periodFieldConditions() : singleConditions(isDueField(field));
  const asked = field.filter?.operators;
  if (!Array.isArray(asked) || !asked.length) return all;
  const names = new Set();

  for (const operator of asked) {
    const name = String(operator);

    if (LEGACY_DATE_OPERATORS[name]) {
      names.add('period');
      names.add('last-days');
      names.add('next-days');
    } else names.add(name);
  }

  const kept = all.filter(one => names.has(one.operator));
  return kept.length ? kept : all;
}

function isDay(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/u.test(value);
}

function dayOf(value) {
  if (typeof value !== 'string') return '';
  const day = value.slice(0, 10);
  return isDay(day) ? day : '';
}

function isTwoDays(value) {
  return Array.isArray(value) && value.length === 2 && isDay(dayOf(value[0])) && isDay(dayOf(value[1]));
}

function isPeriodName(value) {
  return typeof value === 'string' && (DATE_PERIODS.includes(value) || DATE_FUTURE_PERIODS.includes(value));
}

function isCount(value) {
  const number = Number(value);
  return value !== '' && value !== null && value !== true && Number.isInteger(number) && number > 0;
} // The old operators as the new periods, noted once per page in
// SF.deprecations until LEGACY_DATE_OPERATORS_UNTIL.


function normalizeFilterEntry(entry) {
  if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return entry;
  const period = LEGACY_DATE_OPERATORS[entry.operator];
  if (!period) return entry;
  (0,_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_1__.noteDeprecated)({
    component: SET_NAME,
    kind: 'value',
    attribute: 'filter operator',
    from: entry.operator,
    to: `period ${period}`,
    since: '2026-11-17',
    remove_after: LEGACY_DATE_OPERATORS_UNTIL
  });
  return { ...entry,
    operator: 'period',
    value: period
  };
}

function isBlank(value) {
  if (value === null || value === undefined) return true;
  if (Array.isArray(value)) return value.every(isBlank);
  if (typeof value === 'string') return value.trim() === '';
  if (typeof value === 'object') return Object.values(value).every(isBlank);
  return false;
} // Whether a filter entry says nothing yet, so the table drops it with its
// chip. It reads the operator (DF-1): a period, «empty» and «not empty» are
// whole by themselves, and a condition that needs a day is empty without one.
// An entry of any other field keeps the old reading: empty when its value or
// values are.


function isEmptyFilterEntry(entry) {
  if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return isBlank(entry);
  const one = LEGACY_DATE_OPERATORS[entry.operator] ? normalizeFilterEntry(entry) : entry;
  const {
    operator,
    value
  } = one;

  switch (operator) {
    case 'empty':
    case 'not-empty':
      return false;

    case 'period':
      return !isPeriodName(value);

    case 'last-days':
    case 'next-days':
      return !isCount(value);

    case 'overlaps':
    case 'within':
    case 'starts':
    case 'ends':
      return !(isPeriodName(value) || isTwoDays(value));

    default:
      break;
  }

  if (Object.prototype.hasOwnProperty.call(one, 'values')) return isBlank(one.values);
  if (Object.prototype.hasOwnProperty.call(one, 'value')) return isBlank(one.value);
  return Object.entries(one).filter(([key]) => !['operator', 'control', 'type'].includes(key)).every(([, item]) => isBlank(item));
} // The value a condition starts with when it is chosen: the stale day of the
// condition before is not carried into a period (DF-2), but a day stays a day
// and two days stay two days.

function dateConditionValue(next, previous = {}) {
  const before = previous?.value;

  switch (next.need) {
    case 'none':
      return next.period || true;

    case 'day':
      return isDay(dayOf(before)) ? dayOf(before) : null;

    case 'days':
      return isTwoDays(before) ? before.map(dayOf) : null;

    case 'count':
      return isCount(before) ? Number(before) : 30;

    case 'when':
      return isPeriodName(before) || isTwoDays(before) ? before : 'this-week';

    default:
      return null;
  }
} // The condition an entry stands for, in the field's list.

function dateConditionOf(field, entry) {
  const list = dateFilterConditions(field);
  const one = normalizeFilterEntry(entry || {});
  if (one?.operator === 'period') return list.find(item => item.period === one.value) ?? null;
  return list.find(item => item.operator === one?.operator) ?? null;
} // The context a request carries: the time zone and the first day of the week
// the server resolves the periods in. A host that knows the person's own
// (monday.com takes them from the profile) passes them; otherwise the
// browser's zone and the page language's week.

function filterRequestContext(node = null, {
  timeZone,
  weekStart
} = {}) {
  let zone = typeof timeZone === 'string' && timeZone ? timeZone : '';

  if (!zone) {
    try {
      zone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    } catch {
      zone = 'UTC';
    }
  }

  const start = Number.isInteger(weekStart) && weekStart >= 0 && weekStart <= 7 ? weekStart % 7 : (0,_input_date_js_locale_calendar_js__WEBPACK_IMPORTED_MODULE_2__.localeWeekStart)((0,_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__.pageLocale)(node));
  return {
    timeZone: zone,
    weekStart: start
  };
} // A filter's values as the server is asked for them: the old operators read as
// periods, empty entries left out, and the context beside them.

function buildFilterRequest(values = {}, {
  node = null,
  context
} = {}) {
  const out = {};

  for (const [key, entry] of Object.entries(values || {})) {
    if (isEmptyFilterEntry(entry)) continue;
    out[key] = normalizeFilterEntry(entry);
  }

  return {
    values: out,
    context: filterRequestContext(node, context || {})
  };
} // A period's first and last day for a given today, as the server is asked to
// resolve it (a reference for a host's server and for the tests). `today` is
// yyyy-mm-dd in the request's time zone.

function resolveDatePeriod(name, {
  today,
  weekStart = 1
} = {}) {
  if (!isDay(today)) return null;
  const [y, m, d] = today.split('-').map(Number);

  const at = (year, month, day) => {
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.toISOString().slice(0, 10);
  };

  const shift = days => at(y, m, d + days);

  const dow = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  const back = (dow - weekStart % 7 + 7) % 7;

  switch (name) {
    case 'today':
      return [today, today];

    case 'yesterday':
      return [shift(-1), shift(-1)];

    case 'tomorrow':
      return [shift(1), shift(1)];

    case 'this-week':
      return [shift(-back), shift(6 - back)];

    case 'last-week':
      return [shift(-back - 7), shift(-back - 1)];

    case 'next-week':
      return [shift(7 - back), shift(13 - back)];

    case 'last-7-days':
      return [shift(-6), today];

    case 'this-month':
      return [at(y, m, 1), at(y, m + 1, 0)];

    case 'last-month':
      return [at(y, m - 1, 1), at(y, m, 0)];

    case 'next-month':
      return [at(y, m + 1, 1), at(y, m + 2, 0)];

    case 'this-year':
      return [at(y, 1, 1), at(y, 12, 31)];

    default:
      return null;
  }
} // ---- Words ----

const camel = text => String(text).replace(/-([a-z0-9])/gu, (_, letter) => letter.toUpperCase());

function word(node, key, vars, count) {
  return (0,_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__.pageWord)(_lang_index_mjs__WEBPACK_IMPORTED_MODULE_3__["default"], key, node, {
    component: SET_NAME,
    vars,
    count
  });
} // A condition's name in the list: «Точная дата», «Прошлый месяц», «Пусто».


function dateConditionLabel(node, item) {
  if (!item) return '';
  if (item.period) return word(node, `datePeriod_${camel(item.period)}`);
  return word(node, `dateCondition_${camel(item.operator)}`);
}
function dateGroupLabel(node, group) {
  return word(node, `dateGroup_${group}`);
}

function currentYear(timeZone) {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric'
    }).format(new Date());
  } catch {
    return String(new Date().getFullYear());
  }
}

function dayDate(day) {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12));
} // A day as the chip says it: «17 ноября», «20 января 2025» -- the year only when
// it is not this year.


function dayText(node, day, timeZone) {
  if (!isDay(day)) return '…';
  const withYear = day.slice(0, 4) !== currentYear(timeZone);

  try {
    return new Intl.DateTimeFormat((0,_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__.pageLocale)(node), {
      day: 'numeric',
      month: 'long',
      ...(withYear ? {
        year: 'numeric'
      } : {}),
      timeZone: 'UTC'
    }).format(dayDate(day));
  } catch {
    return day;
  }
} // Two days as one span: «1–15 ноября», «28 октября – 3 ноября».


function spanText(node, from, to, timeZone) {
  const a = dayOf(from);
  const b = dayOf(to);
  if (!isDay(a) || !isDay(b)) return dayText(node, a || b, timeZone);
  if (a === b) return dayText(node, a, timeZone);
  const year = currentYear(timeZone);
  const withYear = a.slice(0, 4) !== year || b.slice(0, 4) !== year;

  try {
    const format = new Intl.DateTimeFormat((0,_core_js_page_language_js__WEBPACK_IMPORTED_MODULE_0__.pageLocale)(node), {
      day: 'numeric',
      month: 'long',
      ...(withYear ? {
        year: 'numeric'
      } : {}),
      timeZone: 'UTC'
    });
    return format.formatRange(dayDate(a), dayDate(b));
  } catch {
    return `${dayText(node, a, timeZone)} – ${dayText(node, b, timeZone)}`;
  }
}

function periodPhrase(node, name) {
  return word(node, `datePeriodIn_${camel(name)}`);
} // What a condition says after the field's name on its chip: «в прошлом
// месяце», «не позже 17 ноября», «идёт на этой неделе», «пусто» (DF-4).


function dateConditionPhrase(field, entry, node = null, {
  timeZone
} = {}) {
  const one = normalizeFilterEntry(entry || {});
  const zone = timeZone || filterRequestContext(node).timeZone;
  const {
    operator,
    value
  } = one || {};

  const when = () => isPeriodName(value) ? periodPhrase(node, value) : isTwoDays(value) ? spanText(node, value[0], value[1], zone) : '…';

  switch (operator) {
    case 'eq':
      return dayText(node, dayOf(value), zone);

    case 'between':
      return Array.isArray(value) ? spanText(node, value[0], value[1], zone) : '…';

    case 'lt':
    case 'gt':
    case 'gte':
    case 'lte':
      return word(node, `dateChip_${operator}`, {
        date: dayText(node, dayOf(value), zone)
      });

    case 'period':
      return isPeriodName(value) ? periodPhrase(node, value) : '…';

    case 'last-days':
    case 'next-days':
      return word(node, `dateChip_${camel(operator)}`, undefined, isCount(value) ? Number(value) : 0);

    case 'empty':
    case 'not-empty':
      return word(node, `dateChip_${camel(operator)}`);

    case 'overlaps':
    case 'starts':
    case 'ends':
      return word(node, `dateChip_${operator}`, {
        when: when()
      });

    case 'within':
      return isPeriodName(value) ? word(node, 'dateChip_within', {
        when: when()
      }) : word(node, 'dateChip_withinDays', {
        when: when()
      });

    case 'contains':
      return word(node, 'dateChip_contains', {
        date: dayText(node, dayOf(value), zone)
      });

    default:
      return '';
  }
} // The chip of a date filter: «Дата оплаты: в прошлом месяце». A condition the
// set does not know keeps the field's name alone.

function dateFilterChipText(field = {}, entry, node = null, options = {}) {
  const name = String(field.label ?? field.key ?? '');
  const phrase = dateConditionPhrase(field, entry, node, options);
  return phrase ? word(node, 'dateChip', {
    field: name,
    condition: phrase
  }) : name;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "9ce1a42b2a85"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DATE_TIME_RE: () => (/* binding */ DATE_TIME_RE),
/* harmony export */   composeDateTime: () => (/* binding */ composeDateTime),
/* harmony export */   composeTime: () => (/* binding */ composeTime),
/* harmony export */   normalizeTime: () => (/* binding */ normalizeTime),
/* harmony export */   splitDateTime: () => (/* binding */ splitDateTime),
/* harmony export */   splitTime: () => (/* binding */ splitTime)
/* harmony export */ });
// A datetime's value, read and written back: plain functions, no rendering.
// The edit renderers (renderDateTimeEdit and renderTimeEdit in index.js) use them, the contract
// test runs them without a DOM, and SF.fieldRenderers.dateTime publishes them
// so a host that draws its own pair reads and writes the same way.
//
// Lifted from ui-admin's property view (src/smart/property-view/js/
// datetime-value.js, Larena acceptance 2026-10-22: «Дата и время» kept only
// the day, so a new record could not get a time and «15.11.2026 10:30» was
// saved as «15.11.2026»).
//
// The value is the host's text, in the host's time zone, as it reads it. The
// round trip is lossless: a field whose day and time come back to what they
// were writes back exactly the text it read. A changed day keeps the record's
// clock (seconds, fraction) and zone; a changed time is hh:mm:00 with the
// record's zone; a new value has no zone and is the host's local time.
// The forms a datetime arrives in: a day, or a day and a time separated by T or
// a space, with optional seconds, fraction and zone.
const DATE_TIME_RE = /^(\d{4}-\d{2}-\d{2})(?:[T ](\d{2}):(\d{2})((?::\d{2})(?:\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/u;
const DAY_RE = /^\d{4}-\d{2}-\d{2}$/u; // The value without the host's formatting ({value, text} carries both).

function rawValue(value) {
  if (value && typeof value === 'object' && !Array.isArray(value) && 'value' in value) return value.value;
  return value;
} // What a stored value is made of. `known` is false for a value that is not a
// datetime at all: the controls start empty and, untouched, nothing is written.


function splitDateTime(value) {
  const raw = rawValue(value);
  if (raw === null || raw === undefined || raw === '') return {
    raw: raw ?? null,
    known: true,
    date: '',
    time: '',
    rest: '',
    zone: ''
  };
  const match = typeof raw === 'string' ? raw.trim().match(DATE_TIME_RE) : null;
  if (!match) return {
    raw,
    known: false,
    date: '',
    time: '',
    rest: '',
    zone: ''
  };
  return {
    raw,
    known: true,
    date: match[1],
    time: match[2] ? `${match[2]}:${match[3]}` : '',
    rest: match[4] || '',
    zone: match[5] || ''
  };
} // A time as the person typed it, as hh:mm, or null when it is not one. The
// mask gives «10:30»; without it «1030», «9:30» and «9.30» are read too.

function normalizeTime(text) {
  const value = String(text ?? '').trim().replace(/[_\s]/gu, '');
  if (value === '' || value === ':') return '';
  const match = value.match(/^(\d{1,2})[:.]?(\d{2})$/u);
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return null;
  return `${String(hours).padStart(2, '0')}:${match[2]}`;
} // The value to write for a day and a time, against what the field held.
// {value} -- the text to write (null clears), or {error} -- the key of the
// sentence that says what is missing: dateMissing, dateInvalid, timeMissing,
// timeInvalid.

function composeDateTime(original, draft) {
  const date = String(draft?.date ?? '').trim();
  const time = normalizeTime(draft?.time);
  if (time === null) return {
    error: 'timeInvalid'
  };
  if (!date && !time) return {
    value: null
  };
  if (!DAY_RE.test(date)) return {
    error: date ? 'dateInvalid' : 'dateMissing'
  };
  if (!time) return {
    error: 'timeMissing'
  };
  const before = original?.known ? original : null; // Back to what it was: the very text it read, separator and all.

  if (before && before.date === date && before.time === time) return {
    value: before.raw
  }; // The clock below the minute and the zone are the record's while the
  // person did not change the time; a time they typed is to the minute.

  const sameTime = before && before.time === time;
  const rest = sameTime ? before.rest : ':00';
  const zone = before && before.time ? before.zone : '';
  return {
    value: `${date}T${time}${rest}${zone}`
  };
} // A time of day as a host stores it: hh:mm, or with seconds and a fraction.

const TIME_RE = /^(\d{2}):(\d{2})((?::\d{2})(?:\.\d+)?)?$/u; // What a stored time is made of, as splitDateTime says it for a datetime.

function splitTime(value) {
  const raw = rawValue(value);
  if (raw === null || raw === undefined || raw === '') return {
    raw: raw ?? null,
    known: true,
    time: '',
    rest: ''
  };
  const match = typeof raw === 'string' ? raw.trim().match(TIME_RE) : null;
  if (!match || normalizeTime(`${match[1]}:${match[2]}`) === null) return {
    raw,
    known: false,
    time: '',
    rest: ''
  };
  return {
    raw,
    known: true,
    time: `${match[1]}:${match[2]}`,
    rest: match[3] || ''
  };
} // The value to write for a time, against what the field held: {value} (null
// clears) or {error: 'timeInvalid'}. The same minute writes back the very
// text it read; a changed one keeps the stored shape (hh:mm:00 where the
// host stores seconds), and a new one is hh:mm.

function composeTime(original, text) {
  const time = normalizeTime(text);
  if (time === null) return {
    error: 'timeInvalid'
  };
  if (!time) return {
    value: null
  };
  const before = original?.known ? original : null;
  if (before && before.time === time) return {
    value: before.raw
  };
  return {
    value: before?.rest ? `${time}:00` : time
  };
}

/***/ },

/***/ "ab3947ea3647"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CURRENCY_DISPLAYS: () => (/* binding */ CURRENCY_DISPLAYS),
/* harmony export */   addDecimal: () => (/* binding */ addDecimal),
/* harmony export */   compareDecimal: () => (/* binding */ compareDecimal),
/* harmony export */   currencyCodes: () => (/* binding */ currencyCodes),
/* harmony export */   currencyDisplayOf: () => (/* binding */ currencyDisplayOf),
/* harmony export */   currencyOf: () => (/* binding */ currencyOf),
/* harmony export */   editableDecimal: () => (/* binding */ editableDecimal),
/* harmony export */   formatDecimal: () => (/* binding */ formatDecimal),
/* harmony export */   formatMoney: () => (/* binding */ formatMoney),
/* harmony export */   formatPercent: () => (/* binding */ formatPercent),
/* harmony export */   fractionDigits: () => (/* binding */ fractionDigits),
/* harmony export */   isRtlLocale: () => (/* binding */ isRtlLocale),
/* harmony export */   minorUnits: () => (/* binding */ minorUnits),
/* harmony export */   moneyParts: () => (/* binding */ moneyParts),
/* harmony export */   moneyTotals: () => (/* binding */ moneyTotals),
/* harmony export */   readDecimal: () => (/* binding */ readDecimal),
/* harmony export */   readTypedDecimal: () => (/* binding */ readTypedDecimal),
/* harmony export */   restingDecimal: () => (/* binding */ restingDecimal)
/* harmony export */ });
/* harmony import */ var _core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("15b4e93ff6ed");
/* harmony import */ var _core_js_format_number_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c9ce0852ac73");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__, _core_js_format_number_js__WEBPACK_IMPORTED_MODULE_1__]);
([_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__, _core_js_format_number_js__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// Decimal numbers as strings, never as floats (simai.property-view-port
// 1.18.0; Larena property types standard, notes of 2026-11-03: «Never a float
// on the wire»). What a person typed is read into a canonical decimal string,
// and a decimal, a money amount and a percent are shown in the page's language
// through Intl, which formats a string by its digits: «1500.10» never passes
// through a float on the way to «1 500,10 ₽». Pure, so the unit suite reads it
// without a browser. Money and percent are the Framework's in every mode
// (owner decision C291 (2)) and their display, paste and totals follow owner
// decision C294 (2026-11-17, MP-1..MP-12): the standard sign, never the
// narrow one; a minus and nothing else for a negative; the amount and its
// sign never broken apart; a direction mark on a right-to-left page; what a
// person pastes («1 234,50 ₽», «$1,234.50») read as a decimal string. The
// View set's items, compound and ru.requisites call these functions instead
// of keeping a copy.


const TYPED = /^([+-]?)(\d*)(?:[.,](\d*))?$/u; // Spaces a person or a formatter puts between groups of digits: the plain
// space, the no-break space and the narrow no-break space ru-RU writes, and
// the apostrophe some locales group with.

const GROUP_SPACES = /[\s\u00a0\u202f']/gu;
/**
 * What a person typed, read as a decimal: `{ok: true, value}` with the
 * canonical string (an optional minus, the integer digits without leading
 * zeros, the fraction digits as typed; null for nothing typed), or
 * `{ok: false}` for text that is not a number. A comma and a point both
 * separate the fraction. A JSON integer is read as its digits; a float is not
 * a decimal and is refused rather than guessed at.
 */

function readDecimal(text) {
  if (text === null || typeof text === 'undefined') return {
    ok: true,
    value: null
  };

  if (typeof text === 'number') {
    return Number.isSafeInteger(text) ? {
      ok: true,
      value: String(text)
    } : {
      ok: false
    };
  }

  const plain = String(text).replace(GROUP_SPACES, '');
  if (plain === '') return {
    ok: true,
    value: null
  };
  const match = TYPED.exec(plain);
  if (!match) return {
    ok: false
  };
  const [, sign, whole, fraction] = match;
  if (whole === '' && (fraction ?? '') === '') return {
    ok: false
  };
  const integer = whole.replace(/^0+(?=\d)/u, '') || '0';
  const digits = fraction ?? '';
  const zero = /^0*$/u.test(integer + digits);
  return {
    ok: true,
    value: `${sign === '-' && !zero ? '-' : ''}${integer}${digits ? `.${digits}` : ''}`
  };
}
/** How many digits a canonical decimal string has after its point. */

function fractionDigits(value) {
  const at = String(value ?? '').indexOf('.');
  return at === -1 ? 0 : String(value).length - at - 1;
} // A float a host sent anyway is shown, not refused: a cell is not the place to
// argue with a stored value. Only what reads as a decimal is formatted. A
// float that is not a whole number is rounded to `digits` when they are given
// (a currency's minor units, a percent's six) -- 0.1 + 0.2 roubles are
// «0,30 ₽», never «0,30000000000000004 ₽» (MP-2) -- and the page hears it once
// in the console: the value should have been a decimal string.

const FLOAT_WARNED = new Set();

function warnFloat(kind) {
  if (FLOAT_WARNED.has(kind)) return;
  FLOAT_WARNED.add(kind);
  globalThis.console?.warn?.(`SF.fieldRenderers: a ${kind} value came as a number; send a decimal string ("1500.5"), a float loses digits.`);
}

function decimalOf(value, digits = null, kind = 'number') {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return null;
    if (Number.isInteger(value)) return Number.isSafeInteger(value) ? String(value) : BigInt(value).toString();
    if (!Number.isInteger(digits)) return String(value);
    warnFloat(kind);
    return readDecimal(value.toFixed(Math.min(20, digits)).replace(/(\.\d*?)0+$/u, '$1').replace(/\.$/u, '')).value;
  }

  const read = readDecimal(value);
  return read.ok ? read.value : null;
} // Right-to-left languages: a number drawn there starts with the right-to-left
// mark, so a minus, a sign or a «%» never jumps to the other end of the line
// (C294, MP-9). Intl writes the mark for a negative already; the positive
// amount had none.


const RTL_LANGUAGES = new Set(['ar', 'he', 'iw', 'fa', 'ur', 'ps', 'yi', 'dv', 'ckb', 'sd', 'ug']);
const DIRECTION_MARKS = /[\u200e\u200f\u061c\u2066-\u2069]/gu;
function isRtlLocale(locale) {
  return RTL_LANGUAGES.has(String(locale || '').toLowerCase().split(/[-_]/u)[0]);
} // On a right-to-left page a sign that ends in a neutral mark («US$», «CA$»)
// is isolated left to right (U+2066 .. U+2069), or the browser draws «$US»; a
// percent is held left to right as a whole («12.5 %»), as Intl's Arabic
// pattern holds «12.5%» with its marks.

function directed(text, locale, {
  wholeLtr = false
} = {}) {
  if (!text || !isRtlLocale(locale)) return text;
  if (wholeLtr) return `\u200f\u200e${text.replace(DIRECTION_MARKS, '')}\u200e`;
  const glued = text.replace(/[A-Za-z]+[^\sA-Za-z\d\u00a0\u202f\u200e\u200f\u061c\u2066-\u2069.,\u066b\u066c-]+/gu, '\u2066$&\u2069');
  return glued.startsWith('\u200f') ? glued : `\u200f${glued}`;
} // The amount and its sign stay on one line: every plain space Intl leaves
// between them becomes a no-break one (ru, de write U+00A0 already).


const unbroken = text => text.replace(/ /gu, '\u00a0');
/**
 * A decimal string in the locale's digits and groups, with every digit it has
 * and at least `minDigits`: «1 500,5», «1 234 567,5» (the Number type, MP-5;
 * money and percent use the same groups). A float that is not whole keeps at
 * most six digits.
 */


function formatDecimal(value, locale, {
  minDigits = 0
} = {}) {
  const decimal = decimalOf(value, 6);
  if (decimal === null) return '';
  const digits = Math.min(20, Math.max(minDigits, fractionDigits(decimal)));
  return directed(unbroken((0,_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('NumberFormat', locale, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(decimal)), locale);
}
/** A money value as {amount, currency}; a field that fixes the currency takes a bare amount. */

function moneyParts(value, fixed) {
  const currency = typeof fixed === 'string' && fixed ? fixed : null;

  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return {
      amount: value.amount ?? null,
      currency: currency || (value.currency ?? null)
    };
  }

  if (value === null || typeof value === 'undefined' || value === '') return {
    amount: null,
    currency
  };
  return {
    amount: value,
    currency
  };
} // How a field names its currency (C294, q-mp-sign): Intl's standard sign
// (`symbol`, the default) -- «₽» on a Russian page, «$» for the US dollar on an
// English one and «CA$» for the Canadian dollar, so two currencies never read
// the same -- or the code (`code`, for accounting and exports) or the name
// (`name`). The narrow sign wrote USD, CAD and AUD all as «$» (MP-3): a field
// asking for it gets the standard sign.

const CURRENCY_DISPLAYS = Object.freeze(['symbol', 'code', 'name']);
function currencyDisplayOf(field = {}) {
  return CURRENCY_DISPLAYS.includes(field?.currencyDisplay) ? field.currencyDisplay : 'symbol';
}
/** ISO 4217 minor units of a currency (RUB 2, JPY 0, KWD 3); 2 for a code Intl does not know. */

function minorUnits(currency) {
  try {
    return new Intl.NumberFormat('en', {
      style: 'currency',
      currency
    }).resolvedOptions().maximumFractionDigits ?? 2;
  } catch {
    return 2;
  }
}
/**
 * An amount with its currency, as a person reads it: «1 500,50 ₽», «$1,500.50»,
 * «CA$10.00» (C294). The digits after the point are at least the currency's
 * minor units (ISO 4217) and every digit the amount has; a float is rounded
 * to the minor units, with one console warning. A negative amount has the
 * minus where the language writes it and nothing else -- no colour, no
 * brackets (q-mp-negative). The amount and the sign never break apart, and a
 * right-to-left page gets the direction mark. Without a currency, the amount
 * alone.
 */

function formatMoney(value, field = {}, locale = 'en') {
  const {
    amount,
    currency
  } = moneyParts(value, field.currency);
  const minor = currency ? minorUnits(currency) : 2;
  const decimal = decimalOf(amount, minor, 'money');
  if (decimal === null) return '';
  if (!currency) return formatDecimal(decimal, locale);
  const digits = Math.min(20, Math.max(minor, fractionDigits(decimal)));
  return directed(unbroken((0,_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('NumberFormat', locale, {
    style: 'currency',
    currency,
    currencyDisplay: currencyDisplayOf(field),
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(decimal)), locale);
}
/**
 * A percent, «12,5 %» and «12.5 %»: the value is the percent ("20" is 20 %),
 * never the share -- the share is SF.format's word `share` (MP-4). One
 * spelling in every language (C203 (3)): the number, a no-break space, «%».
 * A float keeps at most six digits, with one console warning.
 */

function formatPercent(value, locale = 'en') {
  const decimal = decimalOf(value, 6, 'percent');
  if (decimal === null) return '';
  const digits = Math.min(20, fractionDigits(decimal));
  return directed((0,_core_js_format_number_js__WEBPACK_IMPORTED_MODULE_1__.percentSign)((0,_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('NumberFormat', locale, {
    style: 'unit',
    unit: 'percent',
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(decimal)), locale, {
    wholeLtr: true
  });
}
/** The sum of decimal strings, by their digits (a column total): "1500.5" + "0.75" is "1501.25"; null when one is not a decimal. */

function addDecimal(...values) {
  let scale = 0;
  const read = [];

  for (const value of values.flat()) {
    if (value === null || value === undefined || value === '') continue;
    const one = decimalOf(value, 20);
    if (one === null) return null;
    read.push(one);
    scale = Math.max(scale, fractionDigits(one));
  }

  let total = 0n;

  for (const one of read) {
    const negative = one.startsWith('-');
    const [whole, fraction = ''] = one.replace('-', '').split('.');
    const units = BigInt(whole + fraction.padEnd(scale, '0'));
    total += negative ? -units : units;
  }

  const negative = total < 0n;
  const digits = (negative ? -total : total).toString().padStart(scale + 1, '0');
  const whole = digits.slice(0, digits.length - scale) || '0';
  const fraction = scale ? digits.slice(-scale).replace(/0+$/u, '') : '';
  const zero = /^0*$/u.test(whole + fraction);
  return `${negative && !zero ? '-' : ''}${whole}${fraction ? `.${fraction}` : ''}`;
}
/**
 * A money column's total (C294): the amounts added by their digits, one sum
 * per currency, in the order the currencies first appear -- a column of
 * dollars and euros is two sums, never one. [{currency, amount, text}];
 * values that are not money are left out.
 */

function moneyTotals(values = [], field = {}, locale = 'en') {
  const sums = new Map();

  for (const value of values) {
    const {
      amount,
      currency
    } = moneyParts(value, field.currency);
    const decimal = decimalOf(amount, currency ? minorUnits(currency) : null);
    if (decimal === null) continue;
    const key = currency ?? '';
    sums.set(key, addDecimal(sums.get(key) ?? '0', decimal));
  }

  return [...sums].map(([currency, amount]) => ({
    currency: currency || null,
    amount,
    text: formatMoney(currency ? {
      amount,
      currency
    } : amount, {
      currencyDisplay: field.currencyDisplay
    }, locale)
  }));
} // What a person pastes or types, read as a decimal (C294, MP-8). Arabic-Indic
// digits and separators are read as ASCII; the currency's signs and code,
// «%», spaces, apostrophes and direction marks are dropped; a minus may stand
// before or after the digits. With both a point and a comma the last one
// separates the fraction; a separator that repeats groups; a single one is
// the fraction, unless it is the page's group separator followed by exactly
// three digits -- «1,234» on an English page is 1234, on a Russian one 1,234.

const CURRENCY_MARKS = /[$€£¥₽₸₴₺₹₩₪₦₱฿₫¤]/gu;

function signsOf(currency, locale) {
  if (typeof currency !== 'string' || !/^[A-Z]{3}$/u.test(currency)) return [];
  const signs = new Set([currency]);

  for (const display of ['symbol', 'narrowSymbol', 'code', 'name']) {
    try {
      for (const part of new Intl.NumberFormat(locale, {
        style: 'currency',
        currency,
        currencyDisplay: display
      }).formatToParts(2)) {
        if (part.type === 'currency') signs.add(part.value);
      }
    } catch {// A code Intl does not know keeps its letters only.
    }
  }

  return [...signs].sort((a, b) => b.length - a.length);
}

function separatorsOf(locale) {
  try {
    const parts = new Intl.NumberFormat(locale).formatToParts(1234567.5);
    return {
      group: parts.find(part => part.type === 'group')?.value ?? ',',
      decimal: parts.find(part => part.type === 'decimal')?.value ?? '.'
    };
  } catch {
    return {
      group: ',',
      decimal: '.'
    };
  }
}
/**
 * `{ok: true, value, typedDigits}` for what reads as a number -- the canonical
 * decimal string (no groups, a point, no trailing zeros after it; null for
 * nothing typed) and how many digits were typed after the separator -- or
 * `{ok: false}`. `currency` names the code whose signs may stand in the text.
 */


function readTypedDecimal(text, {
  locale = 'en',
  currency = null
} = {}) {
  if (text === null || text === undefined) return {
    ok: true,
    value: null,
    typedDigits: 0
  };

  if (typeof text === 'number') {
    const read = readDecimal(Number.isInteger(text) ? text : String(text));
    return read.ok ? {
      ok: true,
      value: read.value,
      typedDigits: fractionDigits(read.value ?? '')
    } : {
      ok: false
    };
  }

  let plain = String(text).replace(/[\u0660-\u0669]/gu, digit => String(digit.charCodeAt(0) - 0x660)).replace(/[\u06f0-\u06f9]/gu, digit => String(digit.charCodeAt(0) - 0x6f0)).replace(/\u066b/gu, '.').replace(/\u066c/gu, '');

  for (const sign of signsOf(currency, locale)) plain = plain.split(sign).join('');

  plain = plain.replace(CURRENCY_MARKS, '').replace(/[%\u066a]/gu, '').replace(DIRECTION_MARKS, '').replace(/[\s\u00a0\u202f'\u2019]/gu, '').replace(/[\u2212\u2013]/gu, '-');
  if (plain === '') return {
    ok: true,
    value: null,
    typedDigits: 0
  };
  let negative = false;

  if (plain.startsWith('-')) {
    negative = true;
    plain = plain.slice(1);
  } else if (plain.startsWith('+')) {
    plain = plain.slice(1);
  } else if (plain.endsWith('-')) {
    negative = true;
    plain = plain.slice(0, -1);
  }

  const dots = (plain.match(/\./gu) || []).length;
  const commas = (plain.match(/,/gu) || []).length;

  if (dots && commas) {
    const mark = plain.charAt(Math.max(plain.lastIndexOf('.'), plain.lastIndexOf(',')));
    plain = plain.split(mark === '.' ? ',' : '.').join('');
    if (mark === ',') plain = plain.replace(',', '.');
  } else if (dots + commas > 1) {
    plain = plain.split(dots ? '.' : ',').join('');
  } else if (dots + commas === 1) {
    const mark = dots ? '.' : ',';
    const after = plain.length - plain.indexOf(mark) - 1;
    if (mark === separatorsOf(locale).group && after === 3) plain = plain.replace(mark, '');else plain = plain.replace(',', '.');
  }

  if (!/^\d*(?:\.\d*)?$/u.test(plain) || !/\d/u.test(plain)) return {
    ok: false
  };
  const [whole = '', fraction = ''] = plain.split('.');
  const integer = whole.replace(/^0+(?=\d)/u, '') || '0';
  const digits = fraction.replace(/0+$/u, '');
  const zero = /^0*$/u.test(integer + digits);
  return {
    ok: true,
    value: `${negative && !zero ? '-' : ''}${integer}${digits ? `.${digits}` : ''}`,
    typedDigits: fraction.length
  };
}
/** A decimal at rest in an edit field: the locale's groups and point, at least `minDigits` after it, no sign («1 500,50»). */

function restingDecimal(value, locale = 'en', minDigits = 0) {
  const read = readDecimal(value);
  if (!read.ok || read.value === null) return '';
  const digits = Math.min(20, Math.max(minDigits, fractionDigits(read.value)));
  return unbroken((0,_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('NumberFormat', locale, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(read.value));
}
/** Every ISO 4217 code the browser knows, for a currency field that names no list; the ten offered codes where Intl cannot list them. */

function currencyCodes(fallback = []) {
  try {
    const codes = Intl.supportedValuesOf?.('currency');
    if (Array.isArray(codes) && codes.length) return codes;
  } catch {// An older engine: the offered list.
  }

  return [...fallback];
} // What the editors of money and percent need (owner decision C291 (2): the two
// types are the Framework's in every mode, the View set's editors were the
// reference): the sign and minor units of a currency, two decimals compared by
// their digits, and a decimal as it is typed back in an input.

/**
 * A currency in a locale: {sign, before, minor} -- the sign the locale writes
 * by the field's `currencyDisplay` (the standard sign by default: «₽», «$»,
 * «CA$»; C294), whether it stands before the amount, and its ISO 4217 minor
 * units (RUB 2, JPY 0, KWD 3). A code Intl does not know keeps its letters,
 * after the amount, with two minor digits.
 */

function currencyOf(code, locale = 'en', display = 'symbol') {
  const fallback = {
    sign: String(code ?? ''),
    before: false,
    minor: 2
  };
  if (typeof code !== 'string' || !/^[A-Z]{3}$/u.test(code)) return fallback;

  try {
    const format = new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: code,
      currencyDisplay: CURRENCY_DISPLAYS.includes(display) ? display : 'symbol'
    });
    const parts = format.formatToParts(1);
    const at = parts.findIndex(part => part.type === 'currency');
    if (at === -1) return fallback;
    return {
      sign: parts[at].value,
      before: at < parts.findIndex(part => part.type === 'integer'),
      minor: format.resolvedOptions().maximumFractionDigits ?? 2
    };
  } catch {
    return fallback;
  }
}
/** -1, 0 or 1: two decimals (canonical strings or integers) compared by their digits, never as floats; null when either is not a decimal. */

function compareDecimal(a, b) {
  const left = readDecimal(a);
  const right = readDecimal(b);
  if (!left.ok || !right.ok || left.value === null || right.value === null) return null;
  const scale = Math.max(fractionDigits(left.value), fractionDigits(right.value));

  const units = value => {
    const negative = value.startsWith('-');
    const [whole, fraction = ''] = value.replace('-', '').split('.');
    const digits = BigInt(whole + fraction.padEnd(scale, '0'));
    return negative ? -digits : digits;
  };

  const x = units(left.value);
  const y = units(right.value);
  return x === y ? 0 : x < y ? -1 : 1;
}
/** A decimal as typed back into an input: the locale's point, no groups («1500,5» on a Russian page); '' for nothing or not a decimal. */

function editableDecimal(value, locale = 'en') {
  const read = readDecimal(value);
  if (!read.ok || read.value === null) return '';
  let point = '.';

  try {
    point = (0,_core_js_format_intl_js__WEBPACK_IMPORTED_MODULE_0__.intlFormatter)('NumberFormat', locale, {}).formatToParts(1.5).find(part => part.type === 'decimal')?.value || '.';
  } catch {
    point = '.';
  }

  return read.value.replace('.', point);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "01ae054f01b4"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cleanHtml: () => (/* binding */ cleanHtml),
/* harmony export */   htmlText: () => (/* binding */ htmlText)
/* harmony export */ });
/* harmony import */ var _input_rich_js_rich_text_html_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4f56033a1eae");
// Formatted text (property-view port 1.17.0, propertyType `html`; Larena,
// 2026-10-30): a value that is an HTML string of sf-input-rich's subset. The
// subset's rule is sf-input-rich's own module, not a second one written here:
// what the editor writes and what a record shows are cleaned by the same
// function, so the two cannot disagree about what a value may hold.
//
// A value is never drawn as it arrives. The host's value may have been stored
// by something other than this editor -- an import, an API, an older site --
// so the view draws only what `cleanHtml` returns, and a table cell draws only
// the text. Both take any value: a string, {value, text} as a host formats a
// scalar, or nothing.


const source = value => {
  const raw = value && typeof value === 'object' && !Array.isArray(value) && 'value' in value ? value.value : value;
  return typeof raw === 'string' ? raw : '';
};
/** The value in the subset: everything else removed, every text escaped; "" when there is no text. */


function cleanHtml(value) {
  const html = source(value);
  return html ? (0,_input_rich_js_rich_text_html_mjs__WEBPACK_IMPORTED_MODULE_0__.sanitizeRichText)(html, {
    mode: 'value'
  }) : '';
}
/** The value's visible text on one line, for a table cell: blocks and line breaks become spaces. */

function htmlText(value) {
  const html = source(value);
  return html ? (0,_input_rich_js_rich_text_html_mjs__WEBPACK_IMPORTED_MODULE_0__.plainText)(html).replace(/\s+/gu, ' ').trim() : '';
}

/***/ },

/***/ "e5483002f3ea"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DATE_FUTURE_PERIODS: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_FUTURE_PERIODS),
/* harmony export */   DATE_PERIODS: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_PERIODS),
/* harmony export */   FILTER_RENDERERS: () => (/* binding */ FILTER_RENDERERS),
/* harmony export */   NUMBER_FILTER_OPERATORS: () => (/* binding */ NUMBER_FILTER_OPERATORS),
/* harmony export */   PROPERTY_TYPES: () => (/* reexport safe */ _registry_js__WEBPACK_IMPORTED_MODULE_5__.PROPERTY_TYPES),
/* harmony export */   buildFilterRequest: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.buildFilterRequest),
/* harmony export */   dateFilterChipText: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateFilterChipText),
/* harmony export */   dateFilterConditions: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateFilterConditions),
/* harmony export */   dateTimeAttribute: () => (/* binding */ dateTimeAttribute),
/* harmony export */   filterRequestContext: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.filterRequestContext),
/* harmony export */   isEmptyFilterEntry: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.isEmptyFilterEntry),
/* harmony export */   isNumericType: () => (/* binding */ isNumericType),
/* harmony export */   normalizeFilterEntry: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.normalizeFilterEntry),
/* harmony export */   propertyModes: () => (/* binding */ propertyModes),
/* harmony export */   renderCellField: () => (/* binding */ renderCellField),
/* harmony export */   renderEditField: () => (/* binding */ renderEditField),
/* harmony export */   renderFilterField: () => (/* binding */ renderFilterField),
/* harmony export */   renderTotalField: () => (/* binding */ renderTotalField),
/* harmony export */   renderViewField: () => (/* binding */ renderViewField),
/* harmony export */   resolveDatePeriod: () => (/* reexport safe */ _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.resolveDatePeriod)
/* harmony export */ });
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2a080a730149");
/* harmony import */ var lit_directives_unsafe_html_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("073f05ff1a81");
/* harmony import */ var _helpers_option_badge_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("b30ec5bc0edb");
/* harmony import */ var _core_js_page_language__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("43090d1c8307");
/* harmony import */ var _core_js_format_date_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("e577837dd70a");
/* harmony import */ var _registry_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("fc654eb7fab0");
/* harmony import */ var _datetime_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("9ce1a42b2a85");
/* harmony import */ var _mask_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("dd6973f77245");
/* harmony import */ var _html_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("01ae054f01b4");
/* harmony import */ var _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("d3818183b14c");
/* harmony import */ var _decimal_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("ab3947ea3647");
/* harmony import */ var _phone_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("25be1c2df717");
/* harmony import */ var _lang_index_mjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("354525e80715");
/* harmony import */ var _date_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("c11c730f061a");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lit__WEBPACK_IMPORTED_MODULE_0__, lit_directives_unsafe_html_js__WEBPACK_IMPORTED_MODULE_1__, _core_js_page_language__WEBPACK_IMPORTED_MODULE_3__, _core_js_format_date_js__WEBPACK_IMPORTED_MODULE_4__, _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_9__, _decimal_js__WEBPACK_IMPORTED_MODULE_10__, _date_filter_js__WEBPACK_IMPORTED_MODULE_13__]);
([lit__WEBPACK_IMPORTED_MODULE_0__, lit_directives_unsafe_html_js__WEBPACK_IMPORTED_MODULE_1__, _core_js_page_language__WEBPACK_IMPORTED_MODULE_3__, _core_js_format_date_js__WEBPACK_IMPORTED_MODULE_4__, _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_9__, _decimal_js__WEBPACK_IMPORTED_MODULE_10__, _date_filter_js__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lit_directives_unsafe_html_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lit_directives_unsafe_html_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_page_language__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_9__);











 // The set's words and the property types' names live in its language files
// (localization study LC-5), as a Smart component keeps them.


 // The Framework's field renderers, addressed by a property type and a template
// rather than by a control name.
//
// Larena asked for one set of renderers shared by the record view and the
// table's cells (their request of 2026-10-05, part B6). The Framework already
// had type-aware rendering in exactly one place -- the table's filter controls
// -- and a second map would have drifted from it, so this module is that map
// with the filter controls moved into it unchanged. The table now asks the set
// instead of answering itself.
//
// The renderers take a host rather than `this`: a small interface the caller
// implements, so the same function serves a table's filter window, a record
// view and anything else that renders a field.
//
//   getFilterControlValue(key)            the value a control shows
//   patchTempFilterValue(key, patch)      the value a control writes
//   getFilterOperatorLabel(operator)      the word for an operator
//   getFilterOptionSearch(key)            what is typed in an option search
//   patchTempFilterOptionSearch(key, s)   what that search writes
//   getVisibleFilterOptions(field)        the options to draw
//   renderFilterOption(field, option)     one option row
//   getEndpointFilterPage(field)          the page of options a host returned
//   loadEndpointFilterPage(field, cursor, search)   ask the host for a page
//
// Every prop below names the axis it answers -- appearance, status, kind -- and
// never `type`, which contracts/public-api-axes.json retires. The names were
// read from each component's description rather than from the property's name:
// `size` on sf-file-preview is the file's size as text, not a rung of the
// ladder, and `type` on sf-list-item answers `kind` while on sf-input it
// answers `appearance`.
// The filter controls take the size of the list they filter: the table's
// size, when it has one. They were written at 1, so a table at the dense
// step 1/2 opened filter fields, buttons and tabs a step larger than itself.

function filterSize(host) {
  const size = String(host?.size || '').trim();
  return size || '1';
}

function renderTextFilterControl(field, host) {
  const value = host.getFilterControlValue(field.key);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input
                size=${filterSize(host)}
                appearance="filled"
                placeholder="${setText(host, 'containsText')}"
                value="${value.value || ''}"
                name="sf_filter_${field.key || 'text'}"
                @change=${event => {
    host.patchTempFilterValue(field.key, {
      value: event.target?.value || '',
      operator: value.operator || field.filter?.defaultOperator || 'contains'
    });
  }}
        ></sf-input>
    `;
}

function renderRangeFilterControl(field, host) {
  const control = host.getFilterControlValue(field.key);
  const operators = field.filter?.operators || ['eq'];
  const selectedOperator = control.operator || field.filter?.defaultOperator || operators[0];
  const isBetween = selectedOperator === 'between';
  const rangeValue = isBetween ? control.value : Array.isArray(control.value) ? control.value[0] : control.value;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="flex gap-1/3 flex-col">
            <div class="sf-filter-operator-range flex gap-1/3 items-cross-center">
                <sf-slider-range
                        id="smart-range-slider-single"
                        min="0"
                        label="tooltip"
                        suffix="%"
                        max="100"
                        multiple=${String(isBetween)}
                        .value=${rangeValue}
                        @onSliderEnd=${e => {
    host.patchTempFilterValue(field.key, {
      value: isBetween ? e.detail.values || [] : e.detail.value,
      operator: selectedOperator
    });
  }}
                ></sf-slider-range>
            </div>
            <sf-dropdown
                    size=${filterSize(host)}
                    appearance="bordered"
                    mode="select"
                    placeholder="${setText(host, 'operator')}"
                    root-class="flex-1"
                    search="false"
                    @change=${event => {
    const operator = event.detail?.values?.[0] || event.detail?.value || selectedOperator;
    host.patchTempFilterValue(field.key, {
      operator
    });
  }}
            >
                ${operators.map(operator => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-list-item
                            kind="text"
                            size=${filterSize(host)}
                            text="${host.getFilterOperatorLabel(operator)}"
                            value="${operator}"
                            ?selected=${operator === selectedOperator}
                    ></sf-list-item>
                `)}
            </sf-dropdown>
        </div>
    `;
} // The number filter (owner decision C294, MP-6, MP-7; the same order as the
// date filter): the condition comes first and under it exactly what it needs
// -- one number, two («Между», both ends included) or nothing («Пусто», «Не
// пусто», whose value is true). The nine conditions are the ones AG Grid, MUI
// X and spreadsheets agree on; a field's `filter.operators` may name fewer.
// The value is typed with the decimal keyboard and the sign in the field (a
// fixed currency's sign where the language writes it, «%» after a percent),
// pasted text is read as a person means it («1 234,50 ₽», «$1,234.50») and
// the request carries a decimal string, never the typed text. A money field
// whose currency lives in the value adds a currency choice (q-mp-mix): the
// request carries `currency` and compares amounts within it. A new condition
// of another shape drops the old value.


const NUMBER_FILTER_OPERATORS = Object.freeze(['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'between', 'empty', 'not-empty']);
const NUMBER_NO_VALUE_OPERATORS = new Set(['empty', 'not-empty']);

const operatorShape = operator => NUMBER_NO_VALUE_OPERATORS.has(operator) ? 'none' : operator === 'between' ? 'two' : 'one';

function numberOperatorLabel(host, operator) {
  return NUMBER_FILTER_OPERATORS.includes(operator) ? setText(host, `numberOperator_${operator}`) : host.getFilterOperatorLabel(operator);
}

function renderNumberFilterControl(field, host, look = {}) {
  const control = host.getFilterControlValue(field.key) || {};
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);
  const operators = field.filter?.operators || NUMBER_FILTER_OPERATORS;
  const selectedOperator = control.operator || field.filter?.defaultOperator || operators[0];
  const shape = operatorShape(selectedOperator);
  const rawValue = control.value;
  const rangeValue = Array.isArray(rawValue) ? rawValue : [rawValue ?? '', ''];
  const currencies = look.currencies || null;
  const currency = currencies ? currencies.includes(control.currency) ? control.currency : currencies[0] : look.currency || null;
  const sign = look.money && currency ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(currency, locale, (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyDisplayOf)(field)) : null;
  const textStart = sign?.before ? sign.sign : '';
  const textEnd = look.percent ? '%' : sign && !sign.before ? sign.sign : '';
  const minDigits = look.money && currency ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(currency, locale).minor : 0;

  const shown = value => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.restingDecimal)(value, locale, value === '' || value === null || value === undefined ? 0 : minDigits);

  const withCurrency = patch => currencies ? { ...patch,
    currency
  } : patch;

  const patch = next => host.patchTempFilterValue(field.key, withCurrency({
    operator: selectedOperator,
    ...next
  }));

  const typed = (index, event) => {
    const input = event.currentTarget ?? event.target;
    const text = String(input?.value ?? '');
    const read = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(text, {
      locale,
      currency
    });

    if (input) {
      input.toggleAttribute('invalid', !read.ok);
      if (read.ok) input.removeAttribute('error-message');else input.setAttribute('error-message', setText(host, 'notNumber'));
    }

    if (!read.ok) return;
    const value = read.value ?? '';

    if (shape !== 'two') {
      patch({
        value
      });
      return;
    }

    const next = [...rangeValue];
    next[index] = value;
    patch({
      value: next
    });
  };

  const input = (index, label, value) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input
                size=${filterSize(host)}
                appearance="bordered"
                root-class="flex-1 min-w-0"
                label=${label}
                value=${shown(value)}
                inputmode=${look.integer ? 'numeric' : 'decimal'}
                text-start=${textStart || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                text-end=${textEnd || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                name="sf_filter_${field.key || 'number'}${index ? '_second' : ''}"
                @change=${event => typed(index, event)}
        ></sf-input>`;

  const valueWord = setText(host, look.money ? 'filterAmount' : look.percent ? 'filterPercent' : 'filterNumber');
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="flex gap-1/3 flex-col">
            <sf-dropdown
                    size=${filterSize(host)}
                    appearance="bordered"
                    mode="select"
                    label=${setText(host, 'condition')}
                    placeholder=${setText(host, 'condition')}
                    root-class="flex-1"
                    search="false"
                    data-sf-filter-part="operator"
                    @change=${event => {
    if (event.target !== event.currentTarget) return;
    const operator = event.detail?.values?.[0] || event.detail?.value || selectedOperator;
    if (operator === selectedOperator) return;
    const next = operatorShape(operator); // A new condition of another shape drops the old value:
    // one amount and two amounts are not the same question.

    const value = next === 'none' ? true : next === shape ? rawValue : next === 'two' ? ['', ''] : '';
    host.patchTempFilterValue(field.key, withCurrency({
      operator,
      value
    }));
  }}
            >
                ${operators.map(operator => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-list-item
                            kind="text"
                            size=${filterSize(host)}
                            text="${numberOperatorLabel(host, operator)}"
                            value="${operator}"
                            ?selected=${operator === selectedOperator}
                    ></sf-list-item>
                `)}
            </sf-dropdown>
            ${shape === 'none' ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : shape === 'two' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <div class="sf-filter-operator-inputs flex gap-1/3 items-cross-start">
                    ${input(0, setText(host, 'rangeFrom'), rangeValue[0])}
                    ${input(1, setText(host, 'rangeTo'), rangeValue[1])}
                </div>` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <div class="sf-filter-operator-inputs flex gap-1/3 items-cross-start">
                    ${input(0, valueWord, Array.isArray(rawValue) ? rawValue[0] : rawValue)}
                </div>`}
            ${currencies && shape !== 'none' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <sf-dropdown
                        size=${filterSize(host)}
                        appearance="bordered"
                        mode="select"
                        label=${setText(host, 'currency')}
                        root-class="flex-1"
                        search=${currencies.length > 12 ? 'true' : 'false'}
                        data-sf-filter-part="currency"
                        .options=${currencies.map(code => ({
    type: 'text',
    size: filterSize(host),
    value: code,
    text: code,
    selected: code === currency
  }))}
                        @change=${event => {
    if (event.target !== event.currentTarget) return;
    const code = event.detail?.values?.[0] || event.detail?.value;
    if (!code || code === currency) return;
    host.patchTempFilterValue(field.key, {
      operator: selectedOperator,
      value: rawValue,
      currency: code
    });
  }}
                ></sf-dropdown>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        </div>
    `;
}

function renderIntegerFilterControl(field, host) {
  return renderNumberFilterControl(field, host, {
    integer: true
  });
} // Money and percent are filtered as numbers with their own sign in the field
// (owner decisions C291 (2), C294): «%» after a percent, a fixed currency's
// sign where the locale writes it. A money field whose currency lives in the
// value chooses the currency in the filter, from the field's `currencies`.


function renderMoneyFilterControl(field, host) {
  const fixed = fixedCurrency(field);
  return renderNumberFilterControl(field, host, {
    money: true,
    currency: fixed,
    currencies: fixed ? null : fieldCurrencies(field)
  });
}

function renderPercentFilterControl(field, host) {
  return renderNumberFilterControl(field, host, {
    percent: true
  });
} // The date filter (owner decision C293, 2026-11-17; it replaces the operator
// words and quick ranges of PD-6/PD-7). A condition first, then exactly what it
// needs: nothing (a period by name, «Пусто», «Не пусто»), one day, two days (a
// range calendar whose quick ranges are the whole periods; pressing one makes
// the condition that period by name), a number of days, or -- for a period
// field -- «when»: a period by name or two days of one's own. The list is
// grouped: Дата, Период, Заполнено (a period field: Период записи,
// Заполнено). Choosing a condition writes its own starting value, so a stale
// day never travels with a period (DF-2); a period, «Пусто» and «Не пусто»
// carry a value of their own, so the table keeps them (DF-1). The rules and
// the words are date-filter.js; this draws them. The day controls keep PD-4,
// PD-5 and PD-8: the table's size, the page's language, the condition above.


function dateFilterPresets(field) {
  const presets = field.filter?.presets;

  if (presets === undefined || presets === null) {
    return [..._date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_PERIODS, ...(field.filter?.future === true ? _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_FUTURE_PERIODS : [])].join(',');
  }

  return Array.isArray(presets) ? presets : String(presets);
}

function defaultDateCondition(field, list) {
  const asked = field.filter?.defaultOperator;

  if (asked) {
    const one = (0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateConditionOf)(field, {
      operator: asked,
      value: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.LEGACY_DATE_OPERATORS[asked] || asked
    });
    const named = list.find(item => item.key === asked);
    if (named || one) return named || one;
  } // One date: «Между» (the list's second, after the exact day); a period
  // field: «Идёт в».


  return list.find(item => item.operator === ((0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateFilterKind)(field) === 'period' ? 'overlaps' : 'between')) ?? list[0];
}

function dateFilterContext(host) {
  return (0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.filterRequestContext)(host ?? null, host?.getFilterContext?.() || {});
}

function renderDateFilterControl(field, host) {
  const control = host.getFilterControlValue(field.key) || {};
  const list = (0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateFilterConditions)(field);
  const asked = control.operator ? (0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateConditionOf)(field, control) : null;
  const current = asked ?? defaultDateCondition(field, list);
  const value = asked ? (0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.normalizeFilterEntry)(control).value : control.value;
  const size = filterSize(host);

  const patch = next => host.patchTempFilterValue(field.key, next);

  const isDateTime = (field.propertyType || field.type) === 'datetime';
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="flex flex-col gap-1/3">
            <sf-dropdown
                    size=${size}
                    appearance="bordered"
                    mode="select"
                    label="${setText(host, 'dateCondition')}"
                    .value=${current.key}
                    hint=${isDateTime ? setWord(host, 'dateByDayIn', {
    zone: dateFilterContext(host).timeZone
  }) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    root-class="flex-1"
                    search="false"
                    @change=${event => {
    const key = event.detail?.values?.[0] || event.detail?.value || current.key;
    const next = list.find(item => item.key === key); // The condition shown before any is chosen is the default;
    // choosing it writes it, with its own starting value.

    if (!next || asked && next.key === current.key) return;
    patch({
      operator: next.operator,
      value: (0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateConditionValue)(next, {
        value
      })
    });
  }}
            >
                ${list.map(item => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-list-item
                            kind="text"
                            size=${size}
                            group=${(0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateGroupLabel)(host, item.group)}
                            text="${(0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateConditionLabel)(host, item)}"
                            value="${item.key}"
                            ?selected=${item.key === current.key}
                    ></sf-list-item>
                `)}
            </sf-dropdown>
            ${renderDateConditionValue(field, host, current, value, patch)}
        </div>
    `;
}

function renderDateConditionValue(field, host, current, value, patch) {
  const size = filterSize(host);
  const name = `sf_filter_${field.key || 'date'}`;
  if (current.need === 'none') return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;

  if (current.need === 'count') {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <sf-input-quantity
                    size=${size}
                    label="${setText(host, current.operator === 'next-days' ? 'dateCountNext' : 'dateCountLast')}"
                    min="1"
                    max="366"
                    unit="${setText(host, 'dateCountUnit')}"
                    name="${name}_count"
                    .value=${Number(value) > 0 ? Number(value) : 30}
                    @change=${event => {
      if (event.target !== event.currentTarget) return;
      const count = Math.round(Number(event.detail?.value));
      patch({
        operator: current.operator,
        value: count > 0 ? count : null
      });
    }}
            ></sf-input-quantity>`;
  }

  if (current.need === 'day') {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <sf-input-date
                    size=${size}
                    label="${setText(host, current.operator === 'contains' ? 'dateValueDay' : 'dateValueDate')}"
                    .value=${typeof value === 'string' ? value.slice(0, 10) : ''}
                    name="${name}"
                    @change=${event => {
      if (event.target !== event.currentTarget) return;
      patch({
        operator: current.operator,
        value: event.detail?.value || null
      });
    }}
            ></sf-input-date>`;
  }

  if (current.need === 'days') return renderDateRangeValue(field, host, current, value, patch); // «when» (a period field): a period by name, or two days of one's own.

  const own = Array.isArray(value);
  const periods = [..._date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_PERIODS, ...(field.filter?.future === true ? _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_FUTURE_PERIODS : [])];
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-dropdown
                size=${size}
                appearance="bordered"
                mode="select"
                label="${setText(host, 'dateWhen')}"
                .value=${own ? 'own' : typeof value === 'string' ? value : ''}
                root-class="flex-1"
                search="false"
                @change=${event => {
    const key = event.detail?.values?.[0] || event.detail?.value;
    if (!key) return;

    if (key === 'own') {
      if (!own) patch({
        operator: current.operator,
        value: ['', '']
      });
      return;
    }

    if (key !== value) patch({
      operator: current.operator,
      value: key
    });
  }}
        >
            ${periods.map(period => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <sf-list-item kind="text" size=${size} text="${(0,_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateConditionLabel)(host, {
    period
  })}" value="${period}"
                        ?selected=${!own && value === period}></sf-list-item>
            `)}
            <sf-list-item kind="text" size=${size} text="${setText(host, 'dateOwnDays')}" value="own" ?selected=${own}></sf-list-item>
        </sf-dropdown>
        ${own ? renderDateRangeValue(field, host, current, value, patch) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}`;
} // Two days on a range calendar. Its quick ranges are the whole periods: one
// pressed is the period by name -- in «Между» the condition becomes that
// period (C293 (4)), in a period field's «when» the value is its name.


function renderDateRangeValue(field, host, current, value, patch) {
  const days = Array.isArray(value) ? value.map(day => typeof day === 'string' ? day.slice(0, 10) : '') : ['', ''];
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-date
                size=${filterSize(host)}
                range
                label="${setText(host, 'dateValuePeriod')}"
                .value=${days}
                .presets=${dateFilterPresets(field)}
                name="sf_filter_${field.key || 'date'}"
                @change=${event => {
    if (event.target !== event.currentTarget) return;
    const preset = event.detail?.preset?.id;

    if (preset && (_date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_PERIODS.includes(preset) || _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_FUTURE_PERIODS.includes(preset))) {
      patch(current.operator === 'between' ? {
        operator: 'period',
        value: preset
      } : {
        operator: current.operator,
        value: preset
      });
      return;
    }

    const next = Array.isArray(event.detail?.value) ? event.detail.value : [event.detail?.startValue || '', event.detail?.endValue || ''];
    patch({
      operator: current.operator,
      value: next
    });
  }}
        ></sf-input-date>`;
}

function renderMultiSelectFilterControl(field, host) {
  const endpointPage = host.getEndpointFilterPage(field);
  const options = host.getVisibleFilterOptions(field);
  const value = host.getFilterControlValue(field.key);
  const search = host.getFilterOptionSearch(field.key);
  const selected = new Set(value.values || []); // A list of options scrolls down, never sideways: a checkbox's ring a pixel
  // or two past the edge drew a horizontal bar under the list (owner,
  // 2026-10-15).

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="flex flex-col gap-1/2 overflow-x-hidden">
            ${field.filter?.searchable && (!endpointPage || endpointPage.searchable) ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <sf-input
                        size=${filterSize(host)}
                        appearance="filled"
                        placeholder="${setText(host, 'searchInList')}"
                        value="${search}"
                        name="sf_filter_${field.key || 'list'}_search"
                        @input=${event => {
    host.patchTempFilterOptionSearch(field.key, event.target?.value || '');
  }}
                        @change=${event => {
    host.patchTempFilterOptionSearch(field.key, event.target?.value || '');
  }}
                ></sf-input>
            ` : ''}
            <div class="flex flex-col gap-1/2 overflow-x-hidden" data-size="4.5">
                ${options.map(option => host.renderFilterOption(field, option, selected))}
            </div>
            ${!options.length && endpointPage?.status !== 'loading' && endpointPage?.status !== 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <!-- A list with nothing in it says why, in one line, as every
                     list does (simai.interaction-rules, five states). -->
                <sf-empty-state layout="inline" size="1/2" kind=${search ? 'nothing-found' : 'no-data'}></sf-empty-state>` : ''}
            ${endpointPage ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <div role="status" aria-live="polite" class="sf-text-1">
                    ${endpointPage.status === 'loading' ? setText(host, 'loadingOptions') : ''}
                </div>
                ${endpointPage.status === 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-empty-state layout="inline" size="1/2" kind="error" text=${setText(host, 'optionsError')}
                    @sf-empty-state-action=${event => {
    if (event.detail?.id === 'retry') host.loadEndpointFilterPage(field, null, search);
  }}></sf-empty-state>` : ''}
                ${endpointPage.nextCursor && endpointPage.status !== 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-button appearance="outline" size=${filterSize(host)} text="${setText(host, 'loadMore')}"
                    ?disabled=${endpointPage.status === 'loading'}
                    @click=${() => host.loadEndpointFilterPage(field, endpointPage.nextCursor, search)}></sf-button>` : ''}
            ` : ''}
        </div>
    `;
}

function renderEntityMultiSelectFilterControl(field, host) {
  // The host travels with the call. It was lost here when these functions were
  // moved out of the table: as a method, `this.renderMultiSelectFilterControl(field)`
  // carried the receiver by itself, and as a function it has to be handed on.
  // The source suite renders no entity control, so nothing in it noticed; the
  // filter-endpoint probe did, with "Cannot read properties of undefined".
  return renderMultiSelectFilterControl(field, host);
} // The filter template, addressed by the property type. The nine control names
// the table used are kept as aliases of the types they serve, so a host that
// declares a control by name keeps working while a host that declares a
// property type gets the same renderer.
// A file is filtered by its kind, a colour by the field's palette (owner,
// 2026-10-15): both fell back to a text search. The filter's values are the
// kinds -- image, document, archive, other -- or the colours, with the
// operator «in»; what a kind holds is the host's to say.


function renderFileFilterControl(field, host) {
  const options = field.filter?.options ?? ['image', 'document', 'archive', 'other'].map(kind => ({
    value: kind,
    label: setText(host, `fileKind_${kind}`)
  }));
  return renderMultiSelectFilterControl({ ...field,
    filter: { ...(field.filter || {}),
      options,
      defaultOperator: field.filter?.defaultOperator ?? 'in'
    }
  }, host);
}

function renderColorFilterControl(field, host) {
  const palette = field.filter?.options ?? (Array.isArray(field.swatches) ? field.swatches : []).map(swatch => typeof swatch === 'string' ? {
    value: swatch,
    label: swatch
  } : swatch).filter(swatch => swatch?.value).map(swatch => ({
    value: swatch.value,
    label: swatch.label ?? swatch.value,
    color: swatch.value
  })); // No palette, nothing to choose from: the value is searched as text.

  if (!palette.length) return renderTextFilterControl(field, host);
  return renderMultiSelectFilterControl({ ...field,
    filter: { ...(field.filter || {}),
      options: palette,
      optionRenderer: field.filter?.optionRenderer ?? 'swatch',
      defaultOperator: field.filter?.defaultOperator ?? 'in'
    }
  }, host);
}

const FILTER_RENDERERS = {
  text: renderTextFilterControl,
  string: renderTextFilterControl,
  number: renderNumberFilterControl,
  integer: renderIntegerFilterControl,
  date: renderDateFilterControl,
  datetime: renderDateFilterControl,
  range: renderRangeFilterControl,
  'date-range': renderDateFilterControl,
  // A period field (a start and an end, C293): its own conditions -- overlaps,
  // within, starts, ends, contains a day.
  period: renderDateFilterControl,
  'multi-select': renderMultiSelectFilterControl,
  'single-select': renderMultiSelectFilterControl,
  choice: renderMultiSelectFilterControl,
  choices: renderMultiSelectFilterControl,
  boolean: renderMultiSelectFilterControl,
  user: renderMultiSelectFilterControl,
  'entity-multi-select': renderEntityMultiSelectFilterControl,
  'entity-single-select': renderEntityMultiSelectFilterControl,
  record: renderEntityMultiSelectFilterControl,
  relation: renderEntityMultiSelectFilterControl,
  lookup: renderEntityMultiSelectFilterControl,
  file: renderFileFilterControl,
  color: renderColorFilterControl,
  // A money amount and a percent are filtered as decimals with their sign
  // (C291 (2)); an items field, which the View set draws, by its number of
  // rows (property-view port 1.18.0).
  money: renderMoneyFilterControl,
  percent: renderPercentFilterControl,
  items: renderIntegerFilterControl
}; // What a field asks to be filtered by: its own declared control if it has one,
// otherwise its property type, otherwise text.
// The date filter's rules for a host that builds the request or draws the
// chips itself (sf-view-table): the same functions as SF.fieldRenderers.dateFilter.


function renderFilterField(field = {}, host) {
  const asked = field.filter?.control || field.propertyType || field.type || field.dataType || 'text';
  const renderer = FILTER_RENDERERS[asked] || FILTER_RENDERERS.text;
  return renderer(field, host);
} // The cell template. A cell is text unless the Framework has a component that
// says more than the text would, and the set renders one only when it can state
// the shape the value must have. Anything else falls back to the value itself,
// so a host that stores a plain string keeps seeing a plain string.
//
// The value shapes are the consumer's, agreed with Larena on 2026-10-06: a
// renderer cannot turn an opaque reference into a name, and resolving one needs
// an access check, so the host sends what it has resolved.
//
//   choice              a value matching one of the column's options
//   integer / number    a number, and with the `scale` variant a number 0..100
//   boolean             true or false
//   user                {value, label, avatarText}
//   record / relation   {value, label, href?} -- href only when it may be opened
//   lookup              {value, label}, or a list of them when multiple; the
//                       labels on one line
//   file                {value, label, mime?, href?} -- an icon from the mime
//                       type and the label, a link when it may be opened
//   choices             a list of option values; one tag per value on the line
//   html                an HTML string of sf-input-rich's subset; its text, on one line
//
// Every element here takes `line`, not `size`: a line element is the row's text
// line, where a control height would make the row grow. That was measured --
// with size-1/2 components a default row went from 57 to 61 on desktop and 45 to
// 51 on mobile.

const CELL_LINE = '1/2'; // A choice badge in a cell is tonal (sf-badge's default since 1.6.0, C140; it
// was main, so the cells shipped filled and the consumer's owner asked for the
// calmer one) -- and a table row is the place for it: a column of
// filled badges reads as a column of buttons. A field may still ask for another
// of the three, which is the same arrangement as the boolean's words: the set
// carries a sensible default, not a decision nobody can change.
//
// It composes with colour rather than replacing it. A scheme name reaches the
// scheme's tonal badge; a hue or a hex colour writes the public
// --sf-badge-background-color as the nearest palette hue's fill step (BG-7,
// C140 (2)) and its own text colour, so the tint survives the appearance
// untouched. Both are measured on the built bytes.

const CELL_BADGE_APPEARANCE = 'tonal'; // A file cell is a reference link with an icon chosen from the mime type: the
// consumer asked for an icon and the label and nothing else -- no size as text
// and no download button, which the record view will carry -- and the component
// that owns that shape already exists. sf-file-preview detects only image/*, so
// this small map lives here until a second caller needs it, which is the session
// that owns that component's own judgement.

const FILE_ICONS = [[/^image\//u, 'image'], [/^video\//u, 'movie'], [/^audio\//u, 'audiotrack'], [/^text\/(csv|tab-separated-values)$/u, 'table'], [/^text\//u, 'description'], [/pdf$/u, 'picture_as_pdf'], [/(zip|compressed|tar|rar|7z)/u, 'folder_zip'], [/(sheet|excel|spreadsheet)/u, 'table'], [/(word|document)$/u, 'description'], [/(presentation|powerpoint)/u, 'slideshow']];

function fileIcon(mime) {
  const value = String(mime || '').toLowerCase();
  const match = FILE_ICONS.find(([pattern]) => pattern.test(value));
  return match ? match[1] : 'attach_file';
} // A colour has the same four faces as every other property. It was absent while a
// running Larena site declares fourteen colours, so a theme colour had nowhere to
// be shown and nowhere to be changed.
//
// `inheritedValue` matters here as much as the value: the site's own colours are
// inherited from the theme until somebody chooses one, and a cell that drew the
// inherited colour as the value would say a record had decided something it had
// not.


function renderColorCell(field, value) {
  const hex = scalarValue(value);
  if (!hex) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing; // The component, not a span with classes of its own: the renderer set has no
  // stylesheet, so markup invented here would reach no rules at all -- and a
  // colour should look the same in a cell as it does in a card, which is what a
  // general part is for.

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-color size="1/2" appearance="plain" value=${String(hex)}
                  aria-label=${field.label || field.key || ''} readonly></sf-input-color>
    `;
} // Reads what port 1.8.0 declares: `inherited` says a value comes from somewhere
// else, `inheritedValue` says what it is. A view that drew the inherited colour as
// the value would make «not set» and «set to the same colour» look identical, and
// only the first follows the theme when the theme moves. The view and the cell
// draw the field read-only (sf-input-color 1.17.0): the value in the text's ink;
// disabled drew it in the disabled ink, as a field nobody may use.


function renderColorView(field, value) {
  const hex = scalarValue(value);
  const inherited = field.inheritedValue ?? '';
  if (!hex && !inherited) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-color
                size="1"
                appearance="plain"
                value=${hex ? String(hex) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                inherited-value=${inherited ? String(inherited) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                readonly
        ></sf-input-color>
    `;
}

function renderColorEdit(field, value, host) {
  const hex = scalarValue(value);
  const inherited = field.inheritedValue ?? '';
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-color
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${hex ? String(hex) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                inherited-value=${inherited ? String(inherited) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                swatches=${field.swatches ? String(field.swatches) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ?clearable=${Boolean(inherited) || field.required !== true}
                ?readonly=${field.readonly === true}
                aria-label=${field.label || field.key || ''}
                @change=${event => host.setFieldValue(field, event.detail?.value ?? '')}
        ></sf-input-color>
    `;
}

function renderFileCell(field, value) {
  if (!value || typeof value !== 'object' || !value.label) return null; // A column the host says holds images shows each as a thumbnail; any other
  // file as a tile with its extension. Which files are images is the host's
  // to say through the variant, never guessed from a name.

  if (isImageField(field)) return renderFilePreviewCell(value);
  return {
    component: {
      type: 'reference-link',
      props: {
        line: CELL_LINE,
        label: String(value.label),
        icon: fileIcon(value.mime),
        ...(value.href ? {
          href: String(value.href)
        } : {})
      }
    }
  };
} // A file as a thumbnail on the row's line: the image when the host gave its
// address and its type is an image, the extension in a tile otherwise. It is
// sf-file-preview told to show nothing but its leading visual, so a file looks
// the same in a row as in the record that holds it.


function renderFilePreviewCell(value) {
  const mime = String(value.mime ?? value.mimeType ?? '');
  const image = Boolean(value.href) && /^image\//u.test(mime);
  return {
    component: {
      type: 'file-preview',
      props: {
        compact: true,
        fileName: String(value.label),
        mimeType: mime,
        icon: fileIcon(mime),
        ...(value.href ? {
          href: String(value.href)
        } : {}),
        ...(image ? {
          imageUrl: String(value.href),
          kind: 'image'
        } : {
          kind: 'icon'
        }),
        actions: false,
        downloadAction: false,
        removeAction: false
      }
    }
  };
} // Several values in one cell: one tag per value, each on the row's text line.
// The tag's `line` resolves its own size and inline mode, so neither is passed
// -- the session that owns it fixed the template to read the resolved values
// rather than the attributes, which is what makes that true.


function renderChoicesCell(field, value) {
  if (!Array.isArray(value) || !value.length) return null;
  if (String(field.variant ?? '') === 'badges') return renderChoicesBadgesCell(field, value);
  const options = field.options || field.filter?.options || field.constraints?.options;

  const label = item => {
    const option = Array.isArray(options) ? options.find(candidate => String(candidate?.value) === String(item)) : null;
    return String(option?.label ?? option?.text ?? item);
  };

  return value.map(item => ({
    component: {
      type: 'tag',
      props: {
        line: CELL_LINE,
        kind: 'default',
        text: label(item)
      }
    }
  }));
} // Several values as tonal badges, each coloured by its option's scheme -- a
// page's publication in each language. A value may be {value, text}: the host
// says more in that one cell than the option's label («ru · 14.10 09:00»), which
// is the host's to format, so the set does not.


function renderChoicesBadgesCell(field, value) {
  const options = field.options || field.filter?.options || field.constraints?.options;
  return value.map(item => {
    const key = item && typeof item === 'object' ? item.value : item;
    const option = Array.isArray(options) ? options.find(candidate => String(candidate?.value) === String(key)) : null;
    const badge = option ? (0,_helpers_option_badge_js__WEBPACK_IMPORTED_MODULE_2__.optionBadgeProps)(option) : null;
    const text = item && typeof item === 'object' && item.text !== undefined ? String(item.text) : String(option?.label ?? option?.text ?? key);
    return {
      component: {
        type: 'badge',
        props: {
          line: CELL_LINE,
          text,
          appearance: field.badgeAppearance ?? CELL_BADGE_APPEARANCE,
          ...(badge?.scheme ? {
            scheme: badge.scheme
          } : {}),
          ...(badge?.rootStyle ? {
            rootStyle: badge.rootStyle
          } : {})
        }
      }
    };
  });
}

const CELL_RENDERERS = {
  // A string is its own text in a row -- except a password, which is never
  // shown anywhere: a row says whether one is set.
  string: renderStringCell,
  // A date in a row used to be whatever the host had stored, printed --
  // «2026-09-25T07:12:00+03:00» beside the same value reading «25 сентября
  // 2026» in the record panel, with no way for a consumer to change the
  // first. These two ask the host and fall through to the stored value when
  // it has nothing to say.
  date: renderDateCell,
  datetime: renderDateCell,
  time: renderHostFormattedCell,
  boolean: renderBooleanCell,
  choices: renderChoicesCell,
  file: renderFileCell,
  color: renderColorCell,
  include: renderIncludeCell,
  choice: renderChoiceCell,
  integer: renderNumericCell,
  number: renderNumericCell,
  user: renderUserCell,
  record: renderReferenceCell,
  relation: renderReferenceCell,
  lookup: renderLookupCell,
  html: renderHtmlCell,
  money: renderMoneyCell,
  percent: renderPercentCell,
  items: renderItemsCell
}; // A consumer found this on their stand: the words were written into the set, so
// an English admin saw «Да». The set must not decide what a value is called in
// anyone's language. They come from the field, which is where the rest of the
// Framework keeps its text -- sf-view-table declares fourteen such inputs -- and the
// Russian stays only as the fallback, so nothing already published changes.
// The field's own words win, as they must: what «true» is called belongs to
// whoever owns the interface. The fallback used to be Russian whatever the page
// was -- an English admin saw «Да» -- so it follows the page's language now.

function booleanWords(field, host) {
  return {
    yes: field.trueText ?? field.labels?.true ?? setText(host, 'yes'),
    no: field.falseText ?? field.labels?.false ?? setText(host, 'no')
  };
}

function renderBooleanCell(field, value, host) {
  if (typeof value !== 'boolean') return null;
  const words = booleanWords(field, host);
  return value ? words.yes : words.no;
}

function renderChoiceCell(field, value) {
  const options = field.options || field.filter?.options || field.constraints?.options;
  if (!Array.isArray(options)) return null;
  const option = options.find(item => String(item?.value) === String(value));
  if (!option) return null;
  const badge = (0,_helpers_option_badge_js__WEBPACK_IMPORTED_MODULE_2__.optionBadgeProps)(option);
  return {
    component: {
      type: 'badge',
      props: {
        line: CELL_LINE,
        text: option.label ?? option.text ?? String(value),
        appearance: field.badgeAppearance ?? CELL_BADGE_APPEARANCE,
        ...(badge?.scheme ? {
          scheme: badge.scheme
        } : {}),
        ...(badge?.rootStyle ? {
          rootStyle: badge.rootStyle
        } : {})
      }
    }
  };
} // The scale is the `scale` variant of a number, and sf-progress-scale takes a
// value between 0 and 100 with no bounds of its own -- which is why the request
// asks for the variant on a field declaring exactly min 0 and max 100. A value
// outside that range is left as text rather than clamped: a clamped number is a
// wrong number drawn confidently.
// A cell the host has formatted. Null when it has not, so the value falls
// through to the plain one the table already prints: the set does not invent a
// format, and «798700» is a better answer than a thousands separator somebody
// did not ask for. What it does not do is leave a consumer no way to say
// «798 700 ₽» -- which was the state of a list until the host reached the cells.


function renderHostFormattedCell(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  return typeof formatted === 'string' && formatted !== '' ? formatted : null;
} // The types a component set draws (property-view port 1.18.0) have their
// cells here, so a table shows them wherever the set's editors live. A host's
// formatFieldValue wins, as for a date; otherwise the page's language:
//
//   money     {amount, currency} or a bare amount under a fixed `currency`;
//             «1 500,50 ₽», every digit the amount has and at least the
//             currency's minor units, formatted from the digits, never a float
//   percent   a decimal string of the percent, «12,5 %»
//   items     a list of rows; how many, «3 строки»
//
// A value that is not one of these shapes falls through to the plain value.


function renderMoneyCell(field, value, host) {
  const formatted = renderHostFormattedCell(field, value, host);
  if (formatted !== null) return formatted;
  const text = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatMoney)(scalarValue(value), field, (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null));
  return text || null;
}

function renderPercentCell(field, value, host) {
  const formatted = renderHostFormattedCell(field, value, host);
  if (formatted !== null) return formatted;
  const text = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatPercent)(scalarValue(value), (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null));
  return text || null;
}

function renderItemsCell(field, value, host) {
  const formatted = renderHostFormattedCell(field, value, host);
  if (formatted !== null) return formatted;
  if (!Array.isArray(value)) return null;
  return value.length ? (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageWord)(SET_TEXT, 'rowCount', host ?? null, {
    component: SET_NAME,
    count: value.length
  }) : '';
} // A date in a row reads as it does in the record panel: the host's text, else
// the page's reading of the day (simai/ui-source#34); null for a value that is
// not a date, which the table prints as it came.


function renderDateCell(field, value, host) {
  const formatted = renderHostFormattedCell(field, value, host);
  if (formatted !== null) return formatted;
  return defaultDateText(field, value, host);
} // A share of a limit (owner decision C203 (5), IM-8): the `meter` variant of a
// number 0..100 is the inline sf-progress-bar meter -- a 64 track, the number
// «72 %» before it -- named by the field's label. The scale stays for levels
// («4 из 5», C185 (5)). Out of range it is left as text, as the scale is.


function meterProps(field, number) {
  const name = typeof field.label === 'string' ? field.label : field.key || '';
  return {
    inline: true,
    meter: true,
    value: String(number),
    ...(name ? {
      label: name
    } : {})
  };
}

function renderNumericCell(field, value, host) {
  const variant = field.variant || field.filter?.variant;
  const number = Number(scalarValue(value));

  if (variant !== 'scale' && variant !== 'meter' || !Number.isFinite(number)) {
    // The host's text first; else the number in the page's language, as
    // the view prints it («12,5»), where the table printed «12.5».
    const formatted = renderHostFormattedCell(field, value, host);
    if (formatted !== null) return formatted;
    if (carriesText(value)) return value.text || null;
    return (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatDecimal)(scalarValue(value), (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null)) || null;
  }

  if (number < 0 || number > 100) return null;
  if (variant === 'meter') return {
    component: {
      type: 'progress-bar',
      props: meterProps(field, number)
    }
  };
  return {
    component: {
      type: 'progress-scale',
      props: {
        line: CELL_LINE,
        value: String(number)
      }
    }
  };
} // A reference in a cell is a link and nothing else: the arrow a reference card
// carries said «goes somewhere» a second time beside a label that is already a
// link, and on a dense row it was the widest thing in the cell. Without an href
// the label is plain text -- a link that leads nowhere is not drawn as one.


function referenceLink(value) {
  return {
    component: {
      type: 'reference-link',
      props: {
        line: CELL_LINE,
        appearance: 'plain',
        icon: '',
        label: String(value.label),
        ...(value.href ? {
          href: String(value.href)
        } : {})
      }
    }
  };
} // A person: the avatar and the name, the name a link to the profile when the
// host gives its href.


function renderUserCell(field, value) {
  if (!value || typeof value !== 'object' || !value.label) return null;
  return [// The person's name is the avatar's heading: its accessible name and
  // the source of its initials (sf-avatar 1.6.0; avatar study AV-2).
  {
    component: {
      type: 'avatar',
      props: {
        line: CELL_LINE,
        text: value.avatarText || '',
        heading: String(value.label)
      }
    }
  }, value.href ? referenceLink(value) : String(value.label)];
}

function renderReferenceCell(field, value) {
  if (!value || typeof value !== 'object' || !value.label) return null;
  return referenceLink(value);
} // A value from a reference list is its label, and several are their labels in
// a row: nothing opens from a country or a status, so there is no link to draw.


function renderLookupCell(field, value) {
  const items = lookupItems(field, value);
  return items.length ? items.map(item => item.label).join(', ') : null;
} // Formatted text in a row is its text, as a text cell is: the markup is for a
// record, and a row of headings and lists would not be a row. A string, so the
// table draws and cuts it exactly as it does any text value.


function renderHtmlCell(field, value) {
  return (0,_html_js__WEBPACK_IMPORTED_MODULE_8__.htmlText)(value) || null;
} // What a cell should hold for a field, in the same shape a host would pass: a
// string, an object with a component, or a list of those. Null means the value
// is better off as itself. Returning the host's own shape is deliberate -- the
// table renders it through the path it already had, so the set adds no second
// way to draw a cell.


function renderCellField(field = {}, value, host) {
  const asked = field.propertyType || field.type || field.dataType;
  const renderer = CELL_RENDERERS[asked];
  if (!renderer) return null; // `host` is for one thing, as in the view: formatFieldValue, where a
  // consumer's own formatting of a number or a date belongs. A cell had no way
  // to reach it, so a list could not be formatted at all while the record
  // panel beside it could.

  const rendered = renderer(field, value, host);
  return rendered === null || typeof rendered === 'undefined' ? null : rendered;
} // The edit template. A field being edited is a control of the form scale, not of
// a row: these take `size`, where the cell template takes `line`.
//
// The host supplies the value and takes the change, through two methods, because
// a renderer must not decide where a value lives:
//
//   getFieldValue(field)          what the control shows
//   setFieldValue(field, value)   what the control writes
//
// Every event bound here is `change`, and that is a rule now rather than a
// coincidence: contracts/public-api-axes.json `change_event` says every form
// value control reports a committed change as `change` on its host, once per
// change the user makes, with each older name kept as an alias the manifest
// marks `alias_of`. So the set binds the canonical name for all of them --
// sf-input, sf-textarea, sf-switch, sf-checkbox, sf-dropdown, sf-segmented and
// sf-datepicker -- where it bound three different alias names before. The one
// event this file still binds under its own name is sf-file-upload:select,
// which is not a value change but a selection; the `change` on that component
// is its inner input's.
// The size the controls are drawn at: 1, or 1/2 when the host asks for it
// with renderEditField(…, {size: '1/2'}) -- a record view beside a table at
// 1/2 read a step larger than it (owner, 2026-10-14). Set for the duration of
// one synchronous render.

let EDIT_SIZE = '1';
const EDIT_RENDERERS = {
  record: renderRecordLookup,
  relation: renderRecordLookup,
  user: renderRecordLookup,
  lookup: renderLookupEdit,
  string: renderTextEdit,
  text: renderTextAreaEdit,
  html: renderHtmlEdit,
  integer: renderNumberEdit,
  number: renderNumberEdit,
  date: renderDateEdit,
  datetime: renderDateTimeEdit,
  time: renderTimeEdit,
  boolean: renderBooleanEdit,
  choice: renderChoiceEdit,
  choices: renderChoicesEdit,
  file: renderFileEdit,
  color: renderColorEdit,
  include: renderIncludeEdit,
  money: renderMoneyEdit,
  percent: renderPercentEdit
};

function fieldName(field) {
  return `sf_field_${field.key || 'value'}`;
} // A telephone is a string with a shape, not a type of its own: the Framework
// already has a control that knows country codes, dial prefixes and masks, so a
// `string` whose variant is `phone` gets it and everything else about a string
// stays true. Counted on a running Larena site, which declares one.
//
// What it writes is E.164, `+79161234567` (FL-1): the control's own form value,
// whatever the box shows -- `+7 916 123-45-67` written back changed a stored
// number on every save. It reads E.164 and the formatted strings stored before.
//
// An extension (`;ext=12`) is not the control's to edit: the number goes to
// it alone and the extension is written back after it, so a save keeps it.
//
// The country an empty field starts on (FL-7): `defaultCountry` (ISO 3166
// alpha-2, "RU") where the field names one, else the page's (ru is Russia,
// en-GB Britain; sf-input-country's own rule). A stored number names its own
// country, so the setting is passed only while the field is empty.


function renderPhoneEdit(field, value, host) {
  const {
    number: stored,
    extension
  } = (0,_phone_js__WEBPACK_IMPORTED_MODULE_11__.splitPhone)(scalarValue(value) ?? '');
  const preferred = String(field.defaultCountry ?? '').trim().toUpperCase();
  const iso2 = /^[A-Z]{2}$/u.test(preferred) && !String(stored).trim() ? preferred : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-country
                size=${EDIT_SIZE}
                name=${fieldName(field)}
                value=${stored}
                iso2=${iso2}
                aria-label=${field.label || field.key || ''}
                ?required=${Boolean(field.required)}
                ?disabled=${field.readonly === true}
                use-mask="true"
                show-code="true"
                @change=${event => host.setFieldValue(field, phoneWritten(event, extension))}
        ></sf-input-country>
    `;
} // The control's form value (E.164; nothing for the dial code alone), or the
// box's text brought to E.164 where the element is not defined yet.


function phoneWritten(event, extension = '') {
  const control = event.currentTarget;
  const number = typeof control?.sfFormValue === 'function' ? control.sfFormValue() ?? '' : (0,_phone_js__WEBPACK_IMPORTED_MODULE_11__.phoneE164)(event.detail?.value ?? event.target?.value ?? '');
  return number && extension ? `${number};ext=${extension}` : number;
}

function isPhoneField(field) {
  return String(field.variant ?? '') === 'phone';
} // A phone shown: the host's text first (formatFieldValue, or {value, text}),
// as for any string; else the number
// laid out by its country, left to right on a right-to-left page too (an
// Arabic page drew the groups in reverse order).


function phoneText(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  if (typeof formatted === 'string') return formatted;
  if (carriesText(value)) return value.text;
  return (0,_phone_js__WEBPACK_IMPORTED_MODULE_11__.formatPhone)(scalarValue(value), setText(host, 'phoneExtension'));
} // A password is a string the set never shows (owner, 2026-10-19; Larena's
// storage settings). The host never sends one: the value of a `password`
// variant is {set: true} or {set: false}, and null or an absent value reads as
// not set. View, cell and a read-only field say «задан» or «не задан» in the
// page's language and nothing else. A host that sends a string by mistake gets
// «задан» for it, and the string is still not drawn.
//
// The edit control starts empty whatever is stored, and it writes only what a
// person types: an untouched field calls nothing, so a save carries no value for
// it and can neither clear nor echo a password. Typing and then erasing writes
// `undefined` -- the person took the change back, and a host drops the key.
// Clearing a set password is not offered: an empty field means «keep».
//
// The typed text lives in the input and nowhere else: no `value` attribute on
// sf-input, no data-*, no text node, no log. The eye that shows the password is
// sf-input's own (C123 (4): a glyph inside the field, the crossed eye after a
// press); the set drew a second one beside the field until the text inputs
// study (TI-7), so a record card showed two.


function isPasswordField(field) {
  return String(field.variant ?? '') === 'password';
}

function passwordIsSet(value) {
  if (value && typeof value === 'object' && !Array.isArray(value)) return value.set === true;
  return typeof value === 'string' && value !== '';
}

function passwordState(host, value) {
  return setText(host, passwordIsSet(value) ? 'passwordSet' : 'passwordUnset');
}

function renderPasswordEdit(field, value, host) {
  const set = passwordIsSet(value);
  const placeholder = field.placeholder || (set ? setText(host, 'passwordKeep') : '');

  const write = event => {
    const typed = event.target?.value ?? '';
    host.setFieldValue(field, typed === '' ? undefined : typed);
  }; // A set password is not required again: an empty field keeps it. Spellcheck
  // is off on the wrapper: the attribute is inherited, and sf-input does not
  // declare it (a shown password would otherwise be sent to a spellchecker).


  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <span class="sf-field-password flex items-cross-center gap-1/3 min-w-0" spellcheck="false">
            <sf-input
                    size=${EDIT_SIZE}
                    appearance="bordered"
                    root-class="flex-1 min-w-0"
                    input-type="password"
                    autocomplete="new-password"
                    name=${fieldName(field)}
                    placeholder=${placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    ?required=${Boolean(field.required) && !set}
                    aria-label=${field.label || field.key || ''}
                    @input=${write}
                    @change=${write}
            ></sf-input>
        </span>
    `;
}

function renderStringCell(field, value, host) {
  if (isPhoneField(field)) {
    const text = phoneText(field, value, host);
    return text ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<bdi dir="ltr">${text}</bdi>` : null;
  }

  return isPasswordField(field) ? passwordState(host, value) : null;
}

function renderStringView(field, value, host) {
  if (isPasswordField(field)) return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${passwordState(host, value)}</span>`;

  if (isPhoneField(field)) {
    const text = phoneText(field, value, host);
    return text ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view"><bdi dir="ltr">${text}</bdi></span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  }

  return renderTextView(field, value, host);
} // A file shown as what it is. The site keeps logos, so a file whose variant says
// image is drawn as the image rather than as a row with a paperclip -- the same
// stored file, told apart by the host rather than guessed from a file name.


const IMAGE_VARIANTS = new Set(['image', 'image-card', 'image-list']);

function isImageField(field) {
  return IMAGE_VARIANTS.has(String(field.variant ?? ''));
} // A block of text or code the host keeps in a file: six of them on a running
// Larena site -- scripts in the head, an included area. It is a property like any
// other, so it is shown and edited here rather than behind a separate screen.
//
// `language` is the host's, never guessed from the text: a component that decided
// a file was JavaScript because it saw a brace would be wrong about every template
// that contains one. Without a language it is plain text and says so by looking
// like text.
//
// No syntax colouring. That needs an editor component, which is its own part with
// its own decision; a monospace area that keeps indentation is honest, usable and
// does not pretend to be more.


function renderIncludeView(field, value) {
  const text = scalarValue(value);
  if (!text) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <pre class="sf-field-include" data-language=${field.language ? String(field.language) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}><code>${String(text)}</code></pre>
    `;
} // The include editor is code (C141 (8)): sf-input-textarea's text="code" --
// the code font, spelling off, no wrapping -- at a fixed eight rows.


function renderIncludeEdit(field, value, host) {
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-textarea
                size=${EDIT_SIZE}
                appearance="bordered"
                class="sf-field-include-edit"
                name=${fieldName(field)}
                value=${scalarValue(value) ?? ''}
                rows="8"
                text="code"
                ?required=${Boolean(field.required)}
                aria-label=${field.label || field.key || ''}
                ?disabled=${field.readonly === true}
                @change=${event => host.setFieldValue(field, event.target?.value ?? '')}
                @input=${event => host.setFieldValue(field, event.target?.value ?? '')}
        ></sf-input-textarea>
    `;
}

function renderIncludeCell(field, value) {
  const text = scalarValue(value);
  if (!text) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing; // One line in a cell: a script in a table row is a fact about the record, not
  // something to read there.

  const first = String(text).split('\n')[0];
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<code>${first.length > 60 ? `${first.slice(0, 60)}…` : first}</code>`;
}

function renderTextEdit(field, value, host) {
  const mask = (0,_mask_js__WEBPACK_IMPORTED_MODULE_7__.maskPattern)(field);
  if (String(field.variant ?? '') === 'phone') return renderPhoneEdit(field, value, host);
  if (isPasswordField(field)) return renderPasswordEdit(field, value, host);
  if (mask) return renderMaskedEdit(field, value, host, mask);
  value = scalarValue(value);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${value ?? ''}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ?required=${Boolean(field.required)}
                aria-label=${field.label || field.key || ''}
                @input=${event => host.setFieldValue(field, event.target?.value ?? '')}
                @change=${event => host.setFieldValue(field, event.target?.value ?? '')}
        ></sf-input>
    `;
} // A string typed through a mask (simai.property-view-port 1.16.0, field.mask;
// consumer simai.main, agreed contract q-b0de123841). The control is the stock
// sf-input with its own mask -- the Framework grammar, the same mask-pattern a
// page writes by hand -- so the typing, the caret and the fixed parts are the
// field's and nothing here formats a character.
//
// What the set adds is the one thing sf-input does not say: whether the text
// fills the pattern (./mask.js). The value written is the text as shown, fixed
// parts included («+7 (912) 345-67-89»): the host stores what it gets. Empty is
// not incomplete -- an optional masked field may be cleared, and writes null,
// or "" for a field that declares `nullable: false`. Required stays a mark: an
// empty required field is written as cleared and the host validates it.
//
// An incomplete text is not a value. The host hears it through the optional
// setFieldError(field, message) on every keystroke -- null once the text is
// complete or empty -- so a panel can hold both of its saves while any masked
// field in it is incomplete, each field on its own. The control marks itself
// invalid with the stock message only once the person leaves it (change):
// shouting «Заполните поле полностью» at the first digit of a phone would be
// an error for typing. A completed or cleared text takes the mark off at once.
//
// What is written while incomplete depends on the host. A host that hears
// errors gets the text as typed, because it re-renders with the value it was
// given and anything else would put an older text over the person's typing (a
// value attribute that moves is written into the input). A host that does not
// hear errors cannot hold a save, so the change is withdrawn with undefined,
// as the datetime pair does: what it saves is never the half-typed text.


function renderMaskedEdit(field, value, host, mask) {
  value = scalarValue(value);
  const cleared = field.nullable === false ? '' : null;

  const write = (event, left) => {
    const input = event.currentTarget;
    const text = String(input?.value ?? '');
    const state = (0,_mask_js__WEBPACK_IMPORTED_MODULE_7__.maskState)(text, mask);

    if (state === 'incomplete') {
      const message = setText(host, 'maskIncomplete');

      if (left && input) {
        input.setAttribute('error-message', message);
        input.toggleAttribute('invalid', true);
      }

      if (typeof host.setFieldError === 'function') {
        host.setFieldError(field, message);
        host.setFieldValue(field, text);
      } else {
        host.setFieldValue(field, undefined);
      }

      return;
    }

    if (input?.hasAttribute('invalid')) {
      input.toggleAttribute('invalid', false);
      input.removeAttribute('error-message');
    }

    host.setFieldError?.(field, null);
    host.setFieldValue(field, state === 'empty' ? cleared : text);
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${value ?? ''}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                autocomplete="off"
                mask
                mask-pattern=${mask}
                ?required=${Boolean(field.required)}
                aria-label=${field.label || field.key || ''}
                @input=${event => write(event, false)}
                @change=${event => write(event, true)}
        ></sf-input>
    `;
}

function renderTextAreaEdit(field, value, host) {
  value = scalarValue(value);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-textarea
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${value ?? ''}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ?required=${Boolean(field.required)}
                aria-label=${field.label || field.key || ''}
                @input=${event => host.setFieldValue(field, event.target?.value ?? '')}
                @change=${event => host.setFieldValue(field, event.target?.value ?? '')}
        ></sf-input-textarea>
    `;
} // Formatted text (property-view port 1.17.0): sf-input-rich, named as the
// textarea is. The editor cleans its own value -- what it is given, every
// paste and every edit -- so what it writes back is already the subset. The
// value is read from the element the listener is on: sf-input-rich says input
// and change from its editing surface inside it, which has no value of its own.


function renderHtmlEdit(field, value, host) {
  value = scalarValue(value);

  const write = event => host.setFieldValue(field, event.currentTarget?.value ?? '');

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-rich
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${typeof value === 'string' ? value : ''}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ?required=${Boolean(field.required)}
                ?disabled=${EDIT_DISABLED}
                aria-label=${field.label || field.key || ''}
                @input=${write}
                @change=${write}
        ></sf-input-rich>
    `;
} // A number edited with steps (owner, 2026-10-25): an integer or a number whose
// variant is `stepper` gets sf-input-quantity -- «−» and «+», the arrow keys, the
// bounds the field names -- and every other number keeps the plain sf-input
// below. The bounds, the step and (for a number) the digits are the field's
// own keys, read by this variant alone: a renderer still does not enforce a
// constraint, the stepper only stops at it and the host validates the record.
//
// An integer has no digits after the point, whatever the field says. A number
// takes `precision`, else the digits its `step` implies, else two: a number
// field whose stepper could not take a decimal mark would be an integer field.
// The value goes out as the stepper's number, or null when the field is
// emptied; the panel prints the label, so the control takes it as its
// accessible name only.


function isStepperField(field) {
  return String(field.variant ?? '') === 'stepper';
}

function stepperNumber(raw) {
  if (raw === null || raw === undefined || raw === '') return '';
  const number = Number(raw);
  return Number.isFinite(number) ? String(number) : '';
}

function renderStepperEdit(field, value, host) {
  const decimal = (field.propertyType || field.type) === 'number';
  const step = stepperNumber(field.step);
  const precision = decimal ? stepperNumber(field.precision) || (step ? '' : '2') : '0';

  const write = event => host.setFieldValue(field, event.detail?.value ?? null);

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-quantity
                size=${EDIT_SIZE}
                name=${fieldName(field)}
                value=${stepperNumber(scalarValue(value))}
                min=${stepperNumber(field.min) || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                max=${stepperNumber(field.max) || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                step=${step || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                precision=${precision || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                ?required=${Boolean(field.required)}
                ?disabled=${field.readonly === true}
                @input=${write}
                @change=${write}
        ></sf-input-quantity>
    `;
} // A number is a decimal (property-view port 1.18.0: «never a float on the
// wire»). What is typed is read with a comma or a point and spaces between
// groups. A number field whose value arrives as a string, or that declares
// `precision`, is a decimal-string field: it writes the canonical decimal
// string («1500.50»), never a float, and refuses more digits after the point
// than `precision` allows. Any other number field writes a number, as before;
// an integer field is unchanged. Text that is not a number is reported as a
// masked string's incomplete entry is: through setFieldError, which holds the
// save, and under the field once the person leaves it.


function isDecimalStringField(field, value) {
  return (field.propertyType || field.type) === 'number' && (typeof value === 'string' || Number.isInteger(field.precision));
}

function renderNumberEdit(field, value, host) {
  if (isStepperField(field)) return renderStepperEdit(field, value, host);
  const decimal = (field.propertyType || field.type) === 'number';
  value = scalarValue(value);

  if (!decimal) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <sf-input
                    size=${EDIT_SIZE}
                    appearance="bordered"
                    name=${fieldName(field)}
                    value=${value ?? ''}
                    inputmode="numeric"
                    ?required=${Boolean(field.required)}
                    aria-label=${field.label || field.key || ''}
                    @input=${event => {
      const next = event.target?.value ?? '';
      host.setFieldValue(field, next === '' ? null : Number(next));
    }}
                    @change=${event => {
      const next = event.target?.value ?? '';
      host.setFieldValue(field, next === '' ? null : Number(next));
    }}
            ></sf-input>
        `;
  }

  const asString = isDecimalStringField(field, value);

  const write = (event, left) => {
    const input = event.currentTarget ?? event.target;
    const text = String(input?.value ?? '');
    const read = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readDecimal)(text);
    let message = null;
    if (!read.ok) message = setText(host, 'notNumber');else if (read.value !== null && Number.isInteger(field.precision) && (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.fractionDigits)(read.value) > field.precision) {
      message = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageWord)(SET_TEXT, 'precisionMax', host ?? null, {
        component: SET_NAME,
        count: field.precision
      });
    }

    if (message) {
      if (left && input) {
        input.setAttribute('error-message', message);
        input.toggleAttribute('invalid', true);
      }

      if (typeof host.setFieldError === 'function') {
        host.setFieldError(field, message);
        host.setFieldValue(field, text);
      } else {
        host.setFieldValue(field, undefined);
      }

      return;
    }

    if (input?.hasAttribute?.('invalid')) {
      input.toggleAttribute('invalid', false);
      input.removeAttribute('error-message');
    }

    host.setFieldError?.(field, null);
    if (read.value === null) host.setFieldValue(field, null);else host.setFieldValue(field, asString ? read.value : Number(read.value));
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${value ?? ''}
                inputmode="decimal"
                ?required=${Boolean(field.required)}
                aria-label=${field.label || field.key || ''}
                @input=${event => write(event, false)}
                @change=${event => write(event, true)}
        ></sf-input>
    `;
} // Money and percent are the Framework's in every mode (owner decision C291
// (2), 2026-11-17; set boundary study BQ-2): the View set's editors were the
// reference, its option names kept -- `currency` (a fixed ISO 4217 code),
// `min`, `max`, `precision` (a percent's digits; money's are its currency's
// minor units, ISO 4217) and `placeholder`, as simai.property-view-port 1.18.0
// declares them. Every value is a decimal string, never a float:
//
//   percent   "12.5" -- the percent, not the share; 0 to 100 unless the
//             field bounds it otherwise
//   money     {amount: "1500.50", currency: "RUB"}; a field with a fixed
//             currency also reads a bare amount, and writes the pair
//
// One sf-input with the decimal keyboard and the sign in the field («%», a
// fixed currency's «₽» after the amount or «$» before it, as the page's
// language writes it); a money field without a fixed currency has a currency
// dropdown beside the amount. What is typed is read with a comma or a point
// and written canonical; the input shows it back in the page's language
// («1500,5»). An entry that is not a value yet -- text that is not a number,
// more digits after the point than allowed, a bound crossed, an amount without
// a currency -- is written as typed and said through setFieldError, which holds
// a save (port 1.16.0, as a masked string's), and under the field once the
// person leaves it. A host without setFieldError hears undefined, as for a
// number.
// The codes a currency choice offers when a field names no `currencies` and
// the browser cannot list ISO 4217 (Intl.supportedValuesOf).


const OFFERED_CURRENCIES = ['RUB', 'USD', 'EUR', 'CNY', 'KZT', 'BYN', 'AED', 'TRY', 'GBP', 'JPY']; // A field's `currencies` (C294, MP-10): an array of ISO 4217 codes or a
// comma-separated string; absent, every code the browser knows.

function fieldCurrencies(field) {
  const asked = Array.isArray(field?.currencies) ? field.currencies : typeof field?.currencies === 'string' ? field.currencies.split(',') : [];
  const codes = asked.map(code => String(code).trim().toUpperCase()).filter(code => /^[A-Z]{3}$/u.test(code));
  return codes.length ? [...new Set(codes)] : (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyCodes)(OFFERED_CURRENCIES);
} // What a person is typing, per host and field: the value written is
// canonical («12.5»), and drawn back as such it would move the caret under
// «12,50» or swallow the comma of «12,». The typed text is shown while it
// still reads as the value, and forgotten when the field is left.


const DECIMAL_DRAFTS = new WeakMap();

function draftOf(host, key) {
  return host && typeof host === 'object' ? DECIMAL_DRAFTS.get(host)?.get(key) : undefined;
}

function keepDraft(host, key, text) {
  if (!host || typeof host !== 'object') return;
  let drafts = DECIMAL_DRAFTS.get(host);

  if (!drafts) {
    drafts = new Map();
    DECIMAL_DRAFTS.set(host, drafts);
  }

  if (text === undefined) drafts.delete(key);else drafts.set(key, text);
} // At rest the amount shows its groups and at least `minDigits` after the
// point («1 500,50»); while it is typed, as typed (C294).


function decimalShown(host, key, value, {
  currency = null,
  minDigits = 0
} = {}) {
  if (value === null || value === undefined || value === '') return '';
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);
  const read = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(value, {
    locale: 'en',
    currency
  });
  if (!read.ok) return String(value);
  const draft = draftOf(host, key);

  if (typeof draft === 'string') {
    const typed = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(draft, {
      locale,
      currency
    });
    if (typed.ok && typed.value === read.value) return draft;
  }

  return (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.restingDecimal)(read.value, locale, minDigits);
}

const hasBound = bound => bound !== null && bound !== undefined && bound !== '' && (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readDecimal)(bound).ok; // What is wrong with a typed decimal, or '': not a number, more digits after
// the point than `digits` (never rounded away: «1500,555» is an error, while
// «1500,500» is 1500.5), outside min..max.


function decimalError(host, text, {
  digits = null,
  min = null,
  max = null,
  currency = null
} = {}) {
  const read = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(text, {
    locale: (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null),
    currency
  });
  if (!read.ok) return setText(host, 'notNumber');
  if (read.value === null) return '';

  if (Number.isInteger(digits) && (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.fractionDigits)(read.value) > digits) {
    return digits === 0 ? setText(host, 'fractionNone') : (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageWord)(SET_TEXT, 'precisionMax', host ?? null, {
      component: SET_NAME,
      count: digits
    });
  }

  const low = hasBound(min) && (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.compareDecimal)(read.value, min) === -1;
  const high = hasBound(max) && (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.compareDecimal)(read.value, max) === 1;
  if (!low && !high) return '';
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);
  const vars = {
    min: hasBound(min) ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatDecimal)(min, locale) : '',
    max: hasBound(max) ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatDecimal)(max, locale) : ''
  };
  if (hasBound(min) && hasBound(max)) return setWord(host, 'boundBetween', vars);
  return low ? setWord(host, 'boundAtLeast', vars) : setWord(host, 'boundAtMost', vars);
} // The value goes to the host with what is wrong with it: a value that is not
// one yet is written as typed while setFieldError holds the save.


function writeDecimal(field, host, value, message) {
  if (message) {
    if (typeof host.setFieldError === 'function') {
      host.setFieldError(field, message);
      host.setFieldValue(field, value);
    } else {
      host.setFieldValue(field, undefined);
    }

    return;
  }

  host.setFieldError?.(field, null);
  host.setFieldValue(field, value);
}

function decimalInput(field, value, host, {
  key,
  check,
  write,
  currency = null,
  minDigits = 0,
  textStart = '',
  textEnd = '',
  rootClass = ''
}) {
  const own = EDIT_ERROR;
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);

  const typed = (event, left) => {
    const input = event.currentTarget ?? event.target;
    const text = String(input?.value ?? '');
    keepDraft(host, key, left ? undefined : text);
    const message = check(text);

    if (input && !own) {
      if (message && left) {
        input.setAttribute('error-message', message);
        input.toggleAttribute('invalid', true);
      } else if (!message && input.hasAttribute?.('invalid') && !input.hasAttribute('data-sf-form-invalid')) {
        input.toggleAttribute('invalid', false);
        input.removeAttribute('error-message');
      }
    }

    const read = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(text, {
      locale,
      currency
    });
    write(read.ok ? read.value : text, message);
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input
                size=${EDIT_SIZE}
                appearance="bordered"
                name=${fieldName(field)}
                value=${decimalShown(host, key, value, {
    currency,
    minDigits
  })}
                inputmode="decimal"
                text-start=${textStart || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                text-end=${textEnd || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                root-class=${rootClass || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ?required=${Boolean(field.required)}
                ?invalid=${Boolean(own)}
                error-message=${own || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                @input=${event => typed(event, false)}
                @change=${event => typed(event, true)}
        ></sf-input>
    `;
}

function fixedCurrency(field) {
  return typeof field?.currency === 'string' && /^[A-Z]{3}$/u.test(field.currency) ? field.currency : null;
} // A percent's digits after the point: `precision`, else the digits its
// `step` has («0.1» is one), else as many as typed.


function percentDigits(field) {
  if (Number.isInteger(field.precision)) return field.precision;
  const step = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readDecimal)(field.step);
  return step.ok && step.value !== null && Number(step.value) > 0 ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.fractionDigits)(step.value) : null;
} // A percent is the percent itself, «12.5» is 12,5 % (C294); it is bounded
// only by the field's min and max -- a growth of 150 % or a change of −5 % is
// a percent too (MP-11: the View set bounded it 0..100 without saying why).


function renderPercentEdit(field, value, host) {
  const key = String(field.key ?? '');
  const min = hasBound(field.min) ? field.min : null;
  const max = hasBound(field.max) ? field.max : null;
  const digits = percentDigits(field);
  return decimalInput(field, scalarValue(value), host, {
    key,
    textEnd: '%',
    check: text => decimalError(host, text, {
      digits,
      min,
      max
    }),
    write: (next, message) => writeDecimal(field, host, next, message)
  });
}

function renderMoneyEdit(field, value, host) {
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);
  const key = String(field.key ?? '');
  const fixed = fixedCurrency(field);
  const display = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyDisplayOf)(field);
  const parts = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.moneyParts)(scalarValue(value), fixed); // A currency chosen before an amount is typed waits here: a value is an
  // amount and its currency, never a currency alone.

  const currencyKey = `${key}#currency`;
  const currency = parts.currency || draftOf(host, currencyKey) || null;
  const min = hasBound(field.min) ? field.min : null;
  const max = hasBound(field.max) ? field.max : null;

  const check = (text, code) => {
    const message = decimalError(host, text, {
      digits: code ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(code, locale).minor : null,
      min,
      max,
      currency: code
    });
    if (message) return message;
    return (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(text, {
      locale,
      currency: code
    }).value !== null && !code ? setText(host, 'chooseCurrency') : '';
  };

  const write = (amount, message, code) => writeDecimal(field, host, amount === null || amount === '' ? null : {
    amount,
    currency: code ?? null
  }, message);

  const sign = fixed ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(fixed, locale, display) : null;
  const amount = decimalInput(field, parts.amount, host, {
    key,
    currency,
    minDigits: currency ? (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(currency, locale).minor : 0,
    textStart: sign?.before ? sign.sign : '',
    textEnd: sign && !sign.before ? sign.sign : '',
    rootClass: fixed ? '' : 'flex-1 min-w-0',
    check: text => check(text, currency),
    write: (next, message) => write(next, message, currency)
  });
  if (fixed) return amount; // The field's `currencies`, the value's own currency first when the list
  // lacks it; without a list, every ISO 4217 code with a search.

  const listed = fieldCurrencies(field);
  const offered = [...new Set([...(currency ? [currency] : []), ...listed])];
  const name = setText(host, 'currency');
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="flex gap-1/3 items-cross-start min-w-0 w-full">
            ${amount}
            <sf-dropdown
                    size=${EDIT_SIZE}
                    appearance="bordered"
                    mode="select"
                    search=${offered.length > 12 ? 'true' : 'false'}
                    root-class="basis-1/3 min-w-0"
                    name=${`${fieldName(field)}_currency`}
                    value=${currency ?? ''}
                    placeholder=${name}
                    aria-label=${name}
                    .options=${offered.map(code => {
    const {
      sign: mark
    } = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(code, locale, display);
    return {
      type: 'text',
      size: '1',
      value: code,
      text: mark === code ? code : `${code} ${mark}`,
      selected: code === currency
    };
  })}
                    @change=${event => {
    const code = event.detail?.values?.[0] || event.detail?.value || null;
    keepDraft(host, currencyKey, code ?? undefined);
    const typed = parts.amount; // The dropdown shows the code itself; a value is written
    // only with an amount.
    // The stored amount is checked as the page would show it.

    if (typed !== null && typed !== undefined && typed !== '') write(typed, check((0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.restingDecimal)(typed, locale), code), code);
  }}
            ></sf-dropdown>
        </div>
    `;
}

function renderPercentView(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  const text = typeof formatted === 'string' ? formatted : carriesText(value) ? value.text : (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatPercent)(scalarValue(value), (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null)) || viewText(field, value, null);
  return text ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${text}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
}

function renderMoneyView(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  const text = typeof formatted === 'string' ? formatted : carriesText(value) ? value.text : (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatMoney)(scalarValue(value), field, (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null));
  return text ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${text}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
} // A date control has no clock. `sf-input-date` declares a format and a date,
// and its parser is anchored (`^\d{4}-\d{2}-\d{2}$`), so a datetime value
// falls through to a loose digit scan that reads `2026-11-27T13:26:00` as day
// 2026 of month 11 in year 27 -- an impossible date, which renders as an empty
// input. Split the value instead: the control edits the day, and the time the
// record already held is put back on the way out. Without that, editing the day
// of a datetime would write a value with the clock silently zeroed, which is
// worse than the empty control, because it looks like it worked. A `datetime`
// field has its own editor now (renderDateTimeEdit); this keeps the clock of a
// `date` field whose value carries one.


const DATE_TIME_RE = /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2})?(?:\.\d+)?)(Z|[+-]\d{2}:?\d{2})?$/;

function splitDateTime(value) {
  const match = typeof value === 'string' ? value.trim().match(DATE_TIME_RE) : null;

  if (!match) {
    return {
      date: value,
      suffix: ''
    };
  }

  return {
    date: match[1],
    suffix: `T${match[2]}${match[3] || ''}`
  };
} // min and max bound the day (PD-2, as a datetime's do): an ISO date, or the
// day of an ISO date and time; the calendar disables the days outside them
// and a typed day outside them is put back. The host still validates.


function dayBound(bound) {
  const match = typeof bound === 'string' ? bound.trim().match(/^\d{4}-\d{2}-\d{2}/u) : null;
  return match ? match[0] : '';
}

function renderDateEdit(field, value, host) {
  value = scalarValue(value);
  const {
    date,
    suffix
  } = splitDateTime(value);
  const min = dayBound(field.min);
  const max = dayBound(field.max);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-date
                size=${EDIT_SIZE}
                name=${fieldName(field)}
                value=${date ?? ''}
                min-date=${min || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                max-date=${max || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                ?required=${Boolean(field.required)}
                ?invalid=${Boolean(EDIT_ERROR)}
                error-message=${EDIT_ERROR || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                @change=${event => {
    const next = event.detail?.value ?? event.target?.value ?? null;
    host.setFieldValue(field, next && suffix ? `${next}${suffix}` : next);
  }}
        ></sf-input-date>
    `;
} // A datetime is edited as what it is: a day and a time of day. The date
// editor above edits the day alone and puts the record's clock back, so a new
// record could not get a time and «15.11.2026 10:30» typed nowhere was saved
// as «15.11.2026» (Larena acceptance, 2026-10-22). The set then drew a pair --
// sf-input-date for the day and an sf-input masked to hh:mm for the time --
// because the picker had no clock, and sf-view-properties drew the same pair
// itself (duplication audit A-14). sf-input-date has a time now (1.4.0,
// mode="datetime"), so a datetime is one control: the calendar with the time
// row under it, typed as «15.11.2026 10:30», at the field's size, named by the
// label.
//
// The value round trip (datetime.js): ISO 8601 with the time; an untouched
// field writes nothing; a changed day keeps the stored time below the minute
// and the zone; a changed time keeps the zone; a new value has no zone (the
// host's local time); a cleared field writes null; coming back to what was
// stored writes undefined -- no change. The control writes only whole values
// (a day always has a time, a typed text that is not one is put back), so no
// partial entry reaches the host. The day is bound as a property, so a
// re-render with the same value does not put back what the person cleared.
//
// min and max (an ISO date, or a date and a time) are the control's min-date
// and max-date; step is its minute step (1 to 60).


function minuteStepOf(field) {
  const step = Number(field.step);
  return Number.isInteger(step) && step >= 1 && step <= 60 ? String(step) : '';
}

function renderDateTimeEdit(field, value, host) {
  const stored = (0,_datetime_js__WEBPACK_IMPORTED_MODULE_6__.splitDateTime)(value);
  const shown = stored.date ? `${stored.date}${stored.time ? `T${stored.time}` : ''}` : '';
  const min = typeof field.min === 'string' ? field.min : '';
  const max = typeof field.max === 'string' ? field.max : '';
  const step = minuteStepOf(field);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-date
                class="sf-field-datetime"
                mode="datetime"
                size=${EDIT_SIZE}
                name=${fieldName(field)}
                .value=${shown}
                min-date=${min || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                max-date=${max || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                minute-step=${step || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                ?required=${Boolean(field.required)}
                ?invalid=${Boolean(EDIT_ERROR)}
                error-message=${EDIT_ERROR || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                @change=${event => {
    // The picker's own change, not a native one from its field.
    if (event.target !== event.currentTarget) return;
    const [date = '', time = ''] = String(event.detail?.value ?? '').split('T');
    const result = (0,_datetime_js__WEBPACK_IMPORTED_MODULE_6__.composeDateTime)(stored, {
      date,
      time
    });
    if (result.error) return;
    const same = result.value === null ? stored.known && !stored.date : result.value === stored.raw;
    host.setFieldValue(field, same ? undefined : result.value);
  }}
        ></sf-input-date>
    `;
} // A time of day (hh:mm, or hh:mm:ss as a host stores it) is sf-input-date in
// time mode: the time row alone, typed as «10:30». An unchanged minute writes
// nothing and keeps the stored seconds; min and max (hh:mm) are the control's
// min-time and max-time; step is its minute step.


function renderTimeEdit(field, value, host) {
  const stored = (0,_datetime_js__WEBPACK_IMPORTED_MODULE_6__.splitTime)(value);
  const min = typeof field.min === 'string' ? field.min : '';
  const max = typeof field.max === 'string' ? field.max : '';
  const step = minuteStepOf(field);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-date
                class="sf-field-time"
                mode="time"
                size=${EDIT_SIZE}
                name=${fieldName(field)}
                .value=${stored.time}
                min-time=${min || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                max-time=${max || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                minute-step=${step || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                ?required=${Boolean(field.required)}
                ?invalid=${Boolean(EDIT_ERROR)}
                error-message=${EDIT_ERROR || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                @change=${event => {
    if (event.target !== event.currentTarget) return;
    const result = (0,_datetime_js__WEBPACK_IMPORTED_MODULE_6__.composeTime)(stored, String(event.detail?.value ?? ''));
    if (result.error) return;
    const same = result.value === null ? stored.known && !stored.time : result.value === stored.raw;
    host.setFieldValue(field, same ? undefined : result.value);
  }}
        ></sf-input-date>
    `;
} // A required boolean has two states and nothing else. In a form saved with a
// button it is a checkbox, and a switch only where the change acts at once
// (owner decision C165 (4), form study FM-6): a switch says «on now», which a
// form that has not been saved has not done. The host says it acts at once with
// renderEditField(…, {apply: 'instant'}). The checkbox carries no `required`:
// a required yes/no is one with a value, and an unticked box is «Нет», not an
// empty answer. An optional one is a pair of buttons with nothing chosen while
// the value is absent -- the consumer owner's decision of 2026-10-06, and the
// reason is that neither a switch nor a checkbox can say «не задано»: rendering
// one over an absent value would write false on the first save, a value nobody
// chose.


function renderBooleanEdit(field, value, host) {
  const optional = field.required !== true;

  if (!optional && EDIT_APPLY === 'instant') {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <sf-switch
                    size=${EDIT_SIZE}
                    name=${fieldName(field)}
                    ?checked=${value === true}
                    aria-label=${field.label || field.key || ''}
                    @change=${event => host.setFieldValue(field, Boolean(event.target?.checked))}
            ></sf-switch>
        `;
  }

  if (!optional) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <sf-checkbox
                    size=${EDIT_SIZE}
                    name=${fieldName(field)}
                    ?checked=${value === true}
                    aria-label=${field.label || field.key || ''}
                    @change=${event => host.setFieldValue(field, Boolean(event.target?.checked ?? event.detail?.checked))}
            ></sf-checkbox>
        `;
  }

  const words = booleanWords(field, host);
  const items = JSON.stringify([{
    value: 'yes',
    label: words.yes
  }, {
    value: 'no',
    label: words.no
  }]);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-segmented
                appearance="buttons"
                size=${EDIT_SIZE}
                items=${items}
                value=${value === true ? 'yes' : value === false ? 'no' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                @change=${event => {
    const next = event.detail?.value;
    host.setFieldValue(field, next === 'yes' ? true : next === 'no' ? false : null);
  }}
        ></sf-segmented>
    `;
}

function editOptions(field, value, multiple) {
  const options = field.options || field.filter?.options || field.constraints?.options || [];
  const chosen = multiple ? new Set((Array.isArray(value) ? value : []).map(item => String(item))) : new Set([String(value ?? '')]);
  return options.map(option => ({
    type: 'text',
    size: '1',
    text: option.label ?? option.text ?? String(option.value),
    value: String(option.value),
    selected: chosen.has(String(option.value))
  }));
} // A choice as buttons (simai.property-view-port 1.16.0, variant `buttons`;
// consumer simai.main, agreed contract q-b0de123841): one segmented
// sf-button-group, a button per option, for a short list a person reads at a
// glance -- a kind, a tier, a yes-no-maybe. The group is the stock one: Tab
// enters it, the arrows move and choose, Space and Enter choose, and it is a
// radiogroup to assistive technology. It wraps when it does not fit and is
// never replaced by a dropdown: a field that changes its control with the
// width of a window is two fields.
//
// `size` is the field's own step on the ladder ("1/2", "1", "2"), absent the
// panel's: the track of a segmented group is exactly as tall as an sf-button of
// the same size, so the buttons stand on the line the fields beside them do.
//
// The value is the option's own, in its own type -- the group speaks strings,
// so a chosen "2" is written back as the 2 the option carries -- or null.
// Pressing the chosen button again clears it when the field is not required;
// the group itself keeps a chosen button chosen (its select answers
// unchanged), so the press is read in the capture phase, before the group's
// own listener, where the value it is about to be compared with is still the
// one shown. A required field keeps the stock behaviour: the chosen button
// stays chosen.
//
// Read-only shows the chosen button chosen, in its own colours, and lets none
// be pressed: pointer events are off on the track and a key that would choose
// is stopped before the group hears it. Disabled is the group's own disabled,
// in the on-disable colours. The two are different facts -- «not yours to
// change» and «not available now» -- and drawn as the group draws them.


const CHOICE_BUTTON_SIZES = new Set(['1/2', '1', '2']);
const CHOOSING_KEYS = new Set(['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', ' ', 'Enter']);

function isChoiceButtons(field) {
  return String(field.variant ?? '') === 'buttons';
}

function renderChoiceButtons(field, value, host) {
  value = scalarValue(value);
  const options = (field.options || field.filter?.options || field.constraints?.options || []).filter(option => option && option.value !== null && option.value !== undefined && String(option.value) !== '');
  const items = options.map(option => ({
    value: String(option.value),
    label: String(option.label ?? option.text ?? option.value),
    ...(option.icon ? {
      icon: String(option.icon)
    } : {}),
    ...(option.disabled ? {
      disabled: true
    } : {})
  }));
  const asked = String(field.size ?? '');
  const size = CHOICE_BUTTON_SIZES.has(asked) ? asked : EDIT_SIZE;
  const disabled = EDIT_DISABLED;
  const locked = !disabled && field.readonly === true;
  const clearable = field.required !== true && !locked && !disabled;
  const chosen = value === null || value === undefined ? '' : String(value);

  const optionValue = text => options.find(option => String(option.value) === text)?.value ?? text;

  const press = {
    capture: true,

    handleEvent(event) {
      const group = event.currentTarget;
      const segment = event.target?.closest?.('[data-sf-button-group-value]');
      if (!group || !segment || !group.contains(segment)) return;

      if (locked) {
        event.preventDefault();
        event.stopPropagation();
        return;
      }

      if (!clearable || segment.disabled) return;
      if (segment.getAttribute('data-sf-button-group-value') !== group.value) return;
      event.preventDefault();
      event.stopPropagation();
      group.clear?.();
    }

  };
  const keys = {
    capture: true,

    handleEvent(event) {
      if (!locked || !CHOOSING_KEYS.has(event.key)) return;
      event.preventDefault();
      event.stopPropagation();
    }

  };
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-segmented
                class="sf-field-choice-buttons"
                appearance="track"
                size=${size}
                root-class=${locked ? 'flex-wrap pointer-events-none' : 'flex-wrap'}
                name=${fieldName(field)}
                items=${JSON.stringify(items)}
                value=${chosen || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ?disabled=${disabled}
                data-readonly=${locked ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                @click=${press}
                @keydown=${keys}
                @change=${event => {
    const next = String(event.detail?.value ?? '');
    host.setFieldValue(field, next === '' ? null : optionValue(next));
  }}
        ></sf-segmented>
    `;
}

function renderChoiceEdit(field, value, host) {
  if (isChoiceButtons(field)) return renderChoiceButtons(field, value, host);
  value = scalarValue(value);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-dropdown
                size=${EDIT_SIZE}
                appearance="bordered"
                mode="select"
                search="false"
                name=${fieldName(field)}
                ?required=${Boolean(field.required)}
                value=${value ?? ''}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                .options=${editOptions(field, value, false)}
                @change=${event => host.setFieldValue(field, event.detail?.value ?? null)}
        ></sf-dropdown>
    `;
} // A long list is chosen from as a checklist, not from a dropdown: a custom
// role's 137 rights in one dropdown were a scroll inside a scroll, and what was
// chosen could not be seen at once (Larena, 2026-10-17). The list stands in
// two columns where the field has the room for them and in one where it does
// not. `variant: 'checklist'` asks for it at any length; `variant: 'select'`
// keeps the dropdown at any length.


const CHECKLIST_FROM = 13;

function renderChoicesChecklist(field, value, host) {
  const options = field.options || field.filter?.options || field.constraints?.options || [];
  const chosen = new Set((Array.isArray(value) ? value : []).map(item => String(item)));

  const toggle = (option, on) => {
    const next = options.filter(candidate => String(candidate.value) === String(option.value) ? on : chosen.has(String(candidate.value))).map(candidate => candidate.value);
    host.setFieldValue(field, next);
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-field-checklist grid gap-1/3 w-full min-w-0" role="group" aria-label=${field.label || field.key || ''}
             style="grid-template-columns: repeat(auto-fill, minmax(min(100%, 14rem), 1fr))">
            ${options.map(option => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-checkbox size=${EDIT_SIZE}
                    name=${fieldName(field)} value=${String(option.value)}
                    label=${option.label ?? option.text ?? String(option.value)}
                    .checked=${chosen.has(String(option.value))}
                    @change=${event => toggle(option, Boolean(event.target?.checked ?? event.detail?.checked))}></sf-checkbox>`)}
        </div>
    `;
}

function renderChoicesEdit(field, value, host) {
  const options = field.options || field.filter?.options || field.constraints?.options || [];
  const variant = String(field.variant ?? '');

  if (variant === 'checklist' || variant !== 'select' && options.length >= CHECKLIST_FROM) {
    return renderChoicesChecklist(field, value, host);
  }

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-dropdown
                size=${EDIT_SIZE}
                appearance="bordered"
                mode="select"
                multiple
                search="false"
                name=${fieldName(field)}
                ?required=${Boolean(field.required)}
                placeholder=${field.placeholder || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-label=${field.label || field.key || ''}
                .options=${editOptions(field, value, true)}
                @change=${event => {
    const next = event.detail?.values ?? event.detail?.value;
    host.setFieldValue(field, Array.isArray(next) ? next : next ? [next] : []);
  }}
        ></sf-dropdown>
    `;
} // The record picker: what a record, a relation or a user is edited with.
//
// It is the entity-select the filter already has, pointed at records instead of
// options and holding one value rather than several. The three cases that break
// a picker are the ones it is built around, and the ones the probe measures
// against the consumer's 448-target field:
//
//   search   hundreds of targets never fit a list, so the search is the way in
//   paging   a page arrives with a cursor and the next is asked for
//   off-page the chosen record is usually not on the page in front of you, so
//            the picker shows what is chosen whether or not the page holds it
//
// The host does the fetching, because a page of records is a query with an
// access check, and the renderer must not make one:
//
//   getFieldOptionsPage(field)                  the page the host holds
//   loadFieldOptions(field, {cursor, search})   ask for a page
//   getFieldOptionSearch(field) / setFieldOptionSearch(field, text)
//
// The value is the resolved object the consumer sends: {value, label}. The
// picker writes the same shape back, so a host never has to re-resolve what it
// already knew.
// The text the set shows beyond a value: a status line, a retry, a load-more, a
// remove label. These belong to whoever owns the interface, not to the set, so
// the host supplies them and the Russian is only the fallback -- the same
// arrangement as `booleanWords`, and the same reason. A host that passes nothing
// keeps exactly what was published.


const SET_TEXT = _lang_index_mjs__WEBPACK_IMPORTED_MODULE_12__["default"]; // The host's word wins, as it always did; the set's own fallback now follows
// the page's language instead of being Russian whatever the page is. `host` is
// the component that called the set, which is the node the rule reads from.
// The set is not an element, so it is named here rather than taken from the
// node: `host` is whichever component called it, and words registered for the
// set should apply wherever it draws rather than once per host.

const SET_NAME = 'sf-field-renderers';

function setText(host, key) {
  return host?.getFieldText?.(key) ?? (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageText)(SET_TEXT, key, host ?? null, SET_NAME);
} // A word with places in it ({zone}, {n}): the host's word wins, as setText's.


function setWord(host, key, vars) {
  const own = host?.getFieldText?.(key);

  if (own !== undefined && own !== null) {
    return String(own).replace(/\{([a-z][\w-]*)\}/giu, (whole, name) => vars && name in vars ? String(vars[name]) : whole);
  }

  return (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageWord)(SET_TEXT, key, host ?? null, {
    component: SET_NAME,
    vars
  });
} // One job, one component (owner decision C139 (1), 2026-11-14): a record, a
// relation, a user and a paged lookup are chosen with sf-input-lookup -- the
// search the host answers, its rows with a picture and a caption, its states
// and its chips -- where they were a searchable sf-dropdown beside a status
// line of the set's own. sf-dropdown stays for a short list given whole (an
// inline lookup). The dropdown path is kept until 2027-01-01 for a host that
// asks renderEditField(…, {picker: 'dropdown'}); it is noted as deprecated.


const DROPDOWN_PICKER_UNTIL = '2027-01-01';
let EDIT_PICKER = '';

function dropdownPicker() {
  if (EDIT_PICKER !== 'dropdown') return false;
  (0,_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_9__.noteDeprecated)({
    component: 'sf-field-renderers',
    kind: 'value',
    attribute: 'picker',
    from: 'dropdown',
    to: null,
    since: '2026-11-14',
    remove_after: DROPDOWN_PICKER_UNTIL
  });
  return true;
} // An item the lookup shows, from what the host's page holds: a user's
// avatarText is the avatar's initials, an item's own avatar ({src} or
// {initials}), icon, caption and match ranges travel as they are.


function lookupItem(item) {
  if (!item || typeof item !== 'object') return null;
  const avatar = item.avatar && typeof item.avatar === 'object' ? item.avatar : item.avatarText ? {
    initials: String(item.avatarText)
  } : undefined;
  return {
    value: item.value,
    label: String(item.label ?? item.text ?? item.value ?? ''),
    ...(item.caption ? {
      caption: String(item.caption)
    } : {}),
    ...(avatar ? {
      avatar
    } : {}),
    ...(item.icon ? {
      icon: String(item.icon)
    } : {}),
    ...(item.match ? {
      match: item.match
    } : {})
  };
} // The lookup's provider over the host's page interface (getFieldOptionsPage,
// loadFieldOptions, getFieldOptionSearch, setFieldOptionSearch): a query is
// one host search, a cursor its next page. The page the host already holds
// for the same query answers at once (a record view asks the first page as
// its group opens). A host that loads without answering a promise answers on
// its next drawing: the page is read again until it is no longer loading.


function hostProvider(field, host) {
  return async (query, {
    cursor = null,
    signal
  } = {}) => {
    const text = String(query ?? '');
    const held = host.getFieldOptionsPage(field) || null;
    const sameSearch = (host.getFieldOptionSearch?.(field) ?? '') === text;
    let page = held;
    let from = 0;
    let before = [];

    if (cursor === null && sameSearch && held?.status === 'ready') {
      page = held;
    } else {
      before = cursor === null || !Array.isArray(held?.items) ? [] : held.items;
      host.setFieldOptionSearch?.(field, text);
      await host.loadFieldOptions(field, {
        cursor,
        search: text
      });
      page = host.getFieldOptionsPage(field) || null;

      for (let wait = 0; page?.status === 'loading' && wait < 100 && !signal?.aborted; wait += 1) {
        await new Promise(done => setTimeout(done, 50));
        page = host.getFieldOptionsPage(field) || null;
      }
    }

    if (signal?.aborted) return {
      items: []
    }; // A host may join the next page to the ones it holds, or replace them
    // with it: only what is new is answered.

    const now = Array.isArray(page?.items) ? page.items : [];
    if (before.length && now.length > before.length && now[0]?.value === before[0]?.value) from = before.length;
    if (page?.status === 'unsupported') return {
      status: 'unavailable'
    };
    if (!page || page.status === 'error' || page.status === 'loading') throw new Error(setText(host, 'recordsError'));
    const items = (Array.isArray(page.items) ? page.items : []).slice(from).map(lookupItem).filter(Boolean);
    return {
      items,
      nextCursor: page.nextCursor ?? null
    };
  };
} // The page a host pages answers a hundred at most: the lookup cuts an answer
// to max-results, and a host page is the host's own size.


const HOST_PAGE_MOST = 100;

function renderHostLookup(field, value, host, {
  multiple,
  placeholder
}) {
  // What the lookup says it chose, in the shape the set writes: {value,
  // label}, or a list of them when multiple.
  const resolved = item => ({
    value: item.value,
    label: String(item.label ?? item.value)
  });

  const write = event => {
    if (event.target !== event.currentTarget) return;
    const next = event.detail?.value ?? event.target?.value;

    if (multiple) {
      host.setFieldValue(field, (Array.isArray(next) ? next : []).map(resolved));
      return;
    }

    host.setFieldValue(field, next && typeof next === 'object' ? resolved(next) : null);
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-field-picker flex flex-col gap-1/3" data-field-picker=${field.key || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>
            <sf-input-lookup
                    size=${EDIT_SIZE}
                    ?multiple=${multiple}
                    suggest
                    min-length="1"
                    max-results=${String(HOST_PAGE_MOST)}
                    name=${fieldName(field)}
                    ?required=${Boolean(field.required)}
                    ?disabled=${EDIT_DISABLED}
                    placeholder=${field.placeholder || placeholder}
                    aria-label=${field.label || field.key || ''}
                    .value=${value ?? (multiple ? [] : null)}
                    .provider=${hostProvider(field, host)}
                    @change=${write}
            ></sf-input-lookup>
        </div>
    `;
} // The record picker: a record, a relation or a user, one value, searched and
// paged by the host (C139 (1)).


function renderRecordLookup(field, value, host) {
  if (dropdownPicker()) return renderRecordPicker(field, value, host);
  if (!host.loadFieldOptions || !host.getFieldOptionsPage) return null;
  const page = host.getFieldOptionsPage(field) || null; // A host that refused this field's candidates has none to give: the field
  // falls back to its value, read-only, as the dropdown path did.

  if (page?.status === 'unsupported') return null;
  const chosen = value && typeof value === 'object' ? value : null;
  return renderHostLookup(field, chosen, host, {
    multiple: false,
    placeholder: setText(host, 'pickRecord')
  });
} // DEPRECATED until 2027-01-01 (C139 (1)): the record picker as a searchable
// sf-dropdown, for a host that asks {picker: 'dropdown'}.


function renderRecordPicker(field, value, host) {
  if (!host.loadFieldOptions || !host.getFieldOptionsPage) return null;
  const page = host.getFieldOptionsPage(field) || null; // A host that refused this field's candidates has none to give, now or ever.
  // Returning nothing here puts the field on the read-only fallback, which shows
  // the value it holds -- rather than an empty picker and a retry that cannot
  // succeed, over a value that is actually there.

  if (page?.status === 'unsupported') return null;
  const search = host.getFieldOptionSearch?.(field) ?? '';
  const chosen = value && typeof value === 'object' ? value : null;
  const items = Array.isArray(page?.items) ? page.items : []; // What is chosen stays in the list even when the page does not hold it --
  // the common case at 448 targets, and the one that makes a picker look like
  // it has forgotten the answer.

  const options = [...(chosen && !items.some(item => String(item.value) === String(chosen.value)) ? [chosen] : []), ...items].map(item => ({
    type: 'text',
    size: '1',
    text: String(item.label ?? item.value),
    value: String(item.value),
    selected: Boolean(chosen && String(chosen.value) === String(item.value))
  }));

  const pick = next => {
    if (!next) {
      host.setFieldValue(field, null);
      return;
    }

    const found = [chosen, ...items].find(item => item && String(item.value) === String(next));
    host.setFieldValue(field, found ? {
      value: found.value,
      label: found.label
    } : {
      value: next
    });
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-field-picker flex flex-col gap-1/3" data-field-picker=${field.key || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>
            <sf-dropdown
                    size=${EDIT_SIZE}
                    appearance="bordered"
                    mode="select"
                    search="true"
                    name=${fieldName(field)}
                    ?required=${Boolean(field.required)}
                    value=${chosen ? String(chosen.value) : ''}
                    placeholder=${field.placeholder || setText(host, 'pickRecord')}
                    search-placeholder=${field.searchPlaceholder || setText(host, 'searchRecords')}
                    aria-label=${field.label || field.key || ''}
                    .options=${options}
                    @change=${event => pick(event.detail?.value ?? null)}
                    @input=${event => {
    const text = event.target?.value ?? '';
    host.setFieldOptionSearch?.(field, text);
    host.loadFieldOptions(field, {
      cursor: null,
      search: text
    });
  }}
            ></sf-dropdown>
            ${page ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <div class="sf-field-picker-state flex items-cross-center gap-1/3">
                    <div role="status" aria-live="polite" class="sf-text-1">
                        ${page.status === 'loading' && !page.quiet ? setText(host, 'loadingRecords') : page.status === 'error' ? setText(host, 'recordsError') : ''}
                    </div>
                    ${page.status === 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-button appearance="outline" size="1" text=${setText(host, 'retry')}
                                @click=${() => host.loadFieldOptions(field, {
    cursor: null,
    search
  })}
                        ></sf-button>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    ${page.nextCursor && page.status !== 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-button appearance="outline" size="1" text=${setText(host, 'loadMore')}
                                ?disabled=${page.status === 'loading'}
                                @click=${() => host.loadFieldOptions(field, {
    cursor: page.nextCursor,
    search
  })}
                        ></sf-button>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                </div>
            ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        </div>
    `;
} // The lookup: a value chosen from a reference list the host keeps (Larena,
// 2026-10-23). It is the record picker's arrangement -- the host pages and
// searches, what is chosen stays shown whether or not the page holds it -- with
// the two things a reference list has that a record does not:
//
//   options   a short list arrives whole, as the field's own `options`, and is
//             chosen from in place: no page is asked for and the dropdown's own
//             search is right here, because the list in hand is the whole set.
//             A page is never searched in place -- it is not the whole set.
//   multiple  several values, each {value, label}, written back as a list.
//
// The value is {value, label}, or a list of them, and the control writes the
// same shape back: the label travels with the value so the host never resolves
// what it already knew, and a view of the value needs no second read.


function lookupItems(field, value) {
  const list = Array.isArray(value) ? value : [value];
  const options = Array.isArray(field.options) ? field.options : [];
  return list.filter(item => item !== null && typeof item !== 'undefined' && item !== '').map(item => {
    if (typeof item === 'object') return {
      value: item.value,
      label: String(item.label ?? item.value ?? '')
    }; // A bare value is read against the field's own list, so a host that
    // sends the inline options and the value alone is still shown a name.

    const option = options.find(candidate => String(candidate?.value) === String(item));
    return {
      value: item,
      label: String(option?.label ?? option?.text ?? item)
    };
  });
}

function renderLookupEdit(field, value, host) {
  const multiple = field.multiple === true;
  const inline = Array.isArray(field.options) && field.options.length > 0; // A list the host pages needs a host that pages; without one the field falls
  // back to its value, read-only, as a record does.

  if (!inline && (!host.loadFieldOptions || !host.getFieldOptionsPage)) return null; // A paged list is the lookup's (C139 (1)); a short list given whole stays
  // the dropdown's, and so does the deprecated dropdown path.

  if (!inline && !dropdownPicker()) {
    if (host.getFieldOptionsPage(field)?.status === 'unsupported') return null;
    return renderHostLookup(field, value, host, {
      multiple,
      placeholder: setText(host, 'pickFromList')
    });
  }

  const page = inline ? null : host.getFieldOptionsPage(field) || null;
  if (page?.status === 'unsupported') return null;
  const search = inline ? '' : host.getFieldOptionSearch?.(field) ?? '';
  const chosen = lookupItems(field, value);
  const candidates = (inline ? field.options : Array.isArray(page?.items) ? page.items : []).filter(item => item && typeof item === 'object').map(item => ({
    value: item.value,
    label: String(item.label ?? item.text ?? item.value)
  }));

  const isChosen = item => chosen.some(one => String(one.value) === String(item.value));

  const options = [...chosen.filter(item => !candidates.some(candidate => String(candidate.value) === String(item.value))), ...candidates].map(item => ({
    type: 'text',
    size: '1',
    text: item.label,
    value: String(item.value),
    selected: isChosen(item)
  })); // What the dropdown reports is the value as a string; the label and the
  // value's own type are taken back from what was offered.

  const known = [...chosen, ...candidates];

  const resolve = raw => {
    const found = known.find(item => String(item.value) === String(raw));
    return found ? {
      value: found.value,
      label: found.label
    } : {
      value: raw,
      label: String(raw)
    };
  };

  const write = event => {
    if (multiple) {
      const next = event.detail?.values ?? event.detail?.value;
      const values = (Array.isArray(next) ? next : next ? [next] : []).filter(item => item !== '');
      host.setFieldValue(field, values.map(resolve));
      return;
    }

    const next = event.detail?.value ?? null;
    host.setFieldValue(field, next === null || next === '' ? null : resolve(next));
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-field-picker flex flex-col gap-1/3" data-field-picker=${field.key || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>
            <sf-dropdown
                    size=${EDIT_SIZE}
                    appearance="bordered"
                    mode="select"
                    ?multiple=${multiple}
                    search="true"
                    name=${fieldName(field)}
                    ?required=${Boolean(field.required)}
                    value=${multiple ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : chosen[0] ? String(chosen[0].value) : ''}
                    placeholder=${field.placeholder || setText(host, 'pickFromList')}
                    search-placeholder=${field.searchPlaceholder || setText(host, 'searchInList')}
                    aria-label=${field.label || field.key || ''}
                    .options=${options}
                    @change=${write}
                    @input=${inline ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : event => {
    const text = event.target?.value ?? '';
    host.setFieldOptionSearch?.(field, text);
    host.loadFieldOptions(field, {
      cursor: null,
      search: text
    });
  }}
            ></sf-dropdown>
            ${page ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <div class="sf-field-picker-state flex items-cross-center gap-1/3">
                    <div role="status" aria-live="polite" class="sf-text-1">
                        ${page.status === 'loading' && !page.quiet ? setText(host, 'loadingOptions') : page.status === 'error' ? setText(host, 'optionsError') : ''}
                    </div>
                    ${page.status === 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-button appearance="outline" size="1" text=${setText(host, 'retry')}
                                @click=${() => host.loadFieldOptions(field, {
    cursor: null,
    search
  })}
                        ></sf-button>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    ${page.nextCursor && page.status !== 'error' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-button appearance="outline" size="1" text=${setText(host, 'loadMore')}
                                ?disabled=${page.status === 'loading'}
                                @click=${() => host.loadFieldOptions(field, {
    cursor: page.nextCursor,
    search
  })}
                        ></sf-button>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                </div>
            ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        </div>
    `;
} // The `file` edit control, composed from the two halves that already exist:
// sf-file-preview for what is stored, sf-file-upload for what is arriving. They
// are not interchangeable and the split is not cosmetic -- the preview carries
// href, download and remove, the upload zone carries progress, retry and the
// selection itself. Neither renders the other's state, so a field that both
// holds files and accepts new ones needs both.
//
// sf-file-upload transfers no bytes. It selects files, keeps an `items` list of
// {state, progress, name, fileSize, errorMessage}, and emits events; the
// transfer is the host's, which is why this renderer asks the host for it
// rather than inventing an endpoint inside the set:
//
//   host.startFieldUpload(field, items)  -- begin transferring; the host writes
//                                           the stored value when a file lands
//   host.getFieldUploads(field)          -- the items in flight, upload-shaped
//   host.retryFieldUpload(field, index)  -- optional; without it, no retry
//   host.setFieldValue(field, next)      -- as every edit renderer
//
// Without the first two the zone is not rendered at all and the stored files
// stay editable, because removing a file that is already there needs no
// transfer. A zone that cannot upload is worse than no zone.
//
// `items` has one writer, and that is the host. The component fills its own
// list the moment files are chosen, but every render writes the host's list
// over it -- so a host that records what `startFieldUpload` was handed sees the
// files it selected, and a host that ignores them watches its own selection
// disappear on the next render. The selected items arrive already in the
// component's own shape, each carrying the real File in `.file`, so recording
// them is a push and not a conversion.


function storedFiles(value) {
  if (Array.isArray(value)) return value.filter(item => item && typeof item === 'object');
  return value && typeof value === 'object' ? [value] : [];
} // One image, edited in place (simai/ui-source#27). A `file` field whose
// variant is `image` and which holds one file -- a logo, a cover, the picture
// of a block -- is what sf-image-field is for: the thumbnail with the name and
// size, «Заменить…», «Убрать», and a file dropped on it replaces the image. The
// preview-and-zone pair below stays for everything else: a field the host
// declares `multiple`, a list that already holds several, the card and list
// variants, and a file that is not an image. Which fields are images is the
// host's to say through the variant, as in the view and the cell.
//
// sf-image-field transfers no bytes either. Its change carries the value in the
// file shape -- a chosen file with the File in `file` and an object URL in
// `href`, null after «Убрать» -- and that goes through setFieldValue as every
// other control's value does, so the record the host holds is what the person
// sees. A host that uploads (startFieldUpload) is handed the File as well, in
// an item carrying it in `.file` as the file control's selection does, and
// writes the stored value with its lasting address when the file lands. A
// value that came as a list of one goes back as a list, so a host reads back
// the shape it sent.
//
// The value is bound as a property, never as the attribute: the attribute is
// JSON, which a File does not survive, and a changed attribute releases the
// object URL the thumbnail is showing. The panel prints the label, so the field
// takes it as its accessible name only.


function isSingleImageField(field, value) {
  return String(field.variant ?? '') === 'image' && field.multiple !== true && storedFiles(value).length <= 1;
}

function renderImageEdit(field, value, host) {
  const stored = storedFiles(value)[0] ?? null;
  const asList = Array.isArray(value);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-input-image
                size=${EDIT_SIZE}
                name=${fieldName(field)}
                accept=${field.accept ? String(field.accept) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                hint=${field.uploadSupportingText || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                .value=${stored}
                aria-label=${field.label || field.key || ''}
                ?required=${Boolean(field.required)}
                ?readonly=${field.readonly === true}
                @change=${event => {
    const next = event.detail?.value ?? null;
    host.setFieldValue(field, asList ? next ? [next] : [] : next);
    const file = event.detail?.file;

    if (file && host.startFieldUpload) {
      host.startFieldUpload(field, [{
        name: file.name,
        state: 'process',
        progress: 0,
        file
      }]);
    }
  }}
        ></sf-input-image>
    `;
}

function renderFileEdit(field, value, host) {
  if (isSingleImageField(field, value)) return renderImageEdit(field, value, host);
  const files = storedFiles(value);
  const multiple = field.multiple === true || Array.isArray(value);
  const canUpload = Boolean(host.startFieldUpload && host.getFieldUploads);
  const uploads = canUpload ? host.getFieldUploads(field) : null;
  const items = Array.isArray(uploads) ? uploads : []; // «×» takes a file out of the field at once, and the notice gives it back
  // with «Вернуть» (decisions C25, C149 (8)): the field's value before the
  // removal is set again.

  const drop = index => {
    const before = value;
    const next = files.filter((_, position) => position !== index);
    host.setFieldValue(field, multiple ? next : next[0] ?? null);
    const removed = files[index];
    globalThis.SF?.notify?.({
      status: 'neutral',
      title: setText(host, 'fileRemoved'),
      text: String(removed?.label ?? removed?.name ?? ''),
      source: 'sf-file-preview',
      action: {
        label: setText(host, 'undo'),
        onSelect: () => host.setFieldValue(field, before)
      }
    });
  };

  const readonly = field.readonly === true; // download-action and remove-action both read true when the attribute is
  // absent, so a file with no href has to say false rather than drop it.

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-field-file flex flex-col">
            ${files.map((file, index) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <sf-file-preview
                        file-name=${String(file.label ?? file.name ?? 'File')}
                        file-size=${String(file.size ?? '')}
                        icon=${fileIcon(file.mime ?? file.mimeType)}
                        mime-type=${String(file.mime ?? file.mimeType ?? '')}
                        href=${file.href ? String(file.href) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        download-action=${file.href ? 'true' : 'false'}
                        remove-action=${readonly ? 'false' : 'true'}
                        remove-label=${`${setText(host, 'removeFile')} ${file.label ?? file.name ?? ''}`.trim()}
                        @sf-file-preview-detach=${() => drop(index)}
                ></sf-file-preview>
            `)}

            ${canUpload ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-file-upload
                                size=${EDIT_SIZE}
                                name=${fieldName(field)}
                                accept=${String(field.accept ?? '')}
                                formats=${String(field.formats ?? '')}
                                link-text=${field.uploadText || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                text=${field.uploadHint || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                supporting-text=${field.uploadSupportingText || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                ?multiple=${multiple}
                                ?disabled=${field.readonly === true}
                                aria-label=${field.label || field.key || ''}
                                .items=${items}
                                @sf-file-upload:select=${event => {
    const picked = event.detail?.files;
    const list = Array.isArray(picked) ? picked : [];
    if (list.length) host.startFieldUpload(field, list);
  }}
                                @sf-file-upload:retry=${event => {
    host.retryFieldUpload?.(field, Number(event.detail?.index ?? -1));
  }}
                        ></sf-file-upload>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        </div>
    `;
} // The control a field is edited with, or null when the set has none for that
// type yet.


const sizeOption = options => options?.size === '1/2' ? '1/2' : '1'; // `options.density`: 'compact' or 'normal', the density the control is drawn in
// (owner decision C22; form study FM-5). Without it the control follows the
// region it stands in, as every component does; with it the host sets the
// region for this field alone -- a compact panel asks for 'compact' instead of
// shrinking the field with size '1/2', which C22 forbids. Anything else is no
// density at all.


const DENSITIES = new Set(['compact', 'normal']);

const densityOption = options => DENSITIES.has(options?.density) ? options.density : ''; // `options.apply`: 'instant' when a change acts at once (a settings panel, the
// parameters of a block), anything else for a form saved with a button. Read by
// the yes/no field only: a switch at once, a checkbox in a form (C165 (4)).


let EDIT_APPLY = ''; // A control that stays a control when it may not be changed: a choice as
// buttons shows which button is chosen, which is what it is for, where the
// view's badge would show a different thing (port 1.16.0).

const keepsControlWhenLocked = (asked, field) => asked === 'choice' && isChoiceButtons(field); // `options.disabled`: the control is drawn disabled, not read-only -- a field a
// condition turns off for now (port 1.14.0 `when.enabled`), which the host
// knows and the field does not carry. Read by the controls that draw the two
// differently; for every other one a disabled field is a read-only one.


let EDIT_DISABLED = false; // `options.error`: what is wrong with the field now, a sentence, or empty (PD-1,
// property type study «Дата»). A control that says its own error (sf-input-date
// for a date, a datetime and a time) is drawn invalid with the sentence under
// it, the error-message of the field family, so a host that is not sf-form --
// a record card -- marks the field itself instead of writing a line under a
// field with a normal border. sf-form keeps setting invalid on the controls it
// draws, as before.

let EDIT_ERROR = '';
function renderEditField(field = {}, value, host, options = {}) {
  const asked = field.propertyType || field.type || field.dataType;
  const disabled = options?.disabled === true; // A field the person may not change is shown, not offered as a control that
  // refuses: the same rule for every type, so `readonly` means one thing
  // wherever the registry lists it.

  if ((field.readonly === true || disabled) && VIEW_RENDERERS[asked] && !keepsControlWhenLocked(asked, field)) {
    return renderViewField(field, value, host, options);
  }

  const renderer = EDIT_RENDERERS[asked];
  if (!renderer || !host?.setFieldValue) return null;
  const outer = EDIT_SIZE;
  const outerDisabled = EDIT_DISABLED;
  const outerPicker = EDIT_PICKER;
  const outerApply = EDIT_APPLY;
  const outerError = EDIT_ERROR;
  EDIT_SIZE = sizeOption(options);
  EDIT_ERROR = typeof options?.error === 'string' ? options.error.trim() : '';
  EDIT_DISABLED = disabled; // `options.picker: 'dropdown'`: the record, relation, user and paged lookup
  // fields drawn as before C139, a searchable sf-dropdown (until 2027-01-01).

  EDIT_PICKER = options?.picker === 'dropdown' ? 'dropdown' : '';
  EDIT_APPLY = options?.apply === 'instant' ? 'instant' : '';

  try {
    return inDensity(renderer(field, value, host), densityOption(options));
  } finally {
    EDIT_SIZE = outer;
    EDIT_DISABLED = outerDisabled;
    EDIT_PICKER = outerPicker;
    EDIT_APPLY = outerApply;
    EDIT_ERROR = outerError;
  }
} // A density asked for one field is a region around it that draws no box of its
// own: the variables of the density rules (core/scss/_sf_css__density.scss)
// stand on it and every part of the control inherits them, the popups it opens
// read it (core/js/density.js densityOf), and the control lays out in the
// host's flex or grid as if the wrapper were not there. No density, no wrapper:
// what a host had is unchanged.

function inDensity(content, density) {
  if (!density || content == null) return content;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-field-density" style="display: contents" data-sf-density=${density}>${content}</div>`;
} // The view template: a field shown and not edited, which is the fourth of the
// four the assignment names and the last one the set was missing.
//
// It renders lit templates rather than the host-shaped values the cell template
// returns, because its consumer is a record view rendering into its own layout,
// exactly as the edit template's is. The cell template returns host shapes only
// because sf-view-table already had a path for those.
//
// `line` and not `size` for everything that sits beside a label on one text
// line -- a badge, a tag, an avatar, a reference link. A size would give those a
// control's height and stand them taller than the words next to them, which is
// the mistake the cell template already avoids one rung down. The two that are
// not inline keep their own scale: a scale bar is a control, and a file preview
// has no visual size at all, its `size` being a legacy name for the file's size
// as text.
// The line a viewed value is drawn on: 1, or 1/2 with {size: '1/2'}, as above.


let VIEW_LINE = '1'; // A scalar may arrive as the value itself or as {value, text}: the data and the
// host's own formatting of it. The consumer asked for the second and they are
// right -- the Framework has no locale and should not acquire one through a field
// renderer. They already hold the localised text, the viewer's locale and the
// format rules, and a second formatter here would disagree with theirs the first
// time a format setting changed. `text` is the formatted value alone; a unit
// stays its own field so a column of numbers can align its units.

function carriesText(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value) && typeof value.text === 'string';
}

function scalarValue(value) {
  return carriesText(value) ? value.value : value;
}

function viewText(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  if (typeof formatted === 'string') return formatted;
  if (carriesText(value)) return value.text;
  const plain = scalarValue(value);
  return plain === null || typeof plain === 'undefined' ? '' : String(plain);
}

function renderTextView(field, value, host) {
  const text = viewText(field, value, host);
  return text ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${text}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
} // Formatted text shown: the value cleaned by sf-input-rich's own rule first,
// and only that cleaned string drawn as markup -- never the value as it came,
// which a host may have stored from anywhere. What is left is the subset:
// paragraphs, headings, emphasis, lists, quotes and links with a safe address.


function renderHtmlView(field, value) {
  const clean = (0,_html_js__WEBPACK_IMPORTED_MODULE_8__.cleanHtml)(value);
  return clean ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-field-view sf-field-html">${(0,lit_directives_unsafe_html_js__WEBPACK_IMPORTED_MODULE_1__.unsafeHTML)(clean)}</div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
} // A number in the page's language (set boundary study, 2026-11-17): «12,5 кг»
// on a Russian page, «12.5 kg» on an English one, through Intl with every
// digit the value has (decimal.js formatDecimal, never through a float on the
// way). The host's formatFieldValue and a value's own text still win; what is
// not a number is shown as it came.


function numberText(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  if (typeof formatted === 'string') return formatted;
  if (carriesText(value)) return value.text;
  return (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatDecimal)(scalarValue(value), (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null)) || viewText(field, value, null);
} // A number carries its unit when the field declares one, and nothing when it
// does not -- the set does not guess at a unit, and «42» with an invented «шт»
// beside it is a worse answer than «42».


function renderNumberView(field, value, host) {
  if (value === null || typeof value === 'undefined' || value === '') return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const variant = field.variant || field.filter?.variant; // The scale needs the number, not the host's text for it.

  const number = Number(scalarValue(value));

  if (variant === 'scale' && Number.isFinite(number) && number >= 0 && number <= 100) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-progress-scale size="1" value=${String(number)}></sf-progress-scale>`;
  }

  if (variant === 'meter' && Number.isFinite(number) && number >= 0 && number <= 100) {
    const {
      label
    } = meterProps(field, number);
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-progress-bar inline meter value=${String(number)} label=${label || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}></sf-progress-bar>`;
  }

  const text = numberText(field, value, host);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${field.unit ? `${text} ${field.unit}` : text}</span>`;
} // A date is the host's to format first: formatFieldValue wins, and so does a
// value that carries its own text. Without it the set used to print the stored
// form -- «2026-10-25T10:30:00+03:00» (simai/ui-source#34) -- so a host that
// formats nothing gets the page's medium reading through core format-date:
// «2 нояб. 2026 г.» / «Nov 2, 2026» for a date, «15 нояб. 2026 г., 10:30» /
// «Nov 15, 2026, 10:30 AM» for a datetime, the form the View set's table
// printed before the renderers formatted dates (C19: the set formats, the
// table inherits). The day and the clock are the record's own (datetime.js
// reads them as written, in the host's zone): nothing is moved to the reader's
// time zone, which would show a different day near midnight. A value that is
// not a date at all is shown as it came, never guessed at.
//
// `format` is the field's display setting (PD-3): the length of the date,
// Intl's dateStyle in the page's language -- short «17.11.2026» / «11/17/26»,
// medium (the default) «17 нояб. 2026 г.» / «Nov 17, 2026», long «17 ноября
// 2026 г.» / «November 17, 2026», full with the weekday. A datetime keeps its
// clock beside it. It is read by the view and the cell; the edit control
// types the locale's digits whatever it says. Any other value is medium, and
// the host's formatFieldValue or text still wins.


const DATE_FORMATS = new Set(['short', 'medium', 'long', 'full']);

function dateFormatOf(field) {
  const format = String(field?.format ?? '').trim();
  return DATE_FORMATS.has(format) ? format : 'medium';
}

function defaultDateText(field, value, host) {
  if (carriesText(value)) return null;
  const parts = (0,_datetime_js__WEBPACK_IMPORTED_MODULE_6__.splitDateTime)(value);
  if (!parts.known || !parts.date) return null;
  const [year, month, day] = parts.date.split('-').map(Number);
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);

  try {
    const date = new Date(0);
    date.setUTCFullYear(year, month - 1, day);
    const type = field?.propertyType || field?.type || field?.dataType;
    const dateStyle = dateFormatOf(field);
    if (type !== 'datetime' || !parts.time) return (0,_core_js_format_date_js__WEBPACK_IMPORTED_MODULE_4__.formatDate)(date, {
      intl: {
        dateStyle,
        timeZone: 'UTC'
      },
      locale
    }) || null;
    const [hours, minutes] = parts.time.split(':').map(Number);
    date.setUTCHours(hours, minutes, 0, 0);
    return (0,_core_js_format_date_js__WEBPACK_IMPORTED_MODULE_4__.formatDate)(date, {
      intl: {
        dateStyle,
        timeStyle: 'short',
        timeZone: 'UTC'
      },
      locale
    }) || null;
  } catch {
    return null;
  }
}

function dateText(field, value, host) {
  const formatted = host?.formatFieldValue?.(field, value);
  if (typeof formatted === 'string') return formatted;
  return defaultDateText(field, value, host) ?? viewText(field, value, null);
} // The machine reading of a date (C40: every moment the Framework prints is a
// time element): the record's own day and clock as written, «2026-11-15» or
// «2026-11-15T10:30», with no zone, because the view never moves a record to
// the reader's zone. That is also why the view is not sf-time, which reads a
// moment in the reader's zone: a date near midnight would show another day.
// '' when the value is no date.


function dateTimeAttribute(field, value) {
  const parts = (0,_datetime_js__WEBPACK_IMPORTED_MODULE_6__.splitDateTime)(value);
  if (!parts.known || !parts.date) return '';
  const type = field?.propertyType || field?.type || field?.dataType;
  return type === 'datetime' && parts.time ? `${parts.date}T${parts.time}` : parts.date;
}

function renderDateView(field, value, host) {
  const text = dateText(field, value, host);
  if (!text) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const datetime = dateTimeAttribute(field, value);
  return datetime ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<time class="sf-field-view" datetime=${datetime}>${text}</time>` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${text}</span>`;
}

function renderBooleanView(field, value, host) {
  if (typeof value !== 'boolean') return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const words = booleanWords(field, host);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${value ? words.yes : words.no}</span>`;
}

function renderChoiceView(field, value) {
  const options = field.options || field.filter?.options || field.constraints?.options;
  const option = Array.isArray(options) ? options.find(item => String(item?.value) === String(value)) : null;
  if (!option) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const badge = (0,_helpers_option_badge_js__WEBPACK_IMPORTED_MODULE_2__.optionBadgeProps)(option); // A table cell is a dense place: the badge keeps the tight side room
  // (sf-badge tight), as it had before sf-badge 1.3.0 widened the default.

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-badge
                line=${VIEW_LINE}
                tight
                appearance=${field.badgeAppearance ?? CELL_BADGE_APPEARANCE}
                scheme=${badge.scheme}
                style=${badge.rootStyle || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                text=${String(option.label ?? option.text ?? value)}
        ></sf-badge>
    `;
} // The values wrap, each tag as wide as its text: on one unwrapping line a
// role's 137 rights shrank every tag to a letter and the text ran down the
// panel (Larena, 2026-10-17). The tag's painted root is the flex item (the
// host is display: contents), so it is told not to shrink through root-class.
// No disclosure for a long list here: a record's
// field in view is the button that opens its group, and a control inside a
// button is not one.


function renderChoicesView(field, value) {
  if (!Array.isArray(value) || !value.length) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const options = field.options || field.filter?.options || field.constraints?.options;

  const label = item => {
    const option = Array.isArray(options) ? options.find(candidate => String(candidate?.value) === String(item)) : null;
    return String(option?.label ?? option?.text ?? item);
  };

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <span class="sf-field-view flex flex-wrap items-cross-center gap-1/3 min-w-0">
            ${value.map(item => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-tag root-class="flex-none" line=${VIEW_LINE} kind="default" text=${label(item)}></sf-tag>`)}
        </span>
    `;
} // A person, as in a cell: the name links to the person when the host gives
// the href -- every value that points at a record opens it (owner,
// 2026-10-14). Plain, as a reference read in a record's field is.


function renderUserView(field, value) {
  if (!value || typeof value !== 'object' || !value.label) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <span class="sf-field-view flex items-cross-center gap-1/3">
            <sf-avatar line=${VIEW_LINE} text=${value.avatarText || ''} heading=${String(value.label)}></sf-avatar>
            ${value.href ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-reference-link appearance="plain" icon="" line=${VIEW_LINE}
                        label=${String(value.label)} href=${String(value.href)}></sf-reference-link>` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span>${String(value.label)}</span>`}
        </span>
    `;
}

function renderReferenceView(field, value) {
  if (!value || typeof value !== 'object' || !value.label) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing; // Plain, and without the arrow: a reference read inside a record's field is
  // a value on a line, not a card. The card's frame and fill drew a second box
  // around a value that already sits in one, and the arrow said «go» beside a
  // word that is already a link (owner, 2026-10-08).

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <sf-reference-link
                appearance="plain"
                icon=""
                line=${VIEW_LINE}
                label=${String(value.label)}
                href=${value.href ? String(value.href) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        ></sf-reference-link>
    `;
} // A value from a reference list reads as its label; several read as their
// labels, each a tag as a list of choices does. Not a link: nothing opens from a
// country or a status.


function renderLookupView(field, value) {
  const items = lookupItems(field, value);
  if (!items.length) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  if (items.length === 1 && field.multiple !== true) return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-field-view">${items[0].label}</span>`;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <span class="sf-field-view flex flex-wrap items-cross-center gap-1/3 min-w-0">
            ${items.map(item => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-tag root-class="flex-none" line=${VIEW_LINE} kind="default" text=${item.label}></sf-tag>`)}
        </span>
    `;
} // The one place the view template is not a smaller edit control: a stored file
// is shown with its own preview, which carries the download the view wants and
// not the remove an edit does.


function renderFileView(field, value) {
  const files = storedFiles(value);
  if (!files.length) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing; // An image is shown as the image. `image-url` and `kind` are inputs the file
  // preview already has, so this is the same component told what it is holding
  // rather than a second way of drawing a file. Which files are images is the
  // host's to say through the variant: guessing from a file name would be wrong
  // for every stored file whose name does not end in a familiar three letters.

  const asImage = isImageField(field);
  const card = String(field.variant ?? '') === 'image-card';
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <span class="sf-field-view flex ${card ? 'flex-row' : 'flex-col'} gap-1/3">
            ${files.map(file => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <sf-file-preview
                        file-name=${String(file.label ?? file.name ?? 'File')}
                        file-size=${String(file.size ?? '')}
                        icon=${fileIcon(file.mime ?? file.mimeType)}
                        mime-type=${String(file.mime ?? file.mimeType ?? '')}
                        href=${file.href ? String(file.href) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        image-url=${asImage && file.href ? String(file.href) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        kind=${asImage ? 'image' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        download-action=${file.href ? 'true' : 'false'}
                        remove-action="false"
                ></sf-file-preview>
            `)}
        </span>
    `;
}

const VIEW_RENDERERS = {
  string: renderStringView,
  text: renderTextView,
  html: renderHtmlView,
  integer: renderNumberView,
  number: renderNumberView,
  date: renderDateView,
  datetime: renderDateView,
  time: renderDateView,
  boolean: renderBooleanView,
  choice: renderChoiceView,
  choices: renderChoicesView,
  user: renderUserView,
  record: renderReferenceView,
  relation: renderReferenceView,
  lookup: renderLookupView,
  file: renderFileView,
  color: renderColorView,
  include: renderIncludeView,
  money: renderMoneyView,
  percent: renderPercentView
}; // A field shown rather than edited. `host` is optional and used for one thing
// only -- formatFieldValue, where a consumer's own formatting of a number or a
// date belongs. Null when the set has no view for that type.
// A column total (owner decision C294, MP-12): the table owns its totals
// row, the set gives the sum by the digits and its display. Money is summed
// per currency -- a column of dollars and euros is two lines, never one
// number -- and a number or an integer is one sum; a percent, a choice or a
// text has no total (null). `values` are the column's stored values; what is
// not a number is left out.

function renderTotalField(field = {}, values = [], host) {
  const type = field.propertyType || field.type || field.dataType;
  const locale = (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(host ?? null);
  const list = (Array.isArray(values) ? values : []).map(value => scalarValue(value));

  if (type === 'money') {
    const totals = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.moneyTotals)(list, field, locale);
    return totals.length ? totals.map(total => total.text) : null;
  }

  if (type !== 'number' && type !== 'integer') return null;
  const numbers = list.filter(value => value !== null && value !== undefined && value !== '' && (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(value).ok);
  if (!numbers.length) return null;
  const sum = (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.addDecimal)(numbers);
  return sum === null ? null : [(0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatDecimal)(sum, locale)];
} // Whether a type is a number a table aligns to the end of the line with
// figures of one width (the registry's `numeric`, C294 MP-12).

function isNumericType(type) {
  return Boolean(_registry_js__WEBPACK_IMPORTED_MODULE_5__.PROPERTY_TYPES.find(entry => entry.type === type)?.numeric);
}
function propertyModes(type) {
  return (0,_registry_js__WEBPACK_IMPORTED_MODULE_5__.modesOf)(type, {
    view: VIEW_RENDERERS,
    edit: EDIT_RENDERERS,
    cell: CELL_RENDERERS,
    filter: FILTER_RENDERERS
  });
}

function renderViewField(field = {}, value, host, options = {}) {
  const asked = field.propertyType || field.type || field.dataType;
  const renderer = VIEW_RENDERERS[asked];
  if (!renderer) return null;
  const outer = VIEW_LINE;
  VIEW_LINE = sizeOption(options);

  try {
    return inDensity(renderer(field, value, host), densityOption(options));
  } finally {
    VIEW_LINE = outer;
  }
} // A host has to be able to reach the set, and a module is not an element: there
// is no tag to place and no attribute to set. The Framework already has one
// place for what a page may call -- window.SF, where the base element, `html`,
// `nothing` and `render` live -- so the set publishes itself there under its own
// name. Without this the module is built, bundled and unreachable: the consumer
// could read the mapping and not call it, which was true of this set until now.
//
// This is the runtime half of the discoverability question. The other half --
// describing the module in the registry, so a host learns what it offers without
// reading our source -- is with the registry's owner.

if (typeof window !== 'undefined') {
  window.SF = window.SF || {};
  window.SF.fieldRenderers = { ...(window.SF.fieldRenderers || {}),
    renderCellField,
    renderEditField,
    renderFilterField,
    renderViewField,
    renderTotalField,
    FILTER_RENDERERS,
    // The nine number conditions in the filter's order (C294).
    NUMBER_FILTER_OPERATORS,
    isNumericType,
    // Decimal strings as the set reads and shows them (C294): the View
    // set's items, compound and ru.requisites call these instead of
    // keeping a copy. format(value), money(value, field), percent(value)
    // take a locale (the page's when absent); read(text, {locale,
    // currency}) reads what a person typed or pasted; add(...values) and
    // compare(a, b) work by the digits; totals(values, field) sums money
    // per currency; currency(code, locale, display) is {sign, before, minor}.
    decimal: {
      format: (value, locale) => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatDecimal)(value, locale || (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(null)),
      money: (value, field = {}, locale) => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatMoney)(value, field, locale || (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(null)),
      percent: (value, locale) => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.formatPercent)(value, locale || (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(null)),
      read: (text, options = {}) => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.readTypedDecimal)(text, {
        locale: (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(null),
        ...options
      }),
      add: _decimal_js__WEBPACK_IMPORTED_MODULE_10__.addDecimal,
      compare: _decimal_js__WEBPACK_IMPORTED_MODULE_10__.compareDecimal,
      totals: (values, field = {}, locale) => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.moneyTotals)(values, field, locale || (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(null)),
      currency: (code, locale, display) => (0,_decimal_js__WEBPACK_IMPORTED_MODULE_10__.currencyOf)(code, locale || (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_3__.pageLocale)(null), display)
    },
    // The date filter's rules (C293): the chip's words, when an entry is
    // empty, the request with its context, a period's days.
    dateFilter: {
      conditions: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateFilterConditions,
      chipText: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.dateFilterChipText,
      isEmptyEntry: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.isEmptyFilterEntry,
      normalizeEntry: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.normalizeFilterEntry,
      requestContext: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.filterRequestContext,
      buildRequest: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.buildFilterRequest,
      resolvePeriod: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.resolveDatePeriod,
      periods: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_PERIODS,
      futurePeriods: _date_filter_js__WEBPACK_IMPORTED_MODULE_13__.DATE_FUTURE_PERIODS
    },
    // A datetime's value read and written back, for a host that draws its
    // own control: split(value), compose(stored, {date, time}),
    // normalizeTime(text); and a time of day's: splitTime(value),
    // composeTime(stored, text).
    dateTime: {
      split: _datetime_js__WEBPACK_IMPORTED_MODULE_6__.splitDateTime,
      compose: _datetime_js__WEBPACK_IMPORTED_MODULE_6__.composeDateTime,
      normalizeTime: _datetime_js__WEBPACK_IMPORTED_MODULE_6__.normalizeTime,
      splitTime: _datetime_js__WEBPACK_IMPORTED_MODULE_6__.splitTime,
      composeTime: _datetime_js__WEBPACK_IMPORTED_MODULE_6__.composeTime
    },
    // The universal properties, each with the modes the set draws for it.
    registry: _registry_js__WEBPACK_IMPORTED_MODULE_5__.PROPERTY_TYPES.map(entry => ({ ...entry,
      modes: propertyModes(entry.type)
    }))
  }; // SF.whenFieldRenderers() settles on this, whichever bundle published the set.

  globalThis.document?.dispatchEvent?.(new CustomEvent('sf-field-renderers-ready'));
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "dd6973f77245"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   maskPattern: () => (/* binding */ maskPattern),
/* harmony export */   maskState: () => (/* binding */ maskState)
/* harmony export */ });
// Whether a masked string is complete (simai.property-view-port 1.16.0,
// field.mask). sf-input formats what a person types through the Framework's
// mask (core/js/mask.js) and reports the text as shown; what the set still has
// to know is whether that text fills every place of the pattern, because an
// incomplete value is not a value -- «+7 (912) 3» is neither a phone nor
// nothing -- and a panel must not send it.
//
// The grammar is core/js/mask.js's, read the same way: `0` a digit, `a` a
// letter, `*` any character, `\` escapes the next character, `{` `}` mark a
// fixed part that belongs to the value and `[` `]` an optional tail, both
// dropped from what is shown, and every other character is a fixed part shown
// in the field. The pattern is compiled into one expression over the shown
// text rather than re-running the formatter: the formatter's job is to make a
// valid prefix out of anything typed, which is exactly the question it cannot
// answer -- every prefix is valid while it is typed. A pattern's optional tail
// is not optional here: the contract names no optional places, and a tail
// that may be left empty would make «complete» mean two lengths.
//
// The text is compared as shown, fixed parts included, because that is the
// value the host receives. A text with the template's placeholders (a
// mask-lazy="false" field shows «+7 (___) ___-__-__») is incomplete, and a
// template with nothing typed into it is empty.
const SLOT = {
  0: '\\d',
  a: '\\p{L}',
  '*': '[\\s\\S]'
};
const TEST = {
  0: character => /\d/u.test(character),
  a: character => /\p{L}/u.test(character),
  '*': () => true
}; // Unicode mode refuses an escaped character that is not syntax, so only these.

const escape = character => character.replace(/[\\^$.*+?()[\]{}|/]/gu, '\\$&');

function compile(pattern) {
  let source = '';
  const tokens = [];

  for (let index = 0; index < pattern.length; index += 1) {
    const character = pattern[index];

    if (character === '\\') {
      index += 1;

      if (index < pattern.length) {
        source += escape(pattern[index]);
        tokens.push({
          fixed: pattern[index]
        });
      }
    } else if (character === '{' || character === '}' || character === '[' || character === ']') {// Markers of the grammar, never shown.
    } else if (SLOT[character]) {
      source += SLOT[character];
      tokens.push({
        test: TEST[character]
      });
    } else {
      source += escape(character);
      tokens.push({
        fixed: character
      });
    }
  }

  return {
    complete: new RegExp(`^${source}$`, 'u'),
    tokens
  };
} // How many places the text fills, read as core/js/mask.js reads it: a
// character that is the fixed part expected there is that fixed part, a
// placeholder in a place is an empty place, anything else fills the next place
// that takes it. A «7» typed into «+7 (000)» is a digit, not the fixed 7.


function filled(value, tokens, placeholder) {
  let count = 0;
  let pointer = 0;

  for (const character of value) {
    while (pointer < tokens.length && tokens[pointer].fixed !== undefined && tokens[pointer].fixed !== character) pointer += 1;

    if (pointer >= tokens.length) break;
    const token = tokens[pointer];
    if (token.fixed !== undefined) pointer += 1;else if (character === placeholder) pointer += 1;else if (token.test(character)) {
      count += 1;
      pointer += 1;
    }
  }

  return count;
}

const COMPILED = new Map();
function maskPattern(field) {
  const mask = field?.mask;
  return typeof mask === 'string' && mask !== '' ? mask : null;
} // 'empty', 'complete' or 'incomplete'. Empty is a text with nothing typed into
// it: no text, or only the pattern's fixed parts and placeholders.

function maskState(text, pattern, placeholder = '_') {
  const value = String(text ?? '');
  if (!COMPILED.has(pattern)) COMPILED.set(pattern, compile(pattern));
  const {
    complete,
    tokens
  } = COMPILED.get(pattern);
  if (complete.test(value)) return 'complete';
  return filled(value, tokens, placeholder) === 0 ? 'empty' : 'incomplete';
}

/***/ },

/***/ "25be1c2df717"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatPhone: () => (/* binding */ formatPhone),
/* harmony export */   phoneDialCode: () => (/* binding */ phoneDialCode),
/* harmony export */   phoneE164: () => (/* binding */ phoneE164),
/* harmony export */   splitPhone: () => (/* binding */ splitPhone)
/* harmony export */ });
// A telephone number, stored and shown (FL-1, FL-7 of the property page study,
// 2026-11-17). Larena keeps a phone in E.164 -- `+79161234567`, a plus and the
// digits, nothing else (Larena decision 2026-10-24) -- and so does every form
// that submits sf-input-country (standard simai.smart-component §17.1 item 2).
// The edit control used to write the text as the box showed it,
// `+7 916 123-45-67`, so opening a record and saving it changed the stored
// value. Edit writes E.164 now; view and cell lay the number out by its
// country, as the box does, and read the formatted strings stored before.
// The national part of each dial code's number, laid out as sf-input-country
// lays it out (its `formatByPattern`): `0` is a digit, anything else is
// written as it stands. Derived from src/component/country-code/data/countries.json
// -- each dial code's pattern without its own code; where countries share a
// code, the country the code means (+7 Russia, +1 the United States, +44
// Britain) -- and held equal to it by tests/phone-e164-fl.contract.test.mjs,
// so the set carries 2 KB instead of the 54 KB table.
const PATTERNS = [['0 00 00 00', '46'], ['0 00 00 00 00', '33 212 237'], ['0 000 00 00', '386'], ['0 000 000', '95 248 265 291 359 961 967 975'], ['0 000 0000', '36 64 66 389 599 850 962 964 970 971'], ['0 0000 000', '385'], ['0 0000 0000', '61 63 886'], ['0 000000', '252'], ['0 0000000', '51 53 591'], ['0 00000000', '20'], ['0 000000000', '43'], ['0-000-0000', '82 593 972'], ['0-0000 0000', '60'], ['0-0000-0000', '81'], ['0-0000000', '880 977'], ['0/000 000 00', '421'], ['00 00 0 00000', '225'], ['00 00 00', '299 508 681'], ['00 00 00 00', '32 45 47 213 222 223 224 226 227 228 235 236 241 253 257 352 377 689'], ['00 00 00 00 00', '229'], ['00 00 000 00', '261'], ['00 00 0000', '509'], ['00 00-00-00', '993'], ['00 000', '682 688'], ['00 000 00 00', '41 48 221 994 995 998'], ['00 000 000', '216 231 258 264 355 371 373 382 383 855 856'], ['00 000 0000', '27 31 40 93 233 242 249 251 255 351 595 963 966'], ['00 000-000', '387'], ['00 0000', '672'], ['00 0000 0000', '30 39 86 98'], ['00 0000-0000', '54 55'], ['00 00000', '243 263 353'], ['00 000000', '49 232 357 374 381 968'], ['00 0000000', '62 254 256 358'], ['00 00000000', '92'], ['00-000', '676'], ['00-0000000', '218'], ['00.00.00', '687'], ['000 00 00', '238 269 423'], ['000 00 00 00', '34 262 590 594 596'], ['000 00 0000', '992'], ['000 00-00-00', '375'], ['000 000', '376'], ['000 000 00 00', '90'], ['000 000 000', '56 94 211 240 244 245 250 260 420 996'], ['000 000 0000', '44 52'], ['000 000-00-00', '7'], ['000 0000', '220 239 246 267 297 354 372 592 670 673 674 675 679 680 691'], ['000 0000 000', '84'], ['000 00000', '350 370'], ['000 0000000', '57'], ['000-000', '597'], ['000-000-0000', '1'], ['000-0000', '501 507 692 960'], ['000-0000000', '58'], ['0000', '683 690'], ['0000 00 0000', '234'], ['0000 0000', '65 230 266 268 356 502 503 505 506 598 852 853 965 973 974 976'], ['0000 00000', '380'], ['0000 000000', '378'], ['0000-0000', '504'], ['00000', '290 500 677 678 685 686'], ['00000 00000', '91'], ['000000', '298']];
const NATIONAL = new Map();

for (const [pattern, codes] of PATTERNS) for (const code of codes.split(' ')) NATIONAL.set(code, pattern);

const digitsOf = text => String(text ?? '').replace(/\D/gu, ''); // An extension rides after the number: Larena writes `+73472468500;ext=12`
// (RFC 3966), and a person may have typed «доб. 12» or «ext. 12». Its digits
// are not the number's: read into the number they made `+7347246850012`.


const EXTENSION = /\s*(?:;\s*ext\s*=\s*|,?\s*(?:ext|доб)\.?\s*)(\d+)\s*$/iu;
/** The number and its extension apart: {number, extension}; extension '' for none. */

function splitPhone(value) {
  const text = String(value ?? '').trim();
  const match = text.match(EXTENSION);
  if (!match || !/\d/u.test(text.slice(0, match.index))) return {
    number: text,
    extension: ''
  };
  return {
    number: text.slice(0, match.index).trim(),
    extension: match[1]
  };
}

function numberE164(text) {
  const digits = digitsOf(text);
  if (!digits) return '';
  if (text.startsWith('+')) return `+${digits}`;
  if (/^00[1-9]/u.test(text.replace(/[\s\-().]/gu, ''))) return `+${digits.slice(2)}`;
  return text;
}
/**
 * The number in E.164: `+` and the digits. A text that starts with `+` (or the
 * international `00`) is a full number, laid out however it was:
 * `+7 916 123-45-67`, `+7 (916) 123 45 67` and `+79161234567` are one number.
 * A text without a country code is returned as it came, trimmed: which country
 * it belongs to is not the renderer's to guess. Empty for no digits. An
 * extension is kept as `;ext=<digits>`: `+7 347 246-85-00 доб. 12` is
 * `+73472468500;ext=12`.
 */


function phoneE164(value) {
  const {
    number,
    extension
  } = splitPhone(value);
  const e164 = numberE164(number);
  return extension && e164.startsWith('+') ? `${e164};ext=${extension}` : extension ? String(value ?? '').trim() : e164;
}
/** The dial code (digits) an E.164 number starts with: the longest one known. */

function phoneDialCode(e164) {
  const digits = digitsOf(e164);

  for (let length = Math.min(4, digits.length); length > 0; length -= 1) {
    if (NATIONAL.has(digits.slice(0, length))) return digits.slice(0, length);
  }

  return '';
}
/**
 * The number as a person reads it: `+79161234567` reads `+7 916 123-45-67`,
 * by the country its code names. Digits beyond the pattern stay at the end, a
 * number is never cut; an unknown code reads `+<digits>`; a number without a
 * country code is shown as it came. An extension follows the number after the
 * page language's word for it (`extensionWord`, «доб.» on a Russian page).
 */

function formatPhone(value, extensionWord = 'ext.') {
  const {
    number,
    extension
  } = splitPhone(value);
  const main = formatNumber(number);
  if (!extension || !main.startsWith('+')) return extension && !main.startsWith('+') ? String(value ?? '').trim() : main;
  return `${main} ${extensionWord} ${extension}`;
}

function formatNumber(value) {
  const e164 = numberE164(String(value ?? '').trim());
  if (!e164.startsWith('+')) return e164;
  const digits = e164.slice(1);
  const code = phoneDialCode(e164);
  if (!code) return e164;
  const rest = digits.slice(code.length);
  if (!rest) return `+${code}`;
  let out = '',
      index = 0;

  for (const char of NATIONAL.get(code)) {
    if (index >= rest.length) break;
    out += char === '0' ? rest[index++] : char;
  }

  return `+${code} ${out}${rest.slice(index)}`.trimEnd();
}

/***/ },

/***/ "fc654eb7fab0"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PROPERTY_TYPES: () => (/* binding */ PROPERTY_TYPES),
/* harmony export */   modesOf: () => (/* binding */ modesOf)
/* harmony export */ });
/* harmony import */ var _lang_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("354525e80715");
// The registry of universal properties (owner, 2026-10-15): every property
// type the Framework renders, or a component set renders beside it (`set`),
// its variants and the parameters a field of it reads -- one list a host
// (Larena's fields and settings), the property workbench and the documentation
// read, instead of each learning the types from the renderers' source. Which
// modes a type has is not written here: it is read from the renderer maps
// themselves (modesOf), so the registry cannot claim a mode the set does not
// draw. A contract keeps the two the same.
//
// `params` are the field keys the type's renderers read -- each one, and no
// other (the probe field-renderer-params calls them with a field that records
// what is read). A record, a relation and a user hold one value and take their
// candidates from the host, not from `options`; a constraint other than a
// choice's options is the host's to enforce, not a renderer's.
// The names of the types and variants live in the set's language files
// (localization study LC-5); `label` keeps its {ru, en} shape for the hosts
// that read it. English is built in; the Russian name is read from the words
// the ru language file registered for sf-field-renderers (owner decision
// C282), English until it is on the page.


const registeredName = (code, key) => globalThis.__sfPageLanguage?.registered?.get?.('sf-field-renderers')?.get?.(code)?.[key];

const typeLabel = key => Object.freeze(Object.defineProperties({}, {
  ru: {
    enumerable: true,
    get: () => _lang_index_mjs__WEBPACK_IMPORTED_MODULE_0__["default"].ru?.[key] ?? registeredName('ru', key) ?? _lang_index_mjs__WEBPACK_IMPORTED_MODULE_0__["default"].en[key]
  },
  en: {
    enumerable: true,
    value: _lang_index_mjs__WEBPACK_IMPORTED_MODULE_0__["default"].en[key]
  }
}));

const PROPERTY_TYPES = Object.freeze([{
  type: 'string',
  label: typeLabel('type-string'),
  // password: write-only. The host never sends the password; the value it
  // sends is {set: true} or {set: false} (null reads as not set), and the
  // set shows only «задан»/«не задан». An edit writes the typed text through
  // setFieldValue and writes nothing for a field nobody typed in.
  variants: [{
    id: 'phone',
    label: typeLabel('variant-string-phone')
  }, {
    id: 'password',
    label: typeLabel('variant-string-password'),
    writeOnly: true
  }],
  // mask (property-view port 1.16.0): the Framework mask grammar of
  // sf-input's mask-pattern; the value is the text as shown, fixed parts
  // included, and an incomplete one is reported, not written as a value.
  // nullable: false makes a cleared masked field write "" instead of null.
  // Read by the plain string alone: phone and password keep their controls.
  // defaultCountry (FL-7): the phone variant's country while it is empty,
  // ISO 3166 alpha-2; without it, the page's.
  params: ['placeholder', 'mask', 'nullable', 'defaultCountry', 'required', 'readonly']
}, {
  type: 'text',
  label: typeLabel('type-text'),
  variants: [],
  params: ['placeholder', 'required', 'readonly']
}, // html (property-view port 1.17.0): formatted text, an HTML string of
// sf-input-rich's subset. Edited with sf-input-rich, shown cleaned by that
// component's own rule, a cell its text on one line, filtered as text.
{
  type: 'html',
  label: typeLabel('type-html'),
  variants: [],
  params: ['placeholder', 'required', 'readonly']
}, // stepper: edited with sf-quantity, «−» and «+» and the arrow keys; min,
// max and step (and a number's precision) are read by that variant alone.
// numeric (C294, MP-12): a number a table aligns to the end of the line
// with figures of one width -- integer, number, money and percent -- read
// from here by any table instead of each keeping its own list.
{
  type: 'integer',
  label: typeLabel('type-integer'),
  numeric: true,
  variants: [{
    id: 'stepper',
    label: typeLabel('variant-integer-stepper')
  }],
  params: ['unit', 'min', 'max', 'step', 'required', 'readonly']
}, {
  type: 'number',
  label: typeLabel('type-number'),
  numeric: true,
  variants: [{
    id: 'scale',
    label: typeLabel('variant-number-scale')
  }, // meter (owner decision C203 (5)): a share of a limit, 0..100, as
  // the inline sf-progress-bar meter; the scale stays for levels.
  {
    id: 'meter',
    label: typeLabel('variant-number-meter')
  }, {
    id: 'stepper',
    label: typeLabel('variant-number-stepper')
  }],
  params: ['unit', 'min', 'max', 'step', 'precision', 'required', 'readonly']
}, // date (PD-2, PD-3): min and max bound the day, an ISO date (the day of a
// date and time is read); format is the length the view and the cell print
// the date in, Intl's dateStyle: short, medium (the default), long, full.
{
  type: 'date',
  label: typeLabel('type-date'),
  variants: [],
  params: ['min', 'max', 'format', 'required', 'readonly']
}, // datetime and time: sf-input-date in mode datetime and time (1.4.0). min
// and max bound the value -- an ISO date or date and time for a datetime,
// hh:mm for a time -- and step is the minute step, 1 to 60. A datetime's
// format is its date's length, as a date's; the clock stays short.
{
  type: 'datetime',
  label: typeLabel('type-datetime'),
  variants: [],
  params: ['min', 'max', 'step', 'format', 'required', 'readonly']
}, {
  type: 'time',
  label: typeLabel('type-time'),
  variants: [],
  params: ['min', 'max', 'step', 'required', 'readonly']
}, {
  type: 'boolean',
  label: typeLabel('type-boolean'),
  variants: [],
  params: ['trueText', 'falseText', 'required', 'readonly']
}, // buttons (property-view port 1.16.0): one segmented button group, a
// button per option, sized by `size` on the ladder ("1/2", "1", "2"; absent,
// the field's); pressing the chosen one again clears a field that is not
// required. The dropdown stays the default.
{
  type: 'choice',
  label: typeLabel('type-choice'),
  variants: [{
    id: 'buttons',
    label: typeLabel('variant-choice-buttons')
  }],
  params: ['options', 'badgeAppearance', 'size', 'required', 'readonly']
}, {
  type: 'choices',
  label: typeLabel('type-choices'),
  // badges: the view; checklist and select: the edit control (a list of
  // 13 or more is a checklist unless select is asked for).
  variants: [{
    id: 'badges',
    label: typeLabel('variant-choices-badges')
  }, {
    id: 'checklist',
    label: typeLabel('variant-choices-checklist')
  }, {
    id: 'select',
    label: typeLabel('variant-choices-select')
  }],
  params: ['options', 'badgeAppearance', 'required', 'readonly']
}, {
  type: 'user',
  label: typeLabel('type-user'),
  variants: [],
  params: ['placeholder', 'searchPlaceholder', 'required', 'readonly']
}, {
  type: 'record',
  label: typeLabel('type-record'),
  variants: [],
  params: ['placeholder', 'searchPlaceholder', 'required', 'readonly']
}, {
  type: 'relation',
  label: typeLabel('type-relation'),
  variants: [],
  params: ['placeholder', 'searchPlaceholder', 'required', 'readonly']
}, // lookup: a value chosen from a reference list the host keeps -- a country,
// a status, a contract type (Larena, 2026-10-23). It is not a record: the
// value is {value, label} and nothing opens from it. Small lists arrive as
// `options` and are chosen from in place; anything larger is paged and
// searched by the host, from the source the field names (`source`, which the
// host reads and no renderer does).
{
  type: 'lookup',
  label: typeLabel('type-lookup'),
  variants: [],
  params: ['options', 'multiple', 'placeholder', 'searchPlaceholder', 'required', 'readonly']
}, {
  type: 'file',
  label: typeLabel('type-file'),
  variants: [{
    id: 'image',
    label: typeLabel('variant-file-image')
  }, {
    id: 'image-card',
    label: typeLabel('variant-file-image-card')
  }, {
    id: 'image-list',
    label: typeLabel('variant-file-image-list')
  }],
  // required: read by the image variant alone, whose control is
  // sf-image-field -- a required, empty one keeps its form from submitting.
  params: ['accept', 'multiple', 'formats', 'uploadText', 'uploadSupportingText', 'uploadHint', 'required', 'readonly']
}, {
  type: 'color',
  label: typeLabel('type-color'),
  variants: [],
  params: ['swatches', 'required', 'readonly']
}, {
  type: 'include',
  label: typeLabel('type-include'),
  variants: [],
  params: ['language', 'required', 'readonly']
}, // money and percent (owner decisions C291 (2) and C294, 2026-11-17): the
// Framework's in every mode -- view, cell, edit and filter. Every number
// is a decimal string, never a float. money is {amount, currency}:
// `currency` fixes an ISO 4217 code (a bare amount is then read in it, and
// no currency is offered); `currencies` lists the codes a value may carry
// (absent: every ISO 4217 code, with a search); `currencyDisplay` is how
// the currency is written -- symbol (default: «₽», «$», «CA$»), code or
// name; the digits after the point are at most the currency's minor units
// (more is a field error, never rounded); min and max bound the amount.
// percent is the percent ("12.5" is 12,5 %), bounded only by min and max;
// its digits after the point are `precision`, else those of `step`.
{
  type: 'money',
  label: typeLabel('type-money'),
  numeric: true,
  variants: [],
  params: ['currency', 'currencies', 'currencyDisplay', 'min', 'max', 'placeholder', 'required', 'readonly']
}, {
  type: 'percent',
  label: typeLabel('type-percent'),
  numeric: true,
  variants: [],
  params: ['min', 'max', 'step', 'precision', 'placeholder', 'required', 'readonly']
}, // The types a component set draws (property-view port 1.18.0; Larena
// property types standard, notes of 2026-11-03): `set` names the set whose
// components show and edit them -- the View set's sf-view-properties -- and
// the Framework draws their table cells and filters (items by its number
// of rows). `params` are the keys the type reads, in the set's renderers
// and in these.
{
  type: 'items',
  label: typeLabel('type-items'),
  set: 'view',
  variants: [],
  params: ['columns', 'minRows', 'maxRows', 'required', 'readonly']
}, {
  type: 'compound',
  label: typeLabel('type-compound'),
  set: 'view',
  variants: [],
  params: ['parts', 'required', 'readonly']
}, {
  type: 'ru.requisites',
  label: typeLabel('type-ru.requisites'),
  set: 'view',
  variants: [],
  params: ['parts', 'required', 'readonly']
}]); // The modes a type has, read from the renderer maps: view and edit (a record),
// cell (a table) and filter -- `own` when the set has a filter control for the
// type, `text` when a filter falls back to a text search.

function modesOf(type, maps) {
  return {
    view: Boolean(maps.view?.[type]),
    edit: Boolean(maps.edit?.[type]),
    cell: maps.cell?.[type] ? 'own' : 'text',
    filter: maps.filter?.[type] ? 'own' : 'text'
  };
}

/***/ },

/***/ "926043d18700"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   debounce: () => (/* binding */ debounce),
/* harmony export */   getElementRowGap: () => (/* binding */ getElementRowGap),
/* harmony export */   getParent: () => (/* binding */ getParent),
/* harmony export */   setParentSpace: () => (/* binding */ setParentSpace)
/* harmony export */ });
function getElementRowGap(element) {
  return parseFloat(getComputedStyle(element).rowGap) || 0;
}
function setParentSpace(items) {
  const firstRef = items.values().next().value;
  const firstValue = firstRef?.value;
  if (!firstValue) return;
  const parent = firstValue.parentNode;
  if (!parent) return;
  return {
    gap: getElementRowGap(parent),
    item: firstValue,
    parent: parent
  };
}
function debounce(func, wait, immediate) {
  let timeout;
  return function () {
    const context = this,
          args = arguments;

    const later = () => {
      timeout = null;

      if (!immediate) {
        func.apply(context, args);
      }
    };

    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);

    if (callNow) {
      func.apply(context, args);
    }
  };
}
function getParent(item) {
  let current = item;

  while (current) {
    if (current.nodeName.toLowerCase().startsWith('sf-')) {
      return current.parentNode;
    }

    current = current.parentNode;
  }

  return null;
}

/***/ },

/***/ "870b5dfddc25"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setLoaderDragState: () => (/* binding */ setLoaderDragState)
/* harmony export */ });
function setLoaderDragState(value) {
  if (typeof SF === "undefined" || !SF.Loader) return;
  const loader = SF.Loader;
  const currentCount = Number(loader.dragObserverLockCount || 0);
  loader.dragObserverLockCount = value ? currentCount + 1 : Math.max(currentCount - 1, 0);
  loader.stopObserver = loader.dragObserverLockCount > 0;
}

/***/ },

/***/ "b30ec5bc0edb"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OPTION_BADGE_HUES: () => (/* binding */ OPTION_BADGE_HUES),
/* harmony export */   OPTION_BADGE_PALETTE: () => (/* binding */ OPTION_BADGE_PALETTE),
/* harmony export */   nearestPaletteHue: () => (/* binding */ nearestPaletteHue),
/* harmony export */   optionBadgeProps: () => (/* binding */ optionBadgeProps)
/* harmony export */ });
/* harmony import */ var _component_badges_js_contract_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a2a9d3c2841e");

const HEX_COLOR = /^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i; // The hues of the static palette (owner decision C17), each with the OKLCH hue
// angle of its tone 50 (src/core/scss/_sf_static_palette.scss, rounded to the
// degree; tests/option-badge-palette.contract.test.mjs holds the two equal).
// Brown and gray are not reached from a hex: brown sits between orange and
// amber and differs from them by chroma alone, which a light or a dark hex
// does not keep; a colour with less chroma than GREY_CHROMA is gray. Both are
// reached by name.

const OPTION_BADGE_HUES = Object.freeze({
  red: 28,
  orange: 47,
  amber: 60,
  yellow: 89,
  lime: 119,
  green: 144,
  teal: 173,
  cyan: 203,
  sky: 232,
  blue: 259,
  indigo: 279,
  violet: 299,
  purple: 320,
  pink: 347
});
const OPTION_BADGE_PALETTE = Object.freeze([...Object.keys(OPTION_BADGE_HUES), "brown", "gray"]);
const GREY_CHROMA = 0.03;

const linear = channel => {
  const c = channel / 255;
  return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}; // {chroma, hue} in OKLCH of a #rgb[a] / #rrggbb[aa]; the alpha is not read.


function oklchOf(hex) {
  let digits = hex.slice(1);
  if (digits.length < 6) digits = [...digits].map(digit => digit + digit).join("");
  const [r, g, b] = [0, 2, 4].map(at => linear(parseInt(digits.slice(at, at + 2), 16)));
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
  const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
  const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  const a = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s;
  const bb = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
  return {
    chroma: Math.hypot(a, bb),
    hue: (Math.atan2(bb, a) * 180 / Math.PI + 360) % 360
  };
}
/** The static palette hue nearest a hex colour: gray when it has no hue to speak of. */


function nearestPaletteHue(hex) {
  const {
    chroma,
    hue
  } = oklchOf(hex);
  if (chroma < GREY_CHROMA) return "gray";
  let best = "gray";
  let distance = Infinity;

  for (const [name, angle] of Object.entries(OPTION_BADGE_HUES)) {
    const apart = Math.abs((hue - angle + 540) % 360 - 180);

    if (apart < distance) {
      best = name;
      distance = apart;
    }
  }

  return best;
} // The fill of a hue: tone 50 at the fill step 24 (C43: no new tones or steps;
// the alpha scale's fill family), over the place in both themes, as the 24 %
// mix of the data's hex was. The text stays on the surface colour, so the
// label reads the same in both themes. Written to the badge's public
// variables, --sf-badge-background-color and --sf-badge-color (owner decision
// C140 (2), BG-7): a colour from data reaches the badge only through them and
// only as a palette step, never the author's hex.

const paletteStyle = hue => `--sf-badge-background-color: var(--sf-${hue}-50--alfa-24); --sf-badge-color: var(--sf-on-surface)`;
/**
 * Badge look for a filter option with optionRenderer 'badge'. option.color is
 * a Framework badge scheme (success, error, info...), a hue of the static
 * palette (red, teal, gray...; C17) or a hex colour. A hue tints the badge with
 * its own palette step; a hex is drawn in the palette hue nearest it, never as
 * the raw colour (C18, C43; badges study BG-7), so the label stays readable in
 * both themes. Anything else is neutral.
 */
// The data view port names the badge look `scheme` on a column's options; a
// filter option has always said `color`. Both are read: reading only `color`
// left every port column's scheme unread and its badges neutral.


function optionBadgeProps(option = {}) {
  const raw = option?.scheme ?? option?.color;
  const color = typeof raw === "string" ? raw.trim() : ""; // A former name (danger) reads as its canonical scheme (error).

  const scheme = (0,_component_badges_js_contract_js__WEBPACK_IMPORTED_MODULE_0__.canonicalBadgeScheme)(color);
  if (scheme) return {
    scheme,
    rootStyle: ""
  };
  const name = color.toLowerCase();
  if (OPTION_BADGE_PALETTE.includes(name)) return {
    scheme: "neutral",
    rootStyle: paletteStyle(name)
  };
  if (HEX_COLOR.test(color)) return {
    scheme: "neutral",
    rootStyle: paletteStyle(nearestPaletteHue(color))
  };
  return {
    scheme: "neutral",
    rootStyle: ""
  };
}

/***/ },

/***/ "c4779e51fee1"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatPlaceholder: () => (/* binding */ formatPlaceholder),
/* harmony export */   localeDateFormat: () => (/* binding */ localeDateFormat),
/* harmony export */   localeWeekStart: () => (/* binding */ localeWeekStart),
/* harmony export */   localeWeekend: () => (/* binding */ localeWeekend),
/* harmony export */   weekendDays: () => (/* binding */ weekendDays)
/* harmony export */ });
// What a locale says about its calendar, read from Intl once per locale: the
// first day of the week and the days off (Intl.Locale#getWeekInfo, the older
// weekInfo getter where a browser still has that). No DOM, so the rules are
// unit-tested as they are (tests/datepicker-c62.contract.test.mjs).
//
// Days are numbered as Date#getDay numbers them, 0 Sunday to 6 Saturday; Intl
// numbers them 1 Monday to 7 Sunday, so 7 is read as Sunday too.
const weekInfos = new Map();

function weekInfo(code) {
  if (weekInfos.has(code)) return weekInfos.get(code);
  let info = null;

  try {
    const locale = new Intl.Locale(code);
    info = (typeof locale.getWeekInfo === 'function' ? locale.getWeekInfo() : locale.weekInfo) || null;
  } catch {// An unknown locale keeps the defaults below.
  }

  weekInfos.set(code, info);
  return info;
} // The first day of the locale's week, read once per locale: the grid asks it
// several times a render. Monday where the locale does not say.


function localeWeekStart(code) {
  const first = weekInfo(code)?.firstDay;
  return Number.isInteger(first) ? first % 7 : 1;
}
const SATURDAY_SUNDAY = Object.freeze([6, 0]); // The locale's days off: Saturday and Sunday in ru, de and en-US, Friday and
// Saturday in ar-EG and he-IL. Saturday and Sunday where the locale does not say.

function localeWeekend(code) {
  const days = weekInfo(code)?.weekend;
  if (!Array.isArray(days) || !days.length) return SATURDAY_SUNDAY;
  return Object.freeze(days.map(day => day % 7));
} // The `weekend` setting (owner decision C62: days off are red, and a product
// whose weekends are working days says so). Empty: the locale's days off.
// "none": no day is a day off. Otherwise the days, comma or space separated,
// 0 or 7 Sunday, 1 Monday to 6 Saturday ("6,7" as Intl writes Saturday and
// Sunday, "5,6" for Friday and Saturday). Anything else in the list is left
// out; a list with nothing left falls back to the locale.

function weekendDays(setting, code) {
  const text = String(setting ?? '').trim().toLowerCase();
  if (!text) return new Set(localeWeekend(code));
  if (text === 'none') return new Set();
  const days = text.split(/[\s,]+/u).filter(part => /^[0-7]$/u.test(part)).map(part => Number(part) % 7);
  return new Set(days.length ? days : localeWeekend(code));
} // The date format of a locale, in the component's tokens (owner decision C62:
// typing follows the language and the country, not a fixed «ДД.ММ.ГГГГ»). The
// parts' order and the signs between them come from Intl alone:
// formatToParts of a two-digit day and month and a numeric year gives
// DD.MM.YYYY for ru and de, MM/DD/YYYY for en-US, DD/MM/YYYY for en-GB and fr,
// YYYY-MM-DD for sv-SE and en-CA. A sign before the first part or after the
// last («12.11.2026 г.» in bg, the closing dot of hu and ko) is left out: it is
// not between two numbers, and a person does not type it. Right-to-left marks
// are left out of the signs too. A locale Intl refuses, or a sign that is not
// one a date is typed with (. / - , or a space), keeps DD.MM.YYYY.

const DEFAULT_DATE_FORMAT = 'DD.MM.YYYY';
const PART_TOKENS = {
  day: 'DD',
  month: 'MM',
  year: 'YYYY'
};
const dateFormats = new Map();
function localeDateFormat(code) {
  if (dateFormats.has(code)) return dateFormats.get(code);
  let format = DEFAULT_DATE_FORMAT;

  try {
    const parts = new Intl.DateTimeFormat(code, {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).formatToParts(new Date(2026, 10, 12));
    const tokens = [];
    const signs = [];
    let sign = '';

    for (const part of parts) {
      if (part.type === 'literal') {
        sign += part.value.replace(/[\u200e\u200f\u061c]/gu, '');
      } else if (PART_TOKENS[part.type]) {
        if (tokens.length) signs.push(sign);
        tokens.push(PART_TOKENS[part.type]);
        sign = '';
      }
    }

    const whole = tokens.length === 3 && new Set(tokens).size === 3 && signs.every(one => /^[\s./,-]+$/u.test(one));
    if (whole) format = tokens.reduce((text, token, index) => text + (index ? signs[index - 1] : '') + token, '');
  } catch {// An unknown locale keeps the default.
  }

  dateFormats.set(code, format);
  return format;
} // The hint in an empty field: the format written with the letters of the
// locale's own names for the parts (Intl.DisplayNames, type dateTimeField):
// ДД.ММ.ГГГГ in ru, MM/DD/YYYY in en-US, TT.MM.JJJJ in de, JJ/MM/AAAA in fr.
// A name in a script without letter case or initials (日, 年) gives the Latin
// D, M, Y, H instead.

const LATIN_LETTERS = {
  DD: 'D',
  MM: 'M',
  YYYY: 'Y',
  YY: 'Y',
  HH: 'H',
  mm: 'M'
};
const FIELD_NAMES = {
  DD: 'day',
  MM: 'month',
  YYYY: 'year',
  YY: 'year',
  HH: 'hour',
  mm: 'minute'
};
const INITIAL_RE = /^[\p{Script=Latin}\p{Script=Cyrillic}\p{Script=Greek}]/u;
const placeholders = new Map();

function letterOf(token, code) {
  try {
    const name = new Intl.DisplayNames(code, {
      type: 'dateTimeField'
    }).of(FIELD_NAMES[token]) || '';
    const first = name.trim().charAt(0);
    if (INITIAL_RE.test(first)) return first.toLocaleUpperCase(code);
  } catch {// No names for this locale: the Latin letter below.
  }

  return LATIN_LETTERS[token];
}

function formatPlaceholder(format, code) {
  const key = `${code}|${format}`;
  if (placeholders.has(key)) return placeholders.get(key);
  const text = String(format || '').replace(/YYYY|YY|MM|DD|HH|mm/gu, token => letterOf(token, code).repeat(token.length));
  placeholders.set(key, text);
  return text;
}

/***/ },

/***/ "94d60d3691b5"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("deb1a4d61565");
/* harmony import */ var _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5b7d7695b41b");
/* harmony import */ var _js_manifest_actions_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("17828be41e75");
/* harmony import */ var _component_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("c1f17ed5a348");
/* harmony import */ var _aliases_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("f8651e83c6c6");
/* harmony import */ var _lang_en_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("678dc07d76bf");
/* harmony import */ var _lang_ru_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("32294b89604f");
/* harmony import */ var _js_templates_default__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("9d9caaf4f796");
/* harmony import */ var _helpers_option_badge_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("b30ec5bc0edb");
/* harmony import */ var _field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("e5483002f3ea");
/* harmony import */ var _field_renderers_html_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("01ae054f01b4");
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("2a080a730149");
/* harmony import */ var lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("8137feb490e0");
/* harmony import */ var _core_js_page_language__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("43090d1c8307");
/* harmony import */ var _helpers_dom__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("926043d18700");
/* harmony import */ var _helpers_loaderDragState__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("870b5dfddc25");
/* harmony import */ var _core_js_position_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("116963e5e31b");
/* harmony import */ var _core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("bf0cea966575");
/* harmony import */ var _core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("18003344cff0");
/* harmony import */ var _core_js_density_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__("1412c5875b4d");
/* harmony import */ var _core_js_menu_open_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__("8d229b7c92e9");
/* harmony import */ var _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__("d3818183b14c");
/* harmony import */ var _core_js_roving_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__("557c99eb8f3a");
/* harmony import */ var _core_js_preferences_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__("51250bf01ab0");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__, _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__, _js_templates_default__WEBPACK_IMPORTED_MODULE_7__, _field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__, lit__WEBPACK_IMPORTED_MODULE_11__, lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__, _core_js_page_language__WEBPACK_IMPORTED_MODULE_13__, _core_js_position_js__WEBPACK_IMPORTED_MODULE_16__, _core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17__, _core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__, _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21__]);
([_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__, _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__, _js_templates_default__WEBPACK_IMPORTED_MODULE_7__, _field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__, lit__WEBPACK_IMPORTED_MODULE_11__, lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__, _core_js_page_language__WEBPACK_IMPORTED_MODULE_13__, _core_js_position_js__WEBPACK_IMPORTED_MODULE_16__, _core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17__, _core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__, _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* harmony import */ var _core_js_smart_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lit__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _core_js_page_language__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_core_js_page_language__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _core_js_position_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_core_js_position_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21__);























 // Sized for what they hold rather than for reading, so they take no floor.
// Every word this table says, in the two languages the Framework speaks. The
// rule is the shared one -- `pageText` reads the nearest [lang] and falls back
// to the document's -- and it is here because the table said only Russian: on
// an English page the list's toolbar read «Фильтр» and «Создать» beside a
// record panel that had switched, which is the sort of thing only a language
// switch in an admin shows (owner, 2026-10-10).
//
// An attribute still wins over both: a consumer who names a word names it.
// SF.Preferences, the Framework's one store of view preferences (core
// publishes it; this bundle's copy is the fallback).

const preferences = () => globalThis.SF?.Preferences || _core_js_preferences_js__WEBPACK_IMPORTED_MODULE_23__["default"];

const tablePreferenceKey = key => `sf-table/${String(key).replace(/[^\w.:-]+/gu, "-")}`; // The id prefix of the entries a host listed for one row action (CM-8).


const ROW_MENU_ITEM = "listed:"; // What a cell may draw as markup rather than as an element of its own.

const LIGHT_CELL_TAGS = new Set(["sf-badge", "sf-tag", "sf-avatar"]); // How long the content table of an sf-view waits for the view's code before
// it draws on its own (saved-views r2, D2), and the grace after the view's
// script errs, for the Loader's one try of the module's other form.

const VIEW_WAIT_MS = 3000;
const VIEW_SCRIPT_RETRY_MS = 500;
const VIEW_SCRIPT = /\/view\/js\/view(?:\.min)?\.js(?:[?#]|$)/u;
const GENERAL_TABLE_PREFERENCE = "sf-table/*";
const TABLE_VIEW_DEFAULTS = Object.freeze({
  density: "normal",
  stripes: false,
  lines: false,
  singleLine: false,
  stickyHead: true
}); // The nearest box that scrolls vertically above an element, across shadow
// roots; null when it is the page.
// A list row's own menu button: «≡» of a plain list, «⋯» of a list with
// quick actions.

const LIST_ROW_MENU_BUTTON = "[data-sf-row-menu], .sf-table-list-menu button"; // The areas the row menu is bound to by sf-menu-context's `for` (C164; SIMAI
// Framework sf-menu-context 1.21.0): the table and the list of each table on
// the page, by an id of their own.

let ROW_AREA_COUNT = 0; // A key cell (owner decision C259, variant Б): a column the host marks
// `key_cell: true` stays in the row of a table with row actions on a phone,
// where every other column goes; `key_line` names the column whose value is
// the key cell's second line there (the client under an order). The names
// follow the Framework's .table-key and .table-key-line (utility.table 1.7.0).

const isKeyCell = column => column?.key_cell === true || column?.keyCell === true;

const keyLineOf = column => {
  const line = column?.key_line ?? column?.keyLine;
  return typeof line === "string" && line ? line : null;
}; // Below the md step of the breakpoint ladder (44rem), where the row menu is
// the bottom sheet (C164 (6)), a keyed table with row actions keeps its key
// cells (C259).


const KEYED_NARROW_REM = 44;

function verticalScroller(element) {
  for (let node = element; node; node = node.parentElement ?? node.getRootNode?.()?.host ?? null) {
    if (node === document.body || node === document.documentElement) return null;
    const style = getComputedStyle(node);
    if (/(auto|scroll|overlay)/u.test(style.overflowY) && node.scrollHeight > node.clientHeight + 1) return node;
  }

  return null;
} // The words are the language files' (lang/<locale>.json, standard 1.3.8 §11),
// read here under the camelCase keys a product registers more languages by
// (SF.language.register("sf-view-table", code, {filterText: …})).


const camelWords = (words = {}) => Object.fromEntries(Object.entries(words).map(([key, word]) => [key.replace(/-([a-z0-9])/gu, (_, letter) => letter.toUpperCase()), word]));

const TABLE_TEXT = {
  en: camelWords(_lang_en_json__WEBPACK_IMPORTED_MODULE_5__.runtime),
  ru: camelWords(_lang_ru_json__WEBPACK_IMPORTED_MODULE_6__.runtime)
};
const SYSTEM_COLUMN_KEYS = new Set(["select", "settings", "actions"]); // The list of resources (C31): a column's place in a list row, and what a
// status value and a fact's status mean there.

const LIST_ROLES = new Set(["status", "title", "supporting", "fact", "hidden"]);
const MAX_QUICK_ACTIONS = 3; // The column types whose values are numbers (C146 (3)): end-aligned, digits of
// one width, never wrapped.

const NUMBER_TYPES = new Set(["integer", "number", "money", "percent"]);
const STATUS_DOTS = Object.freeze({
  ok: "success",
  warning: "warning",
  error: "error",
  stopped: "neutral",
  success: "success",
  danger: "error",
  neutral: "neutral",
  info: "info",
  primary: "primary"
});
const STATUS_WORDS = Object.freeze({
  ok: "statusOk",
  warning: "statusWarning",
  error: "statusError",
  stopped: "statusStopped"
}); // sort="key:asc" (owner decision C296): the attribute's short form, a list of
// one; null when it is not that form (the JSON list keeps working).

function parseSortText(text) {
  const match = /^\s*([^:\s][^:]*?)\s*:\s*(asc|desc)\s*$/u.exec(String(text ?? ""));
  return match ? [{
    key: match[1],
    direction: match[2]
  }] : null;
} // The table's former container settings (C296, VT-13), dated until 2027-01-01.


const CONTAINER_SETTINGS = ["toolbar", "pagin", "filter-templates", "filter-text", "clear-text", "search-placeholder", "create-text", "creatable", "pagination-total", "pagination-page-size", "page-sizes", "filter-apply-text", "layout-switch"];
const CONTAINER_SETTING_HOME = {
  "pagin": "sf-pagination",
  "pagination-total": "sf-pagination total",
  "pagination-page-size": "sf-pagination page-size",
  "page-sizes": "sf-pagination page-sizes"
}; // The short fields edited at the cell (C296 q-edit).

const SHORT_EDIT_TYPES = new Set(["choice", "enum", "select", "user", "date", "datetime", "number", "integer", "money"]); // The schemes a fact's badge takes from its option (C140 (2)).

const BADGE_SCHEMES = new Set(["neutral", "primary", "secondary", "success", "info", "warning", "error"]);
const FACT_LEVELS = Object.freeze({
  warning: 1,
  error: 2
});

const positioning = () => globalThis.SF?.Position || (_core_js_position_js__WEBPACK_IMPORTED_MODULE_16___default()); // Published Composition ports (simai.composition.port-manifest.v1, sf-view-table@1.0.0).


const SF_TABLE_PORTS = Object.freeze({
  outputs: Object.freeze({
    selection: "record-ids.v1"
  }),
  inputs: Object.freeze({
    context: "record-ids.v1"
  })
});
const MAX_PORT_RECORD_IDS = 1000;

function hasControlCharacter(value) {
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code < 32 || code === 127) return true;
  }

  return false;
}

function checkedRecordIds(value) {
  if (!Array.isArray(value) || value.length > MAX_PORT_RECORD_IDS || Array.from(value).some(id => !(typeof id === "string" && id.length > 0 && id.length <= 256 && !hasControlCharacter(id) || Number.isSafeInteger(id))) || new Set(Array.from(value, id => `${typeof id}:${id}`)).size !== value.length) {
    throw new TypeError("Record identities must be unique nonempty strings or safe integers");
  }

  return Object.freeze([...value]);
} // Two tables on one page share nothing: ids, the settings key fallback and the
// portal are all derived from this counter, never from the component name.


let tableInstances = 0; // Many entries (standard simai.smart-component 1.3.8 §18.4; the quality
// profile 1.3.6-1, gate 17): from this many rows the table draws only the rows
// in view and a margin around them. The row height is measured from a drawn
// row; until one is drawn it is guessed.

const WINDOW_FROM = 300;
const WINDOW_MARGIN = 20;
const WINDOW_INITIAL = 60;
const ROW_HEIGHT_GUESS = 40;
const LONG_TEXT_CELL_TYPES = new Set(['text', 'textarea', 'markdown', 'html']); // The box a cell value is drawn in: a Smart element that is display: contents
// (sf-tag) has none of its own, so its first child is the one measured and
// folded.

function cellValueBox(item) {
  return getComputedStyle(item).display === 'contents' ? item.firstElementChild ?? item : item;
} // sf-view-table from its component.json (standard simai.smart-component 1.3.8 §3,
// §4, §8, §11, §18): the settings are attributes and properties, the actions
// answer outcomes, the events take the vocabulary's verbs and the old names
// follow once through the dated aliases (aliases.json). The table's own props
// below keep their parsers and defaults; what they do not name is the
// manifest's.
// A column's content width, as the laid-out table gives it. It is no longer
// rounded up to the 4px grid with a pixel to spare: the printed first paint
// carries no measured width (standard 1.3.9 §5.4) and lays the same columns
// out by their content in the page's own face (default.css, the unmeasured
// content-sized table), so a rounded width moved every printed cell a few
// pixels when the code measured (gate 24, typed-cells: CLS 0.035 at 1280).
// A face that comes later measures again (the fonts' loadingdone).


function contentStep(width) {
  return Math.ceil(width * 64) / 64;
}

const TableElement = (0,_core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__.elementFromManifest)(_component_json__WEBPACK_IMPORTED_MODULE_3__, {
  base: (_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0___default()),
  lang: {
    en: _lang_en_json__WEBPACK_IMPORTED_MODULE_5__,
    ru: _lang_ru_json__WEBPACK_IMPORTED_MODULE_6__
  },
  source: "ru",
  aliases: _aliases_json__WEBPACK_IMPORTED_MODULE_4__
}); // template-save carries {templates} (1.16.0); its former names keep the 1.3
// detail, the template itself or the array of them, until their dates.

const formerTemplateDetail = detail => detail?.templates?.length === 1 ? detail.templates[0] : detail?.templates; // Whether a row of the current set would stand at another index in the next:
// a row kept by id and drawn elsewhere is a layout shift.


function rowsWouldMove(current, next) {
  const at = new Map();
  current.forEach((row, index) => {
    if (row?.id !== undefined && row?.id !== null) at.set(String(row.id), index);
  });
  return next.some((row, index) => {
    if (row?.id === undefined || row?.id === null) return false;
    const was = at.get(String(row.id));
    return was !== undefined && was !== index;
  });
}

class SfTable extends TableElement {
  static get sfPorts() {
    return SF_TABLE_PORTS;
  }

  static get props() {
    return {
      templateName: {
        attribute: "template",
        default: "default"
      },
      ariaLabel: {
        attribute: "aria-label",
        default: "Data table"
      },
      // The row the page has open (component.json settings.current).
      current: {
        attribute: "current",
        default: ""
      },
      selectable: {
        type: Boolean,
        default: true
      },
      // The count of records under the filter, when the host knows it
      // (owner decision C296): the grid's aria-rowcount (VT-4) and the
      // «all N» of the bar of group actions. 0: not known.
      total: {
        type: Number,
        default: 0
      },
      // How many records of the filter come before the first row drawn
      // (a data view's page 2 and on): the rows' aria-rowindex count
      // from it, so a grid of total + 1 rows says where each row is
      // (VT-4, VR2-8). 0: the rows drawn start the list.
      rowOffset: {
        attribute: "row-offset",
        type: Number,
        default: 0
      },
      // Who owns the vertical scroll. `self` keeps the rows in their own
      // scroll area, which is what a host that bounds the table's height
      // wants and what every page has had so far. `page` gives the
      // vertical scroll to the document, so the head stays visible while
      // the page scrolls; the rows then scroll sideways only.
      verticalScroll: {
        attribute: 'vertical-scroll',
        default: 'self',
        values: ['self', 'page']
      },
      // How the records are drawn. `auto` is a table while the table's own
      // container is at least `list-below` pixels wide and a compact list
      // of records below that -- a phone, or a list beside an open panel;
      // `table` and `list` hold one of them whatever the width (owner,
      // 2026-10-12: one mobile view, the compact list). A table is a table
      // unless asked: sf-view asks for auto on a page's list.
      // Auto by default since 1.19.0 (owner decisions C31, C146; TB-11 of
      // the table study): a table alone on a phone stayed a table, wider
      // than the screen, with the box and the menu covering the title.
      // `table` keeps a table at every width; then a narrow box scrolls
      // it sideways with the first column standing still (C146 (9)).
      layout: {
        default: 'auto',
        values: ['auto', 'table', 'list']
      },
      listBelow: {
        attribute: 'list-below',
        type: Number,
        default: 600
      },
      // How many fields a record shows under its title in the list, chosen
      // by the columns' priority (lower first).
      listFields: {
        attribute: 'list-fields',
        type: Number,
        default: 3
      },
      // The list of resources (owner decision C31, 2026-11-09). The row
      // actions drawn in a list row as icon buttons, always visible (at
      // most three, by id); the rest are the row's «more» menu, and on a
      // narrow list these fold into it as well.
      quickActions: {
        attribute: 'quick-actions',
        default: ''
      },
      // What a press on a row opens: `title`, the title link alone (and
      // a double click, Enter); `row`, anywhere in the row but its
      // controls, through the same view intent.
      rowOpen: {
        attribute: 'row-open',
        default: 'title',
        values: ['title', 'row']
      },
      // A list/table switch in the toolbar, before Create. The person's
      // choice is kept with the table's preferences and in its saved
      // views; below list-below there is only the list and no switch.
      layoutSwitch: {
        attribute: 'layout-switch',
        type: Boolean,
        default: false
      },
      toolbar: {
        type: Boolean,
        default: true
      },
      // Alternate rows (zebra), the report author's choice for a wide
      // table that is only read (owner decision C146 (4)); a person's view
      // no longer offers it. Lines between the rows, the hovered and the
      // selected row's fill are the table's own.
      stripes: {
        type: Boolean,
        default: false
      },
      settings: {
        type: Boolean,
        default: true
      },
      pagin: {
        type: Boolean,
        default: false
      },
      actions: {
        type: Boolean,
        default: true
      },
      // The row action column alone; the create button still follows actions.
      rowActions: {
        attribute: "row-actions",
        type: Boolean,
        default: true
      },
      // Rows may be dragged out of the list -- onto a folder of a tree --
      // as records (application/x-sf-records+json).
      dragRows: {
        attribute: "drag-rows",
        type: Boolean,
        default: false
      },
      // The rows can be put in another order by dragging them inside the
      // list (row-reorder, the storage schema's fields, 2026-10-16).
      rowReorder: {
        attribute: "row-reorder",
        type: Boolean,
        default: false
      },
      // A boolean cell the host lets a person write is a checkbox
      // (inline-edit; which cells, the record's `editable` says).
      inlineEdit: {
        attribute: "inline-edit",
        type: Boolean,
        default: false
      },
      // Where the row's buttons are drawn: the active row, or every row.
      rowActionsVisible: {
        attribute: "row-actions-visible",
        default: "hover"
      },
      // The create button and its menu of kinds, inside actions: a data view
      // turns it off for a host on port 1.10.0 that does not announce
      // create-record, so nothing is offered that nobody would answer.
      creatable: {
        type: Boolean,
        default: true
      },
      // The button that saves the filter as a template. A data view turns it
      // off when the host keeps no saved views: a template saved there went
      // nowhere and was gone on the next load.
      filterTemplates: {
        attribute: "filter-templates",
        type: Boolean,
        default: true
      },
      // The gear in the head of the settings column, which opens the column
      // settings. Off, the column still carries each row's menu.
      settingsMenu: {
        attribute: "settings-menu",
        type: Boolean,
        default: true
      },
      // The step of the size ladder the table's own controls take: its
      // toolbar, its row boxes and menus, its filters and context menus.
      // 1/2 is the dense admin step -- 32px controls, 14/20 text, the
      // height of the admin menu beside it -- and the rows follow.
      size: {
        default: "1",
        values: ["1/2", "1"]
      },
      filterText: {
        attribute: "filter-text",
        default: "Filter"
      },
      clearText: {
        attribute: "clear-text",
        default: "Clear"
      },
      searchPlaceholder: {
        attribute: "search-placeholder",
        default: "Search"
      },
      createText: {
        attribute: "create-text",
        default: "Create"
      },
      pinColumnLabel: {
        attribute: "pin-column-label",
        default: "Pin the column"
      },
      unpinColumnLabel: {
        attribute: "unpin-column-label",
        default: "Unpin the column"
      },
      paginationTotal: {
        attribute: "pagination-total",
        type: Number,
        default: 10
      },
      paginationPageSize: {
        attribute: "pagination-page-size",
        type: Number,
        default: 10
      },
      pageSizes: {
        attribute: "page-sizes",
        default: "10,20,30,40"
      },
      contextMenuColumns: {
        attribute: "context-menu-columns",
        type: Number,
        // One, because one is what every table has drawn since this input
        // existed: the read was bare, so neither the declared 2 nor a value
        // a host passed ever reached the menu, which fell to `?? 1`. The
        // getter below makes the input work for the first time, and the
        // default is set to the shipped behaviour so that making it work
        // changes nothing for anyone who does not ask.
        default: 1
      },
      // A table no host keeps settings for remembers its column widths in
      // this browser (owner, 2026-10-14), under table-settings-key.
      rememberWidths: {
        attribute: "remember-widths",
        type: Boolean,
        default: false
      },
      // The key the arrangement is kept under as a view preference.
      preferencesKey: {
        attribute: "preferences-key",
        default: ""
      },
      tableSettingsKey: {
        attribute: "table-settings-key",
        // Empty, because the effective default was never a string at all:
        // the bare read fell through to the attribute, then the element's
        // id, then its instance id, so every table had its own key. The
        // declaration said "users" and the manifest said
        // "admin.collection" -- two different untruths about the same
        // input. Either one, read properly, would have made every table on
        // a page share one settings key and overwrite the others.
        default: ""
      },
      dataState: {
        attribute: "data-state",
        default: "auto",
        values: ["auto", "loading", "populated", "empty", "error"]
      },
      loadingText: {
        attribute: "loading-text",
        default: "Loading"
      },
      emptyText: {
        attribute: "empty-text",
        default: "No data"
      },
      errorText: {
        attribute: "error-text",
        default: "The data could not be loaded"
      },
      retryText: {
        attribute: "retry-text",
        default: "Try again"
      },
      columnMoveLabel: {
        attribute: "column-move-label",
        default: "Move the column"
      },
      filterApplyText: {
        attribute: "filter-apply-text",
        default: "Apply"
      },
      columnSearchPlaceholder: {
        attribute: "column-search-placeholder",
        default: "Search the fields"
      },
      columnSearchEmptyText: {
        attribute: "column-search-empty-text",
        default: "No field matches"
      }
    };
  } // The manifest's declared defaults for these two were fixed in the same
  // commit as these getters and then lost: a rebase replayed a hand-picked list
  // of source files and classified smart.manifest.json as regenerable, which is
  // true of its provenance and false of its declarations. Two pairs shipped with
  // the getters resolving one thing and the manifest declaring another. The
  // other Framework session's defaults contract -- the manifest default against
  // the value a component resolves with no attribute set -- is what catches this
  // class, and it would have caught it here.
  // Declaring a prop creates no accessor in this Framework. These two were read
  // off `this` and were undefined, which the other Framework session's new
  // contract now names. Each is written so that reading it properly preserves
  // the behaviour that shipped, rather than applying a default that never
  // applied.


  get contextMenuColumns() {
    const declared = this.getNumberAttr?.("context-menu-columns", 1) ?? 1;
    return Number.isFinite(declared) && declared > 0 ? declared : 1;
  }

  get tableSettingsKey() {
    return this.getAttribute?.("table-settings-key") || "";
  }

  constructor() {
    super();
    this._emptyContext = null; // One handler for every row's press, not a closure per row and render.

    this.rowPointerDown = event => this.handleRowPointerDown(event);

    this._windowRange = null;
    this._windowed = false;
    this._rowHeight = 0; // The empty state's actions: retry and create are the table's own;
    // anything else (the data view's query reset) goes on up.

    this.addEventListener("sf-empty-state-action", event => {
      const id = event.detail?.id;

      if (id === "retry") {
        event.stopPropagation();
        this.requestRetry();
      } else if (id === "create") {
        event.stopPropagation();
        this.requestCreateIntent();
      } else if (id === "reset-query") {
        event.stopPropagation();
        this.resetQuery(this._emptyContext?.reset ?? "both");
      }
    });
    this._portalContainer = null; // The prefix stays sf-table (rename plan R2): an unkeyed table's preference
    // key is built from it (sf-table/sf-table-<n>), and a renamed key would
    // lose what the person saved.

    this._instanceId = `sf-table-${++tableInstances}`;
    this._selectionPortKey = "[]";
    this._routeContext = null;
    this._querySequence = 0;
    this._pendingQuerySequence = null;
    this._abandonedQuery = false;
    this._filterOptionPages = new Map();
    this._contextViewportBound = false;
    this.contextKeyEvent = this.contextKeyEvent.bind(this);
    this.contextViewportEvent = this.contextViewportEvent.bind(this);
    this.ACTIONS_SETTINGS_ROW = [{
      name: this.text('editActionText'),
      id: 'edit',
      component: {
        type: 'button-icon',
        props: {
          kind: 'icon',
          size: '1',
          appearance: 'ghost',
          scheme: 'on-surface',
          icon: 'edit',
          ariaLabel: this.text('editActionText'),
          value: 'edit'
        }
      }
    }, {
      name: this.text('viewActionText'),
      id: 'view',
      component: {
        type: 'button-icon',
        props: {
          kind: 'icon',
          size: '1',
          appearance: 'ghost',
          scheme: 'on-surface',
          icon: 'visibility',
          ariaLabel: this.text('viewActionText'),
          value: 'view'
        }
      }
    }, {
      name: this.text('deleteActionText'),
      id: 'delete',
      // The kit marks its own delete destructive, as the template
      // menu already does (`danger: !isDeleted`): the row menu
      // draws a danger entry in `error`, and a host that narrows
      // this catalogue gets the entry back untouched, so naming
      // delete in a host catalogue only to restore the red row is
      // no longer the price of leaving it to the kit (Larena
      // storage QA, 2026-10-22). The icon in the actions column
      // (gone with variant В, C146 (5); kept for list rows)
      // says the same with `status: 'error'` (decided 2026-10-23,
      // control/VISUAL-DECISIONS.md «Разрушительное действие
      // строкой»): one act must not look like two on the two
      // surfaces of one row, and with the column's default
      // visibility at most one red icon shows at a time. The
      // status paints, the scheme stays the family it falls back
      // to (sf-button-icon: they cannot both paint it).
      danger: true,
      component: {
        type: 'button-icon',
        props: {
          kind: 'icon',
          size: '1',
          appearance: 'ghost',
          scheme: 'on-surface',
          status: 'error',
          icon: 'delete',
          ariaLabel: this.text('deleteActionText'),
          value: 'delete'
        }
      }
    }]; // Row actions are a system column like select and settings: always last,
    // not resizable or draggable, and never part of saved column settings.

    this.TABLE_ACTIONS_COLUMN = {
      key: "actions",
      label: this.text("actionsColumnLabel"),
      system: true
    };
    this.TABLE_SETTINGS_COLUMN = {
      key: "settings",
      label: "settings",
      system: true,
      width: 'calc(var(--sf-text-height-1) + (var(--sf-ui-1--space-y-tightness-default) * 2) + var(--sf-b6))',
      component: {
        type: "button-icon",
        props: {
          size: "1",
          appearance: "ghost",
          scheme: "on-surface",
          icon: "settings",
          ariaLabel: this.text("settingsColumnLabel"),
          value: "settings",
          // The gear opens the window and closes it again.
          // One click reaches this twice (the button, then its host), so
          // only a later click closes what this one opened.
          '@click': e => {
            const open = this.state.contextMenu?.open && this.state.contextMenu?.menu === 'table-settings';

            if (open && e.timeStamp - (this._settingsOpenedAt ?? 0) > 200) {
              this.closeContextMenu();
              return;
            }

            if (open) return;
            this._settingsOpenedAt = e.timeStamp;
            this.openContextMenu(e, {
              menu: 'table-settings'
            });
          }
        }
      }
    };
    this.contextEvent = this.contextEvent.bind(this);
    this.hoverEvents = this.hoverEvents.bind(this);
    this.outEvent = this.outEvent.bind(this);
    this._contextEventBound = false;
    this._hoverEventBound = false;
    this._columnResizeEventBound = false;
    this._headerSortableRow = null;
    this._headerSortableDetach = null;
    this._columnResizeState = null;
    this.searchChange = this.scheduleSearchChange.bind(this);
    this._searchDebounceTimer = null;
    this._searchPendingProps = null;
    this._searchHoldKey = '';
    this.refs = {
      contextMenu: this.createRef(),
      items: new Map(),
      templateForm: this.createRef(),
      renameInput: this.createRef(),
      table: this.createRef(),
      scroll: this.createRef(),
      rail: this.createRef(),
      resizeGuide: this.createRef()
    }; // Two rows, kept apart: the record the page has open (current,
    // aria-current) and the row the person is on (the keyboard's and the
    // pointer's place, data-current). The keys used to write the first, so
    // ↑/↓ moved «the open record» (C31 acceptance, 2026-11-09).

    this._currentRowId = null;
    this._cursorRowId = null;
    this._checkboxMeasureToken = 0;
    this._responsiveWidth = 0;
    this._responsiveObserver = null;
    this._rowAreaId = `sf-view-table-rows-${++ROW_AREA_COUNT}`;
    this._filterTemplatesLoaded = false;
    this.tempSettings = null;
    this.state = {
      settingsChecked: false,
      bulkActions: [],
      createItems: [],
      // What the toolbar's own control offers, straight from the host.
      toolbarActions: [],
      sort: {
        key: null,
        direction: null
      },
      saveInputValue: '',
      search: {
        searchActive: false,
        value: ''
      },
      contextMenu: {
        open: false
      },
      actions: this.getActions().map(action => Object.assign(action, {
        visible: true
      })),
      actionActive: this.getProp('actions'),
      columnSettings: {},
      selectIndeterminate: false,
      filterDataDirty: false,
      filter: {
        selectedTemplateKey: 'default',
        fields: [],
        templates: [],
        edit: {
          rename: ''
        }
      }
    };
    this.TABLE_SELECT_COLUMN = {
      key: "select",
      label: "select",
      system: true,
      width: 'calc(var(--sf-text-height-1) + var(--sf-b6) + calc(var(--sf-px) * 2))',
      component: {
        type: "checkbox",
        props: {
          position: 'end',
          rootClass: 'content-main-between',
          size: this.size,
          '@change': event => {
            const checked = Boolean(event.target.checked); // Marking the page leaves no single row as the anchor a
            // later Shift-click could extend from, so it is dropped
            // rather than left pointing at whatever was clicked last.

            this._selectionAnchorId = null;
            this.set({
              selectIndeterminate: false,
              settingsChecked: checked
            });
            this.updateRows(row => ({ ...row,
              select: this.getDefaultRowCell(this.TABLE_SELECT_COLUMN, { ...row,
                selected: checked,
                checked
              })
            }), "select-all");
          },
          indeterminate: this.state.selectIndeterminate,
          checked: this.state.settingsChecked,
          ariaLabel: this.text("selectAllLabel")
        }
      },
      rowComponent: {
        type: "checkbox",
        props: {
          position: 'end',
          rootClass: 'content-main-between',
          size: this.size
        }
      }
    };
  } // ---------- the manifest's list settings and values (§4, §18) ----------
  // Each list setting is the property its set-<name> helper writes.


  get rows() {
    return this.getTableData().rows || [];
  }

  set rows(rows) {
    this.setRows(Array.isArray(rows) ? rows : []);
  }

  get columns() {
    return this.getTableData().columns || [];
  }

  set columns(columns) {
    this.setColumns(Array.isArray(columns) ? columns : []);
  }

  get tableData() {
    return this.getTableData();
  }

  set tableData(data) {
    this.setTableData(data && typeof data === "object" ? data : {});
  }

  get tableSettings() {
    return this.getColumnSettings();
  }

  set tableSettings(data) {
    this.setTableSettings(data && typeof data === "object" ? data : {});
  }

  get bulkActions() {
    return this.state?.bulkActions ?? [];
  }

  set bulkActions(actions) {
    this.setBulkActions(actions);
  }

  get createItems() {
    return this.state?.createItems ?? [];
  }

  set createItems(items) {
    this.setCreateItems(items);
  }

  get toolbarActions() {
    return this.getToolbarActions();
  }

  set toolbarActions(items) {
    this.setToolbarActions(items);
  }

  get filterFields() {
    return this.getFilterFields();
  }

  set filterFields(fields) {
    this.setFilterFields(fields);
  }

  get activeFilterFields() {
    return this.getActiveFilterFieldKeys();
  }

  set activeFilterFields(keys) {
    this.setActiveFilterFields(keys);
  }

  get templates() {
    return this.getFilterTemplates();
  }

  set templates(data) {
    this.setTemplates(data);
  } // The host's echo of the order (§4.3 controlled; vocabulary 1.1.5 §2.1):
  // [{key, direction}], the main column first.


  get sort() {
    const {
      key,
      direction
    } = this.state?.sort ?? {};
    return key && direction ? [{
      key,
      direction
    }] : [];
  }

  set sort(list) {
    // The short form of C296's contract: "key:asc" or "key:desc".
    if (typeof list === "string") list = parseSortText(list) ?? (() => {
      try {
        return JSON.parse(list);
      } catch {
        return null;
      }
    })();
    const first = Array.isArray(list) ? list[0] : list;
    const key = first?.key ?? first?.field ?? null;
    const direction = first?.direction ?? first?.dir ?? null;
    if (key && ["asc", "desc"].includes(direction)) this.setSort(key, direction);else this.setSort(null, null);
  } // The row the page has open: marked aria-current, not focused.


  get current() {
    return this._currentRowId ?? "";
  }

  set current(id) {
    const value = id === null || id === undefined ? "" : String(id);
    this._currentRowId = value || null; // Opening a record puts the person on it.

    this._cursorRowId = null;

    if ((this.getAttribute("current") ?? "") !== value) {
      if (value) this.setAttribute("current", value);else this.removeAttribute("current");
    } else {
      this.requestComponentUpdate("current");
    }
  }

  attributeChangedCallback(name, oldValue, newValue) {
    if (name === "current" && oldValue !== newValue) {
      this._currentRowId = newValue || null;
      this._cursorRowId = null;
    }

    super.attributeChangedCallback?.(name, oldValue, newValue);
  }

  get selected() {
    return this._currentRowId ?? undefined;
  }

  get selection() {
    return this.getSelectedRecordIds();
  } // Whether an action was called with its parameters as one object (§4.4).


  isActionParameters(value, names) {
    return value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype && names.some(name => Object.hasOwn(value, name));
  }

  focusRowAction({
    id
  } = {}) {
    if (id === null || id === undefined || id === "") return {
      outcome: "refused",
      reason: "empty"
    };
    this.focusRow(String(id), {
      reveal: true
    });
    return {
      outcome: "applied"
    };
  } // The settings a markup author writes as attributes: sort="key:dir" is
  // read before the base's JSON reading of list attributes, which would
  // otherwise say the short form is not JSON (C296).


  sfReadListAttributes() {
    if (!this.__sfListAttributesRead && this.hasAttribute?.("sort")) {
      const short = parseSortText(this.getAttribute("sort"));
      if (short) this.sort = short;
    }

    return super.sfReadListAttributes?.();
  } // The totals at the foot (C296, q-totals B): the host's numbers, never
  // counted here -- under a filter only the server sees every record.
  // {page?: {key: value}, all?: {key: value}}, keyed by the columns marked
  // `total`; a row per side given, «На странице» then «Всего».


  get totals() {
    return this._totals ?? null;
  }

  set totals(value) {
    const shaped = value && typeof value === "object" && !Array.isArray(value) ? value : null;
    this._totals = shaped ? Object.freeze({ ...(shaped.page && typeof shaped.page === "object" ? {
        page: { ...shaped.page
        }
      } : {}),
      ...(shaped.all && typeof shaped.all === "object" ? {
        all: { ...shaped.all
        }
      } : {})
    }) : null;
    this.requestComponentUpdate?.("totals");
  } // Opening a record (C296): sf-view-table-open {id, newTab} beside the
  // view intent the title has always raised; newTab when a modifier or the
  // middle button took the record's address to a tab of its own.


  requestOpen(row, newTab = false) {
    const id = row?.id;
    if (id === null || id === undefined || id === "") return false;
    return this.emitTableEvent("open", Object.freeze({
      id,
      newTab: newTab === true
    }));
  } // Brings a record's row into view without moving the focus (C296); a row
  // outside the drawn range is drawn first. Answers an outcome, as
  // focus-row does.


  scrollToRow(rowId) {
    const id = rowId && typeof rowId === "object" ? rowId.id : rowId;
    if (id === null || id === undefined || id === "") return {
      outcome: "refused",
      reason: "empty"
    };
    const key = String(id).replace(/"/gu, '\\"');
    const element = this.isList ? this.querySelector(`.sf-table-list-item[data-row-id="${key}"]`) : this.refs.table?.value?.querySelector(`tbody tr[data-row-id="${key}"]`);

    if (element) {
      element.scrollIntoView?.({
        block: "nearest",
        behavior: "instant"
      });
      return {
        outcome: "applied"
      };
    }

    const rows = this.getTableData().rows || [];
    const index = rows.findIndex((one, at) => this.getRowKey(one, at) === String(id));
    if (index < 0) return {
      outcome: "refused",
      reason: "unknown"
    };

    if (this._windowed) {
      this._windowRange = this.clampWindow({
        first: index - WINDOW_MARGIN,
        last: index + WINDOW_MARGIN
      }, rows.length);
      this._windowOnly = true;
      this._pendingScrollRow = String(id);
      this.requestComponentUpdate("window");
    }

    return {
      outcome: "applied"
    };
  } // The old names whose detail §8 changed (split rows of aliases.json).


  sfAliasAdapters() {
    return {
      "sf-table-action-intent": detail => Object.freeze({
        action_id: detail.action,
        record_ids: detail.ids
      }),
      "sf-port-output": detail => Object.freeze({
        port: "selection",
        value: detail.ids
      }),
      onSearchEnd: detail => detail.search,
      "sf-table-template-save": formerTemplateDetail,
      onTemplateSave: formerTemplateDetail
    };
  }

  getActions() {
    if (this.getProp('actions')) {
      return this.ACTIONS_SETTINGS_ROW.map(action => {
        const {
          name,
          id
        } = action;
        return {
          name,
          id
        };
      });
    } else {
      return [];
    }
  }

  isSearchHoldKey(key = '') {
    return key === 'Backspace' || key === 'Delete';
  }

  clearSearchDebounce() {
    if (this._searchDebounceTimer) {
      clearTimeout(this._searchDebounceTimer);
      this._searchDebounceTimer = null;
    }
  }

  scheduleSearchChange(props = {}) {
    this._searchPendingProps = props;
    this.clearSearchDebounce();

    if (this._searchHoldKey) {
      return this;
    }

    this._searchDebounceTimer = setTimeout(() => {
      const pendingProps = this._searchPendingProps || {};
      this._searchPendingProps = null;
      this._searchDebounceTimer = null;
      this.updateSearchState(pendingProps);
    }, 500);
    return this;
  }

  handleSearchKeyDown(event) {
    if (!this.isSearchHoldKey(event?.key)) {
      return this;
    }

    this._searchHoldKey = event.key;
    this.clearSearchDebounce();
    return this;
  }

  handleSearchKeyUp(event) {
    if (!this._searchHoldKey || event?.key !== this._searchHoldKey) {
      return this;
    }

    this._searchHoldKey = '';

    if (this._searchPendingProps) {
      this.scheduleSearchChange(this._searchPendingProps);
    }

    return this;
  }

  updateSearchState(props = {}, isActiveState = true) {
    const currentSearch = this.state.search || {};
    let needUpdate = false;

    for (const [key, value] of Object.entries(props)) {
      if (!Object.is(currentSearch[key], value)) {
        needUpdate = true;
        break;
      }
    }

    if (!needUpdate) return this;
    this.set(prevState => {
      return {
        search: { ...prevState.search,
          ...props
        }
      };
    });
    if (!isActiveState) return this; // Said at once, not after this render: the host's answer (a data view
    // marking the rows loading) then lands in the same frame, and a search
    // costs one render before its rows, not two (rules of the road, rule 1).
    // The old camelCase onSearchEnd is a dated alias of this name
    // (aliases.json, simai/ui-pro#1): it follows once with its old detail.

    this.emitTableEvent('search-change', {
      search: this.state.search.value
    });
    return this;
  } // Every event by its verb, as the manifest declares it (standard 1.3.8
  // §8): the DOM name is <tag>-<verb>, and the old names follow once
  // through the dated aliases (aliases.json), noted in SF.deprecations when
  // a listener reads them. Answers false when a listener refused a
  // cancelable request.


  emitTableEvent(verb, detail = {}, options = {}) {
    return this.sfEmit(verb, detail, options);
  }

  requestActionIntent(actionId, recordIds, options = {}) {
    // An action takes its parameters as one object too (standard 1.3.8 §4.4).
    if (this.isActionParameters?.(actionId, ["action-id", "actionId"])) {
      ({
        actionId,
        recordIds
      } = {
        actionId: actionId["action-id"] ?? actionId.actionId,
        recordIds: actionId["record-ids"] ?? actionId.recordIds
      });
    }

    if (typeof actionId !== 'string' || !actionId.trim() || !Array.isArray(recordIds) || recordIds.length === 0 || Array.from(recordIds).some(id => !(typeof id === 'string' && id.length > 0 || Number.isSafeInteger(id)))) {
      throw new TypeError('Action intent requires an opaque action ID and nonempty typed record IDs');
    }

    const ids = Object.freeze([...recordIds]);
    const rows = this.getTableData().rows || [];
    const revisions = {};

    for (const id of ids) {
      const revision = rows.find(row => row?.id === id)?.revision;
      if (revision !== undefined && revision !== null) revisions[id] = revision;
    } // Vocabulary §5 apply (§18.3): one row's own action is scope entry, a
    // bulk one scope selection. The old sf-table-action-intent follows
    // with its {action_id, record_ids} (a split row and its adapter).


    const scope = options?.scope ?? (ids.length === 1 ? "entry" : "selection");
    this.emitTableEvent('apply', Object.freeze({
      action: actionId,
      scope,
      ids,
      revisions: Object.freeze(revisions)
    }));
    return {
      outcome: "applied"
    };
  }

  getSelectedRecordIds() {
    return this.getTableData().rows.filter(row => row.select?.component?.props?.checked === true).map(row => row.id);
  }

  setBulkActions(actions = []) {
    this.noteBulkActionsName?.();

    if (!Array.isArray(actions) || Array.from(actions).some(action => !action || typeof action !== 'object' || typeof action.id !== 'string' || !action.id.trim() || typeof action.name !== 'string' || !action.name.trim() || Object.keys(action).some(key => key !== 'id' && key !== 'name'))) {
      throw new TypeError('Bulk actions require opaque id and name only');
    }

    return this.set({
      bulkActions: actions.map(({
        id,
        name
      }) => ({
        id,
        name
      }))
    });
  }

  renderBulkActions(place = "before") {
    if (!this.state.bulkActions?.length) return lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
    const bar = this.hasBulkBar();
    if (place === "after") return bar ? this.renderBulkBar() : lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
    if (bar) return lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
    const selected = this.getSelectedRecordIds(); // C116: a bulk action is a regular button (outline on-surface); one
    // that deletes opens a confirmation, so it is the outlined danger and
    // stands last (C164 (5)). None is the filled main button.

    const destructive = action => /^(delete|remove|destroy|trash)\b/iu.test(String(action.id));

    const ordered = [...this.state.bulkActions].sort((a, b) => Number(destructive(a)) - Number(destructive(b)));
    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<div class="flex flex-wrap gap-1/3">
            ${ordered.map(action => (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<sf-button
                appearance="outline" scheme="on-surface" status=${destructive(action) ? "error" : lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                text=${action.name} ?disabled=${selected.length === 0}
                @click=${() => {
      const ids = this.getSelectedRecordIds();
      if (ids.length) this.requestActionIntent(action.id, ids, {
        scope: "selection"
      });
    }}></sf-button>`)}
        </div>`;
  } // C295 / C296: group actions are sf-bulk-actions' job. Where the page's
  // pair carries that element, a table standing alone places one bar after
  // its rows (count, clear and «all N» come with it: BA-2, BA-5); where it
  // does not, the table's own buttons stay above the rows as before. Inside
  // sf-view the view draws the bar. setBulkActions / bulkActions are the
  // former names of the bar's actions until 2027-01-01.


  noteBulkActionsName() {
    if (this.closest?.("sf-view")) return;
    (0,_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21__.noteDeprecated)({
      component: "sf-view-table",
      tag: "sf-view-table",
      kind: "method",
      from: "setBulkActions",
      to: "sf-bulk-actions actions",
      since: "2026-11-18",
      remove_after: "2027-01-01",
      package: "view"
    });
  }

  hasBulkBar() {
    return typeof customElements !== "undefined" && Boolean(customElements.get("sf-bulk-actions"));
  }

  renderBulkBar() {
    const selected = this.getSelectedRecordIds();
    const rows = this.getTableData().rows || [];
    const count = Number(this.getProp?.("total") ?? this.getAttribute("total") ?? 0);
    const total = Number.isSafeInteger(count) && count > 0 ? String(count) : lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
    const actions = this.state.bulkActions.map(({
      id,
      name
    }) => ({
      id,
      text: name
    }));
    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<sf-bulk-actions place="inline" data-sf-table-bulk
            size=${this.getPropsContext().size === "1/2" ? "1/2" : "1"}
            count=${selected.length} page-count=${rows.length} total=${total}
            ?all-selected=${this._bulkAll === true}
            .actions=${actions}
            @sf-bulk-actions-action=${event => {
      const {
        id,
        scope
      } = event.detail || {};
      const ids = this.getSelectedRecordIds();
      if (!id || !ids.length && scope !== "all") return;
      this.requestActionIntent(String(id), ids.length ? ids : rows.map(row => row.id), {
        scope: scope === "all" ? "all" : "selection"
      });
    }}
            @sf-bulk-actions-select-all=${() => {
      this._bulkAll = true;
      this.requestComponentUpdate("bulk");
    }}
            @sf-bulk-actions-select-page=${() => {
      this._bulkAll = false;
      this.requestComponentUpdate("bulk");
    }}
            @sf-bulk-actions-clear=${() => {
      this._bulkAll = false;
      this.clearSelection();
    }}></sf-bulk-actions>`;
  } // Items for the create split button menu. Choosing one (or the main
  // button, with item null) emits sf-table-create-intent; the host opens its form.


  setCreateItems(items = []) {
    if (!Array.isArray(items) || Array.from(items).some(item => !item || typeof item !== 'object' || typeof item.id !== 'string' || !item.id.trim() || typeof item.name !== 'string' || !item.name.trim() || Object.keys(item).some(key => key !== 'id' && key !== 'name'))) {
      throw new TypeError('Create items require opaque id and name only');
    }

    return this.set({
      createItems: items.map(({
        id,
        name
      }) => ({
        id,
        name
      }))
    });
  }

  requestCreateIntent(itemId = null) {
    if (this.isActionParameters?.(itemId, ["item-id", "itemId"])) itemId = itemId["item-id"] ?? itemId.itemId ?? null;

    if (itemId !== null && !this.state.createItems.some(item => item.id === itemId)) {
      throw new TypeError(`sf-view-table has no create item ${String(itemId)}`);
    }

    this.emitTableEvent('create', Object.freeze({
      item: itemId
    }));
    return {
      outcome: "applied"
    };
  } // The actions of the view itself, set by the host: the toolbar's control is
  // a menu of them. Round three took it off column settings, which the gear
  // in the head already owns, and gave it the job the Bitrix-like tables give
  // it -- everything the page used to carry as its own buttons.


  setToolbarActions(items = []) {
    if (!Array.isArray(items) || Array.from(items).some(item => !item || typeof item !== 'object' || typeof item.id !== 'string' || !item.id.trim() || typeof item.label !== 'string' || !item.label.trim() || item.icon != null && typeof item.icon !== 'string' || item.href != null && !this.isSameSiteHref(item.href) || Object.keys(item).some(key => !['id', 'label', 'icon', 'href'].includes(key)))) {
      throw new TypeError('Toolbar actions require id and label, and an optional icon and same-site href');
    }

    return this.set({
      toolbarActions: items.map(({
        id,
        label,
        icon,
        href
      }) => ({
        id,
        label,
        ...(icon ? {
          icon
        } : {}),
        ...(href ? {
          href
        } : {})
      }))
    });
  }

  getToolbarActions() {
    return (this.state.toolbarActions || []).map(item => ({ ...item
    }));
  } // A link out of the table may only go to this same site. A host that sends
  // another origin is sending the person somewhere the table cannot vouch for.


  isSameSiteHref(href = "") {
    const value = String(href ?? "").trim();
    if (!value || value.startsWith("//")) return false;

    try {
      return new URL(value, document.baseURI).origin === new URL(document.baseURI).origin;
    } catch {
      return false;
    }
  } // The event carries the id, and an item with an href also goes there. The
  // event is cancelable, so a host that routes its own pages keeps the view
  // on the page: it calls preventDefault and navigates itself.


  requestToolbarAction(actionId) {
    const action = this.getToolbarActions().find(item => item.id === actionId);

    if (!action) {
      throw new TypeError(`sf-view-table has no toolbar action ${String(actionId)}`);
    }

    const allowed = this.emitTableEvent('toolbar-action', Object.freeze({
      action: action.id,
      href: action.href ?? null
    }), {
      cancelable: true
    });

    if (allowed && action.href && this.isSameSiteHref(action.href)) {
      window.location.assign(action.href);
    }

    return this;
  } // The view's three action menus -- the create arrow's variants, the
  // toolbar's «⋯» and the list's sort -- are the page's one menu of actions,
  // SIMAI Framework SF.menu.open (C184 (4), VF-1, set standard 7.5): the
  // Framework places it at its control, closes it on a press outside or
  // Escape, toggles it from the same control and gives the focus back. They
  // were sf-menu-context windows the table drew in its own portal with
  // position: fixed. Each entry list answers {entries, choose(id)}.


  actionMenu(menu) {
    if (menu === 'toolbar-actions') {
      // The standard menu's entries, not link buttons: a link button in a
      // menu drew centred text on a light block that looked like no other
      // menu in the admin (owner, 2026-10-13).
      const actions = this.getToolbarActions();
      return {
        entries: actions.map(action => ({
          id: String(action.id),
          text: action.label,
          ...(action.icon ? {
            icon: action.icon
          } : {})
        })),
        choose: id => {
          const action = actions.find(item => String(item.id) === id);
          if (action) this.requestToolbarAction(action.id);
        }
      };
    }

    if (menu === 'list-sort') {
      // The list has no column heads to sort by, so its sort is a menu:
      // the host's own order, then each sortable column one way and the
      // other. Choosing one raises sf-table-sort-change exactly as a head
      // does.
      const current = this.state.sort || {};
      const choices = new Map();

      const option = (text, key, direction) => {
        const id = `${key ?? ''}:${direction ?? ''}`;
        choices.set(id, [key, direction]);
        return {
          id,
          text,
          kind: 'radio',
          checked: current.key === key && current.direction === direction
        };
      };

      const sortable = this.getColumns().filter(column => column?.sortable && !column.system && !["select", "settings", "actions"].includes(column.key));
      return {
        entries: [option(this.text('sortNone'), null, null), ...sortable.flatMap(column => [option(`${column.label ?? column.key}, ${this.text('sortAscending')}`, column.key, 'asc'), option(`${column.label ?? column.key}, ${this.text('sortDescending')}`, column.key, 'desc')])],
        choose: id => {
          const choice = choices.get(id);
          if (!choice) return;
          const [key, direction] = choice;
          this.setSort(key, direction);
          this.emitTableEvent('sort-change', Object.freeze({
            key,
            direction
          }));
        }
      };
    }

    if (menu === 'create') {
      const createItems = this.state.createItems || [];
      return {
        entries: createItems.map(item => ({
          id: String(item.id),
          text: item.name
        })),
        choose: id => {
          const item = createItems.find(entry => String(entry.id) === id);
          if (item) this.requestCreateIntent(item.id);
        }
      };
    }

    return null;
  } // Opens one of the action menus at its control through SF.menu.open and
  // acts on the row chosen. A second press on the same control closes it.


  async openActionMenu(menu, anchor) {
    const built = this.actionMenu(menu);
    if (!built || !(anchor instanceof Element)) return null;
    anchor.setAttribute('aria-expanded', 'true');
    const choice = await (0,_core_js_menu_open_js__WEBPACK_IMPORTED_MODULE_20__.menuOpen)({
      anchor,
      entries: built.entries,
      label: this.getContextMenuLabel({
        menu
      }),
      size: this.menuSize
    });
    if (anchor.isConnected) anchor.setAttribute('aria-expanded', 'false');
    if (choice?.id !== undefined && choice?.id !== null) built.choose(String(choice.id));
    return choice;
  } // Sorting reports intent only: the table marks the header and emits
  // sf-table-sort-change; the host reorders or reloads the rows.


  getSort() {
    return { ...this.state.sort
    };
  }

  setSort(key = null, direction = null) {
    if (this.isActionParameters?.(key, ["key", "direction"])) ({
      key = null,
      direction = null
    } = key);

    if (key === null || direction === null) {
      this.set({
        sort: {
          key: null,
          direction: null
        }
      });
      return {
        outcome: "applied"
      };
    }

    if (typeof key !== 'string' || !key || !['asc', 'desc'].includes(direction)) {
      throw new TypeError('Sort requires a column key and direction asc or desc');
    }

    this.set({
      sort: {
        key,
        direction
      }
    });
    return {
      outcome: "applied"
    };
  }

  toggleSort(key) {
    const current = this.state.sort || {};
    const direction = current.key !== key ? 'asc' : current.direction === 'asc' ? 'desc' : current.direction === 'desc' ? null : 'asc';
    this.setSort(direction ? key : null, direction);
    return this.emitTableEvent('sort-change', Object.freeze({
      key,
      direction
    }));
  } // Pointer capture sends the click that ends a column drag or resize to the
  // header cell; that click must not also sort the column.


  suppressNextHeaderClick() {
    this._suppressHeaderClick = true;
    setTimeout(() => {
      this._suppressHeaderClick = false;
    }, 0);
  }

  handleHeaderSortClick(event, column = {}) {
    if (column.sortable !== true || column.system || this._suppressHeaderClick) return;
    const target = event.composedPath?.()[0] || event.target; // A click on the width strip is not a click on the header's own title.

    if (target instanceof Element && target.closest('.sf-table-column-resizer')) return;
    this.toggleSort(column.key);
  } // Emits the selection output once per change of the explicit selection.


  syncSelectionPort() {
    if (!this._isMounted) return this;
    const ids = this.getSelectedRecordIds();
    const key = JSON.stringify(ids.map(id => [typeof id, id]));
    if (key === this._selectionPortKey) return this;
    this._selectionPortKey = key; // Vocabulary §5 select {ids} (§18.2); the composition port's
    // sf-port-output {port: selection, value} follows once (a split row).

    this.emitTableEvent("select", Object.freeze({
      ids: Object.freeze([...ids])
    }));
    return this;
  } // One row's box has been marked. A plain click marks that row; Shift+click
  // marks every row between the last one marked and this one, with the value
  // the clicked box just took, which is what makes unmarking a range work too.


  applyRowSelection(rowId, checked, {
    range = false
  } = {}) {
    const rows = this.getTableData().rows;

    const sameRow = (row, id) => String(row?.id ?? "") === String(id ?? "");

    const index = rows.findIndex(row => sameRow(row, rowId));
    if (index < 0) return this;
    const anchorIndex = range && this._selectionAnchorId != null ? rows.findIndex(row => sameRow(row, this._selectionAnchorId)) : -1;
    const from = anchorIndex < 0 ? index : Math.min(anchorIndex, index);
    const to = anchorIndex < 0 ? index : Math.max(anchorIndex, index); // The page box is cleared first: a row cell asks `settingsChecked`
    // whether it is marked, so leaving it set would mark the rows this call
    // is unmarking back again.

    this.set({
      settingsChecked: false
    });
    this.updateRows((row, position) => position < from || position > to ? row : { ...row,
      selected: checked,
      checked,
      select: this.getDefaultRowCell(this.TABLE_SELECT_COLUMN, { ...row,
        selected: checked,
        checked
      })
    }, range && anchorIndex >= 0 ? "select-range" : "select-row");
    this._selectionAnchorId = rowId;
    return this.syncSelectAllState();
  } // The page box answers for the rows under it: all of them, some of them, or
  // none. It is computed from the rows rather than counted as rows are
  // clicked, so appended rows and a replaced page cannot drift from it.


  syncSelectAllState() {
    const count = this.getSelectedRecordIds().length;
    const total = this.getTableData().rows.length;
    return this.set({
      settingsChecked: total > 0 && count === total,
      selectIndeterminate: count > 0 && count < total
    });
  } // What a pointer press has to settle before the click arrives: whether a
  // range is being extended, and that the press must not start a text
  // selection. A Shift-click or a second click otherwise selects the text of
  // every row it passes over, which is what the host reported.


  handleRowPointerDown(event) {
    this._selectRangeModifier = event?.shiftKey === true;

    if (event?.shiftKey === true || event?.detail > 1) {
      event.preventDefault?.();
    }

    return this;
  } // Controls inside a row answer for themselves. A click on a box, a row
  // menu, a link, a button or a field is that control's click, and neither
  // focuses the row nor opens the record.


  isRowControlTarget(target) {
    if (!(target instanceof Element)) return false;
    return Boolean(target.closest('td[data-key="select"], td[data-key="settings"], a[href], button, input, select, textarea,' + ' [role="button"], [role="link"], sf-checkbox, sf-dropdown, sf-button, sf-button-icon'));
  } // A single click makes the row the current one — wherever in the row it
  // lands. It does not mark it: marking is the box's job, and a click that did
  // both would let a stray click destroy a selection the person had built up.
  //
  // The first version skipped a click on anything interactive, which read
  // well until a consumer's cells turned out to be links: clicking the only
  // content a cell has left the row unmarked as current, and the rule looked
  // broken rather than careful. A control still does its own work — a link
  // still follows, a box still marks — and the row moving under the pointer
  // takes nothing away from that. Only opening the record stays off limits
  // from a control.


  handleRowClick(event, row, index = -1) {
    // A list row's own buttons keep the focus a press gives them: the menu
    // they open goes back to them.
    this.focusRow(this.getRowKey(row, index), {
      focus: !(this.isList && this.isRowControlTarget(event?.target))
    });
    this.openReferenceFromCell(event, row); // row-open="row" (C31): a press anywhere in the row but its controls
    // opens the record, as the title link and Enter do. A press that
    // selected text, or one with a modifier, is not a press to open.

    if (this.getAttribute("row-open") === "row" && !event?.defaultPrevented && !(event?.button > 0) && !event?.metaKey && !event?.ctrlKey && !event?.shiftKey && !event?.altKey && !(event?.detail > 1) && !String(globalThis.getSelection?.() ?? "")) {
      this.handleRowOpen(event, row);
    }

    return this;
  } // A value that points at another record -- a person, a file, a related
  // record -- opens that record in the page's panel instead of loading a page
  // (owner, 2026-10-14): the table asks with sf-table-reference-open and the
  // data view raises record.open {field, value, href}. A click with a
  // modifier or the middle button still follows the address, so a new tab is
  // one keystroke away; a host that cannot open it gets the address.


  openReferenceFromCell(event, row) {
    if (event.defaultPrevented || event.button > 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target?.closest?.("a[href]");
    const cell = link?.closest?.("td[data-key]");
    if (!link || !cell || !this.contains(cell)) return;
    const field = cell.dataset.key;
    const value = row?.[field];
    const href = link.getAttribute("href");
    if (!href || href.startsWith("#") || link.target === "_blank" || link.hasAttribute("download")) return;
    const asked = this.emitTableEvent("reference-open", {
      recordId: row?.id ?? null,
      field,
      value: value ?? null,
      href
    }, {
      cancelable: true
    }); // Only a listener that takes it (cancels the event) keeps the page.

    if (!asked) event.preventDefault();
  } // Which row this is, for the purpose of being the current one. The rest of
  // the template already keys a row by `id`, then `value`, then its position,
  // because the table is given rows keyed all three ways; the current row
  // followed `id` alone, so in a view whose rows carry another key a click
  // marked nothing and looked broken. Opening a record still needs a real id
  // — there is nothing to open without one.


  getRowKey(row, index = -1) {
    const value = row?.id ?? row?.value;

    if (value !== undefined && value !== null && String(value) !== "") {
      return String(value);
    }

    return index >= 0 ? `index:${index}` : "";
  } // Whether a row's action buttons are drawn: always when the host asks
  // (row-actions-visible="always"), else in the row under the pointer, the
  // row holding the focus and the current row.


  actionsShownFor(row) {
    if (this.getAttribute("row-actions-visible") === "always") return true;
    const key = String(row?.id ?? row?.value ?? "");
    if (!key) return true;
    return key === this._pointerRowKey || key === this._focusRowKey || String(this._currentRowId ?? "") === key;
  }

  setActionsRow(kind, key) {
    const field = kind === "focus" ? "_focusRowKey" : "_pointerRowKey";
    const next = key ? String(key) : null;
    if (this[field] === next) return;
    this[field] = next; // The buttons of one row, not the table's layout: no measuring after it.

    this._layoutUnchanged = true;
    this.requestComponentUpdate("row-actions");
  }

  bindRowActionsEvents(table) {
    if (!table || this._rowActionsTable === table) return;
    this._rowActionsAbort?.abort();
    this._rowActionsAbort = new AbortController();
    this._rowActionsTable = table;
    const {
      signal
    } = this._rowActionsAbort;

    const rowKey = target => target?.closest?.("tbody tr[data-row-id]")?.dataset.rowId ?? null;

    table.addEventListener("pointerover", event => this.setActionsRow("pointer", rowKey(event.target)), {
      signal
    }); // A dragged row carries its record, or every selected record when it is
    // one of them (owner, 2026-10-15, the file manager): a tree that
    // accepts records says where they were dropped.

    table.addEventListener("dragstart", event => {
      const key = rowKey(event.target);
      if (!key || !this.hasAttribute("drag-rows") || !event.dataTransfer) return;
      const selected = this.getSelectedRecordIds?.() ?? [];
      const ids = selected.map(String).includes(key) ? selected.map(String) : [key];
      const source = this.getAttribute("preferences-key") || this.getAttribute("table-settings-key") || this.id || null;
      event.dataTransfer.setData("application/x-sf-records+json", JSON.stringify({
        ids,
        source
      }));
      event.dataTransfer.setData("text/plain", ids.join(", "));
      event.dataTransfer.effectAllowed = "copyMove";
      this.emitTableEvent("rows-drag", Object.freeze({
        ids,
        source
      }));
    }, {
      signal
    }); // Reordering inside the list: a row dragged over another goes before
    // it, or after it from its lower half; the drop says which rows moved
    // and the row they now stand before (null: the end). The host decides.

    const reorder = () => this.getAttribute("row-reorder") === "true";

    const dropMark = (row, after) => {
      for (const marked of table.querySelectorAll("tbody tr[data-sf-drop-before], tbody tr[data-sf-drop-after]")) {
        marked.removeAttribute("data-sf-drop-before");
        marked.removeAttribute("data-sf-drop-after");
      }

      if (row) row.setAttribute(after ? "data-sf-drop-after" : "data-sf-drop-before", "");
    };

    const dropTarget = event => {
      const row = event.target?.closest?.("tbody tr[data-row-id]");
      if (!row) return null;
      const box = row.getBoundingClientRect();
      return {
        row,
        after: event.clientY > box.top + box.height / 2
      };
    };

    table.addEventListener("dragstart", event => {
      const key = rowKey(event.target);
      if (!key || !reorder() || !event.dataTransfer) return;
      this._reorderDrag = [key];
      event.dataTransfer.setData("application/x-sf-row-order", key);
      event.dataTransfer.effectAllowed = "move";
    }, {
      signal
    });
    table.addEventListener("dragover", event => {
      if (!this._reorderDrag || !reorder()) return;
      const target = dropTarget(event);
      if (!target) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
      dropMark(target.row, target.after);
    }, {
      signal
    });
    table.addEventListener("drop", event => {
      if (!this._reorderDrag || !reorder()) return;
      const target = dropTarget(event);
      dropMark(null);
      const ids = this._reorderDrag;
      this._reorderDrag = null;
      if (!target) return;
      event.preventDefault();
      const keys = [...table.querySelectorAll("tbody tr[data-row-id]")].map(row => row.dataset.rowId);
      const at = keys.indexOf(target.row.dataset.rowId) + (target.after ? 1 : 0);
      const rest = keys.slice(at).filter(key => !ids.includes(key));
      const before = rest[0] ?? null;
      const now = keys.filter(key => !ids.includes(key));
      const place = before === null ? now.length : now.indexOf(before);
      const order = [...now.slice(0, place), ...ids, ...now.slice(place)];
      if (order.join("\u0000") === keys.join("\u0000")) return;
      this.emitTableEvent("move", Object.freeze({
        ids: [...ids],
        before,
        order
      }));
    }, {
      signal
    });
    table.addEventListener("dragend", () => {
      this._reorderDrag = null;
      dropMark(null);
    }, {
      signal
    });
    table.addEventListener("pointerleave", () => this.setActionsRow("pointer", null), {
      signal
    });
    table.addEventListener("focusin", event => this.setActionsRow("focus", rowKey(event.target)), {
      signal
    });
    table.addEventListener("focusout", event => {
      if (!table.contains(event.relatedTarget)) this.setActionsRow("focus", null);
    }, {
      signal
    });
  } // The record the page has open (aria-current).


  isCurrentRow(row, index = -1) {
    const key = this.getRowKey(row, index);
    return key !== "" && String(this._currentRowId ?? "") === key;
  } // The row the person is on (data-current): where the keys and the last
  // press left them, else the open record.


  isCursorRow(row, index = -1) {
    const key = this.getRowKey(row, index);
    return key !== "" && String(this._cursorRowId ?? this._currentRowId ?? "") === key;
  } // ---------- many entries (§18.4) ----------
  // The rows drawn now, when the list is long enough to be windowed: the
  // range, and the heights of the spacers that stand for the rest.


  windowSlice(rows = []) {
    const count = rows.length;

    if (count < WINDOW_FROM || this.isList) {
      this._windowed = false;
      this._windowCount = count;
      return null;
    }

    this._windowed = true;
    this._windowCount = count;
    const height = this._rowHeight || ROW_HEIGHT_GUESS;
    const range = this.clampWindow(this._windowRange ?? {
      first: 0,
      last: WINDOW_INITIAL - 1
    }, count);
    this._windowRange = range;
    return {
      first: range.first,
      last: range.last,
      before: range.first * height,
      after: Math.max(0, count - 1 - range.last) * height
    };
  }

  clampWindow({
    first = 0,
    last = 0
  } = {}, count = 0) {
    const lastIndex = Math.max(0, count - 1);
    const from = Math.min(Math.max(0, Math.floor(first)), lastIndex);
    const to = Math.min(Math.max(from, Math.floor(last)), lastIndex);
    return {
      first: from,
      last: to
    };
  } // aria-rowcount of a windowed table: every row, the head's included.
  // aria-rowcount (VT-4, APG grid): the head and every record under the
  // filter when the host says how many (total), else the drawn window's.


  ariaRowCount() {
    const total = Number(this.getProp?.("total") ?? this.getAttribute("total") ?? 0);
    if (Number.isSafeInteger(total) && total > 0) return String(total + 1);
    return this.windowRowCount();
  } // A row's aria-rowindex: in a windowed table its place in the window, in
  // a page of a longer list (total and row-offset) its place in the list;
  // else none -- the rows drawn are all there is.


  ariaRowIndex(index, windowed) {
    if (windowed) return String(index + 2);
    const total = Number(this.getProp?.("total") ?? this.getAttribute("total") ?? 0);
    const offset = Number(this.getProp?.("rowOffset") ?? this.getAttribute("row-offset") ?? 0);
    if (!Number.isSafeInteger(total) || total <= 0 || !Number.isSafeInteger(offset) || offset <= 0) return null;
    return String(offset + index + 2);
  }

  windowRowCount() {
    return this._windowed ? String((this._windowCount ?? 0) + 1) : null;
  } // Which rows a person can see: the body's place against the viewport and
  // the table's own scroll box, in row heights.


  seenRows(count) {
    const body = this.refs.table?.value?.tBodies?.[0];
    if (!body || !count) return null;
    const box = body.getBoundingClientRect();
    let top = 0;
    let bottom = globalThis.innerHeight || document.documentElement.clientHeight || 0;
    const scroll = this.refs.scroll?.value;

    if (scroll) {
      const clip = scroll.getBoundingClientRect();
      top = Math.max(top, clip.top);
      bottom = Math.min(bottom, clip.bottom);
    }

    const height = this._rowHeight || ROW_HEIGHT_GUESS;
    const lastIndex = count - 1;
    const first = Math.min(lastIndex, Math.max(0, Math.floor((top - box.top) / height)));
    const last = Math.min(lastIndex, Math.max(first, Math.ceil((bottom - box.top) / height)));
    return {
      first,
      last
    };
  } // After a render and on every scroll: measure a drawn row, and move the
  // range when the rows in view come near its edge. Answers whether the
  // range moved.


  syncWindow() {
    if (!this._windowed) return false;
    const table = this.refs.table?.value;
    const drawn = table?.querySelectorAll?.("tbody tr[data-row-id]") ?? [];
    let moved = false;

    if (drawn.length) {
      // The average of the drawn rows: a row of two lines among rows of
      // one does not throw the spacers off.
      const first = drawn[0].getBoundingClientRect();
      const last = drawn[drawn.length - 1].getBoundingClientRect();
      const height = (last.bottom - first.top) / drawn.length;

      if (height > 0 && Math.abs(height - (this._rowHeight || 0)) > 0.5) {
        this._rowHeight = height;
        moved = true;
      }
    }

    const count = this._windowCount ?? 0;
    const seen = this.seenRows(count);
    if (!seen) return false;
    const range = this._windowRange ?? {
      first: 0,
      last: WINDOW_INITIAL - 1
    };
    const lowEdge = range.first > 0 ? range.first + WINDOW_MARGIN / 2 : 0;
    const highEdge = range.last < count - 1 ? range.last - WINDOW_MARGIN / 2 : count - 1;

    if (seen.first < lowEdge || seen.last > highEdge) {
      this._windowRange = this.clampWindow({
        first: seen.first - WINDOW_MARGIN,
        last: seen.last + WINDOW_MARGIN
      }, count);
      moved = true;
    }

    if (!moved) return false;
    this._windowOnly = true;
    this.requestComponentUpdate("window");
    const {
      first,
      last
    } = this._windowRange;

    if (this._reportedWindow !== `${first}-${last}`) {
      this._reportedWindow = `${first}-${last}`;
      this.emitTableEvent("window", {
        first,
        last
      });
    }

    return true;
  }

  bindWindowScroll() {
    if (this._windowScrollAbort) return;
    this._windowScrollAbort = new AbortController();
    const signal = this._windowScrollAbort.signal;

    const onScroll = () => {
      if (!this._windowed || this._windowFrame) return;
      this._windowFrame = requestAnimationFrame(() => {
        this._windowFrame = 0;
        if (this.isConnected) this.syncWindow();
      });
    }; // Any scroll box between the rows and the page moves them: listened
    // once, in the capture phase, on the document.


    document.addEventListener("scroll", onScroll, {
      capture: true,
      passive: true,
      signal
    });
    globalThis.addEventListener?.("resize", onScroll, {
      passive: true,
      signal
    });
  }

  unbindWindowScroll() {
    this._windowScrollAbort?.abort();
    this._windowScrollAbort = null;
    if (this._windowFrame) cancelAnimationFrame(this._windowFrame);
    this._windowFrame = 0;
  } // A cell that only shows a value is class markup (§18.4): what kind of
  // markup this one is, or null for a cell the full renderer draws.


  rowMarkupCell(row, column) {
    const key = column?.key;
    if (!key || !row) return null;
    const size = this.size === "1/2" ? "1/2" : "1";

    if (key === "select") {
      const cell = row.select?.component;
      if (cell?.type !== "checkbox" || typeof cell.props?.["@change"] !== "function") return null;
      return {
        kind: "box",
        size,
        checked: cell.props.checked === true,
        value: String(cell.props.value ?? row.id ?? ""),
        label: cell.props.ariaLabel ?? "",
        change: cell.props["@change"]
      };
    }

    if (key === "settings") {
      const cell = row.settings?.component;
      if ((0,_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__.canonicalTag)(`sf-${String(cell?.type ?? "").replace(/^sf-/u, "")}`) !== "sf-button-icon" || cell.props?.icon !== "menu" || typeof cell.props?.["@click"] !== "function") return null;
      return {
        kind: "menu",
        size,
        label: cell.props.ariaLabel ?? this.text("menuLabel"),
        click: cell.props["@click"]
      };
    } // The actions cell keeps one kind whether its buttons show or not: a
    // row whose arrangement changes is drawn anew, and the focus that
    // brought the buttons in would leave with the old row.


    if (column.system || column.component || column.renderer === "link" || column.role === "title") return null; // A status or a fact (C31) is the full renderer's: the dot with its
    // word, the badge.

    if (column.list === "status" || column.list === "fact") return null;
    if (this.isTree() || row.path || this.cellEditable(row, column)) return null;
    const value = row[key];
    if (value === null || typeof value === "undefined") return {
      kind: "empty"
    };
    if (typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") return null;

    if (LONG_TEXT_CELL_TYPES.has(column.propertyType ?? column.property_type ?? column.type) && typeof value !== "boolean") {
      const text = this.cellText(column, value);
      return {
        kind: "text",
        className: "sf-table-cell-clip",
        text,
        title: text
      };
    }

    const typed = this.cellValue(column, value);

    if (typed !== null && typeof typed !== "undefined") {
      if (typeof typed !== "string" && typeof typed !== "number") return null;
      const datetime = this.cellDateTime(column, value);
      if (datetime) return {
        kind: "time",
        className: "sf-table-cell-bare",
        text: String(typed),
        datetime
      };
      return {
        kind: "text",
        className: "sf-table-cell-bare",
        text: String(typed)
      };
    }

    if (typeof value === "boolean") return null;
    const text = String(value);
    return {
      kind: "text",
      className: "sf-table-cell-text",
      text,
      title: text.length > 80 ? text : null
    };
  } // The rows a keyboard walks: the drawn and the undrawn, never a «show
  // more» line.


  keyboardRows() {
    return (this.getTableData().rows || []).filter(row => row && !row.__tree?.more);
  } // The current row is marked in the page rather than through state. Going
  // through state re-rendered the rows on every click, and a render between a
  // box's click and its change event swallowed the change — one click on a
  // row was enough to lose a Shift-range selection. The field is read back by
  // the template, so a later render keeps the mark.


  focusRow(rowId, {
    reveal = false,
    focus = true
  } = {}) {
    // The action focus-row {id} (component.json) answers an outcome.
    if (rowId && typeof rowId === "object") return this.focusRowAction(rowId);
    if (rowId == null || rowId === "") return this;
    this._cursorRowId = String(rowId); // The list's rows: the item is marked, and the focus goes to its title
    // link where it has one (the row's tab stop), else to the item.

    if (this.isList) {
      const selector = `.sf-table-list-item[data-row-id="${String(rowId).replace(/"/gu, '\\"')}"]`;

      for (const marked of this.querySelectorAll(".sf-table-list-item[data-current]")) marked.removeAttribute("data-current");

      const item = this.querySelector(selector);
      item?.setAttribute("data-current", "");
      if (reveal) item?.scrollIntoView?.({
        block: "nearest",
        behavior: "instant"
      });
      if (focus) (item?.querySelector(".sf-table-title-link") ?? item)?.focus?.({
        preventScroll: true
      });
      return this;
    }

    const table = this.refs.table?.value;
    if (!table) return this;
    const selector = `tbody tr[data-row-id="${String(rowId).replace(/"/gu, '\\"')}"]`;

    for (const marked of table.querySelectorAll("tbody tr[data-current]")) {
      marked.removeAttribute("data-current");
    }

    const row = table.querySelector(selector);

    if (!row && this._windowed) {
      // A row outside the drawn range: the range moves to it, and the row
      // takes the focus once it is drawn (§18.4).
      const rows = this.getTableData().rows || [];
      const index = rows.findIndex((one, at) => this.getRowKey(one, at) === String(rowId));

      if (index >= 0) {
        this._windowRange = this.clampWindow({
          first: index - WINDOW_MARGIN,
          last: index + WINDOW_MARGIN
        }, rows.length);
        this._pendingFocusRow = String(rowId);
        this._windowOnly = true;
        this.requestComponentUpdate("window");
      }

      return this;
    }

    row?.setAttribute("data-current", ""); // At once, not smoothly: a page that scrolls smoothly would move the
    // window back to where it passes before it arrives.

    if (reveal) row?.scrollIntoView?.({
      block: "nearest",
      behavior: "instant"
    });
    row?.focus?.({
      preventScroll: true
    });
    return this;
  } // A double click opens the record, and only when the record says it can be
  // opened: the row has to offer the view action. Without it the double click
  // does nothing at all — silently, because a person double-clicking a row
  // that cannot be opened has not made a mistake worth a message.


  canOpenRow(row) {
    return Array.isArray(row?.actions) && row.actions.includes("view");
  }

  handleRowOpen(event, row) {
    if (this.isRowControlTarget(event?.target) || !this.canOpenRow(row)) return this; // With row-open="row" the first click of a double click has opened
    // the record already: the second is the same wish, not a second one.

    if (event?.type === "dblclick" && this.getAttribute("row-open") === "row") return this;
    const id = row?.id;
    if (id == null) return this;
    this.requestOpen(row, false);
    return this.requestActionIntent("view", [id]);
  } // The keyboard reaches the same two answers as the pointer: Enter opens the
  // row, Space marks it. Without them the row would be focusable and mute,
  // and marking would be reachable only by pointing at the box.
  // ─── the tree (data view port 1.8.0) ─────────────────────────────────────
  // A table is a tree when its rows carry __tree, which the data view writes
  // from the host's levels. The table only draws it and says what a person
  // asked for; which nodes exist and what opening one means is the view's.
  // Read for every cell of a draw: answered once per list (the rows array is
  // replaced, never edited in place).


  isTree() {
    const rows = this.getTableData?.().rows ?? [];
    if (this._treeMemo?.rows !== rows) this._treeMemo = {
      rows,
      tree: rows.some(row => row?.__tree)
    };
    return this._treeMemo.tree;
  } // The column a tree hangs from: the one the host marked as the title, or
  // the first column that holds data.


  treeColumnKey(columns = this.getColumns()) {
    if (!this.isTree()) return null;
    const data = columns.filter(column => column?.key && !["select", "settings", "actions"].includes(column.key) && !column.system);
    return (data.find(column => column.role === "title") ?? data[0])?.key ?? null;
  }

  toggleTreeRow(row) {
    if (this.isActionParameters?.(row, ["row"]) && !row.__tree) row = row.row;
    if (!row?.__tree?.hasChildren) return {
      outcome: "refused",
      reason: "no-children"
    };
    this.emitTableEvent("expand", Object.freeze({
      id: row.id,
      expanded: row.__tree.expanded === true
    }));
    return {
      outcome: "applied"
    };
  }

  requestTreeMore(row) {
    if (this.isActionParameters?.(row, ["row"]) && !row.__tree) row = row.row;
    if (!row?.__tree?.more) return {
      outcome: "refused",
      reason: "no-more"
    };
    this.emitTableEvent("load-more", Object.freeze({
      direction: "after",
      parent: row.__tree.parent,
      cursor: row.__tree.cursor ?? null
    }));
    return {
      outcome: "applied"
    };
  }

  handleRowKeydown(event, row) {
    // In the list the row's title link is its tab stop: the arrows, Home
    // and End move from it as from the row.
    // In the table the grid walks from a control (C146 (8)).
    const fromTitle = this.isList && event?.target !== event?.currentTarget && event?.target?.matches?.(".sf-table-title-link") && ["ArrowDown", "ArrowUp", "Home", "End"].includes(event?.key);
    if (event?.target !== event?.currentTarget && !fromTitle) return this; // A treegrid row: the right arrow opens a closed node, the left arrow
    // closes an open one.

    if (row?.__tree?.hasChildren && (event.key === "ArrowRight" || event.key === "ArrowLeft")) {
      const open = row.__tree.expanded === true;

      if (event.key === "ArrowRight" !== open) {
        event.preventDefault?.();
        return this.toggleTreeRow(row);
      }
    }

    if (event.key === "Enter") {
      return this.handleRowOpen({
        target: event.currentTarget
      }, row);
    } // The arrows, Home and End move between rows, drawn or not (§4.6,
    // §18.4): a row outside the window is drawn and then focused.


    if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key) && !event.altKey && !event.metaKey && !event.ctrlKey) {
      const rows = this.keyboardRows();
      const at = rows.findIndex(one => String(one?.id ?? one?.value) === String(row?.id ?? row?.value));
      const to = {
        ArrowDown: at + 1,
        ArrowUp: at - 1,
        Home: 0,
        End: rows.length - 1
      }[event.key];

      if (at >= 0 && to >= 0 && to < rows.length && to !== at) {
        event.preventDefault?.();
        this.focusRow(this.getRowKey(rows[to], to), {
          reveal: true
        });
      }

      return this;
    }

    if (event.key === " " || event.key === "Spacebar") {
      event.preventDefault?.();
      const checked = row?.select?.component?.props?.checked !== true;
      return this.applyRowSelection(row?.id, checked, {
        range: event.shiftKey === true
      });
    }

    return this;
  }

  clearSelection() {
    this._selectionAnchorId = null;
    this.set({
      settingsChecked: false,
      selectIndeterminate: false
    });
    if (!this.getSelectedRecordIds().length) return {
      outcome: "applied"
    };
    this.updateRows(row => ({ ...row,
      selected: false,
      checked: false,
      select: this.getDefaultRowCell(this.TABLE_SELECT_COLUMN, { ...row,
        selected: false,
        checked: false
      })
    }), "select-clear");
    return {
      outcome: "applied"
    };
  } // Composition input port. Only declared ports are accepted; the table never
  // resolves a relation itself. It asks the host through a typed query intent.


  sfPortInput(port, value, meta = {}) {
    if (!Object.hasOwn(SF_TABLE_PORTS.inputs, port)) {
      throw new TypeError(`sf-view-table has no input port ${String(port)}`);
    }

    const recordIds = checkedRecordIds(value);
    const sequence = Number.isSafeInteger(meta?.sequence) && meta.sequence > this._querySequence ? meta.sequence : this._querySequence + 1;
    this._routeContext = Object.freeze({
      record_ids: recordIds
    });
    this._querySequence = sequence;
    this.clearSelection();
    this.requestContextQuery(sequence);
    return undefined;
  }

  requestContextQuery(sequence) {
    this._pendingQuerySequence = sequence;
    this._abandonedQuery = false;
    this.setDataState("loading");
    return this.emitTableEvent("query", Object.freeze({
      reason: "context",
      context: this._routeContext,
      sequence
    }));
  } // A table that is the content of an sf-view whose code has not arrived
  // yet does not draw on its own (DEV decision msg-e39bb812: zero toolbar
  // shift when saved views are declared). The Loader defines the table
  // before the view, and drawn alone it showed its own toolbar -- the
  // search field across the whole row, the filter button and the
  // saved-views control coming in a frame later -- for the frames before
  // the view's first paint replaced it with the skeleton, whose toolbar
  // stands where the answer draws it: the toolbar moved by the width of
  // the controls (181 px with saved views declared, 141 px without, at
  // 1440). It draws once the view is defined, with what the view gave it.
  // A table the server printed (its static markup) is adopted as before.
  // The wait is bounded (saved-views r2, D2): when the view's code fails to
  // load (its script errs; the Loader's other form is given half a second)
  // or has not come in VIEW_WAIT_MS, the table draws on its own, without
  // the view's toolbar, and says so once in the console. Without the bound
  // a view whose code never came left the area blank for the page's life.


  canScheduleComponentUpdate(reason = "unknown") {
    if (this._waitsForView()) return false;
    return super.canScheduleComponentUpdate(reason);
  }

  _waitsForView() {
    if (this._viewDefined) return false;
    const host = this.parentElement;
    const waits = Boolean(host) && (0,_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__.isTag)(host, "sf-view") && this.getAttribute("slot") === "content" && !globalThis.customElements?.get?.(host.localName) && !this.querySelector("[data-sf-static]");

    if (!waits) {
      this._viewDefined = true;
      return false;
    }

    if (!this._viewWait) {
      const done = reason => {
        if (this._viewDefined) return;
        clearTimeout(this._viewWaitTimer);
        this._viewWaitAbort?.abort();
        this._viewWait = null;
        this._viewDefined = true;

        if (reason !== "defined") {
          console.warn(`sf-view-table: the ${host.localName} around this table ${reason === "failed" ? "failed to load" : `was not defined in ${VIEW_WAIT_MS} ms`}; the table draws on its own, without the view's toolbar.`);
        }

        if (this.isConnected) this.requestComponentUpdate("host-view");
      };

      this._viewWait = globalThis.customElements.whenDefined(host.localName).then(() => done("defined"));
      this._viewWaitTimer = setTimeout(() => done("timeout"), VIEW_WAIT_MS);
      this._viewWaitAbort = new AbortController(); // A script of the view's own module that errs: the Loader tries
      // the module's other form once, so the table waits a little more.

      document.addEventListener("error", event => {
        const src = event.target?.localName === "script" ? String(event.target.src || "") : "";
        if (!VIEW_SCRIPT.test(src)) return;
        clearTimeout(this._viewWaitTimer);
        this._viewWaitTimer = setTimeout(() => done("failed"), VIEW_SCRIPT_RETRY_MS);
      }, {
        capture: true,
        signal: this._viewWaitAbort.signal
      });
    }

    return true;
  }

  onConnected() {
    super.onConnected(); // The content widths are read once the rows are drawn, and a font or
    // a component's stylesheet that arrives after that makes the same
    // content wider: columns measured before it stayed narrow and their
    // values wrapped onto two lines until something re-rendered the table
    // (owner, 2026-10-14: «after I changed the sort it was right»). The
    // Loader brings a part's stylesheet when the page first uses it, and
    // fonts load late, so both send the widths to be read again.

    if (!this._lateLayoutAbort) {
      this._lateLayoutAbort = new AbortController();
      const signal = this._lateLayoutAbort.signal;

      const again = () => {
        if (this._lateLayoutFrame) return;
        this._lateLayoutFrame = requestAnimationFrame(() => {
          this._lateLayoutFrame = 0;
          if (this.isConnected && this.measureContentWidths()) this.widthsChanged();
        });
      };

      document.fonts?.addEventListener?.("loadingdone", again, {
        signal
      });
      document.fonts?.ready?.then?.(() => {
        if (!signal.aborted) again();
      });
      document.addEventListener("load", event => {
        if (event.target?.localName === "link" && /stylesheet/u.test(event.target.rel)) again();
      }, {
        capture: true,
        signal
      });
    }

    if (typeof ResizeObserver !== "undefined" && !this._responsiveObserver) {
      this._responsiveObserver = new ResizeObserver(([entry]) => {
        const width = Math.floor(entry.contentRect.width);

        if (width > 0 && width !== this._responsiveWidth) {
          this._responsiveWidth = width;
          this.requestComponentUpdate("responsive-columns");
        }

        this.measurePinnedColumns();
      });

      this._observeResponsiveBox();
    }

    if (this._abandonedQuery && this._routeContext) {
      this._querySequence += 1;
      this.requestContextQuery(this._querySequence);
    }
  } // Latest result wins: only the answer to the newest pending context query
  // is applied, and at most once.


  applyQueryResult(sequence, rows) {
    if (this.isActionParameters?.(sequence, ["sequence", "rows"])) ({
      sequence,
      rows
    } = sequence);

    if (!Number.isSafeInteger(sequence) || sequence !== this._pendingQuerySequence || !Array.isArray(rows)) {
      return {
        outcome: "refused",
        reason: "stale"
      };
    }

    this._pendingQuerySequence = null;
    this.setRows(rows);
    this.setDataState("auto");
    return {
      outcome: "applied"
    };
  }

  getQueryContext() {
    return this._routeContext;
  }

  getItemRef(id) {
    if (!this.refs.items.has(id)) {
      this.refs.items.set(id, this.createRef());
    }

    return this.refs.items.get(id);
  } // The table had its own copy of this, which created an element on every
  // render; the base's one keeps the element a position in the template
  // already has. Nothing else about the call changes.


  setIndeterminate() {
    const checked = this.state.data.rows.filter(row => {
      return row.select.component.props.checked;
    });
    return checked.length;
  }

  getTableData() {
    const data = this.state?.data;
    return data && typeof data === "object" ? data : {
      columns: [],
      rows: []
    };
  }

  isContextMenuEvent(event) {
    const target = event?.target;

    if (!(target instanceof Node)) {
      return false;
    }

    const portal = this._portalContainer;

    if (portal instanceof Node && (portal === target || portal.contains(target))) {
      return true;
    }

    const contextMenu = this.refs?.contextMenu?.value;

    if (!(contextMenu instanceof Node)) {
      return false;
    }

    if (contextMenu === target || contextMenu.contains(target)) {
      return true;
    }

    return event.composedPath?.().includes(contextMenu) || false;
  }

  contextEvent(event) {
    if (this.isContextMenuEvent(event)) {
      return;
    } // Nothing in the column settings window is pending any more -- the pin,
    // the tick and the order each apply as they are made -- so a click away
    // has nothing of theirs to lose. What it still drops is the filter form
    // a person was filling in, which is a query rather than a setting.


    this.tempSettings = null;
    this.closeContextMenu(false);
  }

  splitItemsByColumns(items = [], columnCount = 1) {
    const normalizedItems = Array.isArray(items) ? items : [];
    const normalizedColumnCount = Math.max(1, Number(columnCount) || 1);
    const itemsPerColumn = Math.ceil(normalizedItems.length / normalizedColumnCount);

    if (!itemsPerColumn) {
      return [];
    }

    return Array.from({
      length: normalizedColumnCount
    }, (_, index) => normalizedItems.slice(index * itemsPerColumn, (index + 1) * itemsPerColumn)).filter(columnItems => columnItems.length);
  }

  getPendingFilterState(filter = this.state?.filter || {}) {
    const tempFilter = this.tempSettings?.filter || {};
    const hasTempSelectedTemplateKey = Object.prototype.hasOwnProperty.call(tempFilter, "selectedTemplateKey");
    return { ...filter,
      ...tempFilter,
      selectedTemplateKey: hasTempSelectedTemplateKey ? tempFilter.selectedTemplateKey : filter.selectedTemplateKey,
      templates: tempFilter.templates || filter.templates || []
    };
  }

  getSortedFilterTemplates(filter = this.state?.filter || {}) {
    const templates = this.getFilterTemplates(filter);
    return templates.map((template, sourceIndex) => ({ ...template,
      sourceIndex,
      order: typeof template.order === "number" ? template.order : sourceIndex
    })).sort((left, right) => {
      if (Boolean(left.pinned) !== Boolean(right.pinned)) {
        return left.pinned ? -1 : 1;
      }

      if (left.order !== right.order) {
        return left.order - right.order;
      }

      return left.sourceIndex - right.sourceIndex;
    });
  }

  changeTempFilterTemplateSettings(key, patch = {}) {
    if (!key) return;
    const currentFilter = this.getPendingFilterState();
    const templates = this.getFilterTemplates(currentFilter).map(template => {
      for (const [k, v] of Object.entries(patch)) {
        template[k] = key === template.key ? v : !v;
      }

      return template;
    });
    this.tempSettings = { ...(this.tempSettings || {}),
      filter: { ...(this.tempSettings?.filter || {}),
        selectedTemplateKey: currentFilter.selectedTemplateKey,
        templates
      }
    };
    this.requestComponentUpdate("temp-filter-template");
  }

  patchTempFilterTemplateSettings(key, patch = {}) {
    if (!key) return;
    const currentFilter = this.getPendingFilterState();
    const templates = this.getFilterTemplates(currentFilter).map(template => template.key === key ? { ...template,
      ...(typeof patch === "function" ? patch(template) : patch)
    } : template);
    this.tempSettings = { ...(this.tempSettings || {}),
      filter: { ...(this.tempSettings?.filter || {}),
        selectedTemplateKey: currentFilter.selectedTemplateKey,
        templates
      }
    };
    this.requestComponentUpdate("temp-filter-template");
  }

  selectTempFilterTemplate(key) {
    if (!key) return;
    const currentFilter = this.getPendingFilterState();
    const templates = this.getFilterTemplates(currentFilter).map(template => ({ ...template,
      selected: template.key === key
    }));
    this.tempSettings = { ...(this.tempSettings || {}),
      filter: { ...(this.tempSettings?.filter || {}),
        selectedTemplateKey: key,
        templates
      }
    };
    this.requestComponentUpdate("temp-filter-template");
  }

  normalizeFilterTemplate(template = {}, sourceIndex = 0) {
    const key = template.key || `filter_template_${sourceIndex + 1}`;
    const data = template.data && typeof template.data === "object" ? template.data : {};
    return { ...template,
      key,
      label: template.label || data.template_name || key,
      data: { ...data,
        values: { ...(data.values || {})
        },
        tags: { ...(data.tags || {})
        }
      }
    };
  }

  getFilterTemplates(filter = this.state?.filter || {}) {
    const templates = (filter.templates || []).map((template, index) => this.normalizeFilterTemplate(template, index));

    if (templates.length) {
      return templates;
    }

    return [this.normalizeFilterTemplate({
      key: filter.selectedTemplateKey || "default",
      label: this.text("defaultTemplateText"),
      selected: true,
      order: 0,
      data: {}
    })];
  }

  getFilterTemplateByKey(key, filter = this.state?.filter || {}) {
    if (!key || !filter) return null;
    return this.getFilterTemplates(filter).find(template => template.key === key) || null;
  }

  getSelectedFilterTemplate(filter = this.state?.filter || {}) {
    const templates = this.getFilterTemplates(filter);
    const hasSelectedTemplateKey = Object.prototype.hasOwnProperty.call(filter, "selectedTemplateKey");

    if (hasSelectedTemplateKey && filter.selectedTemplateKey === "") {
      return null;
    }

    const selectedKey = filter.selectedTemplateKey || templates.find(template => template.selected)?.key || templates[0]?.key || "";
    return this.getFilterTemplateByKey(selectedKey, { ...filter,
      templates
    }) || templates[0] || null;
  }

  getCurrentFilterValues(filter = this.state?.filter || {}) {
    const selectedTemplate = this.getSelectedFilterTemplate(filter);
    return { ...(selectedTemplate?.data?.values || {})
    };
  }

  getCurrentFilterTags(filter = this.state?.filter || {}) {
    const selectedTemplate = this.getSelectedFilterTemplate(filter);
    return { ...(selectedTemplate?.data?.tags || {})
    };
  }

  normalizeFilterDataForCompare(value) {
    if (Array.isArray(value)) {
      return value.map(item => this.normalizeFilterDataForCompare(item));
    }

    if (value && typeof value === "object") {
      return Object.keys(value).sort().reduce((result, key) => ({ ...result,
        [key]: this.normalizeFilterDataForCompare(value[key])
      }), {});
    }

    return value;
  }

  isSameFilterData(current, next) {
    return JSON.stringify(this.normalizeFilterDataForCompare(current || {})) === JSON.stringify(this.normalizeFilterDataForCompare(next || {}));
  }

  getMergedFilterDraftData(filter = this.state?.filter || {}, tempFilter = this.tempSettings?.filter || {}) {
    const baseFilter = this.getPendingFilterState({ ...filter,
      selectedTemplateKey: Object.prototype.hasOwnProperty.call(tempFilter, "selectedTemplateKey") ? tempFilter.selectedTemplateKey : filter.selectedTemplateKey,
      templates: tempFilter.templates || filter.templates || []
    });
    const currentTags = this.getCurrentFilterTags(baseFilter);
    const currentValues = this.getCurrentFilterValues(baseFilter);
    const tags = tempFilter.replaceTags ? { ...(tempFilter.tags || {})
    } : { ...currentTags,
      ...(tempFilter.tags || {})
    };
    const values = tempFilter.replaceValues ? { ...(tempFilter.values || {})
    } : { ...currentValues,
      ...(tempFilter.values || {})
    };
    Object.entries(tempFilter.values || {}).forEach(([key, value]) => {
      if (!this.isEmptyFilterEntry(value)) {
        return;
      }

      delete values[key];
      delete tags[key];
    });
    return {
      filter: baseFilter,
      tags,
      values
    };
  }

  hasPendingFilterDataChanges(filter = this.state?.filter || {}) {
    const tempFilter = this.tempSettings?.filter;

    if (!tempFilter || !Object.prototype.hasOwnProperty.call(tempFilter, "tags") && !Object.prototype.hasOwnProperty.call(tempFilter, "values") && !tempFilter.replaceTags && !tempFilter.replaceValues) {
      return false;
    }

    const draft = this.getMergedFilterDraftData(filter, tempFilter);
    return !this.isSameFilterData(this.getCurrentFilterTags(draft.filter), draft.tags) || !this.isSameFilterData(this.getCurrentFilterValues(draft.filter), draft.values);
  } // The filter window waits for its button, so a draft and a live query look
  // alike -- the same confusion the pins had, in the window where waiting is
  // the right behaviour. This counts what a press would change, by field: a
  // field whose tag was switched on or off, or whose value or operator
  // differs. Fields are what a person reads as conditions.


  countPendingFilterConditionChanges(filter = this.state?.filter || {}) {
    const tempFilter = this.tempSettings?.filter;
    if (!tempFilter) return 0;
    const draft = this.getMergedFilterDraftData(filter, tempFilter);
    const current = {
      tags: this.getCurrentFilterTags(draft.filter),
      values: this.getCurrentFilterValues(draft.filter)
    };

    const same = (left, right) => this.isSameFilterData(left, right);

    const keys = new Set([...Object.keys(current.tags || {}), ...Object.keys(draft.tags || {}), ...Object.keys(current.values || {}), ...Object.keys(draft.values || {})]);
    let changed = 0;

    for (const key of keys) {
      const wasActive = Boolean((current.tags || {})[key]?.active);
      const willBeActive = Boolean((draft.tags || {})[key]?.active);

      if (wasActive !== willBeActive) {
        changed += 1;
        continue;
      }

      if (!same((current.values || {})[key], (draft.values || {})[key])) {
        changed += 1;
      }
    }

    return changed;
  }

  hasUnsavedFilterDataChanges() {
    return Boolean(this.state?.filterDataDirty && this.getSelectedFilterTemplate(this.state?.filter || {}));
  }

  saveCurrentFilterTemplateData() {
    const template = this.getSelectedFilterTemplate(this.state?.filter || {});

    if (!template) {
      return this;
    }

    return this.set({
      filterDataDirty: false
    }, () => {
      this.dispatchFilterTemplateSave(template.key, this.state.filter, this.getFilterTemplateByKey(template.key));
    });
  }

  mergeObjectDeep(target = {}, patch = {}) {
    return Object.entries(patch || {}).reduce((result, [key, value]) => {
      const currentValue = result[key];
      const shouldMerge = value && typeof value === "object" && !Array.isArray(value) && currentValue && typeof currentValue === "object" && !Array.isArray(currentValue);
      return { ...result,
        [key]: shouldMerge ? this.mergeObjectDeep(currentValue, value) : value
      };
    }, { ...(target || {})
    });
  }

  patchFilterTemplateByKey(key, filter = this.state.filter, props = {}) {
    if (!key || !filter) return {
      filter,
      template: null
    };
    let patchedTemplate = null;
    const nextFilter = { ...filter,
      templates: this.getFilterTemplates(filter).map(template => {
        if (key !== template.key) {
          return template;
        }

        const nextPatch = typeof props === "function" ? props(template) : props;
        patchedTemplate = this.mergeObjectDeep(template, nextPatch);
        return patchedTemplate;
      })
    };
    return {
      filter: nextFilter,
      template: patchedTemplate
    };
  }

  createFilterTemplatePatchState(filter, options = {}) {
    const nextState = {
      filter
    };

    if (Object.prototype.hasOwnProperty.call(options, "saveInputValue")) {
      nextState.saveInputValue = options.saveInputValue;
    }

    return nextState;
  } // Which fields the filter is showing, in the order the host gave them.
  // These are the chips a person adds under "Поля": without them a saved view
  // came back with the fields it was saved without.


  getActiveFilterFieldKeys(filter = this.state?.filter || {}) {
    const tags = this.getCurrentFilterTags(filter);
    const order = this.getFilterFields().map(field => field?.key);
    const chosen = Object.keys(tags).filter(key => tags[key]?.active);
    return [...order.filter(key => chosen.includes(key)), ...chosen.filter(key => !order.includes(key))];
  } // Puts those fields back. The template keeps every other part of itself;
  // only which fields are shown is replaced, because that is what was saved.


  setActiveFilterFields(keys = [], filter = this.state?.filter || {}) {
    if (!Array.isArray(keys) || keys.some(key => typeof key !== 'string' || !key.trim())) {
      throw new TypeError('Filter field keys must be nonempty strings');
    }

    const template = this.getSelectedFilterTemplate(filter);
    if (!template?.key) return this;
    const fields = this.getFilterFields();
    const current = this.getCurrentFilterTags(filter);
    const tags = {};

    for (const key of Object.keys(current)) {
      tags[key] = { ...current[key],
        active: false
      };
    }

    for (const key of keys) {
      const field = fields.find(item => item?.key === key);
      tags[key] = { ...(current[key] || {}),
        active: true,
        label: field?.label ?? current[key]?.label ?? key,
        control: field?.filter?.control || field?.type || field?.dataType || current[key]?.control || 'text'
      };
    }

    const patched = this.patchFilterTemplateByKey(template.key, filter, item => ({ ...item,
      data: { ...(item.data || {}),
        tags
      }
    }));
    return this.set({
      filter: patched.filter
    });
  } // The port passes `settings` through as it is, so the chosen fields ride
  // there. Every save path goes through here: the form's own Save is the one
  // the consumer uses, and it used to send a template without them.


  withFilterFieldSettings(detail, filter = this.state?.filter || {}) {
    if (Array.isArray(detail)) {
      return detail.map(item => this.withFilterFieldSettings(item, filter));
    }

    if (!detail || typeof detail !== 'object') return detail;
    const fields = Array.isArray(detail.data?.tags) ? [] : Object.keys(detail.data?.tags || {}).filter(key => detail.data.tags[key]?.active); // With the layout switch the view's layout rides with it too (C31):
    // a saved view opens as the list or the table it was saved as.

    const layout = this.hasLayoutSwitch ? this.chosenLayout || (this.isList ? "list" : "table") : null;
    return { ...detail,
      settings: { ...(detail.settings || {}),
        filter_fields: fields.length ? fields : this.getActiveFilterFieldKeys(filter),
        ...(layout ? {
          layout
        } : {})
      }
    };
  }

  dispatchFilterTemplateSave(key, filter, template = null) {
    const detail = this.withFilterFieldSettings(template || this.getFilterTemplateByKey(key, filter), filter); // §8: the detail is an object; the template rides in templates.

    this.emitTableEvent('template-save', {
      templates: [detail]
    });
    return this;
  }

  getChangedFilterTemplates(prevFilter = {}, nextFilter = {}, keys = []) {
    const prevTemplates = new Map(this.getFilterTemplates(prevFilter).map(template => [template.key, template]));
    return this.getFilterTemplates(nextFilter).filter(template => {
      const prevTemplate = prevTemplates.get(template.key);

      if (!prevTemplate) {
        return true;
      }

      return keys.some(key => !Object.is(prevTemplate[key], template[key]));
    });
  }

  dispatchFilterTemplatesSave(templates = []) {
    const filteredTemplates = templates.filter(template => template?.key);

    if (!filteredTemplates.length) {
      return this;
    }

    this.emitTableEvent('template-save', {
      templates: this.withFilterFieldSettings(filteredTemplates)
    });
    return this;
  }

  saveFilterTemplatePatch(key, props = {}, options = {}, filter = this.state.filter) {
    if (!key || !filter) return this;
    const patched = this.patchFilterTemplateByKey(key, filter, props);
    const nextFilter = { ...patched.filter,
      ...(options.filterPatch || {})
    };
    return this.set(() => this.createFilterTemplatePatchState(nextFilter, options), () => {
      if (options.dispatch !== false) {
        this.dispatchFilterTemplateSave(key, nextFilter, patched.template);
      }
    });
  }

  setDefaultFilterTemplate(key) {
    if (!key) return this;
    return this.set(prevState => {
      const currentFilter = prevState.filter || {};
      const filter = { ...currentFilter,
        templates: this.getFilterTemplates(currentFilter).map(template => ({ ...template,
          default: template.key === key
        }))
      };
      return {
        filter
      };
    });
  }

  patchFilterTemplateData(filter = {}, patch = {}) {
    const filterRest = { ...filter
    };
    delete filterRest.tags;
    delete filterRest.values;
    const templates = this.getFilterTemplates(filterRest);
    const selectedTemplate = this.getSelectedFilterTemplate({ ...filterRest,
      templates
    });

    if (!selectedTemplate) {
      return { ...filterRest,
        templates
      };
    }

    const nextValues = Object.prototype.hasOwnProperty.call(patch, "values") ? patch.values || {} : selectedTemplate.data?.values || {};
    const nextTags = Object.prototype.hasOwnProperty.call(patch, "tags") ? patch.tags || {} : selectedTemplate.data?.tags || {};
    const nextTemplates = templates.map(template => template.key === selectedTemplate.key ? { ...template,
      data: { ...(template.data || {}),
        ...(patch.data || {}),
        values: nextValues,
        tags: nextTags
      }
    } : template);
    return { ...filterRest,
      selectedTemplateKey: selectedTemplate.key,
      templates: nextTemplates
    };
  }

  getFilterPayload(filter = this.state?.filter || {}) {
    const selectedTemplate = this.getSelectedFilterTemplate(filter);
    const payload = { ...(selectedTemplate?.data || {}),
      templateKey: selectedTemplate?.key || "",
      templateLabel: selectedTemplate?.label || "",
      values: this.getCurrentFilterValues(filter),
      tags: this.getCurrentFilterTags(filter)
    };
    const api = this.dateFilterApi();

    if (api && typeof api.buildFilterRequest === "function") {
      try {
        const context = typeof this.getFilterContext === "function" ? this.getFilterContext() : undefined;
        const request = api.buildFilterRequest(payload.values, {
          node: this,
          context
        });

        if (request && typeof request === "object") {
          if (request.values) payload.values = request.values;
          if (request.context) payload.context = request.context;
        }
      } catch {
        /* the values as written */
      }
    }

    return payload;
  }

  selectFilterTemplate(key) {
    if (!key || this.state?.filter?.selectedTemplateKey === key) {
      return this;
    }

    this.set(prevState => {
      const currentFilter = prevState.filter || {};
      const nextFilter = { ...currentFilter,
        selectedTemplateKey: key,
        templates: (prevState.filter?.templates || []).map(template => ({ ...template,
          selected: template.key === key
        }))
      };
      const selectedTemplate = this.getFilterTemplateByKey(key, nextFilter) || nextFilter.templates[0] || null;
      return {
        filter: nextFilter,
        saveInputValue: selectedTemplate?.label || ""
      };
    });
    return this;
  } // The table's lists are reordered with the Framework's sf-sortable (owner,
  // 2026-10-13): a pointer, a finger or the keyboard, a silhouette where the
  // row lands, the steps announced. A pinned row moves among pinned rows and
  // a loose one among loose ones, so each group is a list of its own and a
  // drag cannot silently unpin anything. What a list asks for arrives as
  // sf-sortable-intent; the order is computed from keys and the window is
  // drawn again from it -- the rows are lit's, not moved by hand.


  static reorderedKeys(list, item, index) {
    const keys = [...list.querySelectorAll('[data-sf-sortable-item]')].filter(node => node.closest('sf-sortable') === list).map(node => node.getAttribute('data-sf-sortable-item')).filter(key => key !== item);
    keys.splice(Math.max(0, Math.min(index, keys.length)), 0, item);
    return keys;
  }

  onFilterTemplateIntent(event) {
    const list = event.target;
    const {
      item,
      index
    } = event.detail ?? {};
    if (!(list instanceof Element) || !item) return;
    const keys = SfTable.reorderedKeys(list, item, index);
    const group = list.getAttribute('data-group') === 'pinned' ? 'pinned' : 'normal';
    const orderedByGroup = {
      pinned: new Map(),
      normal: new Map()
    };
    keys.forEach((key, at) => orderedByGroup[group].set(key, at));
    this.syncFilterTemplateOrder(orderedByGroup);
  }

  syncFilterTemplateOrder(orderedByGroup) {
    const currentFilter = this.getPendingFilterState();
    const templates = this.getFilterTemplates(currentFilter).map((template, sourceIndex) => {
      const group = template.pinned ? "pinned" : "normal";
      const nextOrder = orderedByGroup[group].get(template.key);

      if (typeof nextOrder !== "number") {
        return template;
      }

      return { ...template,
        order: nextOrder,
        sourceIndex
      };
    });
    this.tempSettings = { ...(this.tempSettings || {}),
      filter: { ...(this.tempSettings?.filter || {}),
        selectedTemplateKey: currentFilter.selectedTemplateKey,
        templates: templates.sort((left, right) => {
          if (Boolean(left.pinned) !== Boolean(right.pinned)) {
            return left.pinned ? -1 : 1;
          }

          if (left.order !== right.order) {
            return left.order - right.order;
          }

          return left.sourceIndex - right.sourceIndex;
        })
      }
    };
    this.requestComponentUpdate("temp-filter-template-order");
  } // Whether there is room for every data column to be readable.
  //
  // A floor cannot be a width: write one on a column and it becomes the
  // width, so a cell that needs more wraps and a typed row grows -- measured
  // at 81px against 57 where the typed-cells probe watches it. And a minimum
  // on a cell is ignored in a fixed layout. So the floor is applied only when
  // it is actually needed: while there is room the columns share it as they
  // always have, and when there is not they stop at the floor and the box
  // scrolls, which is what the consumer asked for (Larena, 2026-10-06).


  get columnsAreCramped() {
    if (this._layoutReads?.has('cramped')) return this._layoutReads.get('cramped');
    const cramped = this.readColumnsAreCramped();
    this._layoutReads?.set('cramped', cramped);
    return cramped;
  }

  readColumnsAreCramped() {
    // The box that would do the scrolling is the one to measure. The
    // responsive observer's width is what it last saw, and in an embedded
    // list it had seen nothing at all -- it reported 0 while the columns
    // were 77px wide and wrapping their headings over four lines (owner,
    // 2026-10-09).
    const width = this.refs.scroll?.value?.clientWidth || this._responsiveWidth;
    if (!width) return false;
    const columns = this.getColumns?.() ?? [];
    const floored = columns.filter(column => this.columnTakesFloor(column));
    if (!floored.length) return false;
    const host = this.querySelector(".sf-table") ?? this;
    const raw = globalThis.getComputedStyle?.(host)?.getPropertyValue("--sf-table--column-min-inline-size")?.trim();
    if (!raw) return false;
    const root = Number.parseFloat(globalThis.getComputedStyle?.(document.documentElement)?.fontSize) || 16;
    const floor = raw.endsWith("rem") ? Number.parseFloat(raw) * root : Number.parseFloat(raw);
    if (!Number.isFinite(floor) || floor <= 0) return false; // What the columns that are not floored already take, measured rather
    // than assumed: the select box, the gear, the actions.
    // The actions column counts at its declared width, never more: measured,
    // it had already swallowed the room the data columns were denied, and
    // the measurement made the denial permanent.

    const taken = [...this.querySelectorAll("thead th")].filter(cell => !floored.some(column => column.key === cell.dataset.key)).reduce((total, cell) => total + (cell.dataset.key === "actions" ? Math.min(cell.getBoundingClientRect().width, floor) : cell.getBoundingClientRect().width), 0);
    return width - taken < floored.length * floor;
  } // The actions column as wide as its buttons: each a size-1 icon button, the
  // same measure the settings column is given, with the cell's padding once.
  // Whether the records are a compact list rather than a table: chosen by the
  // width of the box the table sits in, which is what a list beside an open
  // panel is narrow in, not the window.


  get isList() {
    const layout = this.resolvedLayout;
    if (layout === "list") return true;
    if (layout === "table") return false; // A table with row actions that marks key cells stays a table on a
    // phone and keeps them (C259); without key cells, the list below
    // list-below as before.

    if (this.keyedActions) return false;
    return this.isNarrow;
  } // A table with row actions whose host marks key cells (C259).


  get keyedActions() {
    return this.hasRowMenus && (this.getTableData().columns || []).some(isKeyCell);
  } // Below 44rem (the md step, where the row menu is the sheet) such a table
  // keeps the box, «≡» and its key cells alone, without sideways scroll.


  get isKeyedNarrow() {
    if (this.isList || !this.keyedActions || !(this._responsiveWidth > 0)) return false;
    const rem = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    return this._responsiveWidth < KEYED_NARROW_REM * rem;
  } // The column whose value is a key cell's second line on a phone (C259).


  keyLineOf(column) {
    return this.isKeyedNarrow ? keyLineOf(column) : null;
  } // Whether the table's container is below list-below: a phone, or a list
  // beside an open panel.


  get isNarrow() {
    const below = Number(this.getProp?.("listBelow")) || 600;
    return this._responsiveWidth > 0 && this._responsiveWidth < below;
  } // The layout drawn (C31). Without the switch, the layout attribute. With
  // it, the person's choice: a list is a list at every width, a table is a
  // table while there is room for it and the list below list-below; with no
  // choice yet, the attribute, where `table` is read as that same `auto`.


  get resolvedLayout() {
    const own = this.getProp?.("layout") ?? "table";
    if (!this.hasLayoutSwitch) return own;
    const chosen = this.chosenLayout;
    if (chosen === "list") return "list";
    if (chosen === "table") return "auto";
    return own === "table" ? "auto" : own;
  }

  get hasLayoutSwitch() {
    const value = this.getAttribute?.("layout-switch");
    return value !== null && value !== undefined && value !== "false";
  } // Where the choice is kept: the table's view preference (preferences-key,
  // else table-settings-key, else remember-widths' own key), else the page
  // session.


  get layoutPreferenceKey() {
    return this.viewPreferenceKey || this.rememberedWidthsKey || "";
  }

  get chosenLayout() {
    const key = this.layoutPreferenceKey;
    const kept = key ? preferences()?.read(key)?.layout : this._sessionLayout;
    return kept === "list" || kept === "table" ? kept : "";
  } // The switch's answer, and the action set-layout {layout}: kept for this
  // person and drawn. A saved view that is opened brings its own (sf-view).


  setLayoutChoice(layout, {
    emit = true
  } = {}) {
    if (this.isActionParameters?.(layout, ["layout"])) layout = layout.layout;
    if (layout !== "list" && layout !== "table") return {
      outcome: "refused",
      reason: "unknown-layout"
    };
    if (layout === this.chosenLayout) return {
      outcome: "unchanged"
    };
    const key = this.layoutPreferenceKey;
    if (key) this.writeTablePreference(key, {
      layout
    });else this._sessionLayout = layout;
    this.applyTableView();
    this.requestComponentUpdate("layout");
    if (emit) this.emitTableEvent("layout-change", Object.freeze({
      layout
    }));
    return {
      outcome: "applied"
    };
  } // The switch's two items, kept while the words are the same (a new array
  // on every render would draw the switch again).


  layoutSwitchItems() {
    const list = this.text("layoutList");
    const table = this.text("layoutTable");

    if (this._layoutSwitchItems?.key !== `${list}|${table}`) {
      this._layoutSwitchItems = {
        key: `${list}|${table}`,
        items: [{
          value: "list",
          label: list,
          icon: "view_agenda",
          iconOnly: true
        }, {
          value: "table",
          label: table,
          icon: "table_rows",
          iconOnly: true
        }]
      };
    }

    return this._layoutSwitchItems.items;
  } // The action set-layout {layout}.


  setLayout(layout) {
    return this.setLayoutChoice(layout);
  } // ─── the list of resources (C31) ─────────────────────────────────────────
  // A list row is a resource row when a column names its place in it
  // (columns[].list: status, title, supporting, fact or hidden).


  listRoles(columns = this.getColumns?.() ?? []) {
    const roles = {
      status: null,
      title: null,
      supporting: [],
      facts: [],
      any: false
    };

    for (const column of columns) {
      const role = column?.list;
      if (!column?.key || SYSTEM_COLUMN_KEYS.has(column.key) || column.system) continue;
      if (!LIST_ROLES.has(role)) continue;
      roles.any = true;
      if (role === "status") roles.status ??= column;else if (role === "title") roles.title ??= column;else if (role === "supporting") roles.supporting.push(column);else if (role === "fact") roles.facts.push(column);
    }

    return roles;
  } // The ids of the quick actions, in the order written, at most three.


  get quickActionIds() {
    const written = String(this.getAttribute?.("quick-actions") ?? "");
    return [...new Set(written.split(/[\s,]+/u).filter(Boolean))].slice(0, MAX_QUICK_ACTIONS);
  } // A row's actions split for the list: the quick ones (as the row offers
  // them) and the rest, which the «more» menu holds.


  listRowActions(row) {
    const items = this.rowActionItems(row).filter(item => !Array.isArray(item?.members) || item.members.length);
    const ids = this.quickActionIds;
    const quick = ids.map(id => items.find(item => item?.id === id)).filter(Boolean);
    const rest = items.filter(item => !quick.includes(item));
    return {
      quick,
      rest
    };
  } // The words of a value shown as text in the list: a link cell's text, a
  // choice's label, a typed value formatted as its cell would be.


  listText(column, value) {
    if (value === null || value === undefined || value === "") return "";
    if (Array.isArray(value)) return value.map(item => this.listText(column, item)).filter(Boolean).join(", ");

    if (typeof value === "object") {
      const props = value.component?.props;
      if (props) return String(props.text ?? props.label ?? "");
      return String(value.label ?? value.text ?? value.value ?? "");
    }

    const option = Array.isArray(column?.options) ? column.options.find(item => String(item?.value) === String(value)) : null;
    if (option) return String(option.label ?? option.value);
    return String(this.cellText?.(column, value) ?? value);
  } // The state a status column gives a row: the dot's colour and its word.
  // The value is ok, warning, error or stopped (or the dot's own names); an
  // option of the column may name its `status` and its label.


  listStatus(column, row) {
    const raw = row?.[column?.key];
    if (raw === null || raw === undefined || raw === "") return null;
    const value = typeof raw === "object" ? raw.value ?? raw.status ?? "" : raw;
    const option = Array.isArray(column?.options) ? column.options.find(item => String(item?.value) === String(value)) : null;
    const named = String(option?.status ?? (typeof raw === "object" ? raw.status : "") ?? "") || String(value);
    const dot = STATUS_DOTS[named] ?? "neutral";
    const word = (typeof raw === "object" ? raw.label ?? raw.text : null) ?? option?.label ?? (STATUS_WORDS[named] ? this.text(STATUS_WORDS[named]) : String(value));
    return {
      dot,
      word: String(word),
      value: String(value)
    };
  } // A fact: its words, how worrying it is (0 fine, 1 warning, 2 error) and
  // what it says on hover. A plain value is fine; an object or a badge
  // component carries its status; an option of the column may name one.


  listFact(column, row) {
    const raw = row?.[column?.key];
    if (raw === null || raw === undefined || raw === "") return null;
    const props = typeof raw === "object" && !Array.isArray(raw) ? raw.component?.props ?? raw : null;
    const option = !props && Array.isArray(column?.options) ? column.options.find(item => String(item?.value) === String(raw)) : null;
    const status = String(props?.status ?? props?.level ?? option?.status ?? "").replace(/^danger$/u, "error");
    const text = this.listText(column, raw);
    if (!text) return null; // The option's colour reaches the badge (owner decision C140 (2): a
    // status or a value is the tonal badge of its scheme; VT-18 of the
    // sf-view-table study: five statuses drew five grey badges). A
    // warning or an error the fact names wins over it.

    const scheme = String(props?.scheme ?? option?.scheme ?? "");
    return {
      text,
      level: FACT_LEVELS[status] ?? 0,
      status: FACT_LEVELS[status] ? status : "",
      scheme: BADGE_SCHEMES.has(scheme) ? scheme : "",
      tip: String(props?.tip ?? props?.title ?? option?.tip ?? "")
    };
  } // The id of the table's shared name tooltip (C146 (7)).


  tipId(key) {
    return `${this.getInstanceId()}--tip--${String(key).replace(/[^\w-]+/gu, "-")}`;
  } // Whether a column holds numbers (C146 (3)): its type, or the host's
  // own word for it (align: end).


  isNumberColumn(column) {
    if (!column?.key || column.system) return false;
    if (column.align === "end" || column.numeric === true) return true;
    return NUMBER_TYPES.has(column.propertyType ?? column.property_type ?? column.type);
  }

  get actionsColumnWidth() {
    const inline = (this.ACTIONS_SETTINGS_ROW ?? []).filter(action => action?.inline !== false).length;
    if (!inline) return "";
    return `calc(${inline} * (var(--sf-text-height-1) + var(--sf-ui-1--space-y-tightness-default) * 2)` + ` + ${inline - 1} * var(--sf-space-1\\/3) + var(--sf-b6))`;
  } // Each data column as wide as its content wants on one line -- the heading
  // and the values shown -- up to a cap, read from the laid-out table: for a
  // moment the table is laid out by its content at its widest (auto layout,
  // max-content), the headings are measured, and the layout goes back. The
  // columns used to share the room equally and stop at a floor, so a long
  // value wrapped in a column a short one did not need (owner, 2026-10-13).
  // A width the host or the person set wins; what does not fit scrolls.


  measureContentWidths() {
    const table = this.refs.table?.value;
    if (!(table instanceof HTMLTableElement) || !table.isConnected) return false;
    if (this._columnResizeState || this.columnDragActive) return false; // The skeleton and an empty or failed list say nothing about the content,
    // and rows kept on screen while the next ones load are the old ones: a
    // measurement of them is thrown away when the answer comes (owner,
    // 2026-10-15, a sort measured the table twice).

    if (table.querySelector('tbody[data-state]') || table.querySelector('tbody[data-busy]') || !table.querySelector('tbody tr td')) return false;
    const measured = new Map();
    let whole = 0; // What the laid-out table says now, read before the measuring class
    // changes it: the cap, the box's width and the system columns' widths
    // (they were read after the class came off: a style and two layouts
    // more of the whole table, at 4x CPU some 60 ms on the admin's list;
    // stand 25). The box scrolls, so the measuring does not change it.

    const cap = this.columnWidthCap();
    const box = table.parentElement?.clientWidth ?? 0;
    const systemWidths = new Map();

    for (const cell of table.querySelectorAll('thead th[data-key]')) {
      if (SYSTEM_COLUMN_KEYS.has(cell.dataset.key)) systemWidths.set(cell, Math.ceil(cell.getBoundingClientRect().width));
    }

    table.classList.add('sf-table-measuring'); // Measured before the table's own stylesheet has come, the measuring
    // class does nothing, the fixed layout squeezes every column to a
    // letter's width, and those widths were applied and held until the
    // sheet arrived (owner, 2026-10-15, frame by frame). Not measured then:
    // the stylesheet's arrival measures again.

    if (getComputedStyle(table).tableLayout !== 'auto') {
      table.classList.remove('sf-table-measuring');
      return false;
    }

    try {
      whole = table.getBoundingClientRect().width;

      for (const cell of table.querySelectorAll('thead th[data-key]')) {
        const key = cell.dataset.key;
        if (SYSTEM_COLUMN_KEYS.has(key)) continue;
        measured.set(key, contentStep(cell.getBoundingClientRect().width));
      }
    } finally {
      table.classList.remove('sf-table-measuring');
    } // The content's own width: every data column at its content width (as
    // contentWidth caps it) and the system columns at their fixed ones. The
    // table is never narrower (contentInlineSize): the column that takes
    // the spare room keeps its content width where there is none, in a
    // box of any width -- a first paint printed at one width and drawn at
    // another squeezed it to a letter's width (standard 1.3.8 gate 24).


    let content = 0;

    for (const cell of table.querySelectorAll('thead th[data-key]')) {
      const key = cell.dataset.key;
      content += SYSTEM_COLUMN_KEYS.has(key) ? systemWidths.get(cell) ?? 0 : Math.min(measured.get(key) ?? 0, cap);
    }

    const contentChanged = content !== (this._contentInlineSize ?? 0);
    this._contentInlineSize = content; // Room to spare: the content is narrower than the box. A fixed table
    // shares the spare room between every column with a width, the box and
    // the menu columns too, so a list of one data column showed it some
    // 330px in, after two wide empty columns (Larena, 2026-10-14). The last
    // data column is then left without a width and takes the spare room.

    const surplus = box > 0 && whole > 0 && whole < box;
    const surplusChanged = surplus !== Boolean(this._contentSurplus);
    this._contentSurplus = surplus; // A cell drawn by an element whose module is still on the way -- the
    // Loader brings parts when a page first uses them -- is empty when this
    // runs, and its column was measured a few pixels wide and kept so:
    // record links broke inside words in a 45px column (Larena,
    // 2026-10-13). Measure again once those elements are drawn.

    this.remeasureWhenDrawn(table);
    const previous = this._contentWidths ?? new Map();
    const changed = measured.size !== previous.size || [...measured].some(([key, width]) => Math.abs((previous.get(key) ?? 0) - width) > 0.01);
    if (changed) this._contentWidths = measured;
    return changed || surplusChanged || contentChanged;
  } // In pixels, capped here rather than with min() in the column's width: a
  // fixed-layout table read min(784px, 20rem) as no fixed width at all and
  // gave that column the whole of the table's spare room.
  // Folds the values of a multi-value cell that do not fit its line into
  // «+N» (see renderCellValues in the template).


  fitCellValues() {
    // A value that is an element not yet drawn -- its module still on the
    // way, as the Loader brings parts when they are first used -- has no
    // width yet, so the line is measured again once it has one.
    const pending = new Set();

    for (const item of this.querySelectorAll('tbody .sf-table-cell-values > :not(.sf-table-cell-more)')) {
      if (item.localName.includes('-') && (!customElements.get(item.localName) || !cellValueBox(item).getBoundingClientRect().width)) {
        pending.add(item.localName);
      }
    }

    if (pending.size && (this._fitRetries ?? 0) < 3) {
      this._fitRetries = (this._fitRetries ?? 0) + 1;
      const token = this._fitToken = (this._fitToken ?? 0) + 1;
      Promise.all([...pending].map(name => customElements.whenDefined(name))).then(() => new Promise(settle => requestAnimationFrame(() => requestAnimationFrame(settle)))).then(() => {
        if (token === this._fitToken && this.isConnected) this.fitCellValues();
      });
    } else if (!pending.size) {
      this._fitRetries = 0;
    } // Every line put back first and read in one go: a line reset and read
    // in turn laid the table out again for each cell (stand 25, 20 rows of
    // tags and references: a third of the time the rows took to draw).


    const lines = [];

    for (const box of this.querySelectorAll('tbody .sf-table-cell-values')) {
      const more = box.querySelector(':scope > .sf-table-cell-more');
      const items = [...box.children].filter(child => child !== more);
      const valueBoxes = items.map(item => cellValueBox(item));
      lines.push({
        box,
        more,
        items,
        valueBoxes
      });
    }

    for (const {
      more,
      valueBoxes
    } of lines) {
      for (const valueBox of valueBoxes) valueBox.classList.remove('sf-table-cell-folded');

      if (!more) continue;
      more.hidden = true;
      more.removeAttribute('title');
    }

    const overflowing = lines.filter(({
      box,
      more
    }) => more && box.scrollWidth > box.clientWidth + 1);

    for (const {
      box,
      more,
      items,
      valueBoxes
    } of overflowing) {
      // Room for the counter first, then values leave from the end until
      // the rest and the counter fit.
      more.hidden = false;
      more.textContent = `+${items.length}`;
      const folded = [];

      for (let at = items.length - 1; at > 0 && box.scrollWidth > box.clientWidth + 1; at -= 1) {
        valueBoxes[at].classList.add('sf-table-cell-folded');
        folded.unshift(items[at]);
        more.textContent = `+${folded.length}`;
      }

      if (!folded.length) {
        more.hidden = true;
        continue;
      }

      more.title = folded.map(item => item.textContent.trim()).filter(Boolean).join(', ');
    }
  } // True when the measuring waits for the cells' elements to draw: every
  // element in the cells is defined and some have not drawn yet. Measured
  // when they have, or at the next frame at the latest.


  measureWhenCellsDrawn() {
    const table = this.refs.table?.value;
    if (!(table instanceof HTMLTableElement) || this._columnResizeState || this.columnDragActive) return false;
    if (table.querySelector('tbody[data-state]') || table.querySelector('tbody[data-busy]')) return false;
    const drawing = [];

    for (const element of table.querySelectorAll('tbody td *')) {
      if (!element.localName.includes('-')) continue;
      if (!customElements.get(element.localName) || typeof element.whenRendered !== 'function') return false; // One held by its style gate draws when its sheets come, perhaps
      // after this frame: measured now, as before.

      if (element.hasAttribute('data-sf-style-pending')) return false;
      if (element.isRendered !== true) drawing.push(element);
    }

    if (!drawing.length) return false;
    const token = this._cellsDrawnToken = (this._cellsDrawnToken ?? 0) + 1;
    const nextFrame = new Promise(settle => requestAnimationFrame(settle));
    Promise.race([Promise.all(drawing.map(element => element.whenRendered())), nextFrame]).catch(() => {}).then(() => {
      if (token !== this._cellsDrawnToken || !this.isConnected) return;
      if (this.measureContentWidths()) this.applyColumnWidths();
      this._contentRetries = 0;
      this.fitCellValues();
      this.measurePinnedColumns();
      if (this.hasAttribute("data-sf-page-scroll")) this.syncRail();
    });
    return true;
  }

  remeasureWhenDrawn(table) {
    const pending = new Set();

    for (const element of table.querySelectorAll('tbody td *')) {
      if (!element.localName.includes('-')) continue;
      if (!customElements.get(element.localName) || !element.childElementCount) pending.add(element.localName);
    }

    if (!pending.size) {
      this._remeasureTries = 0;
      return;
    }

    if ((this._remeasureTries ?? 0) >= 3) return;
    this._remeasureTries = (this._remeasureTries ?? 0) + 1;
    const token = this._remeasureToken = (this._remeasureToken ?? 0) + 1; // Every element in the cells defined (sf-view-table relates them eagerly):
    // the widths are read again the moment they have drawn, in the same
    // task, before the frame is painted -- read two frames later, the
    // columns moved by a few pixels after the rows had been shown (gate 24
    // phase 3, sf-view at 1280).

    const drawing = [...table.querySelectorAll('tbody td *')].filter(element => pending.has(element.localName) && typeof element.whenRendered === 'function');

    if ([...pending].every(name => customElements.get(name)) && drawing.length) {
      Promise.all(drawing.map(element => element.isRendered === true ? null : element.whenRendered())).then(() => {
        if (token !== this._remeasureToken || !this.isConnected) return;
        if (this.measureContentWidths()) this.widthsChanged();
      });
      return;
    }

    Promise.all([...pending].map(name => customElements.whenDefined(name))).then(() => new Promise(settle => requestAnimationFrame(() => requestAnimationFrame(settle)))).then(() => {
      if (token !== this._remeasureToken || !this.isConnected) return;
      if (this.measureContentWidths()) this.widthsChanged();
    });
  } // New widths after a render: written onto the columns, and what reads
  // widths -- folded values, pinned offsets, the rail -- read again.


  widthsChanged() {
    this.applyColumnWidths();
    this.fitCellValues();
    this.measurePinnedColumns();
    if (this.hasAttribute("data-sf-page-scroll")) this.syncRail();
  }

  applyColumnWidths() {
    const table = this.refs.table?.value;
    if (!(table instanceof HTMLTableElement)) return;
    const columns = new Map((this.getColumns?.() ?? []).map(column => [String(column?.key), column])); // Every column's style worked out before any is written: the cap and
    // whether the columns are cramped are read from the laid-out table,
    // and a write between two reads laid it out again for each column
    // (stand 25: 17 columns, the larger part of the rows' first draw).

    const cols = [...table.querySelectorAll(':scope > colgroup > col[data-key]')];
    const styles = this.readingLayout(() => cols.map(col => {
      const column = columns.get(col.dataset.key);
      return column ? (0,_js_templates_default__WEBPACK_IMPORTED_MODULE_7__.columnStyle)(this, column) : null;
    }));
    cols.forEach((col, at) => {
      const style = styles[at];
      if (style === null) return;

      if ((col.getAttribute('style') ?? '') !== style) {
        if (style) col.setAttribute('style', style);else col.removeAttribute('style');
      }
    });
    table.classList.toggle('sf-table-content-sized', this.contentSized);
    table.classList.toggle('w-max', !this.contentSized);
    if (this.hasContentWidths && this._contentInlineSize) table.style.setProperty('--sf-table--content-inline-size', `${this._contentInlineSize}px`);else table.style.removeProperty('--sf-table--content-inline-size');
  }

  contentWidth(column) {
    const width = this._contentWidths?.get(column?.key);
    if (!width) return ''; // The column that takes the spare room has no width of its own: the
    // table's least width (--sf-table--content-inline-size) gives it its
    // content width where there is no spare room, so it holds in a box of
    // any width.

    if (column?.key === this.spareRoomColumnKey()) return '';
    return `${Math.min(width, this.columnWidthCap())}px`;
  } // The column that takes the spare room: the last data column nobody sized.


  spareRoomColumnKey() {
    const columns = this.getColumns?.() ?? [];

    for (let at = columns.length - 1; at >= 0; at -= 1) {
      const column = columns[at];
      if (!column?.key || SYSTEM_COLUMN_KEYS.has(column.key)) continue;
      if (column.colWidth ?? column.width ?? column.size) return null;
      return column.key;
    }

    return null;
  }

  get hasContentWidths() {
    return Boolean(this._contentWidths?.size);
  } // Content-sized from the first render with rows, before the widths are
  // measured: the table is laid out by its content (default.css, the
  // unmeasured content-sized table), as its printed first paint is, until
  // the measured widths come. Drawn as wide as its content with a fixed
  // layout instead, the first render shared the room between every column
  // for a frame and the printed cells moved twice (gate 24, typed-cells).


  get contentSized() {
    return this.hasContentWidths || (this.getTableData?.()?.rows?.length ?? 0) > 0;
  } // Reads that write nothing in between: the cap and the cramped answer are
  // read once for the whole pass instead of once per column.


  readingLayout(read) {
    if (this._layoutReads) return read();
    this._layoutReads = new Map();

    try {
      return read();
    } finally {
      this._layoutReads = null;
    }
  }

  columnWidthCap() {
    if (this._layoutReads?.has('cap')) return this._layoutReads.get('cap');
    const cap = this.readColumnWidthCap();
    this._layoutReads?.set('cap', cap);
    return cap;
  }

  readColumnWidthCap() {
    const raw = getComputedStyle(this).getPropertyValue('--sf-table--column-max-inline-size').trim();
    const root = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    const value = Number.parseFloat(raw);
    if (!Number.isFinite(value) || value <= 0) return 320;
    return raw.endsWith('rem') ? value * root : value;
  }

  columnTakesFloor(column) {
    if (!column?.key || SYSTEM_COLUMN_KEYS.has(column.key)) return false;
    return !(column.colWidth ?? column.width ?? column.size ?? column.min_width ?? column.minWidth);
  } // The settings column carries two things: the gear in its head, which
  // opens the column settings (settings-menu), and the ≡ in each row, which
  // opens the row's menu of actions. With neither -- no column settings, no
  // row actions to list, no rows to put in order -- it is an empty column
  // of buttons that open nothing, and it is not drawn (Larena, the sites
  // list, 2026-11-05: a «≡» column beside every row of a list without
  // actions).


  settingsColumnHasUse(props = this.getPropsContext()) {
    if (props.settingsMenu !== false) return true;
    if (props.rowReorder === true) return true;
    return (this.ACTIONS_SETTINGS_ROW ?? []).length > 0;
  }

  getSystemColumns() {
    const columns = [];
    const props = this.getPropsContext();

    if (props.selectable) {
      columns.push(this.getSelectColumn());
    } // No «Действия» column (owner decision C146 (5), variant В): every
    // action of a row is in its «≡» menu, which the right button, the
    // menu key and Shift+F10 open too; opening the record is the main
    // field's link. The hover-only column of buttons is gone, so the
    // «≡» column carries the row actions wherever that column stood:
    // settings="false" (a view whose chrome draws no settings) takes the
    // gear from its head and keeps the row menus.


    const rowMenus = Boolean(props.actions && props.rowActions && this.state.actionActive && (this.ACTIONS_SETTINGS_ROW ?? []).length);

    if (props.settings && this.settingsColumnHasUse(props) || rowMenus) {
      columns.push(this.TABLE_SETTINGS_COLUMN);
    }

    return columns;
  }

  setTemplates(data) {
    const nextTemplates = Object.values(data || {}).map((template, index) => this.normalizeFilterTemplate(template, index));
    return this.set(prevState => {
      const currentFilter = prevState.filter || {};
      const templatesByKey = new Map();
      this.getFilterTemplates(currentFilter).forEach(template => {
        templatesByKey.set(template.key, template);
      });
      nextTemplates.forEach(template => {
        templatesByKey.set(template.key, { ...(templatesByKey.get(template.key) || {}),
          ...template
        });
      });
      const templates = Array.from(templatesByKey.values());
      const hasCurrentSelectedTemplateKey = Object.prototype.hasOwnProperty.call(currentFilter, "selectedTemplateKey");
      const defaultTemplate = templates.find(template => template.default === true);
      const incomingSelectedKey = nextTemplates.find(template => template?.selected)?.key;
      const fallbackSelectedKey = defaultTemplate?.key || templates[0]?.key || "";
      const selectedTemplateKey = this._filterTemplatesLoaded ? incomingSelectedKey ?? (hasCurrentSelectedTemplateKey ? currentFilter.selectedTemplateKey : fallbackSelectedKey) : incomingSelectedKey ?? fallbackSelectedKey;
      const nextFilter = { ...currentFilter,
        selectedTemplateKey,
        templates: templates.map(template => ({ ...template,
          selected: template.key === selectedTemplateKey
        }))
      };
      const selectedTemplate = selectedTemplateKey === "" ? null : this.getFilterTemplateByKey(selectedTemplateKey, { ...nextFilter,
        templates
      }) || templates[0] || null;
      this._filterTemplatesLoaded = true;
      return {
        filter: nextFilter,
        saveInputValue: selectedTemplate?.label || ""
      };
    });
  } // The identity of this instance: the author's id when there is one, its own
  // counter otherwise. Never the component name, so a second table on the page
  // cannot inherit the first one's ids or preferences.


  getInstanceId() {
    return this.id || this._instanceId;
  }

  getColumnResizerId(columnKey) {
    return `${this.getInstanceId()}--column-resizer--${columnKey}`;
  }

  getTableSettingsKey() {
    return this.tableSettingsKey || this.getAttribute?.("table-settings-key") || this.id || this.getInstanceId();
  }

  normalizeTableSettings(data = {}, tableSettingsKey = this.getTableSettingsKey()) {
    const settingsMap = data?.tableSettings && typeof data.tableSettings === "object" && !Array.isArray(data.tableSettings) && !data.tableSettings.columnSettings ? data.tableSettings : null;
    const source = data?.item || settingsMap?.[tableSettingsKey] || data?.tableSettings || data?.settings || data || {};
    const columnSettings = source?.columnSettings || data?.columnSettings || {};
    return { ...source,
      columnSettings: columnSettings && typeof columnSettings === "object" && !Array.isArray(columnSettings) ? columnSettings : {}
    };
  }

  setTableSettings(data = {}, reason = "table-settings-load", tableSettingsKey = this.getTableSettingsKey()) {
    const settings = this.normalizeTableSettings(data, tableSettingsKey);
    return this.setColumnSettings(settings.columnSettings, reason, false);
  }

  getContextMenuLabel(data = {}) {
    switch (data.menu || data.type) {
      case 'filter-favorites':
        return this.text('contextSaveTemplateLabel');

      case 'filter-settings':
        return this.text('contextFilterSettingsLabel');

      case 'filter-template-actions':
        return `${this.text('contextTemplateActionsLabel')}: ${data.template?.label || data.template?.key || ''}`.trim();

      case 'tag-settings':
        {
          const fieldKey = data.fieldKey || '';
          const field = this.getFilterField(fieldKey);
          const label = field?.label || this.getCurrentFilterTags()?.[fieldKey]?.label || fieldKey;
          return `${this.text('contextFieldFilterLabel')}: ${label || this.text('fieldWordText')}`;
        }

      case 'row-settings':
        return this.text('contextRowActionsLabel');

      case 'create':
        return this.text('contextCreateOptionsLabel');

      case 'list-sort':
        return this.text('sortLabel');

      case 'toolbar-actions':
        return this.text('contextViewActionsLabel');

      case 'table-settings':
      default:
        return this.text('contextTableSettingsLabel');
    }
  }

  renderFilterFavoritesContextMenu(data) {
    const {
      x,
      y,
      position
    } = data;
    const template = this.getSelectedFilterTemplate();
    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
            <sf-menu-context
                    size=${this.menuSize}
                    :key=${x + y + this._renderToken}
                    aria-label=${this.getContextMenuLabel({ ...data,
      menu: 'filter-favorites'
    })}
                    style="
            position: fixed;
            left: ${x}px;
            inset-block-start: calc(${y}px + calc(var(--sf-focus-outline-width) * 2));
            z-index: var(--sf-table-context-menu--z-index, ${this.contextMenuZIndex()});
          "
                    root-class="sf-table-context-menu ${this.contextWindowClass('filter-favorites')} ${this.size === "1/2" ? "sf-table-context-menu--dense " : ""}flex flex-col"
                    data-context-main-menu
                    position="${position || ""}"
            >
                <div class="flex flex-col flex-1 gap-2" slot="content">
                    <div class="sf-table-context-top"><span class="sf-text-2 bold">${this.text('saveTemplateLabel')}</span></div>
                    <div class="sf-table-context-main">
                        <form ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__.ref)(this.refs.templateForm)} id="save_template" class="flex flex-col gap-1/2">
                            <sf-input
                                    size=${this.size}
                                    appearance="filled"
                                    placeholder="${this.text('templateNamePlaceholder')}"
                                    value="${this.state.saveInputValue}"
                                    name="template_name"
                                    @change=${e => {
      this.set({
        saveInputValue: e.target.value
      });
    }}
                                    @input=${e => {
      this.set({
        saveInputValue: e.target.value
      });
    }}
                            ></sf-input>
                            <div class="flex flex-col gap-1/2">
                                <sf-checkbox size=${this.size}
                                        name="template_default"
                                        position="end"
                                        root-class="content-main-between"
                                        value="1"
                                        ?checked=${template.data.template_default}
                                        label="${this.text('makeDefaultLabel')}"
                                ></sf-checkbox>
                                <sf-checkbox size=${this.size}
                                        name="template_save_for_all"
                                        position="end"
                                        root-class="content-main-between"
                                        value="1"
                                        ?checked=${template.data.template_save_for_all}
                                        label="${this.text('saveForEveryoneLabel')}"
                                ></sf-checkbox>
                        </form>
                    </div>
                </div>
                <div class="sf-table-context-bottom sf-context-menu-footer">
                    <sf-button size=${this.size}
                            ?disabled=${this.state.saveInputValue.length === 0}
                            @click="${() => {
      this.saveFilterTemplate();
    }}" root-class="flex-1" text="${this.text('applyText')}"></sf-button>
                    <sf-button size=${this.size} @click="${() => {
      this.tempSettings = null;
      this.requestComponentUpdate('table');
    }}" appearance="outline" scheme="on-surface" root-class="flex-1"
                               text="${this.text('resetText')}"></sf-button>
                </div>
                </div>
            </sf-menu-context>
        `;
  }

  saveFilterTemplate() {
    const form = this.refs.templateForm.value;
    if (!form) return false;
    const formData = Object.fromEntries(new FormData(form));
    const {
      templates
    } = this.state.filter;
    const prevTemplate = templates.filter(template => {
      return template.label === formData.template_name;
    })?.[0];
    const values = this.getCurrentFilterValues();
    const tags = this.getCurrentFilterTags();
    let template = {
      key: prevTemplate ? prevTemplate.key : `filter_template_${templates.length + 1}`,
      label: formData.template_name,
      selected: true,
      data: { ...formData,
        values,
        tags
      }
    };
    this.emitTableEvent('template-save', {
      templates: [this.withFilterFieldSettings(template)]
    });
    this.tempSettings = null;
    this.closeContextMenu();
  }

  getColumnItems() {
    const dataColumns = this.getTableData().columns || [];
    const originalIndexByKey = new Map(dataColumns.map((column, index) => [column?.key, index]));

    const getOrder = column => {
      const order = column?.order;
      return order !== null && typeof order !== "undefined" && order !== "" && Number.isFinite(Number(order)) ? Number(order) : originalIndexByKey.get(column?.key) ?? 0;
    };

    return dataColumns.map(column => {
      const settings = this.getColumnSetting(column?.key);
      const nextColumn = { ...column,
        ...settings
      };

      if (settings.width) {
        nextColumn.colWidth = settings.width;
      }

      return nextColumn;
    }).sort((left, right) => {
      // The list reads like the table: the pinned group first, then
      // the rest of the visible columns, then the hidden ones. Sorting
      // by order alone put the hidden columns wherever their stored
      // order happened to fall — a consumer opened the settings and
      // found eight columns it had never shown standing above its own,
      // with the pinned one in the middle.
      const group = column => {
        if (this.isColumnPinned(column)) return 0;
        return this.isColumnVisible(column) ? 1 : 2;
      };

      const leftGroup = group(left);
      const rightGroup = group(right);

      if (leftGroup !== rightGroup) {
        return leftGroup - rightGroup;
      }

      const leftOrder = getOrder(left);
      const rightOrder = getOrder(right);

      if (leftOrder === rightOrder) {
        return (originalIndexByKey.get(left.key) ?? 0) - (originalIndexByKey.get(right.key) ?? 0);
      }

      return leftOrder - rightOrder;
    });
  } // Whether a column is shown. The answer the person is editing right now
  // wins, then what the host has stored, then what the column itself says.


  isColumnVisible(column) {
    if (!column?.key) return false;
    const pending = this.tempSettings?.cols?.[column.key];
    const setting = this.getColumnSetting(column.key) || {};
    return pending?.visible ?? setting.visible ?? column.visible !== false;
  } // The person's and the host's column settings, merged. It is asked for
  // hundreds of times in one draw -- every column, every pinned cell -- so
  // the merge is made once per change of either source and read from the
  // memo while drawing (simai/ui-pro#1). Both sources are replaced, never
  // edited in place, so their identity says when they changed.


  getColumnSettings() {
    const dataSettings = this.getTableData().columnSettings;
    const stateSettings = this.state?.columnSettings;
    const memo = this._columnSettingsMemo;
    if (memo && memo.data === dataSettings && memo.state === stateSettings) return memo.value;
    const value = this.mergedColumnSettings(dataSettings, stateSettings);
    this._columnSettingsMemo = {
      data: dataSettings,
      state: stateSettings,
      value
    };
    return value;
  }

  mergedColumnSettings(dataSettings, stateSettings) {
    const normalizedDataSettings = dataSettings && typeof dataSettings === "object" && !Array.isArray(dataSettings) ? dataSettings : {};
    const normalizedStateSettings = stateSettings && typeof stateSettings === "object" && !Array.isArray(stateSettings) ? stateSettings : {};
    return { ...normalizedDataSettings,
      ...normalizedStateSettings
    };
  }

  getColumnSetting(columnKey) {
    if (!columnKey) return {}; // During a draw, the settings read once for it (drawingWith).

    const settings = (this._drawColumnSettings ?? this.getColumnSettings())?.[columnKey];
    return settings && typeof settings === "object" && !Array.isArray(settings) ? settings : {};
  }

  normalizeColumnSetting(settings = {}) {
    const nextSettings = {};
    Object.entries(settings || {}).forEach(([key, value]) => {
      if (typeof value === "undefined") {
        return;
      }

      if (key === "colWidth") {
        nextSettings.width = value;
        return;
      }

      nextSettings[key] = value;
    });

    if (typeof nextSettings.order !== "undefined" && nextSettings.order !== null && nextSettings.order !== "") {
      nextSettings.order = Number(nextSettings.order);
    }

    return nextSettings;
  }

  mergeColumnSettings(currentSettings = {}, patch = {}) {
    const nextSettings = { ...(currentSettings || {})
    };
    Object.entries(patch || {}).forEach(([columnKey, columnPatch]) => {
      if (!columnKey || !columnPatch || typeof columnPatch !== "object") {
        return;
      }

      nextSettings[columnKey] = this.normalizeColumnSetting({ ...(nextSettings[columnKey] || {}),
        ...columnPatch
      });
    });
    return nextSettings;
  } // The person asked for the default columns back. The component names no
  // defaults of its own — it says the layer should go, and the host answers
  // with whatever it considers default for this view.


  requestColumnSettingsReset() {
    // The person's arrangement goes from the preference too.
    if (this.viewPreferenceKey) {
      const {
        columnSettings,
        widths,
        ...rest
      } = preferences()?.read(this.viewPreferenceKey) ?? {};
      preferences()?.write(this.viewPreferenceKey, rest);
    }

    return this.emitTableEvent("column-settings-reset", Object.freeze({
      target: "personal",
      tableSettingsKey: this.getTableSettingsKey?.() ?? null
    }));
  }

  emitColumnSettingsChange(reason = "column-settings") {
    if (reason !== "preferences" && this.viewPreferenceKey) {
      this.writeTablePreference(this.viewPreferenceKey, {
        columnSettings: this.getColumnSettings()
      });
    }

    const detail = {
      reason,
      columnSettings: this.getColumnSettings(),
      tableSettingsKey: this.getTableSettingsKey()
    }; // Vocabulary §5 save {kind: columns}; sf-table-column-settings-change,
    // sf-table:column-settings-change and onColumnSettingsChange follow
    // once each with the same fields (detail-adds rows).

    this.emitTableEvent('save', {
      kind: "columns",
      ...detail
    });
    return this;
  }

  setColumnSettings(settings = {}, reason = "column-settings", emit = true) {
    const nextSettings = typeof settings === "function" ? settings(this.getColumnSettings()) : settings;
    return this.set({
      columnSettings: nextSettings && typeof nextSettings === "object" ? nextSettings : {}
    }, reason, () => emit ? this.emitColumnSettingsChange(reason) : false);
  }

  patchColumnSettings(columnKey, patch = {}, reason = "column-settings") {
    if (!columnKey) return this;
    const currentSetting = this.getColumnSetting(columnKey);
    const nextPatch = typeof patch === "function" ? patch(currentSetting) : patch;
    return this.patchColumnSettingsBatch({
      [columnKey]: nextPatch || {}
    }, reason);
  }

  patchColumnSettingsBatch(patch = {}, reason = "column-settings") {
    const currentSettings = this.getColumnSettings();
    const nextSettings = this.mergeColumnSettings(currentSettings, patch);

    if (JSON.stringify(currentSettings) === JSON.stringify(nextSettings)) {
      return this;
    }

    return this.setColumnSettings(nextSettings, reason);
  }

  getFilterFields() {
    const fields = this.state?.filter?.fields;
    return Array.isArray(fields) ? fields : [];
  } // Whether the toolbar offers a filter at all: when the host gave fields to
  // filter by or saved templates to choose from, or a filter is already on.
  // Without them the button opened a panel of templates and fields with no
  // value to set, which read as broken (documentation trial 6; owner and
  // Larena, 2026-10-18).


  offersFilter(activeCount = 0) {
    const templates = this.state?.filter?.templates;
    return this.getFilterFields().length > 0 || Array.isArray(templates) && templates.length > 0 || activeCount > 0;
  }

  getFilterField(fieldKey) {
    if (!fieldKey) return null;
    return this.getFilterFields().find(field => field?.key === fieldKey) || null;
  }

  setFilterFields(fields = [], reason = "filter-fields") {
    for (const page of this._filterOptionPages.values()) {
      page.controller?.abort();
      clearTimeout(page.searchTimer);
    }

    this._filterOptionPages.clear();

    return this.set(prevState => ({
      filter: { ...(prevState.filter || {}),
        fields: Array.isArray(fields) ? fields : []
      }
    }), reason);
  }

  patchTempColumnSettings(columnKey, patch = {}) {
    if (!columnKey) return;
    this.tempSettings = { ...(this.tempSettings || {}),
      cols: { ...(this.tempSettings?.cols || {}),
        [columnKey]: { ...(this.tempSettings?.cols?.[columnKey] || {}),
          ...(typeof patch === "function" ? patch() : patch)
        }
      }
    };
  }

  patchTempFilterTagSettings(columnKey, patch = {}) {
    if (!columnKey) return;
    this.tempSettings = { ...(this.tempSettings || {}),
      filter: { ...(this.tempSettings?.filter || {}),
        tags: { ...(this.tempSettings?.filter?.tags || {}),
          [columnKey]: { ...(this.tempSettings?.filter?.tags?.[columnKey] || {}),
            ...(typeof patch === "function" ? patch() : patch)
          }
        }
      }
    }; // The same defect the pins had: a patch is a plain property, so nothing
    // redrew and anything reading the draft kept the state it was drawn
    // with -- here the button that says how many conditions are pending.
    // Switching a condition on is a checkbox, so a redraw costs nothing a
    // person can feel.

    this.requestComponentUpdate('filter-tag');
  }

  patchTempFilterValue(fieldKey, patch = {}) {
    if (!fieldKey) return;
    const currentValues = this.getCurrentFilterValues(this.getPendingFilterState());
    const currentValue = this.tempSettings?.filter?.values?.[fieldKey] || currentValues[fieldKey] || {};
    const nextPatch = typeof patch === "function" ? patch(currentValue) : patch;
    const nextValue = { ...currentValue,
      ...(nextPatch || {})
    };

    const isSameValue = (current, next) => {
      if (!Array.isArray(current) || !Array.isArray(next)) {
        return Object.is(current, next);
      }

      if (current.length !== next.length) {
        return false;
      }

      return current.every((item, index) => Object.is(item, next[index]));
    };

    const changed = Object.keys(nextValue).some(key => !isSameValue(currentValue[key], nextValue[key]));

    if (!changed) {
      return;
    }

    this.tempSettings = { ...(this.tempSettings || {}),
      filter: { ...(this.tempSettings?.filter || {}),
        values: { ...(this.tempSettings?.filter?.values || {}),
          [fieldKey]: nextValue
        }
      }
    };
    this.requestComponentUpdate('temp-filter-value');
  }

  isEmptyFilterValue(value) {
    if (value === null || typeof value === "undefined") {
      return true;
    }

    if (Array.isArray(value)) {
      return value.every(item => this.isEmptyFilterValue(item));
    }

    if (typeof value === "string") {
      return value.trim() === "";
    }

    if (value && typeof value === "object") {
      return Object.values(value).every(item => this.isEmptyFilterValue(item));
    }

    return false;
  } // C293 (DF-1, DF-4, DF-6): the date filter's own reading -- a period,
  // empty and not empty are whole entries; the chip says the condition; the
  // request carries the zone and week start -- comes with the pair that has
  // SF.fieldRenderers.dateFilter. Without it the table reads as before.


  dateFilterApi() {
    const api = globalThis.SF?.fieldRenderers?.dateFilter;
    return api && typeof api.isEmptyFilterEntry === "function" ? api : null;
  }

  filterChipText(key, tag = {}) {
    const api = this.dateFilterApi();
    const label = tag?.label ?? key;
    if (!api || typeof api.dateFilterChipText !== "function") return label;
    const field = (this.getFilterFields?.() || []).find(item => item?.key === key);
    const type = field?.propertyType ?? field?.type ?? field?.dataType ?? tag?.control;
    if (!["date", "datetime", "period"].includes(type)) return label;
    const entry = this.getCurrentFilterValues?.()?.[key];
    if (!entry || this.isEmptyFilterEntry(entry)) return label;

    try {
      return api.dateFilterChipText({ ...field,
        label
      }, entry, this) || label;
    } catch {
      return label;
    }
  }

  isEmptyFilterEntry(entry) {
    const api = this.dateFilterApi();
    if (api) return api.isEmptyFilterEntry(entry);

    if (!entry || typeof entry !== "object") {
      return this.isEmptyFilterValue(entry);
    }

    if (Object.prototype.hasOwnProperty.call(entry, "values")) {
      return this.isEmptyFilterValue(entry.values);
    }

    if (Object.prototype.hasOwnProperty.call(entry, "value")) {
      return this.isEmptyFilterValue(entry.value);
    }

    return Object.entries(entry).filter(([key]) => !["operator", "control", "type"].includes(key)).every(([, value]) => this.isEmptyFilterValue(value));
  }

  mergeFilterState(prevFilter = {}, tempFilter = {}) {
    const {
      filter,
      tags,
      values
    } = this.getMergedFilterDraftData(prevFilter, tempFilter);
    return this.patchFilterTemplateData(filter, {
      tags,
      values
    });
  } // «Сбросить» in the column settings: the state the window opened with,
  // applied at once and announced once -- not the host's defaults, which is
  // what the filter window's own Reset asks for.


  restoreColumnSettingsOnOpen(reason = 'column-settings-restore') {
    const columnSettings = JSON.parse(JSON.stringify(this._columnSettingsOnOpen || {}));
    this.tempSettings = null;
    this.set(prevState => ({ ...prevState,
      columnSettings
    }), reason, () => this.emitColumnSettingsChange(reason));
    return this;
  } // What «Применить» did, as a method, so a control that applies on the spot
  // does exactly the same thing rather than its own version of it.


  commitColumnSettings(reason = 'table-settings') {
    const tempSettings = this.tempSettings || {};
    const {
      cols: tempColumns,
      ...rest
    } = tempSettings;
    if (!tempColumns) return this;
    const columnSettings = this.mergeColumnSettings(this.getColumnSettings(), tempColumns);
    this.tempSettings = Object.keys(rest).length ? rest : null;
    this.set(prevState => ({ ...prevState,
      columnSettings
    }), reason, () => this.emitColumnSettingsChange(reason));
    return this;
  } // Pinning a column puts it at the end of the pinned block, unpinning it at
  // the start of the loose ones — the place a person expects what they just
  // moved to be, rather than wherever its old order number happens to land it.


  toggleColumnPinned(col) {
    if (!col?.key || col.system) return this;
    const next = !this.isColumnPinned(col);
    const columns = this.getColumnItems().filter(column => column?.key && !column.system);
    const orders = columns.map((column, index) => {
      const pending = this.tempSettings?.cols?.[column.key];
      const setting = this.getColumnSetting(column.key) || {};
      const value = Number(pending?.order ?? setting.order ?? column.order);
      return Number.isFinite(value) ? value : (index + 1) * 10;
    });
    const group = columns.map((column, index) => ({
      column,
      order: orders[index]
    })).filter(entry => entry.column.key !== col.key && this.isColumnPinned(entry.column) === next);
    const order = next ? Math.max(0, ...group.map(entry => entry.order)) + 10 // Never below 0: the host refuses a negative order, and a loose
    // column already at 0 made an unpin send -10 and fail.
    : Math.max(0, Math.min(...group.map(entry => entry.order), 10) - 10);
    this.patchTempColumnSettings(col.key, {
      pinned: next,
      order
    }); // The patch is a plain property, so nothing re-rendered and the pin kept
    // the state it was drawn with: every pin read aria-pressed="false", a
    // press looked like it had done nothing, and the only visible effect was
    // the row moving into the pinned group on some later render.

    this.requestComponentUpdate('column-pin'); // A pin applies on the spot and reaches the host, by the consumer
    // owner's decision of 2026-10-05. Before it, a press wrote a draft that
    // a click outside the window threw away without saying so, and with the
    // window's own buttons below the fold that read as "pins do not work".

    this.commitColumnSettings('column-pin');
    return this;
  } // Two sortable lists, one under the other: the pinned rows, then the
  // loose ones. Each is a group of its own, so a row stays in its group.


  renderSortableGroups(pinnedRows, looseRows, {
    name,
    label,
    onIntent
  }) {
    const list = (group, rows) => rows.length ? (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<sf-sortable
                group=${`${name}-${group}`}
                data-group=${group}
                label=${label}
                class="flex flex-col gap-1/3"
                @sf-sortable-intent=${onIntent}>${rows}</sf-sortable>` : lit__WEBPACK_IMPORTED_MODULE_11__.nothing;

    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`${list('pinned', pinnedRows)}${list('loose', looseRows)}`;
  }

  getFilterTagColsData() {
    const fields = this.getFilterFields().filter(field => field?.filter?.enabled !== false);
    const items = fields.length ? fields : this.getColumnItems();
    return items.map(field => {
      const pending = this.tempSettings?.filter?.tags?.[field.key];
      const current = this.getCurrentFilterTags(this.getPendingFilterState())?.[field.key];
      const data = {
        type: "checkbox",
        props: {
          size: this.size,
          label: field.label,
          position: 'end',
          rootClass: 'content-main-between',
          checked: pending?.active ?? current?.active ?? false,
          ':ref': this.getItemRef(`filter-tag-column:${field.key}`) || false,
          '@change': event => {
            this.patchTempFilterTagSettings(field.key, {
              active: Boolean(event.target?.checked),
              label: field.label,
              control: field.filter?.control || field.type || field.dataType || 'text'
            });
          }
        }
      };
      return this.renderSmartElement(data.type, data.props);
    });
  }

  getFilterControlValue(fieldKey) {
    return { ...(this.getCurrentFilterValues()?.[fieldKey] || {}),
      ...(this.tempSettings?.filter?.values?.[fieldKey] || {})
    };
  }

  getFilterOptions(field = {}) {
    const filter = field.filter || {};
    const source = filter.optionsSource || {};

    if (source.type === 'endpoint') {
      const page = this.getEndpointFilterPage(field);
      const selected = new Set(this.getFilterControlValue(field.key).values || []);
      const options = new Map();

      for (const option of [...(page?.selected || []), ...(page?.items || [])]) {
        if (typeof option?.value === 'string' && typeof option?.label === 'string') {
          if (selected.has(option.value) || (page?.items || []).includes(option)) {
            options.set(option.value, option);
          }
        }
      }

      return [...options.values()];
    }

    if (Array.isArray(filter.options)) {
      return filter.options;
    }

    if (Array.isArray(source.items)) {
      return source.items;
    }

    return [];
  }

  getEndpointFilterPage(field = {}) {
    const source = field.filter?.optionsSource;

    if (source?.type !== 'endpoint' || typeof source.url !== 'string' || !source.url.trim() || !field.key) {
      return null;
    }

    let page = this._filterOptionPages.get(field.key);

    if (!page || page.url !== source.url) {
      page?.controller?.abort();
      page = {
        url: source.url,
        items: [],
        selected: [],
        nextCursor: null,
        status: 'idle',
        sequence: 0,
        searchable: false
      };

      this._filterOptionPages.set(field.key, page);

      queueMicrotask(() => {
        if (this.isConnected && this._filterOptionPages.get(field.key) === page) {
          this.loadEndpointFilterPage(field);
        }
      });
    }

    return page;
  }

  async loadEndpointFilterPage(field = {}, cursor = null, search = '') {
    const page = this.getEndpointFilterPage(field);
    if (!page || !this.isConnected) return false;
    let url;

    try {
      url = new URL(page.url, globalThis.location?.href);
      if (url.origin !== globalThis.location?.origin) throw new TypeError('filter_options_cross_origin');
    } catch {
      page.status = 'error';
      this.requestComponentUpdate('filter-options');
      return false;
    }

    page.controller?.abort();
    const controller = new AbortController();
    const sequence = ++page.sequence;
    page.controller = controller;
    page.status = 'loading';
    url.searchParams.set('limit', '50');
    url.searchParams.set('sequence', String(sequence));
    if (cursor) url.searchParams.set('cursor', cursor);else url.searchParams.delete('cursor');
    if (search && page.searchable) url.searchParams.set('search', search);else url.searchParams.delete('search');
    url.searchParams.delete('selected_values[]');

    for (const value of this.getFilterControlValue(field.key).values || []) {
      if (typeof value === 'string') url.searchParams.append('selected_values[]', value);
    }

    this.requestComponentUpdate('filter-options');

    try {
      const response = await fetch(url, {
        credentials: 'same-origin',
        signal: controller.signal,
        headers: {
          Accept: 'application/json'
        }
      });
      const answer = await response.json();
      if (page.sequence !== sequence || this._filterOptionPages.get(field.key) !== page || !this.isConnected) return false;

      if (!response.ok || answer?.status !== 'ok' || answer.sequence !== sequence || !Array.isArray(answer.items) || !Array.isArray(answer.selected) || answer.next_cursor !== null && typeof answer.next_cursor !== 'string') {
        throw new TypeError('filter_options_answer_invalid');
      }

      const clean = items => items.filter(item => typeof item?.value === 'string' && item.value && typeof item?.label === 'string' && item.label).map(({
        value,
        label
      }) => ({
        value,
        label
      }));

      const merged = new Map((cursor ? page.items : []).map(item => [item.value, item]));

      for (const item of clean(answer.items)) merged.set(item.value, item);

      page.items = [...merged.values()];
      page.selected = clean(answer.selected);
      page.nextCursor = answer.next_cursor;
      page.searchable = answer.searchable === true;
      page.status = 'ready';
      this.requestComponentUpdate('filter-options');
      return true;
    } catch (error) {
      if (page.sequence !== sequence || error?.name === 'AbortError') return false;
      page.status = 'error';
      this.requestComponentUpdate('filter-options');
      return false;
    }
  }

  getFilterOptionSearch(fieldKey) {
    if (!fieldKey) return '';
    return this.tempSettings?.filterSearch?.[fieldKey] || '';
  }

  patchTempFilterOptionSearch(fieldKey, value = '') {
    if (!fieldKey) return;
    this.tempSettings = { ...(this.tempSettings || {}),
      filterSearch: { ...(this.tempSettings?.filterSearch || {}),
        [fieldKey]: String(value || '')
      }
    };
    this.requestComponentUpdate('filter-option-search');
    const field = this.getFilterField(fieldKey);
    const page = field && this.getEndpointFilterPage(field);

    if (page?.searchable) {
      clearTimeout(page.searchTimer);
      page.searchTimer = setTimeout(() => this.loadEndpointFilterPage(field, null, String(value || '').trim()), 200);
    }
  }

  filterUpdate() {
    return this.getFilterPayload();
  }

  getFilterOptionSearchKeys(field = {}) {
    const keys = field.filter?.searchKeys || field.filter?.optionSearchKeys;

    if (Array.isArray(keys) && keys.length) {
      return keys;
    }

    return ['label', 'title', 'name', 'text', 'value', 'id'];
  }

  getObjectPathValue(source = {}, path = '') {
    return String(path || '').split('.').filter(Boolean).reduce((value, key) => {
      if (value === null || typeof value === 'undefined') {
        return '';
      }

      return value[key];
    }, source);
  }

  normalizeFilterSearchValue(value = '') {
    return String(value || '').trim().toLowerCase();
  }

  optionMatchesSearch(option = {}, search = '', keys = []) {
    const query = this.normalizeFilterSearchValue(search);
    if (!query) return true;
    return keys.some(key => {
      const value = this.getObjectPathValue(option, key);
      return this.normalizeFilterSearchValue(value).includes(query);
    });
  }

  getVisibleFilterOptions(field = {}) {
    const options = this.getFilterOptions(field);
    const search = this.getFilterOptionSearch(field.key);

    if (!search) {
      return options;
    }

    const keys = this.getFilterOptionSearchKeys(field);
    return options.filter(option => this.optionMatchesSearch(option, search, keys));
  } // A cell for a column that names a property type: the Framework's renderer
  // for that type, or nothing, in which case the value renders as itself. A
  // host that passes its own component never reaches here -- the escape hatch
  // is that the host's choice is consulted first, by the template.
  // The set answers with a cell value in the shape a host would pass -- a
  // string, an object with a component, or a list of those -- so the template
  // renders it through the path it already had. The set adds no second way to
  // draw a cell.
  // A boolean cell the host lets this person write: the table is told it
  // may (inline-edit) and the record names the field in `editable`.


  cellEditable(row = {}, column = {}) {
    if (this.getAttribute("inline-edit") !== "true") return false;
    if ((column.propertyType ?? column.property_type ?? column.type) !== "boolean") return false;
    return Array.isArray(row.editable) && row.editable.map(String).includes(String(column.key));
  }

  cellPending(row = {}, column = {}) {
    return this._pendingCells?.has(`${this.getRowKey(row)}\u0000${column.key}`) === true;
  } // A checkbox pressed: the cell waits for the host, which answers with the
  // record as it now is, or not, and then the row is drawn from what it says.


  setCellValue(row = {}, column = {}, value) {
    const id = this.getRowKey(row);
    this._pendingCells ??= new Set();

    this._pendingCells.add(`${id}\u0000${column.key}`);

    this.requestComponentUpdate("cell-pending");
    this.emitTableEvent("cell-set", Object.freeze({
      id: row.id ?? id,
      key: column.key,
      value,
      revision: row._revision ?? row.revision ?? null
    }));
  } // C296: a short field -- a choice, a person, yes/no, a date, a number --
  // the host lets this person write is edited at the cell, in a small menu
  // or popover, when the author turns inline-edit on. Longer fields are the
  // record card's. A boolean keeps its checkbox in the cell.


  cellShortEditable(row = {}, column = {}) {
    if (this.getAttribute("inline-edit") !== "true" || column.system) return false;
    const type = column.propertyType ?? column.property_type ?? column.type;
    if (!SHORT_EDIT_TYPES.has(type)) return false;
    if ((type === "user" || type === "choice" || type === "enum" || type === "select") && !Array.isArray(column.options)) return false;
    return Array.isArray(row.editable) && row.editable.map(String).includes(String(column.key));
  } // Opens the editor of one cell: a menu of the choices (checked at the
  // value), or a popover with the Framework's own edit field and Save and
  // Cancel. What is chosen goes to the host as cell-set, like the checkbox.


  async openCellEditor(row, column, cell) {
    if (!row || !column || !(cell instanceof Element) || !this.cellShortEditable(row, column)) return null;
    if (this.cellPending(row, column)) return null;
    const type = column.propertyType ?? column.property_type ?? column.type;
    const value = row[column.key];
    const label = column.label ?? column.key;

    if (type === "boolean" || Array.isArray(column.options)) {
      const options = type === "boolean" ? [{
        value: true,
        label: this.text("cellEditYes")
      }, {
        value: false,
        label: this.text("cellEditNo")
      }] : column.options;
      const current = value && typeof value === "object" && !Array.isArray(value) ? value.value ?? value.id : value;
      const entries = options.map((option, index) => ({
        id: String(index),
        text: String(option?.label ?? option?.text ?? option?.value ?? ""),
        checked: String(option?.value) === String(current)
      }));
      const choice = await (0,_core_js_menu_open_js__WEBPACK_IMPORTED_MODULE_20__.menuOpen)({
        anchor: cell,
        entries,
        label: `${this.text("cellEditLabel")}: ${label}`,
        size: this.menuSize
      });
      if (choice?.id === undefined || choice?.id === null) return null;
      const picked = options[Number(choice.id)];
      if (!picked || String(picked.value) === String(current)) return null;
      this.setCellValue(row, column, picked.value);
      return {
        outcome: "applied"
      };
    }

    return this.openCellPopover(row, column, cell, value, label);
  }

  openCellPopover(row, column, cell, value, label) {
    this.closeCellPopover();
    const box = document.createElement("div");
    box.className = "sf-table-cell-editor";
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-label", `${this.text("cellEditLabel")}: ${label}`);
    let draft = value;
    const host = {
      setFieldValue: (_field, next) => {
        draft = next;
      },
      text: key => this.text(key)
    };
    const field = { ...column,
      key: column.key,
      label,
      propertyType: column.propertyType ?? column.property_type ?? column.type
    };
    const size = this.getPropsContext().size === "1/2" ? "1/2" : "1";

    const finish = apply => {
      const was = String(value ?? "");
      this.closeCellPopover();
      if (apply && String(draft ?? "") !== was) this.setCellValue(row, column, draft);
      cell.closest("tr")?.focus?.({
        preventScroll: true
      });
    };

    (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)((0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<form class="sf-table-cell-editor-form" @submit=${event => {
      event.preventDefault();
      finish(true);
    }}
                @keydown=${event => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        finish(false);
      }
    }}>
            ${(0,_field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__.renderEditField)(field, value, host, {
      size
    })}
            <div class="sf-table-cell-editor-actions">
                <sf-button size=${size} scheme="primary" text=${this.text("cellEditApply")}
                    @click=${() => finish(true)}></sf-button>
                <sf-button size=${size} appearance="outline" scheme="on-surface" text=${this.text("cellEditCancel")}
                    @click=${() => finish(false)}></sf-button>
            </div>
        </form>`, box);
    document.body.append(box);
    this._cellPopover = box; // Placed by the Framework's one anchoring helper (SF.Position): under
    // the cell, at least as wide, flipped or shifted to stay in view, in
    // the top layer. A press outside closes it without saving.

    this._cellPlace = positioning().anchor(cell, box, {
      side: "block-end",
      align: "start",
      matchWidth: "min"
    }); // One layer of the page's stack: Escape and a press outside close it
    // without saving (a picker the field opens is a layer above it).

    (0,_core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__.openLayer)(box, {
      kind: "surface",
      root: () => box,
      onEscape: () => {
        finish(false);
        return true;
      },
      onOutsidePress: () => this.closeCellPopover(box)
    });
    requestAnimationFrame(() => box.querySelector("input, select, textarea, button, [tabindex]")?.focus?.());
    return {
      outcome: "opened"
    };
  }

  closeCellPopover(only = null) {
    const box = this._cellPopover;
    if (!box || only && only !== box) return;
    this._cellPopover = null;
    this._cellPlace?.stop?.();
    this._cellPlace = null;
    (0,_core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__.closeLayer)(box, {
      restoreFocus: false
    });
    (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(lit__WEBPACK_IMPORTED_MODULE_11__.nothing, box);
    box.remove();
  } // Double click or F2 on a short editable cell opens its editor.


  cellEditTarget(event) {
    const cell = event.target instanceof Element ? event.target.closest("tbody td[data-key]") : null;
    if (!cell || !this.contains(cell)) return null;
    const row = this.rowOfElement(cell);
    const column = (this.getTableData().columns || []).find(one => String(one.key) === cell.dataset.key);
    return row && column && this.cellShortEditable(row, column) ? {
      row,
      column,
      cell
    } : null;
  }

  clearCellPending(id, key) {
    if (this._pendingCells?.delete(`${id}\u0000${key}`)) this.requestComponentUpdate("cell-pending");
  } // The box shows what the host holds again. A render cannot do it: the
  // value it would draw is the one it drew before the click, so nothing
  // changes for it, while the box itself was toggled by the click.


  resetCellControl(id, key, value) {
    const escape = text => String(text).replace(/"/gu, '\\"');

    const box = this.querySelector(`tbody tr[data-row-id="${escape(id)}"] [data-cell-edit="${escape(key)}"]`);
    if (!box) return;
    const checked = value === true;
    box.checked = checked;
    box.toggleAttribute("checked", checked);
    const input = box.querySelector("input");
    if (input) input.checked = checked;
  }

  getTypedCellValue(column = {}, value) {
    // The host is passed so `formatFieldValue` is reachable from a cell. It
    // was reachable from the record panel and not from the list -- the
    // panel hands the renderer set its port, the table handed it nothing --
    // so the same date read «25 сентября 2026» in a card and
    // «2026-09-25T07:12:00+03:00» in a row, and a consumer had no way to
    // change the second. The set still refuses to guess a format; this only
    // lets the host say one (admin polygon, 2026-10-10).
    const host = this.cellHost ?? null;
    const type = column.propertyType ?? column.property_type ?? column.type; // Several files are one value each, as several choices are tags: the
    // renderer set reads a file and not a list of them, so a column of
    // documents drew nothing at all (the Fields page, 2026-11-05). Each is
    // its name with its kind's icon, and what does not fit folds into «+N».

    if (type === "file" && Array.isArray(value)) {
      const files = value.map(file => (0,_field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__.renderCellField)(column, file, host)).filter(item => item !== null && item !== undefined);
      return files.length ? files : null;
    } // A date reads as the SIMAI Framework's field renderers read it (the
    // record's own day and clock, in the page's language; the host's
    // formatFieldValue first): the table's own date parsing is gone (VF-10).


    const rendered = (0,_field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__.renderCellField)(column, value, host);
    if (rendered !== null && rendered !== undefined) return rendered;
    return null;
  } // What a cell draws: the field renderers' answer, and when they leave a
  // plain number to the host and the host has none, the number in the
  // page's language (VT-14 of the sf-view-table study: «1.5» in a Russian
  // table, while money and dates were localised) -- every digit the value
  // has, never rounded, grouped as the language groups.


  cellValue(column = {}, value) {
    const typed = this.getTypedCellValue(column, value);
    if (typed !== null && typed !== undefined) return typed;
    const type = column.propertyType ?? column.property_type ?? column.type;
    if ((type === "integer" || type === "number") && !(column.variant || column.filter?.variant)) return this.localNumber(value);
    return null;
  }

  localNumber(value) {
    const text = typeof value === "number" ? Number.isFinite(value) ? String(value) : "" : String(value ?? "").trim();
    if (!/^-?\d+(\.\d+)?$/u.test(text)) return null;
    const digits = (text.split(".")[1] ?? "").length;
    const locale = this.closest?.("[lang]")?.getAttribute("lang") || globalThis.document?.documentElement?.lang || undefined;

    try {
      return new Intl.NumberFormat(locale || undefined, {
        minimumFractionDigits: digits,
        maximumFractionDigits: digits
      }).format(Number(text));
    } catch {
      return null;
    }
  } // The machine reading of a date cell (C40, PD-9): a date or a date and time
  // the Framework reads is printed as a time element whose datetime is the
  // record's own day and clock, as the record panel prints it. '' for any
  // other cell, or a value that is no date.


  cellDateTime(column = {}, value) {
    const type = column.propertyType ?? column.property_type ?? column.type;
    if (type !== "date" && type !== "datetime") return "";
    if (typeof value !== "string" && !(value && typeof value === "object" && !Array.isArray(value))) return "";
    return (0,_field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__.dateTimeAttribute)({ ...column,
      propertyType: type
    }, value) || "";
  } // The text a long-text cell shows on its one line: formatted text is its
  // text, not its markup -- «<p>Этапы: <strong>дизайн</strong>…» stood in
  // the row as written (the Fields page, 2026-11-05).


  cellText(column = {}, value) {
    const type = column.propertyType ?? column.property_type ?? column.type;
    return type === "html" ? (0,_field_renderers_html_js__WEBPACK_IMPORTED_MODULE_10__.htmlText)(value) : String(value);
  } // The filter controls were the Framework's only type-aware rendering, and
  // Larena's request asks for one renderer set shared by the record view and
  // the table's cells. Keeping these here as well would have made two maps
  // for one question, so they moved into src/smart/field-renderers and this
  // asks the set. The host interface is small on purpose: the set renders,
  // the table owns the state.


  renderFilterControl(field = {}) {
    return (0,_field_renderers_index_js__WEBPACK_IMPORTED_MODULE_9__.renderFilterField)(field, {
      // The filter controls take this size: the host built here had none,
      // so the search field in a field's window stayed at 1 beside
      // buttons at 1/2.
      size: this.size,
      getFilterControlValue: key => this.getFilterControlValue(key),
      patchTempFilterValue: (key, patch) => this.patchTempFilterValue(key, patch),
      getFilterOperatorLabel: operator => this.getFilterOperatorLabel(operator, field),
      getFilterOptionSearch: key => this.getFilterOptionSearch(key),
      patchTempFilterOptionSearch: (key, search) => this.patchTempFilterOptionSearch(key, search),
      getVisibleFilterOptions: item => this.getVisibleFilterOptions(item),
      renderFilterOption: (item, option) => this.renderFilterOption(item, option),
      getEndpointFilterPage: item => this.getEndpointFilterPage(item),
      loadEndpointFilterPage: (item, cursor, search) => this.loadEndpointFilterPage(item, cursor, search)
    });
  }

  renderFilterOption(field = {}, option = {}, selected = new Set()) {
    const value = option.value ?? option.id ?? option.key ?? option.label ?? option.title;
    const label = option.label || option.title || String(value || '');
    const badge = field.filter?.optionRenderer === 'badge' ? (0,_helpers_option_badge_js__WEBPACK_IMPORTED_MODULE_8__.optionBadgeProps)(option) : null; // An option list is a dense place: its badge keeps the size's own narrow
    // side room (sf-badge tight, sf-badge 1.3.0), as a cell's choice badge does.

    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
            <div
                    ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__.ref)(this.getItemRef(option.label))}
                    class="flex items-cross-center gap-1/2 content-main-between">
                <div class="flex items-cross-center gap-1/2 min-w-0">
                    ${badge ? (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                        <sf-badge
                                appearance="tonal"
                                tight
                                scheme=${badge.scheme}
                                root-style=${badge.rootStyle || lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                                icon=${option.icon || lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                                text=${label}
                        ></sf-badge>
                    ` : (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                        ${this.renderFilterOptionVisual(field, option)}
                        <span class="sf-text-1 truncate">${label}</span>
                    `}
                </div>
                <sf-checkbox
                        size=${this.size}
                        position="end"
                        root-class="content-main-between"
                        ?checked=${selected.has(value)}
                        @change=${event => {
      const nextSelected = new Set(selected);

      if (event.target?.checked) {
        nextSelected.add(value);
      } else {
        nextSelected.delete(value);
      }

      this.patchTempFilterValue(field.key, {
        values: Array.from(nextSelected),
        operator: field.filter?.defaultOperator || 'in'
      });
    }}
                ></sf-checkbox>
            </div>
        `;
  }

  renderFilterOptionVisual(field = {}, option = {}) {
    // A colour from the field's palette is shown as its swatch.
    if (field.filter?.optionRenderer === 'swatch' && option.color) {
      return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<span class="sf-table-filter-swatch" aria-hidden="true" style=${`background-color: ${option.color}`}></span>`;
    }

    if (field.filter?.optionRenderer !== 'avatar-checkbox') {
      return '';
    }

    if (option.imageUrl) {
      return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                <sf-avatar
                        size=${this.size}
                        image-url="${option.imageUrl}"
                        heading="${option.title || option.label || ''}"
                ></sf-avatar>
            `;
    }

    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
            <sf-avatar
                    size=${this.size}
                    heading="${option.avatarText || option.title || option.label || ''}"
            ></sf-avatar>
        `;
  } // A date's comparisons read as time, not as amounts (PD-6): «Позже»,
  // «Не раньше», «Раньше», «Не позже» for a date or a date and time field.


  getFilterOperatorLabel(operator, field = null) {
    const type = field?.propertyType ?? field?.property_type ?? field?.type ?? field?.dataType ?? field?.filter?.control;
    const dated = {
      gt: 'operatorAfter',
      gte: 'operatorOnOrAfter',
      lt: 'operatorBefore',
      lte: 'operatorOnOrBefore'
    };
    if ((type === 'date' || type === 'datetime') && dated[operator]) return this.text(dated[operator]);
    const keys = {
      eq: 'operatorEq',
      gt: 'operatorGt',
      gte: 'operatorGte',
      lt: 'operatorLt',
      lte: 'operatorLte',
      between: 'operatorBetween',
      contains: 'operatorContains',
      startsWith: 'operatorStartsWith',
      any: 'operatorAny',
      today: 'operatorToday',
      week: 'operatorWeek',
      month: 'operatorMonth',
      in: 'operatorIn'
    }; // An operator nobody has a word for is shown as it is stored, which is
    // better than a blank and says what to add.

    return keys[operator] ? this.text(keys[operator]) : operator;
  }

  renderFilterSettingsContextMenu(data) {
    const {
      x,
      y,
      position,
      columnCount,
      columnsCount,
      transform
    } = data;
    let pos = `translateX(${transform !== undefined ? transform : 0}%)`;
    const pendingFilter = this.getPendingFilterState(); // What a press would change, so the button can say it. The button is
    // already a filled primary one, so an extra fill or ring would say
    // nothing: the count is the marked state, and with nothing pending the
    // button reads exactly as it did before. sf-button carries no `filled`
    // property -- that belongs to the icon button -- so setting one would
    // have been an attribute nobody reads.

    const pendingConditions = this.countPendingFilterConditionChanges();
    const selectedTemplateKey = pendingFilter.selectedTemplateKey;
    const sortedTemplates = this.getSortedFilterTemplates(pendingFilter);
    const sortTemplates = sortedTemplates.map(col => {
      let component;
      const isActiveEdit = this.state.filter.rename === col.key;

      if (this.state.filter.rename !== col.key) {
        const data = {
          type: "radio",
          props: {
            size: this.size,
            // A template the host gave no name is the view as it
            // stands: it is named so, not drawn as an empty row
            // (owner, 2026-10-14).
            label: col.label || this.text('untitledTemplateText'),
            name: 'filter_templates',
            checked: selectedTemplateKey ? selectedTemplateKey === col.key : col.selected || false,
            '@change': () => {
              this.selectTempFilterTemplate(col.key);
            }
          }
        };
        component = this.renderSmartElement(data.type, data.props);
      } else {
        component = (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                    <div class="flex items-cross-center gap-1/4 flex-1">
                        <sf-input size=${this.size} ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__.ref)(this.refs.renameInput)} root-class="flex-1"
                                  default-value="${col.label}"></sf-input>
                        <div class="flex items-cross-center flex-none">
                            <sf-button-icon size=${this.size} segment="start" appearance="outline" scheme="on-surface" @click="${() => {
          this.set(prevState => ({
            filter: { ...(prevState.filter || {}),
              rename: ''
            }
          }));
        }}"
                                            icon="close"></sf-button-icon>
                            <sf-button-icon size=${this.size} segment="end" icon="check" @click="${() => {
          const name = this.refs.renameInput.value?.value;
          this.saveFilterTemplatePatch(col.key, {
            label: name
          }, {
            filterPatch: {
              rename: ''
            },
            saveInputValue: name
          });
        }}"></sf-button-icon>
                        </div>
                    </div>`;
      }

      return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                <div
                        :key=${col.key}
                        ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__.ref)(this.getItemRef(col.label))}
                        class="sf-settings-context-menu-item flex items-cross-center flex-1 gap-1/3 ${col.deleted ? 'opacity-3' : ''}"
                        data-filter-template-key="${col.key}"
                        data-sf-sortable-item=${col.key}
                        data-pinned="${col.pinned ? "1" : "0"}"
                >
                    ${!isActiveEdit ? (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                        <sf-button-icon size=${this.size}
                                id="${this.getInstanceId()}--template-move--${col.key}"
                                appearance="ghost"
                                data-move
                                data-sf-sortable-handle
                                scheme="on-surface"
                                aria-label=${`${this.text("templateMoveLabel")}: ${col.label}`}
                                icon="drag_indicator"
                                root-class="cursor-move"
                        ></sf-button-icon>` : lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                    ${component}
                    ${!isActiveEdit ? (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                        <div class="flex items-cross-center m-inline-start-auto gap-1/3">
                            <sf-button-icon
                                    appearance="ghost"
                                    data-keep
                                    size="1/3"
                                    scheme="on-surface"
                                    aria-label=${`${this.text("templatePinLabel")}: ${col.label}`}
                                    ?filled="${col.pinned}"
                                    root-class="${col.pinned ? 'sf-button-pinned' : ''}"
                                    icon="keep"
                                    @click=${() => {
        this.patchTempFilterTemplateSettings(col.key, {
          pinned: !col.pinned
        });
      }}
                            ></sf-button-icon>
                            <sf-button-icon size=${this.size}
                                    appearance="ghost"
                                    data-settings
                                    data-context-submenu-anchor="${col.key}"
                                    scheme="on-surface"
                                    aria-label=${`${this.text("templateActionsLabel")}: ${col.label}`}
                                    icon="more_horiz"
                                    @click=${event => {
        this.openContextSubmenu(event, {
          type: 'filter-template-actions',
          template: col
        });
      }}
                            ></sf-button-icon>
                        </div>` : lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                </div>`;
    });
    const menuColumnCount = columnCount ?? columnsCount ?? this.contextMenuColumns ?? 1;
    const colsData = this.getFilterTagColsData();
    const columnGroups = this.splitItemsByColumns(colsData, menuColumnCount);
    let contextItems = `${this.text('templatesTabText')}|${this.text('fieldsTabText')}`;
    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
            <sf-menu-context
                    size=${this.menuSize}
                    :key=${x + y + this._renderToken}
                    aria-label=${this.getContextMenuLabel({ ...data,
      menu: 'filter-settings'
    })}
                    style="
            position: fixed;
            left: ${x}px;
            inset-block-start: calc(${y}px + calc(var(--sf-focus-outline-width) * 2));
            transform: ${pos};
            z-index: var(--sf-table-context-menu--z-index, ${this.contextMenuZIndex()});
            --sf-table-context-menu--max-block-size: calc(100dvh - ${y}px - var(--sf-space-4));
            --sf-table-context-menu--trigger-inline-size: ${this.contextTriggerInlineSize(data)}px;
          "
                    root-class="sf-table-context-menu ${this.contextWindowClass('filter-settings', menuColumnCount)} ${this.size === "1/2" ? "sf-table-context-menu--dense " : ""}flex flex-col"
                    position="${position || ""}"
                    role="dialog"
                    tabs=${contextItems}
                    active-tab=${this._filterTab === 'fields' ? '1' : '0'}
                    closable
                    @sf-menu-context-tab=${event => {
      event.stopPropagation();
      this._filterTab = event.detail?.index === 1 ? 'fields' : 'templates';
      this.requestComponentUpdate('filter-tab');
    }}
                    @sf-menu-context-close=${event => {
      event.stopPropagation();
      this.closeContextMenu();
    }}
            >
                <!-- The Framework's panel with tabs (owner, 2026-10-15): the
                     tabs stay while the rows scroll, the buttons stay at the
                     bottom, and the window keeps its width -- it grew under
                     the pointer when «Применить (2)» got longer. -->
                <div class="sf-table-context-body flex flex-col flex-1" slot="content">
                    ${this._filterTab !== 'fields' ? (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                            <div
                                    class="sf-context-menu-columns flex flex-col gap-1/4 overflow-auto flex-1"
                                    data-filter-template-list
                            >
                                ${this.renderSortableGroups(sortTemplates.filter((_, at) => sortedTemplates[at].pinned), sortTemplates.filter((_, at) => !sortedTemplates[at].pinned), {
      name: 'filter-templates',
      label: this.text('templatesTabText'),
      onIntent: event => this.onFilterTemplateIntent(event)
    })}
                            </div>` : (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                            <div class="sf-context-menu-columns flex flex-1 gap-1 overflow-auto">
                                ${columnGroups.map(group => (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                                            <div class="flex flex-col gap-1 flex-1">
                                                ${group}
                                            </div>
                                        `)}
                            </div>`}
                </div>
                        <sf-button slot="footer" size=${this.size} @click="${() => {
      const tempFilter = this.tempSettings?.filter;

      if (tempFilter) {
        let changedTemplates = [];
        let deletedKeys = [];
        let selectedKey = null;
        this.set(prevState => {
          const hasDataChanges = this.hasPendingFilterDataChanges(prevState.filter || {});
          const filter = this.mergeFilterState(prevState.filter || {}, tempFilter);
          const selectedTemplate = this.getSelectedFilterTemplate(filter);
          changedTemplates = tempFilter.templates ? this.getChangedFilterTemplates(prevState.filter || {}, filter, ['order', 'pinned', 'deleted', 'selected', 'default']) : [];
          deletedKeys = filter.templates.filter(template => template.deleted && template.key).map(template => template.key);
          filter.templates = filter.templates.filter(el => !el.deleted);
          const previousKey = this.getSelectedFilterTemplate(prevState.filter || {})?.key || null;
          selectedKey = selectedTemplate?.key && selectedTemplate.key !== previousKey ? selectedTemplate.key : null;
          return {
            filter,
            filterDataDirty: prevState.filterDataDirty || hasDataChanges,
            saveInputValue: selectedTemplate?.label || ""
          };
        }, () => {
          if (changedTemplates.length) {
            this.dispatchFilterTemplatesSave(changedTemplates);
          }

          for (const key of deletedKeys) {
            this.emitTableEvent('template-delete', Object.freeze({
              key
            }));
          }

          if (selectedKey) {
            this.emitTableEvent('template-select', Object.freeze({
              key: selectedKey
            }));
          }
        });
      }

      this.tempSettings = null;
      this.closeContextMenu();
    }}" root-class="flex-1"
                                   aria-label=${pendingConditions ? `${this.text("filterApplyText", "filter-apply-text")}: ${pendingConditions}` : this.text("filterApplyText", "filter-apply-text")}
                                   text=${pendingConditions ? `${this.text("filterApplyText", "filter-apply-text")} (${pendingConditions})` : this.text("filterApplyText", "filter-apply-text")}></sf-button>
                        <sf-button slot="footer" size=${this.size} @click="${() => {
      // Reset means the defaults, not "forget what I just
      // typed here": the draft goes, and the host is asked
      // to clear the person's own layer — order, widths,
      // visibility and pinning — because the defaults are
      // the host's to decide, not this component's.
      this.tempSettings = null;
      this.requestComponentUpdate('table');
      this.requestColumnSettingsReset();
    }}" appearance="outline" scheme="on-surface" root-class="flex-1"
                                   text="${this.text('resetText')}"></sf-button>
            </sf-menu-context>
        `;
  }

  renderTagsSettingsContextMenu(data) {
    const {
      x,
      y,
      position,
      fieldKey
    } = data;
    const field = this.getFilterField(fieldKey) || {
      key: fieldKey,
      label: this.getCurrentFilterTags()?.[fieldKey]?.label || fieldKey || '',
      filter: {
        control: this.getCurrentFilterTags()?.[fieldKey]?.control || 'text'
      }
    };
    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
            <sf-menu-context
                    size=${this.menuSize}
                    :key=${x + y + this._renderToken}
                    aria-label=${this.getContextMenuLabel({ ...data,
      menu: 'tag-settings'
    })}
                    style="
            position: fixed;
            left: ${x}px;
            inset-block-start: calc(${y}px + calc(var(--sf-focus-outline-width) * 2));
            z-index: var(--sf-table-context-menu--z-index, ${this.contextMenuZIndex()});
          "
                    root-class="sf-table-context-menu ${this.contextWindowClass('tag-settings')} ${this.size === "1/2" ? "sf-table-context-menu--dense " : ""}flex flex-col"
                    position="${position || ""}"
            >
                <div class="flex flex-col flex-1 ${this.size === "1/2" ? "p-top-1" : "p-top-3"}" slot="content">
                    <div class="sf-table-context-main">
                        <div class="sf-table-tags-search flex flex-col">
                            <div class="flex flex-col ${this.size === "1/2" ? "p-bottom-1" : "p-bottom-3"}">
                                ${this.renderFilterControl(field)}
                            </div>
                        </div>
                    </div>
                    <div class="sf-table-context-bottom sf-context-menu-footer">
                        <sf-button size=${this.size} @click="${() => {
      const tempFilter = this.tempSettings?.filter;

      if (tempFilter) {
        this.set(prevState => {
          const hasDataChanges = this.hasPendingFilterDataChanges(prevState.filter || {});
          return {
            filter: this.mergeFilterState(prevState.filter || {}, tempFilter),
            filterDataDirty: prevState.filterDataDirty || hasDataChanges
          };
        }, () => {
          const detail = this.filterUpdate();
          this.emitTableEvent('filter-change', detail);
        });
      }

      this.tempSettings = null;
      this.closeContextMenu();
    }}" root-class="flex-1" text="${this.text('applyText')}"></sf-button>
                        <sf-button size=${this.size} @click="${() => {
      this.tempSettings = null;
      this.requestComponentUpdate('table');
    }}" appearance="outline" scheme="on-surface" root-class="flex-1"
                                   text="${this.text('resetText')}"></sf-button>
                    </div>
                </div>
            </sf-menu-context>
        `;
  }

  removeFilterTag(id = null) {
    if (id) {
      this.tempSettings = null;
      this.set(prevState => {
        const prevFilter = prevState.filter || {};
        const tags = { ...this.getCurrentFilterTags(prevFilter)
        };
        const values = { ...this.getCurrentFilterValues(prevFilter)
        };
        delete tags[id];
        delete values[id];
        return {
          filter: this.patchFilterTemplateData(prevFilter, {
            tags,
            values
          }),
          filterDataDirty: true
        };
      }, () => {
        const detail = this.filterUpdate();
        this.emitTableEvent('filter-change', detail);
      });
      return this;
    }

    this.tempSettings = null;
    this.set(prevState => {
      const prevFilter = prevState.filter || {};
      return {
        filter: { ...prevFilter,
          selectedTemplateKey: "",
          templates: this.getFilterTemplates(prevFilter).map(template => ({ ...template,
            selected: false
          }))
        },
        saveInputValue: "",
        filterDataDirty: false
      };
    }, () => {
      const detail = this.filterUpdate();
      this.emitTableEvent('filter-change', detail);
    });
    return this;
  } // The gear's window (owner decision C106): SIMAI Framework sf-settings in
  // its panel look, not sf-menu-context's tabs with rows drawn here. Two
  // groups as tabs, «Поля» -- the columns, shown or not, in their order, the
  // pinned ones on top, with the panel's search -- and «Вид» -- the rows'
  // density, the lines, one line, the held head and whether a change is for
  // all the person's tables. Everything applies at once (2026-10-05);
  // «Сбросить» puts back the fields as the window opened with them, or the
  // view's defaults, by the tab it stands on. The panel takes its density
  // from the gear (C22); a size is passed only when the host wrote one.


  renderTableSettingsContextMenu(data) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
            <sf-settings
                    look="panel"
                    search
                    data-table-settings
                    for=${this.settingsTriggerId(data.anchor)}
                    size=${this.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                    label=${this.getContextMenuLabel({ ...data,
      menu: 'table-settings'
    })}
                    .items=${this.tableSettingsItems()}
                    @sf-settings-changed=${event => this.onTableSettingChanged(event)}
                    @sf-settings-reset=${event => this.onTableSettingsReset(event)}
                    @sf-settings-open=${event => event.stopPropagation()}
                    @sf-settings-opened=${event => event.stopPropagation()}
                    @sf-settings-close=${event => this.onTableSettingsClose(event)}
                    @sf-settings-closed=${event => this.onTableSettingsClosed(event)}
            ></sf-settings>
        `;
  } // The panel opens against the control that opened the window, which it
  // names by id (sf-settings for=): a control without one is given one.


  settingsTriggerId(anchor) {
    const trigger = anchor instanceof Element ? anchor : this;
    if (!trigger.id) trigger.id = `${this.getInstanceId()}--settings-trigger`;
    return trigger.id;
  } // The gear's settings as sf-settings items, made again only when what they
  // say changes, so the panel is not handed a new list on every drawing.


  tableSettingsItems() {
    const view = this.tableView;
    const options = this.getColumnItems().filter(column => column?.key).map(column => ({
      id: String(column.key),
      text: column.label || String(column.key),
      checked: this.isColumnVisible(column),
      // The box and the row menu are always pinned (offered nothing).
      pinned: Boolean(column.system) || this.isColumnPinned(column)
    }));
    const density = {
      compact: "viewDensityCompact",
      normal: "viewDensityNormal",
      spacious: "viewDensitySpacious"
    };

    const toggle = (id, word) => ({
      id,
      type: "switch",
      text: this.text(word),
      value: view[id] === true
    });

    const items = [{
      type: "group",
      text: this.text("settingsFieldsTab"),
      items: [{
        id: "columns",
        type: "fields",
        text: this.text("settingsFieldsTab"),
        sortable: true,
        pinnable: true,
        options
      }]
    }, {
      type: "group",
      text: this.text("settingsViewTab"),
      items: [{
        id: "density",
        type: "choice",
        text: this.text("viewDensity"),
        value: view.density,
        options: Object.entries(density).map(([id, word]) => ({
          id,
          text: this.text(word)
        }))
      }, toggle("lines", "viewLines"), toggle("singleLine", "viewSingleLine"), ...(this.getAttribute("vertical-scroll") === "page" ? [toggle("stickyHead", "viewStickyHead")] : []), ...(this.viewPreferenceKey ? [{
        type: "separator"
      }, {
        id: "everywhere",
        type: "switch",
        text: this.text("viewEverywhere"),
        value: this._viewEverywhere === true
      }] : [])]
    }];
    const key = JSON.stringify(items);
    if (this._settingsItems?.key !== key) this._settingsItems = {
      key,
      items
    };
    return this._settingsItems.items;
  } // The fields list's value as the table holds it: what the panel shows
  // after a change the table took otherwise or not at all.


  tableSettingsColumns() {
    const columns = this.tableSettingsItems()[0].items[0].options;
    return columns.map(({
      id,
      checked,
      pinned
    }) => ({
      id,
      checked,
      pinned
    }));
  } // A setting a person changed in the panel, applied as the window's own
  // controls applied it: a pin through toggleColumnPinned (the end of the
  // pinned block, the start of the loose ones), a column shown or hidden,
  // the order of every column (a drag or Alt+arrows), the view through
  // setTableView, for this table or for all of them.


  onTableSettingChanged(event) {
    event.stopPropagation();
    const settings = event.currentTarget;
    const {
      id,
      value
    } = event.detail ?? {};
    if (id === "columns") this.applyColumnsSetting(value);else if (id === "everywhere") this._viewEverywhere = value === true;else if (["density", "lines", "singleLine", "stickyHead"].includes(id)) {
      this.setTableView({
        [id]: value
      }, {
        everywhere: this._viewEverywhere === true
      });
    } // A change the table did not take (a system column's pin or place)
    // goes back in the panel; one it took is already the same.

    requestAnimationFrame(() => {
      if (id === "columns" && settings?.isConnected) settings.setValue?.("columns", this.tableSettingsColumns());
    });
  }

  applyColumnsSetting(value = []) {
    const columns = this.getColumnItems().filter(column => column?.key);
    const byKey = new Map(columns.map(column => [String(column.key), column]));
    const asked = (Array.isArray(value) ? value : []).filter(one => byKey.has(one?.id));
    const pin = asked.find(one => !byKey.get(one.id).system && Boolean(one.pinned) !== this.isColumnPinned(byKey.get(one.id)));
    if (pin) return this.toggleColumnPinned(byKey.get(pin.id));
    const shown = asked.find(one => Boolean(one.checked) !== this.isColumnVisible(byKey.get(one.id)));

    if (shown) {
      this.patchTempColumnSettings(byKey.get(shown.id).key, {
        visible: Boolean(shown.checked)
      });
      return this.commitColumnSettings("column-visibility");
    }

    const loose = list => list.filter(key => !byKey.get(key).system);

    const ordered = loose(asked.map(one => one.id));
    const before = loose(columns.map(column => String(column.key)));
    if (ordered.join("\n") === before.join("\n")) return this;
    ordered.forEach((key, position) => this.patchTempColumnSettings(byKey.get(key).key, {
      order: (position + 1) * 10
    }));
    this.requestComponentUpdate("column-order");
    return this.commitColumnSettings("column-order");
  } // The tab the panel stands on: its groups are tabs (a search and a fields
  // list), «Поля» first.


  settingsTabOf(settings) {
    const tabs = settings?.querySelector?.(".sf-settings-panel-tabs");
    return Number(tabs?.getAttribute("active-index") ?? 0) === 1 ? "view" : "fields";
  }

  onTableSettingsReset(event) {
    event.stopPropagation();
    event.preventDefault();
    if (this.settingsTabOf(event.currentTarget) === "view") this.resetTableView();else this.restoreColumnSettingsOnOpen();
  } // The window opens again on the tab it was closed on.


  onTableSettingsClose(event) {
    event.stopPropagation();
    this._settingsTab = this.settingsTabOf(event.currentTarget);
  } // Closed by the panel itself (×, Escape, a press outside, Tab out): the
  // window goes; the panel has already put the focus back. A panel leaving
  // because the window closed is not connected any more.


  onTableSettingsClosed(event) {
    event.stopPropagation();
    if (event.currentTarget?.isConnected && this.state.contextMenu?.open) this.closeContextMenu(false);
  } // The panel drawn, it is opened against its trigger, on the tab it was
  // closed on; a trigger the page cannot find by id is passed in.


  async showSettingsPanel(settings) {
    await customElements.whenDefined("sf-settings");
    await settings.whenRendered?.();
    if (!settings.isConnected) return;
    const view = this._settingsTab === "view";
    const answer = await settings.show?.(view ? "density" : "columns");

    if (answer?.outcome === "unavailable" && answer.reason === "no-trigger" && settings.isConnected) {
      settings.toggle?.(this.state.contextMenu?.anchor ?? this);
      if (view) settings.chooseGroup?.(1);
    }
  }

  renderMainContextMenu(data) {
    const menu = data.menu || data.menuType || data.contextMenu;

    switch (menu) {
      case 'filter-favorites':
        return this.renderFilterFavoritesContextMenu(data);

      case 'filter-settings':
        return this.renderFilterSettingsContextMenu(data);

      case 'table-settings':
        return this.renderTableSettingsContextMenu(data);

      case 'tag-settings':
        return this.renderTagsSettingsContextMenu(data);

      default:
        return this.renderTableSettingsContextMenu(data);
    }
  } // A saved view's actions -- rename, make it the default, delete or
  // restore -- through SF.menu.open, at its «⋯» inside the filter window
  // (VF-1): the menu was a second sf-menu-context the table placed with
  // position: fixed and a tail. A delete or a restore is marked in the window
  // and applied with «Применить», as before.


  async openTemplateActionsMenu(anchor, template = {}) {
    const temp = this.getFilterTemplateByKey(template.key, this.tempSettings?.filter || null);
    const isDeleted = (temp || template).deleted;
    const isDefaultTemplate = (temp || template).default === true;
    const choice = await (0,_core_js_menu_open_js__WEBPACK_IMPORTED_MODULE_20__.menuOpen)({
      anchor,
      label: this.getContextMenuLabel({
        type: 'filter-template-actions',
        template
      }),
      size: this.menuSize,
      entries: [// The standard menu's rows (owner, 2026-10-14), not link
      // buttons; a delete is marked as one, a restore is not.
      {
        id: 'rename',
        text: this.text('renameText'),
        icon: 'edit'
      }, {
        id: 'default',
        text: isDefaultTemplate ? this.text('defaultTemplateText') : this.text('makeDefaultLabel'),
        icon: isDefaultTemplate ? 'remove' : 'check'
      }, {
        id: 'delete',
        text: isDeleted ? this.text('restoreText') : this.text('deleteActionText'),
        icon: isDeleted ? 'restore_from_trash' : 'delete',
        danger: !isDeleted
      }]
    });
    const id = choice?.id;

    if (id === 'rename') {
      this.set(prevState => ({
        filter: { ...(prevState.filter || {}),
          rename: template.key
        }
      }));
    } else if (id === 'default') {
      this.changeTempFilterTemplateSettings(template.key, {
        default: !isDefaultTemplate
      });
    } else if (id === 'delete') {
      this.patchTempFilterTemplateSettings(template.key, {
        deleted: !isDeleted
      });
    }

    return choice;
  }

  renderContextMenu(data) {
    // A window is drawn into this element's portal, which the Loader reads
    // as the page (SF.Loader.watch in getPortalContainer); the window's
    // elements are asked for as it opens so they arrive with it.
    if (data?.open) {
      globalThis.SF?.Loader?.ensure?.(data.menu === 'tag-settings' ? ["sf-input-date", "sf-slider-range"] : ["sf-sortable", "sf-radio", "sf-tabs", "sf-settings"]);
    }

    if (!data?.open) {
      (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this.getPortalContainer());
      this.hidePortal();
      if (this._settingsHost?.isConnected) (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this._settingsHost);
      return lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
    } // The column window (C296, VT-12): the Framework's sf-settings panel is
    // a popover of its own (the top layer, against the gear or «Все
    // колонки…»), so it is not put in the table's full-viewport portal --
    // a 1440x800 layer for a 320-wide panel. It stands in a host of no box.


    if (data.menu === 'table-settings') {
      (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this.getPortalContainer());
      this.hidePortal();
      this.bindContextEvent();
      (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)((0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`<div class="sf-table-context-layer" data-sf-table-settings-layer ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__.ref)(this.refs.contextMenu)}>
                    ${this.renderTableSettingsContextMenu(data)}</div>`, this.getSettingsHost());

      const panel = this._settingsHost.querySelector("sf-settings[data-table-settings]");

      if (panel && panel !== this._settingsShown) {
        this._settingsShown = panel;
        this.showSettingsPanel(panel);
      }

      requestAnimationFrame(() => this.redrawWhenComponentsUpgrade(this._settingsHost));
      return lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
    }

    if (this._settingsHost?.isConnected) (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this._settingsHost); // On the layer stack before it is drawn: the windows take their
    // z-index from their place in it.

    this.bindContextEvent();
    (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)((0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                <div
                        class="sf-table-context-layer"
                        data-sf-sheet=${this.isList && ["filter-settings", "tag-settings"].includes(data.menu) ? "" : lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                        ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_12__.ref)(this.refs.contextMenu)}
                >
                    ${this.renderMainContextMenu(data)}
                    ${this.isList && ["filter-settings", "tag-settings"].includes(data.menu) ? (0,lit__WEBPACK_IMPORTED_MODULE_11__.html)`
                        <div class="sf-table-sheet-close">
                            <sf-button-icon size=${this.size} appearance="ghost" scheme="on-surface"
                                            icon="close" aria-label=${this.text('closeText')}
                                            @click=${() => this.closeContextMenu()}></sf-button-icon>
                        </div>` : lit__WEBPACK_IMPORTED_MODULE_11__.nothing}
                </div>
            `, this.getPortalContainer());
    this.showPortal();
    this.bindContextViewport(); // The gear's panel opens itself once it is drawn, once per window.

    const settings = this.getPortalContainer().querySelector("sf-settings[data-table-settings]");

    if (settings && settings !== this._settingsShown) {
      this._settingsShown = settings;
      this.showSettingsPanel(settings);
    }

    requestAnimationFrame(() => {
      this.clampContextMenusToViewport(); // The menu lives in the portal, not in this element's own tree.

      this.redrawWhenComponentsUpgrade(this.getPortalContainer());
    });
    return lit__WEBPACK_IMPORTED_MODULE_11__.nothing;
  }

  getActionItems() {
    return this.state.actions.map(action => {
      const data = {
        type: "checkbox",
        props: {
          size: this.size,
          label: action.name,
          position: 'end',
          rootClass: 'content-main-between',
          checked: action.visible,
          "@change": e => {
            let actionActive = false;
            let arr = this.tempSettings && this.tempSettings.actions ? this.tempSettings.actions : this.state.actions;
            const items = arr.map(item => {
              let visible = item.id === action.id ? e.target.checked : item.visible;

              if (visible) {
                actionActive = true;
              }

              return { ...item,
                visible: visible
              };
            });
            this.tempSettings = { ...(this.tempSettings || {}),
              actionActive,
              actions: items
            };
          }
        }
      };
      return this.renderSmartElement(data.type, data.props);
    });
  }

  hoverEvents(e) {
    if (this._columnResizeState || this.columnDragActive) {
      return;
    }

    const th = e.target.closest('th');

    if (!th) {
      return;
    }

    const wrap = th.querySelector('.sidebar-resizer');

    if (!wrap) {
      return;
    }

    th.classList.add('hover'); // The line belongs to the handle, not to the header. Shown on any
    // header hover it read as if the column were already being resized, and
    // it crossed the rows whenever the pointer merely passed over a title.

    if (this.getColumnResizeHandle(e.target)) {
      this.showColumnResizeGuide(th);
    } else {
      this.hideColumnResizeGuide();
    }
  }

  outEvent(e) {
    if (this._columnResizeState || this.columnDragActive) {
      return;
    }

    const th = e.target.closest('th');

    if (!th) {
      return;
    }

    const wrap = th.querySelector('.sidebar-resizer');

    if (!wrap) {
      return;
    }

    th.classList.remove('hover');
    this.hideColumnResizeGuide();
  }
  /**
   * The line that shows where a column edge will land runs through the rows
   * only, from the bottom of the head to the last row. A head cell cannot draw
   * it: a pseudo-element of a `th` has no way to reach into the body, and the
   * body's height is not known to CSS. So it is one element in the scroll
   * area, placed against the edge being dragged.
   */


  showColumnResizeGuide(th) {
    const guide = this.refs.resizeGuide?.value;
    const scroll = this.refs.scroll?.value;
    const table = this.refs.table?.value;

    if (!guide || !scroll || !th || !table) {
      return;
    }

    const head = table.querySelector('thead');
    const body = table.querySelector('tbody');

    if (!head || !body) {
      this.hideColumnResizeGuide();
      return;
    }

    const area = scroll.getBoundingClientRect();
    const cell = th.getBoundingClientRect();
    const headBox = head.getBoundingClientRect();
    const bodyBox = body.getBoundingClientRect();

    if (bodyBox.height <= 0) {
      this.hideColumnResizeGuide();
      return;
    } // The line continues the header's separator, so it is placed on that
    // separator rather than on the cell's outer edge: the separator is the
    // cell's own border, which occupies the last pixels inside the box.
    //
    // Nothing here is rounded. Rounding to whole pixels put the line beside
    // the separator whenever the cell's edge fell on a fraction -- which is
    // what a column width in rem or a root size of 87.5% produces, and what
    // the consumer measured as one pixel aside.


    const border = parseFloat(getComputedStyle(th).borderInlineEndWidth) || 0;
    const inlineStart = this.isRightToLeft() ? cell.left - area.left + scroll.scrollLeft : cell.right - area.left + scroll.scrollLeft - border;
    guide.style.insetInlineStart = `${inlineStart}px`;
    guide.style.insetBlockStart = `${headBox.bottom - area.top + scroll.scrollTop}px`;
    guide.style.blockSize = `${bodyBox.height}px`;
    guide.hidden = false;
  }

  hideColumnResizeGuide() {
    const guide = this.refs.resizeGuide?.value;

    if (guide) {
      guide.hidden = true;
    }
  }

  isRightToLeft() {
    return getComputedStyle(this).direction === 'rtl';
  }

  bindHoverEvent() {
    if (this._hoverEventBound) return;
    this._hoverEventBound = true;
    const table = this.refs.table?.value;
    table?.addEventListener('mouseover', this.hoverEvents);
    table?.addEventListener('mouseout', this.outEvent); //
    // this.addEventListener('mouseout', () => {
    //     this.querySelectorAll('.hover')
    //         .forEach(el => el.classList.remove('hover'));
    // });
  }

  unBindHoverEvent() {
    if (!this._hoverEventBound) {
      return;
    }

    const table = this.refs.table?.value;
    table?.removeEventListener('mouseover', this.hoverEvents);
    table?.removeEventListener('mouseout', this.outEvent);
    this._hoverEventBound = false;
  } // A column's edge is the Framework's resize gesture (SF.Resizer.attach,
  // owner 2026-10-14) -- the same drag, keys and double click as a panel's
  // edge: the table says what the width is the width of and keeps it in the
  // column settings, as it did.


  bindColumnResizeEvent() {
    const table = this.refs.table?.value;
    if (!table || this._columnResizeTable === table) return;
    const attach = globalThis.SF?.Resizer?.attach;

    if (typeof attach !== 'function') {
      globalThis.SF?.Loader?.ensure?.(['sf-resizer'], {
        timeout: Infinity
      }).then(({
        missing
      }) => {
        if (!missing.length && this.isConnected) this.bindColumnResizeEvent();
      });
      return;
    }

    this._columnResizeDetach?.();
    this._columnResizeTable = table;
    this._columnResizeDetach = attach(table, {
      handles: '.sf-table-column-resizer',
      session: handle => this.columnResizeSession(handle),
      // The value a screen reader hears: the share of the way from the
      // least width to the most, «27 %» (C158 (3)).
      text: share => this.text('columnWidthValue').replace('{n}', String(share))
    });
  }

  unbindColumnResizeEvent() {
    this._columnResizeDetach?.();
    this._columnResizeDetach = null;
    this._columnResizeTable = null;
  }

  columnResizeSession(handle) {
    const th = handle?.closest?.('th');
    const key = th?.dataset?.key;
    const column = key ? this.getColumns().find(item => item?.key === key) : null;
    if (!th || !column || column.system || column.resizable === false) return null;
    const table = this.refs.table?.value;
    const col = table?.querySelector(`col[data-key="${this.escapeColumnKey(key)}"]`);
    const state = {
      key,
      th,
      col,
      frozenWidths: null,
      dragging: false
    };

    const clear = () => {
      this._columnResizeState = null;
      th.style.width = '';
    };

    return {
      measure: () => th.getBoundingClientRect().width,
      limits: () => {
        const {
          minWidth,
          maxWidth
        } = this.getColumnResizeLimits(column, th.getBoundingClientRect().width); // A column with no most width of its own goes as wide as the
        // table's box: the share a screen reader hears runs from the
        // least width to there (C158 (3)), and End is that width. With
        // no end the share was 0 % at any width.

        const box = this.refs.scroll?.value?.clientWidth ?? 0;
        return {
          min: minWidth,
          max: Number.isFinite(maxWidth) ? maxWidth : Math.max(minWidth, box || minWidth)
        };
      },
      direction: () => table && getComputedStyle(table).direction === 'rtl' ? -1 : 1,
      step: this.resolveCssLength(getComputedStyle(this).getPropertyValue('--sf-space-1'), 16),
      start: () => {
        state.dragging = true;
        this._columnResizeState = state;
        (0,_helpers_loaderDragState__WEBPACK_IMPORTED_MODULE_15__.setLoaderDragState)(true);
        document.documentElement.classList.add('sf-table-column-resizing');
      },
      apply: width => {
        state.frozenWidths ??= this.freezeColumnsWidthForResize(table);
        this._columnResizeState = state;
        if (col) col.style.width = `${width}px`;
        th.style.width = `${width}px`; // The line is placed from the cell's own edge, so it moves in the
        // same frame the edge does.

        this.showColumnResizeGuide(th);
        return width;
      },
      commit: width => {
        const frozen = state.frozenWidths ?? {};
        clear();
        this.applyColumnResizeWidths(key, width, frozen);
      },
      end: () => {
        document.documentElement.classList.remove('sf-table-column-resizing');
        (0,_helpers_loaderDragState__WEBPACK_IMPORTED_MODULE_15__.setLoaderDragState)(false);
        this.suppressNextHeaderClick(); // The drag is over before the line goes: hidden while the
        // state still said «resizing», it stayed on the edge.

        clear();
        this.hideColumnResizeGuide();
      },
      // A double click on the edge is the fit to content (C158 (5));
      // «По умолчанию» in the head's menu is the width the column has
      // by itself (resetColumnWidth).
      reset: () => {
        clear();
        this.resetColumnWidth(key);
      }
    };
  } // The browser's memory of the widths, for a table that asks for it with
  // remember-widths: no host keeps its settings, so a reload lost them.
  // The widths are part of the table's view preference (SF.Preferences):
  // under preferences-key, or with remember-widths under the table's own key.


  get rememberedWidthsKey() {
    if (this.viewPreferenceKey) return this.viewPreferenceKey;
    if (!this.hasAttribute("remember-widths")) return "";
    return tablePreferenceKey(this.getTableSettingsKey() || this.id || globalThis.location?.pathname || "table");
  }

  readRememberedWidths() {
    const key = this.rememberedWidthsKey;
    if (!key) return {};
    const widths = preferences()?.read(key)?.widths;
    return widths && typeof widths === "object" ? widths : {};
  }

  writeTablePreference(key, patch) {
    if (!key) return;
    preferences()?.write(key, { ...(preferences()?.read(key) ?? {}),
      v: 1,
      ...patch
    });
  }

  storeRememberedWidths(widths = {}) {
    this.writeTablePreference(this.rememberedWidthsKey, {
      widths: { ...this.readRememberedWidths(),
        ...widths
      }
    });
  }

  forgetRememberedWidth(column) {
    const widths = this.readRememberedWidths();
    delete widths[column];
    this.writeTablePreference(this.rememberedWidthsKey, {
      widths
    });
  } // How this person arranged this table -- order, visibility, pinning,
  // widths (owner, 2026-10-14): kept under preferences-key (or the table's
  // table-settings-key when the host names one), read before the first
  // paint so the skeleton is already in that order, and written each time
  // the person changes it.


  get viewPreferenceKey() {
    const key = this.getAttribute("preferences-key") || this.getAttribute("table-settings-key") || "";
    return key ? tablePreferenceKey(key) : "";
  }

  applyTablePreference(value, {
    render = false
  } = {}) {
    const kept = value?.columnSettings;
    if (!kept || typeof kept !== "object") return false; // On the host's columns, not on what is drawn: a value that no longer
    // names a column returns it to the host's settings. Merged onto the
    // drawn state, a dropped key kept its old width or visibility on this
    // device until a reload (docs trial 5).

    const host = this.getTableData().columnSettings;
    const base = host && typeof host === "object" && !Array.isArray(host) ? host : {};
    const next = this.mergeColumnSettings(base, kept);
    if (render) this.setColumnSettings(next, "preferences", false);else this.state.columnSettings = next;
    return true;
  }

  connectTablePreference() {
    const key = this.viewPreferenceKey;
    if (key === this._preferenceKeyBound) return;
    this._preferenceUnsubscribe?.();
    this._preferenceKeyBound = key;
    this._preferenceUnsubscribe = null;
    this.applyTableView();
    if (!key) return;
    this.applyTablePreference(preferences()?.read(key)); // The host's value, when it differs from this browser's, arrives later.

    const own = preferences()?.subscribe(key, value => {
      if (value) this.applyTablePreference(value, {
        render: true
      }); // SF.Preferences.remove() from page code: back to the columns as the
      // host gave them, drawn now (docs trial 4: the table kept the
      // removed arrangement until a reload).
      else {
        const host = this.getTableData().columnSettings;
        this.setColumnSettings(host && typeof host === "object" && !Array.isArray(host) ? { ...host
        } : {}, "preferences", false);
      }
      this.applyTableView(); // The layout chosen on another tab, or by the host's copy.

      if (this.hasLayoutSwitch && this._renderedList !== undefined && this.isList !== this._renderedList) this.requestComponentUpdate("layout");
    });
    const general = preferences()?.subscribe(GENERAL_TABLE_PREFERENCE, () => this.applyTableView());

    this._preferenceUnsubscribe = () => {
      own?.();
      general?.();
    };
  } // How the table looks for this person (the gear's «Вид», owner
  // 2026-10-14): density, alternate rows, lines between columns, text on
  // one line. Their tables' preference (sf-view-table/*) lies under this table's.


  get tableView() {
    const key = this.viewPreferenceKey;
    const general = preferences()?.read(GENERAL_TABLE_PREFERENCE)?.view ?? {};
    const own = key ? preferences()?.read(key)?.view ?? {} : this._sessionView ?? {};
    return { ...TABLE_VIEW_DEFAULTS,
      ...general,
      ...own
    };
  }

  applyTableView() {
    const view = this.tableView;

    const flag = (name, on) => on ? this.setAttribute(name, "") : this.removeAttribute(name);

    if (view.density === "normal") this.removeAttribute("data-sf-view-density");else this.setAttribute("data-sf-view-density", view.density); // Zebra is the author's (C146 (4)): a person's stored choice is no
    // longer read.

    flag("data-sf-view-stripes", this.hasAttribute("stripes") && this.getAttribute("stripes") !== "false");
    flag("data-sf-view-lines", view.lines === true);
    flag("data-sf-view-single-line", view.singleLine === true);
    const page = this.getAttribute("vertical-scroll") === "page" && !this.isList;
    flag("data-sf-page-scroll", page);
    flag("data-sf-sticky-head", page && view.stickyHead !== false);
  } // The head held under the toolbar while what scrolls -- the page, or a
  // box around the table -- scrolls past it (page mode): moved down by as
  // much as the table's top has gone above the line, never past its last
  // row. A sticky head cannot do it, because the area it sits in scrolls
  // sideways and so is a scroll container of its own.


  syncStickyHead() {
    const table = this.refs.table?.value;
    const head = table?.tHead;
    if (!head) return;
    const held = this.hasAttribute("data-sf-sticky-head");
    let delta = 0;

    if (held && table.isConnected) {
      const scroller = verticalScroller(this.refs.scroll?.value?.parentElement ?? this);
      const top = scroller ? scroller.getBoundingClientRect().top : 0;
      const toolbar = this.querySelector(":scope > .sf-table > .sf-table-toolbar");
      const line = Math.max(top, toolbar ? toolbar.getBoundingClientRect().bottom : top);
      const box = table.getBoundingClientRect();
      const room = box.height - head.offsetHeight;
      delta = Math.round(Math.min(Math.max(line - box.top, 0), Math.max(room, 0)));
    }

    head.style.transform = delta ? `translateY(${delta}px)` : "";
    this.toggleAttribute("data-sf-head-stuck", delta > 0);
  } // The rail under the area is its sideways bar: as wide as what the area
  // scrolls, shown only when there is something to scroll, and each follows
  // the other.


  syncRail() {
    const rail = this.refs.rail?.value;
    const scroll = this.refs.scroll?.value;
    if (!rail || !scroll) return;
    const wide = scroll.scrollWidth > scroll.clientWidth + 1;
    rail.hidden = !wide;
    const track = rail.firstElementChild;
    if (track) track.style.inlineSize = `${scroll.scrollWidth}px`;

    if (rail._sfBound !== scroll) {
      rail._sfBound = scroll;
      let following = false;

      const follow = (from, to) => () => {
        if (following) return;
        following = true;
        to.scrollLeft = from.scrollLeft;
        following = false;
      };

      scroll.addEventListener("scroll", follow(scroll, rail), {
        passive: true
      });
      rail.addEventListener("scroll", follow(rail, scroll), {
        passive: true
      }); // The columns take their widths after a render (content widths,
      // late fonts): the rail follows the table's size, not the render.

      this._railObserver?.disconnect();

      if (typeof ResizeObserver !== "undefined") {
        this._railObserver = new ResizeObserver(() => this.syncRail());

        this._railObserver.observe(scroll);

        if (this.refs.table?.value) this._railObserver.observe(this.refs.table.value);
      }
    }

    if (wide) rail.scrollLeft = scroll.scrollLeft;
  }

  bindPageScroll() {
    if (this._pageScrollAbort) return;
    this._pageScrollAbort = new AbortController();
    const {
      signal
    } = this._pageScrollAbort;

    const again = () => {
      if (this._pageScrollFrame) return;
      this._pageScrollFrame = requestAnimationFrame(() => {
        this._pageScrollFrame = 0;
        if (this.isConnected) this.syncStickyHead();
      });
    };

    document.addEventListener("scroll", again, {
      capture: true,
      passive: true,
      signal
    });
    globalThis.addEventListener("resize", () => {
      again();
      this.syncRail();
    }, {
      passive: true,
      signal
    });
  }

  unbindPageScroll() {
    this._railObserver?.disconnect();
    this._railObserver = null;
    const rail = this.refs.rail?.value;
    if (rail) rail._sfBound = null;
    this._pageScrollAbort?.abort();
    this._pageScrollAbort = null;
    cancelAnimationFrame(this._pageScrollFrame ?? 0);
    this._pageScrollFrame = 0;
  } // One option changed. «Для всех моих таблиц» writes it to the person's
  // tables and takes it off this one, so this one follows them.


  setTableView(patch = {}, {
    everywhere = false
  } = {}) {
    const key = this.viewPreferenceKey;

    if (everywhere || !key) {
      if (everywhere) {
        const general = preferences()?.read(GENERAL_TABLE_PREFERENCE) ?? {};
        preferences()?.write(GENERAL_TABLE_PREFERENCE, { ...general,
          v: 1,
          view: { ...(general.view ?? {}),
            ...patch
          }
        });
      }

      if (key) {
        const own = { ...(preferences()?.read(key)?.view ?? {})
        };

        for (const field of Object.keys(patch)) delete own[field];

        this.writeTablePreference(key, {
          view: own
        });
      } else if (!everywhere) {
        this._sessionView = { ...(this._sessionView ?? {}),
          ...patch
        };
      }
    } else {
      this.writeTablePreference(key, {
        view: { ...(preferences()?.read(key)?.view ?? {}),
          ...patch
        }
      });
    }

    this.applyTableView();
    this.requestComponentUpdate("table-view");
    this.emitTableEvent("view-change", Object.freeze({
      view: this.tableView,
      everywhere
    }));
    return this;
  }

  resetTableView() {
    const key = this.viewPreferenceKey;
    if (key) this.writeTablePreference(key, {
      view: {}
    });
    this._sessionView = null;
    this.applyTableView();
    this.requestComponentUpdate("table-view");
    return this;
  } // The remembered widths of the columns the table now has, as settings.


  restoreRememberedWidths() {
    const widths = this.readRememberedWidths();
    const keys = new Set((this.getColumns?.() ?? []).map(column => column?.key));
    const patch = Object.fromEntries(Object.entries(widths).filter(([column, width]) => keys.has(column) && typeof width === "string").map(([column, width]) => [column, {
      width
    }]));
    if (Object.keys(patch).length) this.patchColumnSettingsBatch(patch, "column-widths-restore");
  }

  resetColumnWidth(key) {
    if (!key) return this;
    this.forgetRememberedWidth(key);
    return this.patchColumnSettingsBatch({
      [key]: {
        width: null
      }
    }, 'column-resize-reset');
  } // A heading is dragged with the Framework's sortable in its column mode
  // (SF.Sortable.attach, owner 2026-10-13): the column is dimmed in every row,
  // an outline the width of the column and the height of the table stands
  // where it will go, a pinned column moves among pinned ones and a loose one
  // among loose ones, and the click a drop ends with does not sort. The
  // table's own drag -- nine hundred lines moving cells between lit's part
  // markers and putting them back -- is gone. Keyboard reordering is the
  // column settings list.


  get columnDragActive() {
    return document.documentElement.hasAttribute('data-sf-sortable-active');
  }

  bindColumnDragEvent() {
    const table = this.refs.table?.value;
    const row = table?.tHead?.rows?.[0];
    if (!row || this._headerSortableRow === row) return;
    const attach = globalThis.SF?.Sortable?.attach;

    if (typeof attach !== 'function') {
      // sf-sortable is a lazy relation: fetched when first needed.
      globalThis.SF?.Loader?.ensure?.(['sf-sortable'], {
        timeout: Infinity
      }).then(({
        missing
      }) => {
        if (!missing.length && this.isConnected) this.bindColumnDragEvent();
      });
      return;
    }

    this._headerSortableDetach?.();
    this._headerSortableRow = row;
    this._headerSortableDetach = attach(row, {
      items: 'th[data-key]',
      extent: table,
      // A column moving shows the line it will stand at, between two
      // columns (owner, 2026-10-14): the outline of the place it would
      // take read as a column already there.
      preview: 'line',
      label: this.text('settingsColumnLabel'),
      groupOf: th => this.headerColumnGroup(th.dataset.key),
      canStart: (event, th) => !this._columnResizeState && !this.getColumnResizeHandle(event.target) && ['pinned', 'loose'].includes(this.headerColumnGroup(th.dataset.key)),
      cellsOf: th => [...table.rows].map(tr => tr.cells[th.cellIndex]).filter(Boolean),
      onIntent: detail => this.onHeaderColumnIntent(detail)
    });
  }

  unbindColumnDragEvent() {
    this._headerSortableDetach?.();
    this._headerSortableDetach = null;
    this._headerSortableRow = null;
  } // Which group a heading moves in: the system columns and a column marked
  // draggable: false do not move; a pinned column moves among pinned ones.


  headerColumnGroup(key) {
    if (this.getSystemColumns().some(column => String(column.key) === key)) return 'system';
    const column = this.getColumns().find(item => String(item.key) === key);
    if (!column || column.system || column.draggable === false) return 'fixed';
    return this.isColumnPinned(column) ? 'pinned' : 'loose';
  } // The order a heading drop asks for: the column at its place among the
  // shown columns of its group, the others where they are.


  onHeaderColumnIntent({
    item,
    index,
    group
  }) {
    const table = this.refs.table?.value;
    const shown = [...(table?.tHead?.rows?.[0]?.cells ?? [])].map(cell => cell.dataset?.key).filter(key => key && ['pinned', 'loose', 'fixed'].includes(this.headerColumnGroup(key)));
    const peers = shown.filter(key => key !== item && this.headerColumnGroup(key) === group);
    const rest = shown.filter(key => key !== item);
    const before = peers[index];
    const after = peers[index - 1];
    const at = before !== undefined ? rest.indexOf(before) : after !== undefined ? rest.indexOf(after) + 1 : rest.length;
    rest.splice(at, 0, item);
    if (rest.join('|') === shown.join('|')) return this;
    return this.applyColumnOrder(rest, {});
  }

  getColumnResizeHandle(target) {
    if (!(target instanceof Element)) {
      return null;
    } // The handle is found by the attribute it carries, not by a prefix of its
    // id. The id is built from the instance, so it never began with
    // `column_resizer_`: pointerdown on the handle was not recognised as a
    // resize and fell through to the column-move handler, which is why
    // dragging the edge moved the column instead of changing its width.


    return target.closest('[data-sf-column-resizer]');
  }

  parseColumnSize(value, fallback = null) {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return value;
    }

    if (typeof value === 'string') {
      const normalized = value.trim();

      if (/^-?\d+(\.\d+)?px$/.test(normalized)) {
        return parseFloat(normalized);
      }
    }

    return fallback;
  }

  resolveCssLength(value, fallback = 0) {
    const normalized = String(value || '').trim();
    const match = normalized.match(/^(-?\d+(?:\.\d+)?)(px|rem|em)$/);

    if (!match) {
      return fallback;
    }

    const amount = Number(match[1]);
    const unit = match[2];

    if (unit === 'px') {
      return amount;
    }

    const reference = unit === 'rem' ? document.documentElement : this;
    const fontSize = parseFloat(getComputedStyle(reference).fontSize);
    return Number.isFinite(fontSize) ? amount * fontSize : fallback;
  }

  getColumnResizeLimits(column = {}, fallbackWidth = 0) {
    const semanticMinWidth = this.resolveCssLength(getComputedStyle(this).getPropertyValue('--sf-c4'), fallbackWidth);
    const minWidth = this.parseColumnSize(column.minWidth, null) ?? semanticMinWidth;
    const maxWidth = this.parseColumnSize(column.maxWidth, Infinity);
    return {
      minWidth,
      maxWidth: Math.max(maxWidth, minWidth)
    };
  }

  hasColumnSize(column = {}) {
    return [column.colWidth, column.width, column.size].some(value => value !== null && typeof value !== 'undefined' && String(value).trim() !== '');
  }

  escapeColumnKey(key) {
    const value = String(key || '');

    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
      return CSS.escape(value);
    }

    return value.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  freezeColumnsWidthForResize(table) {
    const frozenWidths = {};
    const columns = this.getColumns();
    columns.forEach(column => {
      if (!column?.key) {
        return;
      }

      const key = String(column.key);
      const escapedKey = this.escapeColumnKey(key);
      const th = table?.querySelector(`th[data-key="${escapedKey}"]`);
      const col = table?.querySelector(`col[data-key="${escapedKey}"]`);
      const width = th?.getBoundingClientRect?.().width || 0;

      if (!width) {
        return;
      }

      const nextWidth = `${Math.round(width)}px`;

      if (col) {
        col.style.width = nextWidth;
      }

      if (!column.system && !this.hasColumnSize(column)) {
        frozenWidths[key] = nextWidth;
      }
    });
    return frozenWidths;
  }

  applyColumnResizeWidths(key, width, frozenWidths = {}) {
    if (!key) {
      return this;
    }

    const nextWidths = { ...(frozenWidths || {}),
      [key]: `${Math.round(width)}px`
    };
    this.storeRememberedWidths(nextWidths);
    const settingsPatch = Object.fromEntries(Object.entries(nextWidths).map(([columnKey, columnWidth]) => [columnKey, {
      width: columnWidth
    }]));
    return this.patchColumnSettingsBatch(settingsPatch, 'column-resize');
  }

  reorderColumnDomByKeys(table, userKeys = []) {
    if (!table || !Array.isArray(userKeys) || !userKeys.length) {
      return;
    }

    const moveKeyedChildren = (container, selector) => {
      if (!container) {
        return;
      }

      const userKeySet = new Set(userKeys);
      let insertAfter = null;

      for (const child of Array.from(container.children || [])) {
        const childKey = child?.dataset?.key;

        if (childKey && userKeySet.has(childKey)) {
          break;
        }

        if (childKey) {
          insertAfter = child;
        }
      }

      userKeys.forEach(key => {
        const escapedKey = this.escapeColumnKey(key);
        const child = container.querySelector(`${selector}[data-key="${escapedKey}"]`);

        if (child) {
          container.insertBefore(child, insertAfter?.nextSibling || container.firstChild);
          insertAfter = child;
        }
      });
    };

    moveKeyedChildren(table.querySelector('colgroup'), 'col');
    moveKeyedChildren(table.tHead?.rows?.[0], 'th');
    Array.from(table.tBodies || []).forEach(tbody => {
      Array.from(tbody.rows || []).forEach(row => {
        moveKeyedChildren(row, 'td');
      });
    });
  }

  applyColumnOrder(userKeys = [], frozenWidths = {}) {
    // Moving a column rearranges the columns the person can see, among the
    // places those columns already occupy. Numbering every draggable
    // column from ten upward instead renumbered the hidden ones too, and a
    // hidden column has no place on screen to be numbered from, so they
    // came out ahead of everything: a consumer dropped one column one place
    // to the left and found its nine visible columns pushed behind seven it
    // had never shown. Hidden columns keep their order, so they keep their
    // place between the visible ones when they are shown again.
    if (!Array.isArray(userKeys) || !userKeys.length) {
      return this;
    }

    const settingsPatch = {};
    const slots = this.getColumnOrderSlots(userKeys);
    userKeys.forEach((key, index) => {
      settingsPatch[key] = {
        order: slots[index]
      };

      if (frozenWidths?.[key]) {
        settingsPatch[key].width = frozenWidths[key];
      }
    });
    return this.patchColumnSettingsBatch(settingsPatch, 'column-drag');
  } // The places the moved columns already occupy, in order. A column whose
  // order nobody has ever set takes the place its position gives it, so a
  // first move on an untouched layout still numbers in tens.


  getColumnOrderSlots(userKeys = []) {
    const all = (this.getTableData().columns || []).filter(column => column?.key && !column.system);

    const effective = (column, index) => {
      const setting = this.getColumnSetting(column.key) || {};
      const value = setting.order ?? column.order;
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : (index + 1) * 10;
    };

    const current = new Map(all.map((column, index) => [String(column.key), effective(column, index)]));
    const taken = userKeys.map(key => current.get(String(key))).filter(value => Number.isFinite(value)).sort((left, right) => left - right); // Two columns can share a place when a host sends the same order twice.
    // Then the places are rebuilt from the positions, which cannot collide.

    const distinct = new Set(taken);

    if (taken.length !== userKeys.length || distinct.size !== taken.length) {
      return userKeys.map((_, index) => (index + 1) * 10);
    }

    return taken;
  }

  setColumnResizeClasses(th, delta = 0) {
    if (!th) return;
    th.classList.add('is-resizing');
    th.classList.toggle('is-resizing-forward', delta >= 0);
    th.classList.toggle('is-resizing-backward', delta < 0); // The line follows the edge while it is dragged, not only on hover.

    this.showColumnResizeGuide(th); // Resizing a pinned column moves every pinned column after it.

    this.measurePinnedColumns();
  }

  clearColumnResizeClasses(th) {
    if (!th) return;
    th.classList.remove('is-resizing', 'is-resizing-forward', 'is-resizing-backward');
    this.hideColumnResizeGuide();
    this.measurePinnedColumns();
  } // An open window is a surface of the document's one layer stack
  // (standard 1.3.8 §19): the stack's one listener hands it a press outside
  // and Escape while it is the top layer, and it is drawn at the stack's
  // height. The table bound a document click and keydown of its own (reuse
  // audit 2026-11-02, findings 1 and 3), which acted whatever lay above the
  // window and closed it together with a drawer or a record panel under it.
  // The layer is the portal the windows are drawn in, not the table: a press
  // anywhere else in the table is outside the window.


  bindContextEvent() {
    if (this._contextEventBound) {
      return;
    }

    const portal = this.getPortalContainer();
    this._contextLayerOwner = portal;
    (0,_core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17__.holdOpenSurfaceMark)(portal, true, {
      root: () => portal,
      onOutsidePress: event => this.contextOutsidePress(event),
      onEscape: event => this.contextKeyEvent(event)
    });
    this._contextEventBound = true;
  }

  unbindContextEvent() {
    if (!this._contextEventBound) {
      return;
    }

    (0,_core_js_open_surface_mark_js__WEBPACK_IMPORTED_MODULE_17__.holdOpenSurfaceMark)(this._contextLayerOwner, false);
    this._contextLayerOwner = null;
    this._contextEventBound = false;
  } // The window's place on the stack's z-index scale; the Framework's old
  // fixed step until it is on the stack.
  // The kind of window a menu name opens (C32, owner 2026-11-09): the
  // table's own windows are not menus -- the menus (create, sort, row and
  // toolbar actions) are sf-menu-context's own rows and take its widths.
  // The filter with its saved views and the column settings are panels:
  // one width, --sf-popup-panel-width (20rem; 18rem compact), or the
  // trigger's when that is wider. Saving a template and a chip's own
  // filter are forms: --sf-popup-form-width (20rem; 18rem compact). A
  // panel laid out in several columns is as wide as they are. Every window
  // stays inside the room it has (--sf-table-context-menu--available-inline-size).


  contextWindowClass(menu, columns = 1) {
    const kind = {
      'filter-settings': 'panel',
      'table-settings': 'panel',
      'filter-favorites': 'form',
      'tag-settings': 'form'
    }[menu] ?? 'panel';
    return `sf-table-context-menu--${kind}${kind === 'panel' && Number(columns) > 1 ? ' sf-table-context-menu--columns' : ''}`;
  } // The trigger's width, for a panel that is at least as wide as the button
  // that opened it.


  contextTriggerInlineSize(data = {}) {
    const width = data.anchor?.getBoundingClientRect?.().width;
    return Number.isFinite(width) ? Math.ceil(width) : 0;
  }

  contextMenuZIndex() {
    const zIndex = this._contextLayerOwner ? (0,_core_js_layer_stack_js__WEBPACK_IMPORTED_MODULE_18__.layerZIndex)(this._contextLayerOwner) : '';
    return zIndex === '' ? 'var(--sf-z-index-9)' : String(zIndex);
  } // A press on the control that opened the window is left to that
  // control's own click, which reopens or closes it as it always did: closed
  // here first, the gear's second press would open the window again.


  contextOutsidePress(event) {
    const opener = this.contextTarget;

    if (opener instanceof Element && (event.composedPath?.() || []).includes(opener)) {
      return;
    }

    this.contextEvent(event);
  } // Answers true when it took the press; the stack then stops it.


  contextKeyEvent(event) {
    if (event.key !== 'Escape' || !this.state.contextMenu?.open) {
      return false;
    }

    this.closeContextMenu(true);
    return true;
  } // The table's windows -- filter, field popovers, settings, menus -- are
  // drawn in the page's top layer from inside the table, not moved to the end
  // of the body. Moved out, a window was not clipped by the table's scroll
  // box, but it lost everything the table gives what it holds: its size (the
  // filter opened a step larger than a table at 1/2), its language, its theme,
  // the variables its containers set (owner, 2026-10-13). In the top layer it
  // stays where it belongs and is still drawn above everything, unclipped.
  //
  // The container is a form of its own, before the table's rendered content:
  // inside a page's form a filter field would be submitted with it and Enter
  // in one would send the page's form; and before the content, so a re-render
  // of the table never takes it away. Its fields' own change and input stop
  // at it: they are the table's business, not the page's.


  getPortalContainer() {
    if (this._portalContainer?.isConnected) {
      return this._portalContainer;
    }

    const portal = document.createElement("form");
    portal.className = "sf-table-portal";
    portal.noValidate = true;
    portal.dataset.tableSettingsKey = this.getTableSettingsKey();
    portal.dataset.sfInstance = this.getInstanceId();
    if (typeof portal.showPopover === "function") portal.setAttribute("popover", "manual");
    portal.addEventListener("submit", event => event.preventDefault());

    for (const type of ["change", "input"]) {
      portal.addEventListener(type, event => event.stopPropagation());
    }

    this.insertBefore(portal, this.firstChild); // What the windows draw here is read by the Loader as the page is
    // (core.runtime 1.19.0): no lazy element is asked for by name.

    globalThis.SF?.Loader?.watch?.(portal);
    this._portalContainer = portal;
    return portal;
  } // The column window's host (VT-12): no box of its own, in this element
  // so the panel reads the table's density and the Loader sees it.


  getSettingsHost() {
    if (this._settingsHost?.isConnected) return this._settingsHost;
    const host = document.createElement("div");
    host.className = "sf-table-settings-host";
    host.dataset.sfInstance = this.getInstanceId();

    for (const type of ["change", "input"]) host.addEventListener(type, event => event.stopPropagation());

    this.insertBefore(host, this.firstChild);
    globalThis.SF?.Loader?.watch?.(host);
    this._settingsHost = host;
    return host;
  } // The top layer is entered while a window is open and left when none is.


  showPortal() {
    const portal = this._portalContainer;
    if (!portal?.isConnected || typeof portal.showPopover !== "function") return;
    if (!portal.matches(":popover-open")) portal.showPopover();
  }

  hidePortal() {
    const portal = this._portalContainer;
    if (!portal?.isConnected || typeof portal.hidePopover !== "function") return;
    if (portal.matches(":popover-open")) portal.hidePopover();
  }

  getVisualViewportRect() {
    const viewport = window.visualViewport;
    return {
      left: viewport?.offsetLeft || 0,
      top: viewport?.offsetTop || 0,
      right: (viewport?.offsetLeft || 0) + (viewport?.width || window.innerWidth),
      bottom: (viewport?.offsetTop || 0) + (viewport?.height || window.innerHeight)
    };
  }

  clampContextMenusToViewport() {
    const portal = this._portalContainer;

    if (!portal?.isConnected) {
      return;
    }

    const viewport = this.getVisualViewportRect();
    const rootStyle = getComputedStyle(document.documentElement);
    const inset = parseFloat(rootStyle.getPropertyValue('--sf-space-1/3')) || 0;
    const anchored = new Set();
    portal.querySelectorAll('sf-menu-context').forEach(menu => {
      if (this.anchorContextMenu(menu, viewport, inset)) {
        anchored.add(menu);
        return;
      }

      const availableInlineSize = Math.max(0, viewport.right - viewport.left - inset * 2);
      const availableBlockSize = Math.max(0, viewport.bottom - viewport.top - inset * 2); // Both names: the stylesheet reads the second one, and only the
      // first was written here, so a menu placed by click coordinates
      // never received the cap this line means to give it.

      menu.style.setProperty('--sf-table-context-menu--available-inline-size', `${availableInlineSize}px`);
      menu.style.setProperty('--sf-context-menu-available-inline-size', `${availableInlineSize}px`);
      menu.style.setProperty('--sf-context-menu-available-block-size', `${availableBlockSize}px`);
      menu.style.translate = '';
      const surface = menu.querySelector(':scope > .sf-context-menu') || menu;
      const rect = surface.getBoundingClientRect();
      let offsetX = 0;
      let offsetY = 0;

      if (rect.left < viewport.left + inset) {
        offsetX = viewport.left + inset - rect.left;
      } else if (rect.right > viewport.right - inset) {
        offsetX = viewport.right - inset - rect.right;
      }

      if (rect.top < viewport.top + inset) {
        offsetY = viewport.top + inset - rect.top;
      } else if (rect.bottom > viewport.bottom - inset) {
        offsetY = viewport.bottom - inset - rect.bottom;
      }

      if (offsetX || offsetY) {
        menu.style.translate = `${offsetX}px ${offsetY}px`;
      }
    });

    for (const [menu, entry] of this._contextPositions || []) {
      if (!anchored.has(menu)) {
        entry.controller.stop();

        this._contextPositions.delete(menu);
      }
    }
  } // Placement of an open menu relative to the element it was opened from:
  // menus with a tail (row actions, template actions) open beside it, the
  // others below it. null keeps the static click-coordinate placement.
  // Cells re-render their controls, so an opener can be replaced while its
  // menu is open. Remember where it sits (row cell, header, toolbar id) to
  // find its replacement.


  describeContextAnchor(anchor) {
    if (!(anchor instanceof Element)) return null;
    const host = anchor.closest('[data-item], th[data-key], [id]');
    if (!host || !this.contains(host)) return null;
    const selector = host.dataset.item !== undefined ? `[data-item="${this.escapeColumnKey(host.dataset.item)}"]` : host.matches('th[data-key]') ? `th[data-key="${this.escapeColumnKey(host.dataset.key)}"]` : `[id="${this.escapeColumnKey(host.id)}"]`;
    const tag = anchor.tagName.toLowerCase();
    return {
      selector,
      tag,
      index: host === anchor ? -1 : Array.from(host.querySelectorAll(tag)).indexOf(anchor)
    };
  }

  resolveContextAnchor(data) {
    if (data?.anchor instanceof Element && data.anchor.isConnected) return data.anchor;
    const ref = data?.anchorRef;
    const host = ref ? this.querySelector(ref.selector) : null;
    const anchor = host && (ref.index < 0 ? host : host.querySelectorAll(ref.tag)[ref.index]);
    if (!anchor) return null;
    data.anchor = anchor;
    return anchor;
  } // Menus opened from a control at the end of a row align to that control's
  // end edge, so they open under the button instead of hanging past it over
  // the next column. The consumer measured a menu whose left edge matched the
  // button's left and whose right edge stood 34 to 124px beyond it.


  getContextMenuPlacement(menu) {
    const data = this.state.contextMenu;
    const anchor = this.resolveContextAnchor(data);
    if (!anchor) return null;
    const position = String(data.position || (data.type === 'left' ? 'left' : ''));
    const family = /^(left|right)(-top|-bottom)?$/.exec(position);

    if (!family) {
      return {
        anchor,
        side: 'block-end',
        align: 'start',
        tail: null
      };
    }

    const suffix = family[2] || '';
    return {
      anchor,
      side: family[1] === 'left' ? 'inline-end' : 'inline-start',
      align: suffix === '-top' ? 'start' : suffix === '-bottom' ? 'end' : 'center',
      tail: suffix
    };
  } // Shared Framework geometry (SF.Position): the menu flips when its side
  // does not fit, shifts inside the viewport and follows its opener while
  // the page scrolls. Sizes are written to the rendered surface, not the
  // boxless host, so they never re-render the menu over this placement.


  anchorContextMenu(menu, viewport, inset) {
    const placement = this.getContextMenuPlacement(menu);
    if (!placement) return false;
    const surface = menu.querySelector(':scope > .sf-context-menu');
    if (!surface) return false;
    this._contextPositions = this._contextPositions || new Map();

    const current = this._contextPositions.get(menu); // SF.Position writes an inline max-width from the free space, which
    // would override the menu's stylesheet cap; keep that cap in the width.


    const cssCap = current?.cssCap ?? (parseFloat(getComputedStyle(surface).maxWidth) || Infinity);
    const inlineSize = `${Math.max(0, Math.min(viewport.right - viewport.left - inset * 2, cssCap))}px`;
    surface.style.setProperty('--sf-table-context-menu--available-inline-size', inlineSize);
    surface.style.setProperty('--sf-context-menu-available-inline-size', inlineSize);
    const key = `${placement.side}|${placement.align}`;

    if (current && current.anchor === placement.anchor && current.surface === surface && current.key === key) {
      current.controller.update();
      return true;
    }

    current?.controller.stop();
    surface.style.transform = 'none';
    surface.style.translate = 'none';
    surface.style.setProperty('--sf-context-menu-available-block-size', `${Math.max(0, viewport.bottom - viewport.top - inset * 2)}px`);
    const Position = positioning();
    const gap = placement.tail === null ? Position.resolveLength('calc(var(--sf-focus-outline-width) * 2)', surface) : Position.resolveLength('var(--sf-context-menu-tail-corner-offset)', surface);
    const anchorBox = placement.anchor.getBoundingClientRect();
    const controller = Position.anchor(placement.anchor, surface, {
      side: placement.side,
      align: placement.align,
      offset: gap,
      alignmentOffset: placement.align === 'center' || placement.tail === null ? 0 : Math.max(0, anchorBox.height / 2 - gap),
      padding: inset,
      fitHeight: false,
      onPosition: ({
        side
      }) => {
        const box = placement.anchor.getBoundingClientRect();
        const view = this.getVisualViewportRect();
        const blockSize = side === 'block-end' ? view.bottom - inset - box.bottom - gap : side === 'block-start' ? box.top - gap - inset - view.top : view.bottom - view.top - inset * 2;
        const value = `${Math.max(0, Math.floor(blockSize))}px`;

        if (surface.style.getPropertyValue('--sf-context-menu-available-block-size') !== value) {
          surface.style.setProperty('--sf-context-menu-available-block-size', value);
        }

        if (placement.tail !== null) {
          const next = `${side === 'inline-end' ? 'left' : 'right'}${placement.tail}`;
          if (menu.getAttribute('position') !== next) menu.setAttribute('position', next);
        }
      }
    });

    this._contextPositions.set(menu, {
      controller,
      anchor: placement.anchor,
      surface,
      key,
      cssCap
    }); // The first placement is measured before the webfont has arrived, and
    // the cap written then is the cap of a narrower menu. The positioner
    // watches the box, but a font swap is cheap to wait for by name.


    document.fonts?.ready?.then(() => {
      if (this._contextPositions?.get(menu)?.controller === controller) controller.update();
    }).catch(() => {});
    return true;
  }

  stopContextMenuPositions() {
    for (const entry of this._contextPositions?.values() || []) entry.controller.stop();

    this._contextPositions?.clear();
  }

  contextViewportEvent() {
    requestAnimationFrame(() => this.clampContextMenusToViewport());
  }

  bindContextViewport() {
    if (this._contextViewportBound) {
      return;
    }

    window.addEventListener('resize', this.contextViewportEvent);
    window.visualViewport?.addEventListener('resize', this.contextViewportEvent);
    window.visualViewport?.addEventListener('scroll', this.contextViewportEvent);
    this._contextViewportBound = true;
  }

  unbindContextViewport() {
    if (!this._contextViewportBound) {
      return;
    }

    window.removeEventListener('resize', this.contextViewportEvent);
    window.visualViewport?.removeEventListener('resize', this.contextViewportEvent);
    window.visualViewport?.removeEventListener('scroll', this.contextViewportEvent);
    this._contextViewportBound = false;
  }

  openContextMenu(event, opts = {}) {
    // The row's menu is the one standard menu bound to the rows (CM-8,
    // C164 (2)); the table no longer draws a second one of its own.
    if (opts.menu === "row-settings" || !opts.menu && opts.type === "left" && opts.row) {
      this.closeContextMenu(false);
      return this.openRowMenu(event, opts.row ?? {}, {
        group: Array.isArray(opts.action?.members) ? opts.action : null,
        items: Array.isArray(opts.items) ? opts.items : null
      });
    } // The action menus are SF.menu.open's: no window of the table's own.


    if (["create", "list-sort", "toolbar-actions"].includes(opts.menu)) {
      this.closeContextMenu(false);
      const opener = event.currentTarget instanceof Element ? event.currentTarget : event.target instanceof Element ? event.target : null;
      if (!opener) return;
      event.preventDefault?.();
      event.stopPropagation?.();
      return this.openActionMenu(opts.menu, this.resolveBoxedAnchor(event, opener));
    }

    this.closeContextMenu(false);
    this.contextTarget?.classList.remove("active");
    const target = event.currentTarget instanceof Element ? event.currentTarget : event.target instanceof Element ? event.target : null;

    if (!target) {
      return;
    } // Custom-element hosts use display:contents and have no positioning box.
    // Anchor to the native control on the event path within this opener.


    const nativeTarget = (event.composedPath?.() || []).filter(node => node instanceof Element).map(node => node.closest?.('button, input, select, textarea, a[href], [role="button"]')).find(node => node && (node === target || target.contains(node))); // Without a native control (for example a clicked sf-tag), anchor to the
    // first rendered box inside the opener instead of its boxless host.

    const hasBox = node => {
      const rect = node.getBoundingClientRect();
      return rect.width > 0 || rect.height > 0;
    };

    const boxedTarget = nativeTarget || hasBox(target) ? target : Array.from((target.shadowRoot || target).querySelectorAll?.('*') || []).find(hasBox) || target;
    this.contextTarget = nativeTarget || boxedTarget;
    this.contextTarget.classList.add("active"); // A chip opens its menu from the label button but anchors to the chip.

    let anchor = opts.anchorSelector && this.contextTarget.closest?.(opts.anchorSelector) || this.contextTarget;
    let pos = anchor.getBoundingClientRect();
    event.preventDefault();
    event.stopPropagation();
    let data = {
      open: true,
      id: this.contextTarget,
      ...opts
    };
    let tempData = {};

    switch (opts.type) {
      case 'left':
        tempData = {
          x: pos.left + pos.width,
          y: pos.y + pos.height / 2
        };
        break;

      case 'bottom':
        {
          let parent = null;

          if (opts.parent) {
            parent = (0,_helpers_dom__WEBPACK_IMPORTED_MODULE_14__.getParent)(event.target);
            pos = parent.getBoundingClientRect();
            anchor = parent;
          }

          tempData = {
            x: pos.left,
            y: pos.y + pos.height
          };
          break;
        }

      default:
        tempData = {
          x: pos.left,
          y: pos.y + pos.height
        };
    }

    data = { ...data,
      ...tempData,
      anchor,
      anchorRef: this.describeContextAnchor(anchor)
    }; // What «Сбросить» returns to in the column settings window: the settings
    // as they stood when it was opened. Everything in that window applies on
    // the spot now, so without this there is nothing to go back to.

    if (data.menu === 'table-settings') {
      this._columnSettingsOnOpen = JSON.parse(JSON.stringify(this.getColumnSettings() || {}));
    }

    this.set({
      contextMenu: { ...data
      }
    });
  } // The element to anchor to: the native control the event passed through,
  // else the first box inside the opener, else the opener itself. A Framework
  // control's host element is display:contents and has no box of its own.


  resolveBoxedAnchor(event, target) {
    if (!(target instanceof Element)) return target;

    const hasBox = node => {
      const rect = node?.getBoundingClientRect?.();
      return Boolean(rect) && (rect.width > 0 || rect.height > 0);
    };

    const native = (event?.composedPath?.() || []).filter(node => node instanceof Element).map(node => node.closest?.('button, input, select, textarea, a[href], [role="button"]')).find(node => node && (node === target || target.contains(node)));
    if (native && hasBox(native)) return native;
    if (hasBox(target)) return target;
    const inside = Array.from((target.shadowRoot || target).querySelectorAll?.('*') || []).find(hasBox);
    return inside || target;
  } // A context menu renders Framework elements, and a page may open one before
  // their modules have arrived -- the consumer saw a template row with its
  // handle and its menu but no radio and no name, and the window's tabs
  // rendering as one list, because sf-radio and sf-tabs were not upgraded yet.
  // Nothing redrew when they were. This asks once per element and redraws when
  // it is defined; an element already defined costs nothing.


  redrawWhenComponentsUpgrade(root = this) {
    if (!root?.querySelectorAll) return this;
    this._awaitedComponents = this._awaitedComponents || new Set();
    const names = new Set(Array.from(root.querySelectorAll('*')).map(node => node.tagName.toLowerCase()).filter(name => name.includes('-') && !customElements.get(name)));

    for (const name of names) {
      if (this._awaitedComponents.has(name)) continue;

      this._awaitedComponents.add(name);

      customElements.whenDefined(name).then(() => {
        this.requestComponentUpdate('component-upgrade');
      }).catch(() => {});
    }

    return this;
  } // A saved view's «⋯» opens the page's one menu of actions (VF-1).


  openContextSubmenu(event, opts = {}) {
    event.preventDefault();
    event.stopPropagation();
    const target = event.target instanceof Element ? event.target : null;
    const anchorTarget = event.currentTarget instanceof Element ? event.currentTarget : target;
    if (!anchorTarget) return null; // The opener is usually an sf-button-icon, whose host is display:contents
    // and has no box at all; the native control on the event path has one.

    const boxed = this.resolveBoxedAnchor(event, anchorTarget);
    return this.openTemplateActionsMenu(boxed, opts.template || {});
  } // Every element the table draws goes through here -- its own controls,
  // the row menus, the select boxes, a host's row actions -- and each was
  // written for the ladder's step 1. A table at another step draws them at
  // its own: a size of 1 becomes the table's. An element that names no size
  // keeps its own default -- a badge's is 1/3, a tag's 1/2 -- which a table at
  // a smaller step would otherwise have grown.
  // A value in a cell that is only shown -- a badge, a tag, an avatar -- is
  // drawn as its component's own markup, from a detached instance of the
  // component, instead of as an element of its own (owner, 2026-10-15: a
  // page of rows held four hundred elements, each rendering itself, and a
  // sort built them all). The classes, so the look, are the component's;
  // anything interactive, or a component not defined yet, stays an element.


  renderCellElement(type, props = {}) {
    const tag = (0,_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__.canonicalTag)(`sf-${String(type ?? "").replace(/^sf-/u, "")}`); // A status or a value in a cell is a tonal badge (owner decision C140
    // (2), (4); TB-6 of the table study): the host's main, or no
    // appearance on a pair whose default is still main, draws tonal; an
    // outline stays an outline.

    if (tag === "sf-badge" && props.appearance !== "outline") props = { ...props,
      appearance: "tonal"
    };
    const shown = LIGHT_CELL_TAGS.has(tag) && props.interactive !== true && props.closable !== true && props.type !== "checkbox" && !Object.keys(props).some(key => key.startsWith("@") || /^on[A-Z]/u.test(key));
    const Element = shown ? customElements.get(tag) : null;
    if (!Element) return this.renderSmartElement(type, props);
    this._lightCells ??= new Map();

    let element = this._lightCells.get(tag);

    if (!element) {
      element = document.createElement(tag);

      this._lightCells.set(tag, element);
    }

    if (typeof element.template !== "function") return this.renderSmartElement(type, props);

    for (const name of [...element.getAttributeNames()]) element.removeAttribute(name);

    for (const [key, value] of Object.entries(this.relativeSize(props))) {
      if (value === undefined || value === null || value === false) continue;
      const attribute = key.replace(/[A-Z]/gu, letter => `-${letter.toLowerCase()}`);
      if (typeof value === "object" || typeof value === "function") element[key] = value;else element.setAttribute(attribute, value === true ? "" : String(value));
    }

    try {
      return element.template();
    } catch {
      return this.renderSmartElement(type, props);
    }
  } // A component type names a Framework element: a former tag (a host's
  // {type: 'icon-button'}, a dated alias until 2027-01-01) draws the element
  // under its current tag.


  renderSmartElement(type, props = {}) {
    type = (0,_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__.canonicalTag)(`sf-${String(type ?? "").replace(/^sf-/u, "")}`);
    return super.renderSmartElement(type, this.relativeSize(props));
  }

  get size() {
    return this.getEnumAttr("size", ["1/2", "1"], "1");
  } // The size a control inside is written with (C22): the host's own when it
  // has one, none when it has not. A control written at size 1 in a host
  // without a size stayed 40 under compact page density, where the page's
  // own controls were 32 (Larena, 2026-11-10).


  get controlSize() {
    const size = this.getAttribute("size");
    return size === "1/2" || size === "1" ? size : null;
  } // Every menu the table opens is on the table's step (owner remark
  // 2026-11-15): its resolved size -- the attribute, else the default "1" --
  // as its rows, checkboxes and buttons already are. A menu with no size
  // fell back to the menu's own default 1/2: a table of size 1 (rows 48,
  // text 16) opened 32 px rows with 14 px text.


  get menuSize() {
    return this.size === "1/2" ? "1/2" : "1";
  } // A control a column or an action names at size 1 is "this table's
  // size": the host's size when it has one, otherwise no size at all.


  relativeSize(props) {
    if (!props || String(props.size) !== "1") return props;
    const {
      size: _size,
      ...rest
    } = props;
    return this.controlSize ? { ...rest,
      size: this.controlSize
    } : rest;
  }

  getSelectColumn() {
    return { ...this.TABLE_SELECT_COLUMN,
      component: { ...this.TABLE_SELECT_COLUMN.component,
        props: { ...(this.TABLE_SELECT_COLUMN.component?.props || {}),
          checked: Boolean(this.state?.settingsChecked),
          indeterminate: Boolean(this.state?.selectIndeterminate)
        }
      }
    };
  }

  getColumns() {
    const dataColumns = this.getTableData().columns || [];
    const systemColumns = this.getSystemColumns();
    const systemKeys = new Set(systemColumns.map(column => column.key));
    const rightSystemKeys = new Set(['actions']);
    const originalIndexByKey = new Map(dataColumns.map((column, index) => [column?.key, index]));
    const userColumns = dataColumns.filter(column => column?.key && !systemKeys.has(column.key)).map(column => {
      const settings = this.getColumnSetting(column.key);
      const nextColumn = { ...column,
        ...settings
      };

      if (settings.width) {
        nextColumn.colWidth = settings.width;
      }

      return nextColumn;
    }).sort((left, right) => {
      const getOrder = column => {
        const order = column?.order;
        return order !== null && typeof order !== "undefined" && order !== "" && Number.isFinite(Number(order)) ? Number(order) : originalIndexByKey.get(column?.key) ?? 0;
      };

      const leftOrder = getOrder(left);
      const rightOrder = getOrder(right);

      if (leftOrder === rightOrder) {
        return (originalIndexByKey.get(left.key) ?? 0) - (originalIndexByKey.get(right.key) ?? 0);
      }

      return leftOrder - rightOrder;
    });
    const leftSystemColumns = systemColumns.filter(column => !rightSystemKeys.has(column?.key));
    const rightSystemColumns = systemColumns.filter(column => rightSystemKeys.has(column?.key)); // Pinned columns stand right after the box and the row menu, each group
    // in its own order. The partition is stable, so pinning changes which
    // group a column is in and nothing else about where it sits.

    const pinnedUserColumns = userColumns.filter(column => this.isColumnPinned(column));
    const looseUserColumns = userColumns.filter(column => !this.isColumnPinned(column));
    const columns = [...leftSystemColumns, ...pinnedUserColumns, ...looseUserColumns, ...rightSystemColumns].filter(column => column?.visible !== false); // On a phone a keyed table with row actions keeps the box, «≡» and
    // the key cells (C259); the others are the record's, opened by its name.

    if (this.isKeyedNarrow) return columns.filter(column => systemKeys.has(column.key) || isKeyCell(column));
    const width = this._responsiveWidth || this.clientWidth || 0; // The list chooses its own fields by priority and wants every column to
    // choose from; dropping columns that do not fit is the table's answer.

    if (this.isList || !width || !userColumns.some(column => column.priority !== undefined)) return columns;

    const columnWidth = column => {
      const value = column.min_width ?? column.minWidth ?? column.width;
      const parsed = typeof value === "number" ? value : Number.parseFloat(String(value ?? ""));
      return Number.isFinite(parsed) && parsed > 0 ? parsed : column.system ? 48 : 160;
    };

    const retained = new Set(columns);
    let needed = columns.reduce((sum, column) => sum + columnWidth(column), 0);
    const removable = userColumns.filter(column => column.visible !== false).sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));

    for (const column of removable) {
      if (needed <= width || retained.size <= systemColumns.length + 1) break;
      retained.delete(column);
      needed -= columnWidth(column);
    }

    return columns.filter(column => retained.has(column));
  } // The columns that stay in place while the rows scroll sideways: the box,
  // the row menu, and the column the host marked as the record's title. The
  // host declares the title with `role: "title"` on the column rather than
  // the table guessing the first text column — a guess breaks on a page whose
  // first column is an icon or a flag, and the host already knows which
  // column leads the record.
  // Whether a column is pinned. The person decides, through the toggle in the
  // column settings, and the answer is stored beside the order and the width;
  // the column the host marked as the record's title starts pinned, because
  // that is the column a reader names a row by. The box and the row menu are
  // always pinned and are not offered a toggle.


  isColumnPinned(column) {
    if (!column?.key) return false;
    if (column.key === "select" || column.key === "settings") return true;
    if (column.system) return false;
    const pending = this.tempSettings?.cols?.[column.key];
    const setting = this.getColumnSetting(column.key) || {};
    const chosen = pending?.pinned ?? setting.pinned ?? column.pinned;
    if (typeof chosen === "boolean") return chosen;
    if (column.role === "title") return true; // Without a title, the first data column stands still when the table
    // scrolls sideways (owner decision C146 (9)): a plain table on a phone
    // keeps the name of each row in view.

    const data = (this.getTableData().columns || []).filter(one => one?.key && !SYSTEM_COLUMN_KEYS.has(one.key) && !one.system);
    return !data.some(one => one.role === "title") && data[0]?.key === column.key;
  }

  getPinnedColumnKeys(columns = this.getColumns()) {
    return columns.filter(column => column?.key && this.isColumnPinned(column)).map(column => column.key);
  }

  isPinnedColumn(column) {
    if (!column?.key) return false;
    if (["start", "end"].includes(column.sticky)) return true;
    return this.isColumnPinned(column);
  } // A pinned cell's offset is read from the page, not from the declared
  // widths. The box and the row menu declare their widths as `calc()` over
  // tokens, which no arithmetic here can resolve, and a column the person has
  // resized no longer has the width its description names. The measured
  // offsets are published as custom properties, so the cells themselves only
  // ever name a property.


  getStickyCellStyle(columns, index) {
    const column = columns[index];
    const pinned = this.isPinnedColumn(column);
    if (!pinned) return "";
    const side = ["start", "end"].includes(column.sticky) ? column.sticky : "start"; // Only the placing is inline. The colour is a rule, because a pinned
    // cell has to carry the colour of the row it is in: painting it here
    // beat every row state and left the pinned columns white under a
    // selected or hovered row.

    return `position: sticky; inset-inline-${side}: var(--sf-table-pin-${column.key}, 0px); z-index: 2;`;
  } // Measured after a draw and on every resize of the box: the column
  // settings are read once for it (drawingWith).


  measurePinnedColumns() {
    return this.drawingWith(() => this.measurePinnedColumnsNow());
  }

  measurePinnedColumnsNow() {
    const table = this.refs.table?.value;
    const scroll = this.refs.scroll?.value;
    if (!table) return this;
    const keys = this.getPinnedColumnKeys();
    const head = table.querySelector("thead tr"); // The widths read first, the offsets written after: written in turn,
    // each read laid the table out again (stand 25: a pinned column each
    // side, every scroll and every render). The offsets do not change the
    // widths. An offset that is already there is not written again.

    const widths = keys.map(key => {
      const cell = head?.querySelector(`th[data-key="${key}"]`);
      return cell ? cell.getBoundingClientRect().width : 0;
    });
    let offset = 0;
    keys.forEach((key, at) => {
      const value = `${Math.round(offset)}px`;
      if (table.style.getPropertyValue(`--sf-table-pin-${key}`) !== value) table.style.setProperty(`--sf-table-pin-${key}`, value);
      offset += widths[at];
    });
    const last = keys[keys.length - 1]; // Marked where it changes only: a mark taken off and put back on every
    // measure touched each pinned cell of every row (stand 25: a
    // revalidated list redrew rows nothing had changed in).

    const edge = new Set(last ? table.querySelectorAll(`[data-key="${last}"]`) : []);

    for (const cell of table.querySelectorAll("[data-sf-pin-edge]")) {
      if (!edge.has(cell)) cell.removeAttribute("data-sf-pin-edge");
    }

    for (const cell of edge) {
      if (!cell.hasAttribute("data-sf-pin-edge")) cell.setAttribute("data-sf-pin-edge", "");
    } // The shadow only means something once something is hidden behind the
    // pinned block, so it follows the scroll position. In a right-to-left
    // table the browser reports that position as a negative number.


    if (scroll) {
      const scrolled = Math.abs(scroll.scrollLeft) > 0;
      if (scrolled) scroll.setAttribute("data-sf-pin-scrolled", "");else scroll.removeAttribute("data-sf-pin-scrolled");
    }

    return this;
  }

  bindPinnedColumnScroll() {
    const scroll = this.refs.scroll?.value;
    if (!scroll || this._pinnedScrollBound === scroll) return this;
    this._pinnedScrollBound = scroll;
    scroll.addEventListener("scroll", () => this.measurePinnedColumns(), {
      passive: true
    });
    return this;
  } // A row's select box has no visible label: the row is the label. A reader
  // moving through the column hears each box by the row's first data cell,
  // instead of a run of unnamed checkboxes it cannot tell apart.


  getRowSelectLabel(row) {
    const text = this.getRowNameText(row);
    return text ? `${this.text("selectRowLabel")}: ${text}` : this.text("selectRowLabel");
  } // The row's «≡» says whose actions it holds (owner decision C146 (5),
  // variant В): «Действия: <name>», as the SIMAI Framework table recipe
  // names it (utility.table 1.5.0).


  getRowMenuLabel(row) {
    const text = this.getRowNameText(row);
    return text ? `${this.text("actionsColumnLabel")}: ${text}` : this.text("menuLabel");
  } // The text a row is named by: its first data column's value, else its id.


  getRowNameText(row) {
    const batch = this._labelColumnBatch;
    const column = batch && "column" in batch ? batch.column : this.getColumnItems().find(item => item?.key && !item.system && item.key !== "select" && item.key !== "settings");
    if (batch) batch.column = column;
    const raw = column ? row?.[column.key] : undefined;
    const value = raw !== null && typeof raw === "object" ? raw.text ?? raw.label ?? raw.value ?? "" : raw;
    return String(value ?? "").trim() || String(row?.id ?? "").trim();
  }

  createRowComponentCell(component, props = {}) {
    if (!component?.type) {
      return null;
    }

    return {
      component: {
        type: component.type,
        props: { ...(component.props || {}),
          ...props
        }
      }
    };
  } // The row's menu is the Framework's standard menu (owner, 2026-10-12): it
  // opens below its button and start-aligned, in the top layer, and a group
  // of the host's row_actions is a real submenu rather than a second menu
  // swapped in over the first. What a choice does is unchanged -- an intent
  // for the row, or the action's own handler where it has one.
  //
  // One menu, bound to the table's rows by sf-menu-context's `for` (C164,
  // SIMAI Framework sf-menu-context 1.21.0): the right button, the menu key,
  // Shift+F10 and a long press on a row open it through the menu itself, and
  // a row's «≡» (or a list row's «⋯») opens it at the button. Every way in
  // asks the same `open` question, answered by fillRowMenu: one list (C164
  // (2)), every action of the row (C259 (3)).
  //
  // A group's own button (an «Опубликовать» drawn in the row) opens the same
  // menu with that group's members alone (CM-8): it was a second menu of the
  // table's own, drawn by hand with a tail beside the button.


  async openRowMenu(event, row = {}, {
    group = null,
    items = null
  } = {}) {
    const anchor = event?.currentTarget?.querySelector?.("button") ?? event?.target?.closest?.("button") ?? event?.currentTarget;
    if (!(anchor instanceof Element)) return null;
    this._rowMenuGroup = Array.isArray(items) && items.length ? {
      row,
      items,
      anchor
    } : Array.isArray(group?.members) ? {
      row,
      group,
      anchor
    } : null; // The standard menu is a lazy relation of the table: fetched after the
    // page is ready, and asked for here if a press comes first.

    await globalThis.SF?.Loader?.ensure?.(["sf-menu-context"]);
    const menu = this.rowMenu();
    await customElements.whenDefined?.("sf-menu-context"); // The row is named: a table inside a shadow root (sf-view's own
    // table) is not found by `for`, which reads the document's ids.

    const target = anchor.closest("[data-row-id]") ?? undefined;

    try {
      return menu.toggleFor(anchor, target ? {
        target
      } : {});
    } finally {
      this._rowMenuGroup = null;
    }
  } // Whether the rows carry a menu: the host's row actions, whatever
  // row-actions says -- a view writes row-actions="false" when every action
  // lives in the row menu (no actions column), and the menu stays.


  get hasRowMenus() {
    return (this.ACTIONS_SETTINGS_ROW ?? []).length > 0;
  } // The ids of the areas the row menu is bound to: the table and the list.


  get rowAreaId() {
    return this._rowAreaId;
  } // The menu is in the page as soon as the rows have one, so the right
  // button, the menu key and a long press find it before any «≡» is pressed.


  bindRowMenu() {
    if (!this.isConnected || !this.hasRowMenus) return; // A slot's fallback table is not drawn while the slot holds another.

    const slot = this.parentElement;
    if (slot?.tagName === "SLOT" && slot.assignedNodes?.().length) return;
    this.bindShadowRowMenu();
    if (this._rowMenu?.isConnected) return;
    globalThis.SF?.Loader?.ensure?.(["sf-menu-context"]);
    this.rowMenu();
  } // sf-menu-context's `for` reads the document's ids and listens on the
  // document, so a table inside a shadow root (sf-view's own table, when
  // the host slots none) is out of its reach. There the table answers the
  // right button, the menu key and Shift+F10 itself, the way the menu does
  // for its areas (C164 (1)): Shift with the right button, a link, a field
  // and selected text keep the browser's menu.


  bindShadowRowMenu() {
    if (this._shadowRowMenuBound) return;
    this._shadowRowMenuBound = true;

    const inShadow = () => this.getRootNode() !== document;

    const rowAt = event => {
      const element = event.target?.closest?.("tbody > tr[data-row-id], li[data-row-id]");
      return element && this.contains(element) ? element : null;
    };

    const keeps = event => Boolean(event.target?.closest?.("a[href], input:not([type=checkbox]), textarea, select, [contenteditable]")) || Boolean(String(document.getSelection?.() ?? "").trim());

    this.addEventListener("keydown", event => {
      if (!inShadow() || event.defaultPrevented) return;
      if (event.key !== "ContextMenu" && !(event.shiftKey && event.key === "F10")) return;
      const row = rowAt(event);
      if (!row || keeps(event)) return;
      event.preventDefault();
      this._shadowMenuKeyAt = Date.now();
      this.rowMenu().openAtTarget?.(row);
    });
    this.addEventListener("contextmenu", event => {
      if (!inShadow() || event.defaultPrevented) return;
      const row = rowAt(event);
      if (!row) return;

      if (Date.now() - (this._shadowMenuKeyAt ?? 0) < 500) {
        event.preventDefault();
        return;
      }

      if (event.shiftKey && event.button === 2 || keeps(event)) return;
      event.preventDefault();
      const menu = this.rowMenu();
      if (event.button === 2 || event.pointerType === "touch") menu.openAt?.(event.clientX, event.clientY, {
        target: row
      });else menu.openAtTarget?.(row);
    });
  } // The entries of the row the menu opens for (C164): every action the row
  // offers (C259 (3): the quick ones of a list too); over several selected
  // rows (C164 (3)) the actions every one of them offers, under «Выбрано N».


  fillRowMenu(menu, row, ids, anchor) {
    const selection = Array.isArray(row.actions) && row.actions.every(item => typeof item === "string") ? row.actions : null;
    const asked = this._rowMenuGroup && String(this._rowMenuGroup.row?.id) === String(row?.id) ? this._rowMenuGroup : null;
    const only = asked?.group ?? null; // A list a host built for one row action (its `menu` with `items`):
    // the entries of the same standard menu, each choice its own handler.

    if (asked?.items) {
      const entries = asked.items.map((item, at) => {
        const props = item.props || item.component?.props || {};
        return {
          id: `${ROW_MENU_ITEM}${at}`,
          text: props.text ?? item.name ?? "",
          icon: props.iconStart ?? props.icon ?? undefined,
          danger: props.scheme === "error" || item.danger === true,
          disabled: Boolean(props.disabled)
        };
      });
      menu.setAttribute("size", this.menuSize);
      (0,_core_js_density_js__WEBPACK_IMPORTED_MODULE_19__.followDensity)(menu, this);
      menu.setAttribute("aria-label", this.getContextMenuLabel({
        row,
        menu: "row-settings"
      }));
      menu.entries = entries;
      this._rowMenuContext = {
        row,
        items: [],
        listed: asked.items,
        anchor,
        ids: null
      };
      return entries.length;
    }

    const many = !only && Array.isArray(ids) && ids.length > 1;
    let items = this.getActionRowItems(row);

    if (only) {
      const group = items.find(item => item.id === only.id && Array.isArray(item.members));
      const members = (group?.members ?? []).filter(member => !selection || selection.includes(member.id));
      const entries = members.map(member => ({
        id: member.id,
        text: member.name,
        icon: member.icon ?? member.component?.props?.icon ?? undefined,
        danger: member.danger === true
      }));
      entries.sort((a, b) => Number(a.danger === true) - Number(b.danger === true));
      const firstDanger = entries.findIndex(entry => entry.danger === true);
      if (firstDanger > 0) entries.splice(firstDanger, 0, {
        type: "separator"
      });
      menu.setAttribute("size", this.menuSize);
      (0,_core_js_density_js__WEBPACK_IMPORTED_MODULE_19__.followDensity)(menu, this);
      menu.setAttribute("aria-label", `${this.getContextMenuLabel({
        row,
        menu: "row-settings"
      })}: ${only.name ?? only.id}`);
      menu.entries = entries;
      this._rowMenuContext = {
        row,
        items: group ? [group] : [],
        anchor,
        ids: null
      };
      return entries.length;
    }

    if (many) {
      const rows = this.getTableData().rows.filter(one => ids.some(id => String(id) === String(one.id)));
      items = items.filter(action => rows.every(one => this.getActionRowItems(one).some(other => other.id === action.id)));
    }

    const iconOf = action => action?.icon ?? action?.component?.props?.icon ?? undefined;

    const entries = items.map(action => Array.isArray(action.members) ? {
      id: action.id,
      text: action.name,
      icon: iconOf(action),
      submenu: action.members.filter(member => !selection || selection.includes(member.id)).map(member => ({
        id: member.id,
        text: member.name,
        icon: iconOf(member),
        danger: member.danger === true
      }))
    } : {
      id: action.id,
      text: action.name,
      icon: iconOf(action),
      danger: action.danger === true
    }); // A destructive entry closes the menu (C164 (5)): whatever order a host
    // catalogue gives, «Удалить» is the last entry, the rest keep theirs.

    entries.sort((a, b) => Number(a.danger === true) - Number(b.danger === true)); // …after a divider, when anything stands above it (C164).

    const firstDanger = entries.findIndex(entry => entry.danger === true);
    if (firstDanger > 0) entries.splice(firstDanger, 0, {
      type: "separator"
    });
    if (many) entries.unshift({
      type: "heading",
      text: `${this.text("selectedRowsHeading")} ${ids.length}`
    }); // On every opening, as the table stands now: the row menu lives on
    // <body> or in the open dialog, outside the table, so it has neither
    // the table's size nor the density of the table's area unless it is
    // given them (owner remark 2026-11-15).

    menu.setAttribute("size", this.menuSize);
    (0,_core_js_density_js__WEBPACK_IMPORTED_MODULE_19__.followDensity)(menu, this);
    menu.setAttribute("aria-label", this.getContextMenuLabel({
      row,
      menu: "row-settings"
    }));
    menu.entries = entries;
    this._rowMenuContext = {
      row,
      items,
      anchor,
      ids: many ? ids.map(String) : null
    };
    return entries.length;
  }

  rowMenu() {
    if (this._rowMenu?.isConnected) return this._rowMenu;
    const menu = document.createElement("sf-menu-context");
    menu.setAttribute("popup", "");
    menu.dataset.sfTableMenu = "row"; // The table's rows and the list's rows are this menu's objects.

    menu.setAttribute("for", `${this.rowAreaId} ${this.rowAreaId}-list`); // The question every way in asks (C164 (2)): which row, and what it
    // offers. A press outside a record's row (the head, a «load more»
    // row) and a row without actions open nothing.

    menu.addEventListener("sf-menu-context-open", event => {
      // An opening asked for one row's group or listed entries (CM-8):
      // the row is the one named, wherever the opener stands.
      const asked = this._rowMenuGroup;

      if (asked) {
        if (!this.fillRowMenu(menu, asked.row, null, asked.anchor)) event.preventDefault();
        return;
      }

      const target = event.detail?.target;
      const element = target instanceof Element ? target.closest("[data-row-id]") : null;
      const row = element && this.contains(element) ? this.rowOfElement(element) : null;

      if (!row || !this.getActionRowItems(row).length) {
        event.preventDefault();
        return;
      } // The selection rule (C164 (3)): a selected row speaks for the
      // selection, a row outside it becomes the selection first.


      const {
        ids
      } = this.rowMenuTargets(row);
      const anchor = element.querySelector(LIST_ROW_MENU_BUTTON) ?? element;
      if (!this.fillRowMenu(menu, row, ids, anchor)) event.preventDefault();
    });
    menu.addEventListener("sf-menu-context-select", event => {
      const context = this._rowMenuContext;
      if (!context) return;
      const id = event.detail?.id;
      const {
        row,
        items,
        anchor,
        ids,
        listed
      } = context;

      if (listed && String(id ?? "").startsWith(ROW_MENU_ITEM)) {
        const item = listed[Number(String(id).slice(ROW_MENU_ITEM.length))];
        const props = item?.props || item?.component?.props || {};
        const handler = props["@click"] ?? props.onClick;
        if (typeof handler === "function") handler({
          currentTarget: anchor,
          target: anchor,

          preventDefault() {},

          stopPropagation() {}

        });
        return;
      } // A menu over several selected rows acts on all of them.


      if (ids && id) {
        this.requestActionIntent(id, ids);
        return;
      }

      const action = items.find(item => item.id === id);
      const member = action ? null : items.flatMap(item => item.members ?? []).find(item => item.id === id);

      if (member) {
        this.requestActionIntent(member.id, [row.id]);
        return;
      }

      const handler = action?.component?.props?.["@click"] ?? action?.component?.props?.onClick;
      if (typeof handler === "function") handler({
        currentTarget: anchor,
        target: anchor,

        preventDefault() {},

        stopPropagation() {}

      });else if (action) this.requestActionIntent(action.id, [row.id]);
    });
    (this.closest("dialog[open]") || document.body).append(menu);
    this._rowMenu = menu;
    return menu;
  } // Which of the table's actions this row offers, and in what shape.
  //
  // `row.actions` is read twice over a row's life and means two things. From
  // a host it is ids -- `["view"]`, the data view port's word for which
  // actions apply to this record -- and that is what selects from the table's
  // own list. Once the cell is built it holds the built items, and the
  // template calls this again with them, so the filter was asking whether an
  // array of objects includes a string. It never does: every action was
  // filtered out and the «Действия» column drew an empty container in every
  // row of every list, page lists included. A consumer reported it on an
  // embedded one, which is only where they happened to be looking (owner,
  // 2026-10-09).
  //
  // Ids select. Anything else is already the selection and is not filtered
  // again.
  // The same items for the same row, so a render finds the elements it made
  // last time rather than new ones.
  //
  // A re-query brings new row objects for the same records, so a cache held
  // on the row produced new items every time and lit rebuilt every actions
  // cell -- which is exactly what tests/browser/table-round-3 exists to
  // refuse: it used to tear every cell out and build it again, and the
  // control a person was using went with them. The key is what the cell
  // actually depends on: the row, the ids it offers, and the list those ids
  // select from (owner, 2026-10-09).


  rowActionItems(row = {}) {
    const ids = Array.isArray(row?.actions) && row.actions.every(item => typeof item === "string") ? row.actions.join(",") : "*";
    const list = this.ACTIONS_SETTINGS_ROW ?? [];
    const listKey = list.map(action => action?.id ?? "").join(",");

    if (this._rowActionListKey !== listKey) {
      this._rowActionListKey = listKey;
      this._rowActionItems = new Map();
    }

    const key = `${row?.id ?? ""}|${ids}`;
    if (!this._rowActionItems) this._rowActionItems = new Map();

    if (!this._rowActionItems.has(key)) {
      this._rowActionItems.set(key, this.getActionRowItems(row));
    }

    return this._rowActionItems.get(key);
  }

  getActionRowItems(row = {}, actions = this.ACTIONS_SETTINGS_ROW) {
    const selection = Array.isArray(row.actions) && row.actions.every(item => typeof item === "string") ? row.actions : null; // A group (the host's row_actions, port 1.8.0) is offered when the
    // record allows any of its members, and opens a submenu of exactly
    // those: «Опубликовать › ru» on a row drafted in ru, not in en.

    const allowedMembers = action => (action.members || []).filter(member => !selection || selection.includes(member.id));

    return actions.filter(action => Array.isArray(action.members) ? allowedMembers(action).length > 0 : !selection || selection.includes(action.id)).map(action => {
      if (Array.isArray(action.members)) {
        const members = allowedMembers(action);
        const props = { ...(action.component?.props || {})
        };

        props["@click"] = event => this.openRowMenu(event, row, {
          group: { ...action,
            members
          }
        });

        return { ...action,
          component: { ...(action.component || {}),
            props
          }
        };
      }

      const component = action.component || {};
      const props = { ...(action.props || {}),
        ...(component.props || {})
      };
      const menu = action.menu || props.menu;
      const hasClickHandler = typeof props["@click"] === "function" || typeof props.onClick === "function";

      if (menu === "row-settings" && !hasClickHandler) {
        // The row's own menu is the one standard menu (CM-8, C164 (2)).
        props["@click"] = event => this.openRowMenu(event, row);
      } else if (menu && !hasClickHandler) {
        props["@click"] = event => {
          const menuOptions = menu && typeof menu === "object" ? menu : {
            menu
          };
          this.openContextMenu(event, {
            type: "left",
            row,
            action,
            ...menuOptions
          });
        };
      } else if (!hasClickHandler) {
        props["@click"] = () => this.requestActionIntent(action.id, [row.id]);
      }

      return { ...action,
        component: { ...component,
          props
        }
      };
    });
  }

  getDefaultRowCell(column, row) {
    if (!column?.key) {
      return null;
    }

    if (column.key === "select") {
      return this.createRowComponentCell(column.rowComponent, {
        checked: this.state.settingsChecked ? true : Boolean(row?.selected || row?.checked),
        value: row?.id ?? row?.value ?? "",
        ariaLabel: this.getRowSelectLabel(row),
        "@change": event => {
          this.applyRowSelection(row.id, Boolean(event.target.checked), {
            range: this._selectRangeModifier === true
          });
        }
      });
    }

    if (column.key === "settings") {
      return this.createRowComponentCell(column.rowComponent || {
        type: "button-icon",
        props: {
          size: "1",
          appearance: "ghost",
          scheme: "on-surface",
          icon: "menu",
          ariaLabel: this.getRowMenuLabel(row),
          value: "menu",
          "@click": e => this.openRowMenu(e, row)
        }
      });
    }

    if (column.key === 'actions') {
      return this.getActionRowItems(row);
    }

    return null;
  }

  normalizeRow(row = {}, systemColumns = this.getSystemColumns()) {
    if (!row || typeof row !== "object" || Array.isArray(row)) {
      return row;
    } // A row that already carries its system cells is kept as it is: a
    // change of one row copies that row alone, not the ten thousand others
    // (standard 1.3.8 §18.4, gate 17 «one entry changed»).


    if (systemColumns.every(column => !column?.key || column.visible === false || typeof row[column.key] !== "undefined")) {
      return row;
    }

    const nextRow = { ...row
    };
    systemColumns.forEach(column => {
      if (!column?.key || typeof nextRow[column.key] !== "undefined" || column.visible === false) {
        return;
      }

      const cell = this.getDefaultRowCell(column, nextRow);

      if (cell) {
        nextRow[column.key] = cell;
      }
    });
    return nextRow;
  } // The system columns and the column a box is named by are read once for
  // the whole list, not once per row: ten thousand rows asked for them ten
  // thousand times (simai/ui-pro#2).


  normalizeRows(rows = []) {
    if (!Array.isArray(rows)) return [];
    const systemColumns = this.getSystemColumns();
    this._labelColumnBatch = {};

    try {
      return this.drawingWith(() => rows.map(row => this.normalizeRow(row, systemColumns)));
    } finally {
      this._labelColumnBatch = null;
    }
  }

  setTableData(patch = {}, reason = "data") {
    const currentData = this.getTableData();
    const nextPatch = typeof patch === "function" ? patch(currentData) : patch;

    if (!nextPatch || typeof nextPatch !== "object") {
      return this;
    }

    const result = this.set({
      data: { ...currentData,
        ...nextPatch
      }
    }, reason);
    this.syncSelectionPort(); // New rows are new selection: a tree that redrew its rows after a bulk
    // write left the page box half-ticked over rows none of which were.

    if (Object.prototype.hasOwnProperty.call(nextPatch, "rows")) this.syncSelectAllState();
    return result;
  }

  setColumns(columns = [], reason = "columns") {
    const currentColumns = this.getTableData().columns || [];
    const nextColumns = typeof columns === "function" ? columns(currentColumns) : columns;
    const result = this.setTableData({
      columns: Array.isArray(nextColumns) ? nextColumns : []
    }, reason);
    if (this.rememberedWidthsKey) this.restoreRememberedWidths();
    return result;
  }

  addColumns(columns = []) {
    const nextColumns = Array.isArray(columns) ? columns : [columns];
    return this.setColumns(currentColumns => [...currentColumns, ...nextColumns.filter(Boolean)]);
  }

  updateColumn(columnKey, patch = {}, reason = "columns") {
    if (!columnKey) {
      return this;
    }

    return this.setColumns(columns => columns.map((column, index) => {
      if (!column || column.key !== columnKey) {
        return column;
      }

      const nextPatch = typeof patch === "function" ? patch(column, index) : patch;
      return { ...column,
        ...(nextPatch || {})
      };
    }), reason);
  } // Which drawing of the rows is on screen: a new result set whose kept rows
  // would move is drawn as new rows (setRows "result"), so the template keys
  // rows by this and their id.


  rowsGeneration() {
    return this._rowsGeneration ?? 0;
  }

  setRows(rows = [], reason = "rows") {
    const currentRows = this.getTableData().rows || [];
    const nextRows = typeof rows === "function" ? rows(currentRows) : rows; // A new result set (a search, a filter, another page: reason
    // "result") is drawn as new rows when a row it keeps would stand
    // elsewhere. Keyed by id alone, the kept rows were moved to their new
    // places, and the browser counted every one as a layout shift (stand
    // 25 D12: CLS 0.17 per search); new rows are drawn, not shifted. The
    // swap is one render, so the old rows go and the new come in one frame.

    if (reason === "result" && Array.isArray(nextRows) && rowsWouldMove(currentRows, nextRows)) {
      this._rowsGeneration = (this._rowsGeneration ?? 0) + 1;
    }

    return this.setTableData({
      rows: this.normalizeRows(nextRows)
    }, reason);
  }

  addRows(rows = [], reason = "rows") {
    if (this.isActionParameters?.(rows, ["rows"])) rows = rows.rows ?? [];
    const nextRows = Array.isArray(rows) ? rows : [rows];
    this.setRows(currentRows => [...currentRows, ...nextRows.filter(Boolean)], reason);
    return {
      outcome: "applied"
    };
  }

  updateRowsByKey(key, value, patch = {}, reason = "rows") {
    if (!key) {
      return this;
    }

    const patchRow = typeof patch === "function" ? patch : row => ({ ...row,
      ...(patch || {})
    });
    return this.setRows(rows => rows.map((row, index) => {
      if (!row || row[key] !== value) {
        return row;
      }

      const nextRow = patchRow(row, index);
      return nextRow && typeof nextRow === "object" ? nextRow : row;
    }), reason);
  } // One entry changed: that row is drawn again in place, and the widths
  // measured from the content are kept (standard 1.3.8 §18.4, gate 17 «one
  // entry changed ≤ 50 ms whatever the count»).


  updateRowByKey(key, value, patch = {}, reason = "row") {
    this._entryOnly = true;
    return this.updateRowsByKey(key, value, patch, reason);
  }

  updateRows(patch = {}, reason = "rows") {
    const patchRow = typeof patch === "function" ? patch : row => ({ ...row,
      ...(patch || {})
    });
    return this.setRows(rows => rows.map((row, index) => {
      const nextRow = patchRow(row, index);
      return nextRow && typeof nextRow === "object" ? nextRow : row;
    }), reason);
  }

  updateRowCell(rowKey, rowValue, cellKey, patch = {}, reason = "cell") {
    if (!cellKey) {
      return this;
    }

    return this.updateRowsByKey(rowKey, rowValue, row => {
      const currentCell = row && row[cellKey] && typeof row[cellKey] === "object" ? row[cellKey] : {};
      const nextCellPatch = typeof patch === "function" ? patch(currentCell, row) : patch;
      return { ...row,
        [cellKey]: { ...currentCell,
          ...(nextCellPatch || {})
        }
      };
    }, reason);
  }

  updateRowCellProps(rowKey, rowValue, cellKey, props = {}, reason = "cell-props") {
    return this.updateRowCell(rowKey, rowValue, cellKey, cell => ({
      component: { ...(cell.component || {}),
        props: { ...(cell.component?.props || {}),
          ...(typeof props === "function" ? props(cell.component?.props || {}, cell) : props || {})
        }
      }
    }), reason);
  }

  closeContextMenu(restoreFocus = true) {
    const trigger = this.contextTarget;
    this.set({
      contextMenu: {
        open: false
      }
    });
    this.stopContextMenuPositions();
    (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this.getPortalContainer());
    this.hidePortal(); // The column window's host empties with the window (VT-12).

    if (this._settingsHost?.isConnected) (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this._settingsHost);

    if (this.refs.contextMenu) {
      this.refs.contextMenu.value = null;
    }

    this.unbindContextEvent();
    this.unbindContextViewport();
    this.contextTarget?.classList.remove("active");
    this.contextTarget = null;

    if (restoreFocus && trigger?.isConnected && typeof trigger.focus === 'function') {
      requestAnimationFrame(() => trigger.focus());
    }
  }

  get templateName() {
    return this.getAttribute("template") || "default";
  } // The vocabulary's data state is `ready`; `populated` is read as its
  // alias (standard 1.3.8 gate 26), and the template keeps drawing it.


  get dataState() {
    const state = this.getEnumAttr('data-state', ['loading', 'ready', 'populated', 'empty', 'error'], 'auto');
    return state === 'ready' ? 'populated' : state;
  }

  setDataState(state = 'auto') {
    const named = state === 'ready' ? 'populated' : state;
    const normalized = ['loading', 'populated', 'empty', 'error'].includes(named) ? named : 'auto';

    if (normalized === 'auto') {
      this.removeAttribute('data-state');
    } else {
      this.setAttribute('data-state', normalized);
    }

    return this;
  }

  requestRetry() {
    this.emitTableEvent('refresh', {});
    return {
      outcome: "applied"
    };
  } // Why there are no rows, as a data view knows it: {kind: 'no-access' |
  // 'nothing-found' | 'no-data', reset: 'search' | 'filters' | 'both',
  // headingLevel, message}. `message` is the host's own sentence for a list
  // it refused or could not give; it is the brick's title, drawn as text. A table on its own knows only no data and could not load.


  get emptyContext() {
    return this._emptyContext;
  }

  set emptyContext(value) {
    this._emptyContext = value && typeof value === "object" ? { ...value
    } : null;
    this.requestComponentUpdate("empty-context");
  } // What «Сбросить поиск и фильтры» does: the table's own search and filter
  // are emptied, and each says so the way a person's edit would.


  resetQuery(scope = "both") {
    if (scope !== "search") this.removeFilterTag();

    if (scope !== "filters") {
      this.clearSearchDebounce();
      this._searchPendingProps = null; // A search the table did not hold (the view's own, or a host's) is
      // still cleared: the event goes either way.

      if (this.state.search?.value) this.updateSearchState({
        value: ""
      });else this.emitTableEvent("search-change", {
        search: ""
      });
    }

    return this;
  } // The brick for a table without rows: its reason, its words and its one
  // action. The host's empty-text and error-text are the titles they always
  // were, and empty-description the line under an empty list's title; the
  // rest are the brick's own words in the page language.


  emptyBrick(dataState) {
    const context = this._emptyContext ?? {};
    const size = this.size === "1/2" ? "1/2" : "1";
    const headingLevel = String(context.headingLevel ?? 3);
    const message = typeof context.message === "string" ? context.message.trim() : "";

    if (dataState === "error") {
      return {
        kind: "error",
        size,
        headingLevel,
        title: message || this.getAttribute("error-text") || "",
        text: "",
        live: context.caused ? "alert" : "auto",
        actions: [{
          id: "retry",
          text: this.text("retryText", "retry-text"),
          appearance: "outline"
        }]
      };
    }

    const kind = ["no-access", "nothing-found"].includes(context.kind) ? context.kind : "no-data";
    if (kind === "no-access") return {
      kind,
      size,
      headingLevel,
      title: message,
      text: "",
      actions: []
    };

    if (kind === "nothing-found") {
      const key = {
        search: "resetSearchText",
        filters: "resetFiltersText"
      }[context.reset] ?? "resetBothText"; // A list empty only because of its filters says so by its glyph
      // (owner decision C120 (3)): filter_alt_off; a search, or a search
      // and filters together, keep the brick's own search_off.

      return {
        kind,
        size,
        headingLevel,
        title: "",
        text: "",
        icon: context.reset === "filters" ? "filter_alt_off" : "",
        actions: [{
          id: "reset-query",
          text: this.text(key),
          appearance: "outline"
        }]
      };
    }

    const creatable = this.getBooleanAttr("actions", true) && this.getBooleanAttr("creatable", true);
    return {
      kind,
      size,
      headingLevel,
      title: this.getAttribute("empty-text") || "",
      text: this.getAttribute("empty-description") || "",
      actions: creatable ? [{
        id: "create",
        text: this.text("createText", "create-text")
      }] : []
    };
  }

  disconnectedCallback() {
    this.closeCellPopover();
    this.unbindWindowScroll();

    for (const controller of this._toolbarRoving?.values() ?? []) controller.destroy();

    this._toolbarRoving?.clear(); // The row menu lives beside the page, not inside the table: it goes
    // with the table that made it.

    this._rowMenu?.close?.({
      restoreFocus: false
    });
    this._rowMenu?.remove();
    this._rowMenu = null;

    for (const page of this._filterOptionPages.values()) {
      page.controller?.abort();
      clearTimeout(page.searchTimer);
    }

    this._filterOptionPages.clear();

    clearTimeout(this._viewWaitTimer);
    this._viewWaitAbort?.abort();
    this._viewWaitAbort = null;
    this._viewWait = null;
    this._responsiveObserver?.disconnect();
    this._responsiveObserver = null;
    this._responsiveWidth = 0;
    this._responsiveTarget = null;
    this._preferenceUnsubscribe?.();
    this._preferenceUnsubscribe = null;
    this._preferenceKeyBound = undefined;
    this._rowActionsAbort?.abort();
    this._rowActionsAbort = null;
    this._rowActionsTable = null;
    this.unbindPageScroll();
    this._lateLayoutAbort?.abort();
    this._lateLayoutAbort = null;
    cancelAnimationFrame(this._lateLayoutFrame ?? 0);
    this._lateLayoutFrame = 0;
    this.clearSearchDebounce();
    this._searchPendingProps = null;
    this._searchHoldKey = '';
    this.stopContextMenuPositions();
    this.unbindContextEvent();
    this.unbindContextViewport();
    this.unBindHoverEvent();
    this.unbindColumnResizeEvent();
    this.unbindColumnDragEvent();
    this.tempSettings = null;
    this._selectionPortKey = "[]"; // A removed table abandons its pending answer; a remount asks again.

    this._abandonedQuery = this._pendingQuerySequence !== null;
    this._pendingQuerySequence = null;
    this.state.contextMenu = {
      open: false
    };
    this.state.settingsChecked = false;
    this.state.selectIndeterminate = false;
    const data = this.getTableData();
    this.state.data = { ...data,
      rows: data.rows.map(row => ({ ...row,
        selected: false,
        checked: false,
        ...(row.select?.component ? {
          select: { ...row.select,
            component: { ...row.select.component,
              props: { ...row.select.component.props,
                checked: false
              }
            }
          }
        } : {})
      }))
    };

    if (this.refs.contextMenu) {
      this.refs.contextMenu.value = null;
    }

    this.contextTarget?.classList?.remove('active');
    this.contextTarget = null;

    if (this._portalContainer) {
      (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this._portalContainer);

      this._portalContainer.remove();

      this._portalContainer = null;
    }

    if (this._settingsHost) {
      (0,lit__WEBPACK_IMPORTED_MODULE_11__.render)(null, this._settingsHost);

      this._settingsHost.remove();

      this._settingsHost = null;
      this._settingsShown = null;
    }

    super.disconnectedCallback();
  }
  /**
   * One of this table's words, in the page's language. An attribute wins over
   * both languages, because a consumer who names a word has named it.
   *
   * The declared default is the English one, so a component read through its
   * props alone still says something sensible; the context below overrides
   * every text key with this, which is what makes the Russian reachable. A
   * key left out of that override would quietly fall back to English on a
   * Russian page -- which is exactly how three labels in the record panel's
   * head came to read «Close» beside «В избранное».
   */


  text(key, attribute) {
    return attribute && this.getAttribute(attribute) || (0,_core_js_page_language__WEBPACK_IMPORTED_MODULE_13__.pageText)(TABLE_TEXT, key, this);
  }

  templateContext() {
    this._readResponsiveWidthNow();

    this._renderedCramped = this.columnsAreCramped;
    const props = this.getPropsContext();
    return this.createTemplateContext({ ...props,
      component: this,
      list: this._renderedList = this.isList,
      // The list's toolbar is the compact one, unless the person chose
      // the list on a container wide enough for the table's toolbar and
      // its layout switch (C31).
      compactToolbar: this._renderedList && !(this.hasLayoutSwitch && !this.isNarrow),
      layoutSwitch: this.hasLayoutSwitch && !this.isNarrow,
      shownLayout: this._renderedList ? "list" : "table",
      quickActionIds: this.quickActionIds,
      // The row menu's areas (C164) and the phone's keyed table (C259).
      rowAreaId: this.rowAreaId,
      keyedNarrow: this.isKeyedNarrow,
      // The size the controls inside are written with: the host's own,
      // or none, so a host without a size keeps its controls relative
      // and page density moves them (C22).
      controlSize: this.controlSize,
      rootClass: this.getRootClass(),
      rootStyle: this.getRootStyle(),
      filterText: this.text("filterText", "filter-text"),
      clearText: this.text("clearText", "clear-text"),
      searchPlaceholder: this.text("searchPlaceholder", "search-placeholder"),
      createText: this.text("createText", "create-text"),
      pinColumnLabel: this.text("pinColumnLabel", "pin-column-label"),
      unpinColumnLabel: this.text("unpinColumnLabel", "unpin-column-label"),
      loadingText: this.text("loadingText", "loading-text"),
      emptyText: this.text("emptyText", "empty-text"),
      errorText: this.text("errorText", "error-text"),
      retryText: this.text("retryText", "retry-text"),
      columnMoveLabel: this.text("columnMoveLabel", "column-move-label"),
      filterApplyText: this.text("filterApplyText", "filter-apply-text"),
      columnSearchPlaceholder: this.text("columnSearchPlaceholder", "column-search-placeholder"),
      columnSearchEmptyText: this.text("columnSearchEmptyText", "column-search-empty-text")
    });
  }

  setCheckboxHeight() {
    if (!this.refs.items.size) return;
    const measureToken = ++this._checkboxMeasureToken;
    requestAnimationFrame(() => {
      if (!this.isConnected || measureToken !== this._checkboxMeasureToken) {
        return;
      }

      const parentSpace = (0,_helpers_dom__WEBPACK_IMPORTED_MODULE_14__.setParentSpace)(this.refs.items);

      if (!parentSpace) {
        return;
      }

      const {
        item,
        gap,
        parent
      } = parentSpace;
      this.parentGap = gap;
      const itemHeight = item.tagName.toLowerCase().startsWith('sf-') ? item.children[0]?.clientHeight : item.clientHeight;

      if (!itemHeight) {
        return;
      }

      const itemSize = parent.dataset.size || 8;
      const parentHeight = (itemHeight + gap) * itemSize;

      if (parent.clientHeight <= parentHeight) {
        return false;
      }

      parent.setAttribute('style', `height: ${parentHeight}px; overflow: auto;`);
    });
  }

  beforeRender() {
    super.beforeRender();
    this.connectTablePreference();
    this.applyTableView();
    this._checkboxMeasureToken++;
    this.refs.items = new Map();
  } // The width the first render is chosen by (saved-views r2, D1): the
  // observer below reports a width only after the first paint, so a table
  // whose answer was in by the time its code was defined drew its first
  // frame as if it were wide -- at 390 the desktop toolbar, the search
  // field across the row and Create and Filter on the rows below, 80-124 px
  // tall, then the compact 36 px bar one or two frames later. The compact
  // toolbar and the list are other markup, not a restyle, and list-below is
  // the table's own attribute, which a container query cannot read; so
  // until the observer has spoken, the width is read here, before the
  // render and so before any paint: the content box of the nearest
  // ancestor that has a box (the table's own tag and sf-view are
  // display: contents), as the observer measures it.


  _readResponsiveWidthNow() {
    if (this._responsiveWidth > 0 || !this.isConnected) return;

    for (let element = this.querySelector(".sf-table") ?? this.parentElement; element; element = element.parentElement) {
      const box = element.getBoundingClientRect?.();
      if (!box || box.width <= 0) continue;
      const style = globalThis.getComputedStyle?.(element);

      const edge = side => (parseFloat(style?.[`padding${side}`]) || 0) + (parseFloat(style?.[`border${side}Width`]) || 0);

      const width = Math.floor(box.width - edge("Left") - edge("Right"));
      if (width > 0) this._responsiveWidth = width;
      return;
    }
  } // SfBaseElement is display: contents, so its own box has no width: the
  // nearest visible container is observed instead of the custom tag. The
  // box is chosen again once the one observed has left the document: a
  // table printed by a server (its static markup) is replaced by the drawn
  // one, and the width of a box no longer in the page never changes -- a
  // list on a phone stayed a table, its width read as nothing (stand 24).


  _observeResponsiveBox() {
    if (!this._responsiveObserver || this._responsiveTarget?.isConnected) return;
    const candidates = [this.querySelector('.sf-table'), this.parentElement, this.getRootNode()?.host];
    const target = candidates.find(element => element?.getBoundingClientRect?.().width > 0) ?? candidates.find(Boolean) ?? this;
    if (this._responsiveTarget) this._responsiveObserver.unobserve(this._responsiveTarget);
    this._responsiveTarget = target;

    this._responsiveObserver.observe(target);
  } // C296 / C295 (VT-13): the table draws columns and rows. Its toolbar,
  // search, filter, saved templates, create button, layout switch, own
  // paging and own group buttons are the container's (sf-view,
  // sf-pagination, sf-bulk-actions). They keep working, as they were,
  // until 2027-01-01; a table standing alone that is given one is noted in
  // SF.deprecations once. Inside sf-view the view writes them: no note.


  noteContainerSettings() {
    if (this._containerNoted || this.closest?.("sf-view")) return;
    this._containerNoted = true;

    for (const name of CONTAINER_SETTINGS) {
      // toolbar="false" and the like already say what the table becomes.
      if (!this.hasAttribute(name) || this.getAttribute(name) === "false") continue;
      (0,_core_js_deprecations_js__WEBPACK_IMPORTED_MODULE_21__.noteDeprecated)({
        component: "sf-view-table",
        tag: "sf-view-table",
        kind: "attribute",
        attribute: name,
        from: name,
        to: CONTAINER_SETTING_HOME[name] ?? "sf-view",
        since: "2026-11-18",
        remove_after: "2027-01-01",
        package: "view"
      });
    }
  } // A row scrollToRow asked for outside the drawn range is drawn now, and
  // brought into view inside the table's scroll (C296).


  revealPendingRow() {
    const id = this._pendingScrollRow;
    this._pendingScrollRow = null;
    this.refs.table?.value?.querySelector(`tbody tr[data-row-id="${id.replace(/"/gu, '\\"')}"]`)?.scrollIntoView?.({
      block: "nearest",
      behavior: "instant"
    });
  }

  afterRender() {
    this.drawingWith(() => this.afterDraw());
  } // The selection boxes draw their tick only when a box is checked: an
  // unchecked row's glyph is empty, so the page's first icon font never had
  // «check», and the first box checked waited for a second font before its
  // tick showed (0.6 s on a fast line; the Loader keeps an unknown glyph at
  // font-size 0 until its font is in). A table with boxes asks for the tick
  // and the head's «remove» with its first font, as sf-segmented and sf-input
  // ask for the glyphs they will draw (SF.Loader.preloadIcons). Once per
  // element; a Loader without it answers nothing.


  preloadSelectionGlyphs() {
    if (this._selectionGlyphsAsked || !this.getPropsContext().selectable) return;
    const loader = globalThis.SF?.Loader;
    if (typeof loader?.preloadIcons !== 'function') return;
    this._selectionGlyphsAsked = true;
    loader.preloadIcons(['check', 'remove']);
  } // A box checked since the last drawing names its tick now; the Loader's
  // page observer marks such a glyph a few frames later (115 ms measured),
  // so the drawing hands the new ticks over at once, as the Smart base hands
  // over the glyphs of an ignored region (SF.Loader.adoptStaticIcons). Only
  // the checked boxes' glyphs not yet marked: nothing per row otherwise.


  adoptSelectionGlyphs() {
    const loader = globalThis.SF?.Loader;
    if (typeof loader?.adoptStaticIcons !== 'function') return;

    for (const glyph of this.querySelectorAll('input[data-sf-row-box]:checked + .sf-icon:not(.sf-icon-loaded)')) {
      loader.adoptStaticIcons(glyph);
    }
  }

  afterDraw() {
    this.noteContainerSettings();
    this.preloadSelectionGlyphs();
    this.adoptSelectionGlyphs();

    this._observeResponsiveBox();

    this.bindRowActionsEvents(this.refs.table?.value);
    this.bindToolbarKeyboard();
    this.syncGrid();
    this.bindRowMenu();
    this.syncListStops();
    this.toggleAttribute("data-sf-keyed-narrow", this.isKeyedNarrow);
    if (this._windowed) this.bindWindowScroll();
    if (this._pendingScrollRow) this.revealPendingRow();

    if (this._pendingFocusRow) {
      const id = this._pendingFocusRow;
      this._pendingFocusRow = null;
      this._windowOnly = false;
      this._entryOnly = false;
      this.focusRow(id, {
        reveal: true
      });
      return;
    } // A render that only moved the window, or changed one entry, draws
    // rows of the same columns: their values are folded, no width is
    // measured again.


    if (this._windowOnly || this._entryOnly) {
      this._windowOnly = false;
      this._entryOnly = false;
      this._layoutUnchanged = false;
      this.fitCellValues();
      this.measurePinnedColumns();
      this.syncWindow();
      this.markClippedTitles();
      return;
    } // A render that only moved a row's buttons changed no width.


    if (this._layoutUnchanged) {
      this._layoutUnchanged = false;
      return;
    } // Content widths first: they change the widths everything below reads.
    // Written straight onto the columns: a render for them drew every row
    // and every value in it again (owner, 2026-10-15).
    // Cells whose elements are defined but still drawing (a reference, a
    // colour, a file) are measured once, when they have drawn -- in this
    // task, before the frame is painted. They used to be measured now and
    // again then, and the first reading was thrown away: two layouts of
    // the whole table in auto and fixed form, and the values folded twice
    // (stand 25: 300 ms of the first page's 1.2 s at 4x CPU).


    if (!this.measureWhenCellsDrawn()) {
      if (this.measureContentWidths()) this.applyColumnWidths();
      this._contentRetries = 0;
      this.fitCellValues();
      this.measurePinnedColumns();
    }

    if (this.hasAttribute("data-sf-page-scroll")) {
      this.bindPageScroll();
      this.syncRail();
      this.syncStickyHead();
    } else {
      this.unbindPageScroll();
      const head = this.refs.table?.value?.tHead;
      if (head?.style.transform) head.style.transform = "";
    } // Whether the columns are cramped is read from the laid-out table, so
    // the first render guesses: before layout the actions column and the
    // floors are not yet where they will be. When the answer after the
    // render is not the one the render used, render once more.
    // Twice at most in a row, so a width that sits on the edge cannot keep
    // the table re-rendering.


    if (this.columnsAreCramped !== this._renderedCramped && (this._crampedRetries ?? 0) < 2) {
      this._crampedRetries = (this._crampedRetries ?? 0) + 1;
      this.requestComponentUpdate("cramped-columns");
    } else {
      this._crampedRetries = 0;
    }

    this.bindPinnedColumnScroll();
    this.setCheckboxHeight();
    this.bindHoverEvent();
    this.bindColumnResizeEvent();
    this.bindColumnDragEvent();
    this.syncWindow();
    this.markClippedTitles();
  } // The toolbar's keyboard is SIMAI Framework roving.js (C184 (1)-(3),
  // VF-6): each group of the toolbar's buttons -- the filter with its chips
  // and their buttons at the start, create and the view's actions at the
  // end -- is one Tab stop, the arrows walk it in the row's direction, ↓ on
  // a menu button opens its menu, and Tab comes back to the button left.
  // The search field and the layout switch keep their own keys and stops.


  bindToolbarKeyboard() {
    const groups = [...this.querySelectorAll(":scope .sf-table-toolbar .sf-table-toolbar-start, :scope .sf-table-toolbar .sf-table-toolbar-end, :scope .sf-table-toolbar .sf-table-list-search")].filter(group => group.closest("sf-view-table, sf-table") === this);
    this._toolbarRoving ??= new Map();

    for (const [group, controller] of this._toolbarRoving) {
      if (!groups.includes(group) || !group.isConnected) {
        controller.destroy();

        this._toolbarRoving.delete(group);
      }
    }

    const buttons = group => () => [...group.querySelectorAll("button")].filter(button => !button.closest("sf-input, .sf-input, sf-segmented, .sf-segmented"));

    for (const group of groups) {
      if (this._toolbarRoving.has(group)) continue;

      this._toolbarRoving.set(group, (0,_core_js_roving_js__WEBPACK_IMPORTED_MODULE_22__.roving)(group, {
        items: buttons(group),
        orientation: "horizontal"
      }));
    }
  } // A name cut by its two lines (C146 (7)) says so on its cell, and the
  // Framework tooltip over it shows the whole name; a name that fits has
  // no tooltip.


  markClippedTitles() {
    const table = this.refs.table?.value;
    if (!table) return;
    const tip = this.tipId("title");

    for (const clamp of table.querySelectorAll('tbody td[data-sf-cell="title"] .sf-table-cell-text')) {
      const clipped = clamp.scrollHeight > clamp.clientHeight + 1 || clamp.scrollWidth > clamp.clientWidth + 1;
      if (clipped !== clamp.hasAttribute("data-sf-clipped")) clamp.toggleAttribute("data-sf-clipped", clipped); // A cut name is a trigger of the table's name tooltip; a whole
      // one is none (the Framework's tooltip unlinks it).

      if (clipped && clamp.getAttribute("data-tooltip") !== tip) clamp.setAttribute("data-tooltip", tip);else if (!clipped && clamp.hasAttribute("data-tooltip")) clamp.removeAttribute("data-tooltip");
    }

    if (this._titleTipTable === table) return;
    this._titleTipTable = table; // The name tooltip says the name the pointer or the focus is on,
    // written before the tooltip's delay ends.

    const write = event => {
      const clamp = event.target instanceof Element ? event.target.closest('td[data-sf-cell="title"] .sf-table-cell-text[data-sf-clipped]') : null;
      const text = clamp ? document.getElementById(tip)?.querySelector(".sf-tooltip-text") : null;
      if (text && text.textContent !== clamp.textContent.trim()) text.textContent = clamp.textContent.trim();
    };

    table.addEventListener("pointerover", write);
    table.addEventListener("focusin", write);
  } // ─── the table as a grid (owner decision C146 (8)) ──────────────────────
  // A table whose rows hold controls -- the box, the row menu, the name's
  // link, the row's buttons -- is a grid: one Tab stop, the arrows between its rows
  // and between the controls of a row (WAI-ARIA APG grid). Up and down keep
  // the place in the row; left and right walk the row's controls, the row
  // itself first; Home and End go to the row's first and last, with Ctrl to
  // the first and last row; Enter opens, Space marks the row; Shift+F10 and
  // the menu key open the row's «≡» (C146 (5)). The head is
  // the grid's first row: its sort
  // buttons, the edges that set a width, the box for all and the gear. A
  // plain table, with nothing to press in its rows, stays a table.


  gridControls(row) {
    const own = row.parentElement?.tagName === "TBODY" ? [row] : []; // A column edge is no stop of the grid (C146 (8), RS-10): the person
    // sets a width with the pointer.

    const controls = [...row.querySelectorAll("a[href], button:not([disabled]), input:not([disabled]):not([type=hidden]), select:not([disabled]), textarea:not([disabled])")].filter(element => !element.closest(".sf-tooltip, [hidden]") && !element.matches("[data-sf-column-resizer]")); // The head of a column whose width can be set and that has nothing to
    // press (no sort) is a stop itself: the arrows reach it and Enter
    // opens its width menu (C158 (5)).

    const heads = row.parentElement?.tagName === "THEAD" ? [...row.children].filter(cell => this.headStopOf(cell) === cell) : [];

    if (heads.length) {
      return [...controls, ...heads].sort((a, b) => a.compareDocumentPosition(b) & 4 ? -1 : 1);
    }

    return [...own, ...controls];
  } // ─── a column's width from the keyboard (owner decision C158 (5)) ───────
  // The table stays one Tab stop (C146 (8)): the arrows walk the heads, and
  // Enter on a head whose column has an edge -- Shift+F10, the menu key or
  // the right button too -- opens «Изменить ширину · По содержимому · По
  // умолчанию». «Изменить ширину» takes the focus to the edge, where the
  // arrows set the width (SIMAI Framework SF.Resizer.attach, sf-resizer
  // 1.3.0); Enter or Escape there go back to the head. A double click on the
  // edge is the fit to content. Space on a sort button still sorts.
  // The stop of a head: its sort button, or the head itself; null for a
  // column without an edge (the system columns, the last column, a column
  // marked resizable: false).


  headStopOf(cell) {
    if (!(cell instanceof Element) || cell.tagName !== "TH") return null;
    if (!cell.querySelector("[data-sf-column-resizer]")) return null;
    return cell.querySelector(".sf-table-sort-button") ?? cell;
  } // A plain table (no grid) keeps its sort buttons as its stops; a head with
  // nothing to press is reached by the arrows from them, and is the head
  // row's one stop when the row has no other.


  syncHeadStops(table) {
    const row = table?.tHead?.rows?.[0];
    if (!row) return;
    const heads = [...row.children].filter(cell => this.headStopOf(cell) === cell);

    for (const head of heads) if (head.getAttribute("aria-haspopup") !== "menu") head.setAttribute("aria-haspopup", "menu");

    if (this.isGrid) return;
    const others = this.gridControls(row).filter(element => !heads.includes(element));
    heads.forEach((head, index) => {
      const value = index === 0 && !others.length ? "0" : "-1";
      if (head.getAttribute("tabindex") !== value) head.setAttribute("tabindex", value);
    });
  } // The head's keys go first, so Enter on a sort button opens the width
  // menu rather than sorting; the right button on a head with an edge opens
  // the same menu (the row menu's `for` asks only about rows).


  bindHeadMenu(table, signal) {
    table.addEventListener("keydown", event => this.handleHeadKeydown(event, table), {
      signal
    });
    table.addEventListener("contextmenu", event => {
      const cell = event.target instanceof Element ? event.target.closest("th") : null;
      if (!cell || cell.parentElement?.parentElement !== table.tHead) return;
      const key = cell.dataset.key;
      const column = key ? this.getColumns().find(item => String(item?.key) === key) : null;
      if (!column || column.system) return;
      event.preventDefault();
      event.stopPropagation(); // Shift+F10 and the menu key opened it already.

      if (Date.now() - (this._headMenuKeyAt ?? 0) < 500) return;
      if (event.target.closest("[data-sf-column-resizer]")) return;
      const point = event.button === 2 || !this.headStopOf(cell) ? {
        x: event.clientX,
        y: event.clientY
      } : null;
      this.openColumnMenu(cell, this.headStopOf(cell) ?? cell, point);
    }, {
      signal
    });
  }

  handleHeadKeydown(event, table) {
    if (event.defaultPrevented) return;
    const target = event.target instanceof Element ? event.target : null;
    const cell = target?.closest?.("th");
    if (!cell || cell.parentElement?.parentElement !== table.tHead) return; // On the edge: Enter and Escape go back to the head (the Framework's
    // gesture leaves them to the table).

    if (target.matches("[data-sf-column-resizer]")) {
      if (event.key !== "Enter" && event.key !== "Escape") return;
      const stop = this.headStopOf(cell);
      if (!stop) return;
      event.preventDefault();
      event.stopPropagation();
      this.focusHeadStop(stop);
      return;
    }

    const stop = this.headStopOf(cell);
    const onStop = stop && target === stop;

    if (onStop && (event.key === "Enter" || event.key === "ContextMenu" || event.shiftKey && event.key === "F10")) {
      event.preventDefault();
      event.stopPropagation();
      this._headMenuKeyAt = Date.now();
      this.openColumnMenu(cell, stop);
      return;
    } // A plain table walks its heads with the arrows as a grid does.


    if (this.isGrid || event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
    const stops = this.gridControls(cell.parentElement);
    const at = stops.indexOf(target);
    if (at < 0) return;
    const forward = event.key === "ArrowRight" !== this.isRightToLeft();
    const next = stops[at + (forward ? 1 : -1)];
    if (!next) return;
    event.preventDefault();
    this.focusHeadStop(next);
  }

  focusHeadStop(stop) {
    if (this.isGrid) {
      this._gridStop = stop;
      this.syncGrid();
    }

    stop.focus({
      preventScroll: false
    });
  } // The column's menu (owner decision C296, q-columns B): on the head --
  // the right button, a long press, Shift+F10, the menu key, Enter on a
  // head with an edge -- sort up and down, pin, hide and «Все колонки…»
  // (the column window), then the width (C158 (5)). The window stays for
  // the order and for bringing a hidden column back.


  columnMenuEntries(column, cell) {
    const entries = [];
    const sort = this.state?.sort ?? {};

    if (column.sortable === true && !column.system) {
      entries.push({
        id: "sort-asc",
        text: this.text("columnSortAsc"),
        icon: "arrow_upward",
        checked: sort.key === column.key && sort.direction === "asc"
      });
      entries.push({
        id: "sort-desc",
        text: this.text("columnSortDesc"),
        icon: "arrow_downward",
        checked: sort.key === column.key && sort.direction === "desc"
      });
    } // Under the list head (sf-view head="list") there is no gear: the view
    // settings are «Настроить вид» above the list (C301 (1)). The column's
    // own pin and hide stay on its head all the same (C296, VR2-1), and
    // «Все колонки…» opens «Настроить вид» (data-sf-view-columns="head",
    // written by the view where the host keeps personal column settings).


    const underHead = this.getAttribute("data-sf-view-columns") === "head";
    const settings = this.getPropsContext?.().settings !== false && (this.getAttribute("settings-menu") !== "false" || underHead);

    if (!column.system && settings) {
      const pinned = this.isColumnPinned(column);
      const group = [{
        id: "pin",
        text: this.text(pinned ? "columnUnpin" : "columnPin"),
        icon: "push_pin"
      }]; // The title stays: it is the record's name and its link (C146 (5)).

      const shown = this.getColumnItems().filter(item => item?.key && !item.system && this.isColumnVisible(item));
      if (column.role !== "title" && shown.length > 1) group.push({
        id: "hide",
        text: this.text("columnHide"),
        icon: "visibility_off"
      });
      if (entries.length) entries.push({
        type: "separator"
      });
      entries.push(...group, {
        id: "all",
        text: this.text("columnAll"),
        icon: "view_column"
      });
    }

    if (cell?.querySelector?.("[data-sf-column-resizer]")) {
      if (entries.length) entries.push({
        type: "separator"
      });
      entries.push({
        id: "resize",
        text: this.text("columnWidthChangeText")
      }, {
        id: "fit",
        text: this.text("columnWidthFitText")
      }, {
        id: "default",
        text: this.text("columnWidthDefaultText")
      });
    }

    return entries;
  }

  async openColumnMenu(cell, anchor = cell, point = null) {
    const key = cell?.dataset?.key;
    const column = key ? this.getColumns().find(item => String(item?.key) === key) : null;
    if (!column || column.system) return null;
    const entries = this.columnMenuEntries(column, cell);
    if (!entries.length) return null;
    await globalThis.SF?.Loader?.ensure?.(["sf-menu-context"]);
    await customElements.whenDefined?.("sf-menu-context");
    const menu = this.columnMenu();
    menu.setAttribute("size", this.menuSize);
    (0,_core_js_density_js__WEBPACK_IMPORTED_MODULE_19__.followDensity)(menu, this);
    const label = column.label || column.key;
    menu.setAttribute("aria-label", `${this.text("columnMenuLabel")}: ${label}`);
    menu.entries = entries;
    this._columnMenuContext = {
      key,
      cell,
      anchor,
      column
    };
    if (point) return menu.openAt?.(point.x, point.y);
    return typeof menu.toggleFor === "function" ? menu.toggleFor(anchor, {
      align: "start"
    }) : menu.openFor?.(anchor, {
      align: "start"
    });
  } // A choice of the column menu: the sort goes out as a person's sort
  // (sort-change), the pin and the hide as column settings (save), «Все
  // колонки…» opens the column window against the head.


  applyColumnMenuChoice(id, context) {
    const {
      key,
      column
    } = context;

    if (id === "sort-asc" || id === "sort-desc") {
      const direction = id === "sort-asc" ? "asc" : "desc";
      const sort = this.state?.sort ?? {};
      if (sort.key === key && sort.direction === direction) return true;
      this.setSort(key, direction);
      this.emitTableEvent("sort-change", Object.freeze({
        key,
        direction
      }));
      return true;
    }

    if (id === "pin") {
      this.toggleColumnPinned(column);
      return true;
    }

    if (id === "hide") {
      this.patchColumnSettings(key, {
        visible: false
      }, "column-hide");
      return true;
    }

    if (id === "all") {
      const view = this.getAttribute("data-sf-view-columns") === "head" ? this.closest?.("sf-view") : null;

      if (typeof view?.openCustomize === "function") {
        view.openCustomize();
        return true;
      }

      const gear = this.querySelector('thead th[data-key="settings"] button, thead th[data-key="settings"] [role="button"]');
      const anchor = gear ?? context.cell;
      this._settingsTab = "columns";
      this.openContextMenu({
        currentTarget: anchor,
        target: anchor,
        timeStamp: performance.now(),

        preventDefault() {},

        stopPropagation() {}

      }, {
        menu: "table-settings"
      });
      return true;
    }

    return false;
  }

  columnMenu() {
    if (this._columnMenu?.isConnected) return this._columnMenu;
    const menu = document.createElement("sf-menu-context");
    menu.setAttribute("popup", "");
    menu.dataset.sfTableMenu = "column";
    menu.addEventListener("sf-menu-context-select", event => {
      const context = this._columnMenuContext;
      if (!context) return;
      const id = event.detail?.id ?? event.detail?.entry?.id;
      const stop = this.headStopOf(context.cell) ?? context.anchor;
      menu.close?.();

      if (id !== "all" && this.applyColumnMenuChoice(id, context)) {
        requestAnimationFrame(() => {
          const cell = this.refs.table?.value?.querySelector(`thead th[data-key="${this.escapeColumnKey(context.key)}"]`);
          const again = this.headStopOf(cell) ?? (cell?.isConnected ? null : null);
          if (again?.isConnected) this.focusHeadStop(again);
        });
        return;
      }

      if (id === "all") {
        // After the menu has closed and given the focus back.
        requestAnimationFrame(() => this.applyColumnMenuChoice(id, context));
        return;
      }

      if (id === "resize") {
        const edge = context.cell.querySelector("[data-sf-column-resizer]"); // After the menu has given the focus back to its opener.

        requestAnimationFrame(() => edge?.focus({
          preventScroll: true
        }));
        return;
      }

      if (id === "fit") this.fitColumnToContent(context.key);else if (id === "default") this.resetColumnWidth(context.key);
      requestAnimationFrame(() => {
        const cell = this.refs.table?.value?.querySelector(`thead th[data-key="${this.escapeColumnKey(context.key)}"]`);
        const again = this.headStopOf(cell) ?? stop;
        if (again?.isConnected) this.focusHeadStop(again);
      });
    });
    (this.closest("dialog[open]") || document.body).append(menu);
    this._columnMenu = menu;
    return menu;
  } // «По содержимому»: the column as wide as its head and the values shown
  // want on one line, up to the cap of a content width, read the way the
  // table measures its content widths (sf-table-measuring: auto layout at
  // max-content, for one read), and kept as the person's width.


  fitColumnToContent(key) {
    const table = this.refs.table?.value;
    if (!(table instanceof HTMLTableElement) || !key) return this;
    const column = this.getColumns().find(item => String(item?.key) === String(key));
    const th = table.querySelector(`thead th[data-key="${this.escapeColumnKey(key)}"]`);
    if (!column || !th) return this;
    let width = 0;
    table.classList.add("sf-table-measuring");

    try {
      if (getComputedStyle(table).tableLayout === "auto") width = th.getBoundingClientRect().width;
    } finally {
      table.classList.remove("sf-table-measuring");
    }

    if (!width) return this;
    const {
      minWidth,
      maxWidth
    } = this.getColumnResizeLimits(column, width);
    const fitted = Math.min(Math.max(contentStep(width), minWidth), maxWidth, Math.max(minWidth, this.columnWidthCap()));
    const frozen = this.freezeColumnsWidthForResize(table);
    return this.applyColumnResizeWidths(key, fitted, frozen);
  } // ─── the list's keyboard (VT-3; C146 (8) as in the grid) ────────────────
  // The list of records is one Tab stop, as the table is: the record the
  // person was on (or its control), else the current one, else the first.
  // ↑↓ walk the records from the record or any of its controls, ←→ walk a
  // record's own controls (box, «≡», title, actions); Home/End and Enter,
  // Space keep their row meaning (handleRowKeydown). 27 stops for 8 rows
  // and 39 for 12 before (the study's now-admin at 390).


  listItems(list = this.querySelector(":scope .sf-table-list")) {
    return list ? [...list.querySelectorAll(":scope > li.sf-table-list-item[data-row-id]")] : [];
  }

  listControls(item) {
    return [item, ...[...item.querySelectorAll("a[href], button:not([disabled]), input:not([disabled]):not([type=hidden])")].filter(element => !element.closest(".sf-tooltip, [hidden]"))];
  }

  syncListStops() {
    const list = this.isList ? this.querySelector(":scope .sf-table-list") : null;

    if (!list) {
      this._listAbort?.abort();
      this._listBound = null;
      return;
    }

    this.bindListKeys(list);
    const items = this.listItems(list);
    const stops = items.flatMap(item => this.listControls(item));
    let stop = this._listStop?.isConnected && stops.includes(this._listStop) ? this._listStop : null;
    stop ??= list.querySelector(":scope > li[data-current]") ?? items[0] ?? null;

    for (const element of stops) {
      const index = element === stop ? "0" : "-1";
      if (element.getAttribute("tabindex") !== index) element.setAttribute("tabindex", index);
    }

    this._listStop = stop;
  }

  bindListKeys(list) {
    if (this._listBound === list) return;
    this._listAbort?.abort();
    this._listAbort = new AbortController();
    this._listBound = list;
    const {
      signal
    } = this._listAbort;
    list.addEventListener("focusin", event => {
      const target = event.target instanceof Element ? event.target : null;
      if (!target || target === this._listStop || !this.listItems(list).some(item => item.contains(target))) return;
      this._listStop = target;
      this.syncListStops();
    }, {
      signal
    });
    list.addEventListener("keydown", event => {
      if (event.defaultPrevented || event.altKey || event.metaKey) return;
      const target = event.target instanceof Element ? event.target : null;
      const items = this.listItems(list);
      const item = items.find(one => one.contains(target));
      if (!item || target.closest("textarea, select, [contenteditable]") || target.matches("input") && !/^(checkbox|radio)$/u.test(target.type)) return;
      const controls = this.listControls(item);
      const at = controls.indexOf(target);
      let next = null;

      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        const forward = event.key === "ArrowRight" !== this.isRightToLeft();
        next = controls[at + (forward ? 1 : -1)] ?? null;
      } else if ((event.key === "ArrowDown" || event.key === "ArrowUp") && target !== item && !target.matches(".sf-table-title-link")) {
        // From a control: the same place in the next record (from the
        // record itself and its title the row's own keys move).
        const other = items[items.indexOf(item) + (event.key === "ArrowDown" ? 1 : -1)];
        const list2 = other ? this.listControls(other) : [];
        next = list2[Math.min(Math.max(at, 0), list2.length - 1)] ?? null;
      } else {
        return;
      }

      if (!next || next === target) return;
      event.preventDefault();
      this._listStop = next;
      this.syncListStops();
      next.focus({
        preventScroll: false
      });
    }, {
      signal
    });
    let queued = 0;
    const observer = new MutationObserver(records => {
      if (queued || !records.some(record => [...record.addedNodes].some(node => node.nodeType === 1))) return;
      queued = requestAnimationFrame(() => {
        queued = 0;
        if (this._listBound === list) this.syncListStops();
      });
    });
    observer.observe(list, {
      childList: true,
      subtree: true
    });
    signal.addEventListener("abort", () => {
      observer.disconnect();
      if (queued) cancelAnimationFrame(queued);
    });
  }

  gridRows(table = this.refs.table?.value) {
    if (!table) return [];
    return [...table.querySelectorAll(":scope > thead > tr, :scope > tbody > tr[data-row-id]")];
  }

  get isGrid() {
    const table = this.refs.table?.value;
    if (!table || this.isList) return false;
    return Boolean(table.querySelector(":scope > tbody > tr[data-row-id] :is(a[href], button, input)"));
  }

  syncGrid() {
    const table = this.refs.table?.value;
    if (!(table instanceof HTMLTableElement)) return;
    this.bindGridKeys(table);
    const grid = this.isGrid;

    if (!this.isTree()) {
      if (grid) table.setAttribute("role", "grid");else if (table.getAttribute("role") === "grid") table.removeAttribute("role");
    } // Several rows may be marked (VT-4): said on the grid, not on a plain table.
    // Read from the drawn head: no column setting is asked outside a draw.


    const many = grid && Boolean(table.querySelector(':scope > thead th[data-key="select"]'));
    if (many) table.setAttribute("aria-multiselectable", "true");else table.removeAttribute("aria-multiselectable");
    this.syncHeadStops(table);
    if (!grid) return;
    const rows = this.gridRows(table);
    const stops = rows.flatMap(row => this.gridControls(row)); // The one stop: the control the person was on, else the row the
    // person is on, else the first row.

    let stop = this._gridStop?.isConnected && stops.includes(this._gridStop) ? this._gridStop : null;
    stop ??= table.querySelector(":scope > tbody > tr[data-current]") ?? table.querySelector(":scope > tbody > tr[data-row-id]");

    for (const element of stops) {
      const index = element === stop ? "0" : "-1";
      if (element.getAttribute("tabindex") !== index) element.setAttribute("tabindex", index);
    }

    this._gridStop = stop;
  }

  bindGridKeys(table) {
    if (this._gridTable === table) return;
    this._gridAbort?.abort();
    this._gridAbort = new AbortController();
    this._gridTable = table;
    const {
      signal
    } = this._gridAbort; // Wherever the focus lands -- a click, a Tab into a control the grid
    // has not seen yet -- that is the one stop.

    table.addEventListener("focusin", event => {
      if (!this.isGrid) return;
      const target = event.target;
      if (!(target instanceof Element) || target === this._gridStop) return;
      if (!this.gridRows(table).some(row => row.contains(target))) return;
      this._gridStop = target;
      this.syncGrid();
    }, {
      signal
    });
    this.bindHeadMenu(table, signal);
    table.addEventListener("keydown", event => this.handleGridKeydown(event, table), {
      signal
    }); // A double press on a short field the record lets this person write
    // edits it at the cell (C296); it does not open the record. Caught on
    // the way down, before the row's own double press.

    table.addEventListener("dblclick", event => {
      const edit = this.cellEditTarget(event);
      if (!edit) return;
      event.preventDefault();
      event.stopPropagation();
      this.openCellEditor(edit.row, edit.column, edit.cell);
    }, {
      signal,
      capture: true
    }); // A row's buttons come after the draw: the «Действия» buttons of the
    // row a person is on, and a Smart button's own <button>, which its
    // element draws once defined. Each new control leaves the Tab order
    // in the next frame, or it would be a second stop.

    let queued = 0;
    const observer = new MutationObserver(records => {
      if (queued || !records.some(record => [...record.addedNodes].some(node => node.nodeType === 1))) return;
      queued = requestAnimationFrame(() => {
        queued = 0;
        if (this._gridTable === table) this.syncGrid();
      });
    });
    observer.observe(table, {
      childList: true,
      subtree: true
    });
    signal.addEventListener("abort", () => {
      observer.disconnect();
      if (queued) cancelAnimationFrame(queued);
    });
  }

  rowOfElement(element) {
    const key = element?.closest?.("[data-row-id]")?.dataset.rowId;
    if (key == null) return null;
    const rows = this.getTableData().rows || [];
    return rows.find((row, index) => String(this.getRowKey(row, index)) === key) ?? null;
  } // The rows a context menu over `row` acts on (C164): a selected row
  // speaks for the whole selection; a row outside it becomes the selection
  // first. ids is null for the row alone. Asked by the row menu's `open`
  // question (rowMenu), whatever way the menu was opened: the rows carry no
  // aria-selected of their own, so the engine leaves the selection to this.


  rowMenuTargets(row) {
    if (!this.getPropsContext().selectable) return {
      ids: null,
      reselected: false
    };
    const selected = this.getSelectedRecordIds().map(String);
    if (selected.includes(String(row.id))) return {
      ids: selected,
      reselected: false
    };
    if (selected.length) this.clearSelection();
    this.applyRowSelection(row.id, true);
    return {
      ids: null,
      reselected: true
    };
  }

  handleGridKeydown(event, table) {
    if (event.defaultPrevented || !this.isGrid) return; // Alt+Down / Alt+Up are not the grid's: a data view steps the record
    // card open beside the list with them (C305 (4), VR2-3).

    if (event.altKey && (event.key === "ArrowDown" || event.key === "ArrowUp")) return;
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return; // F2 edits the short cell under the focus, or the row's first one.

    if (event.key === "F2") {
      const tr = target.closest("tbody tr[data-row-id]");
      const record = tr && this.rowOfElement(tr);
      const columns = this.getTableData().columns || [];
      const cells = tr ? [...tr.querySelectorAll(":scope > td[data-key]")] : [];
      const own = target.closest("td[data-key]");
      const cell = [own, ...cells].find(one => one && record && this.cellShortEditable(record, columns.find(c => String(c.key) === one.dataset.key) ?? {}));

      if (cell) {
        event.preventDefault();
        this.openCellEditor(record, columns.find(c => String(c.key) === cell.dataset.key), cell);
      }

      return;
    } // A field keeps its own keys.


    if (target.closest("textarea, select, [contenteditable]") || target.matches("input") && !/^(checkbox|radio)$/u.test(target.type)) return; // An edge that sets a width keeps its arrows, Home and End.

    if (target.matches("[data-sf-column-resizer]") && /^(ArrowLeft|ArrowRight|Home|End|Enter)$/u.test(event.key)) return;
    const rows = this.gridRows(table);
    const rowIndex = rows.findIndex(row => row === target || row.contains(target));
    if (rowIndex < 0) return;
    const row = rows[rowIndex];
    const controls = this.gridControls(row);
    const at = controls.indexOf(target); // The row's own keys (handleRowKeydown) move between rows from the
    // row itself, drawn or not; these move from a control, and across.

    const inBody = row.parentElement?.tagName === "TBODY";

    const place = (index, list, from) => {
      // A body row starts with the row itself; the head row does not.
      const fromBody = from.parentElement?.tagName === "TBODY";
      const toBody = list[0]?.tagName === "TR";
      const shift = (toBody ? 1 : 0) - (fromBody ? 1 : 0);
      return Math.max(0, Math.min(list.length - 1, index + shift));
    };

    let next = null;

    if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
      const forward = event.key === "ArrowRight" !== this.isRightToLeft();
      next = controls[at + (forward ? 1 : -1)] ?? null; // A tree row opens and closes with the arrows from the row itself.

      if (target === row && row.hasAttribute("aria-expanded")) return;
    } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      // From a row the row's own keys moved already, when there was a
      // row to move to; from the first one, up is the head.
      const other = rows[rowIndex + (event.key === "ArrowDown" ? 1 : -1)];

      if (other) {
        const list = this.gridControls(other);
        next = list[place(at, list, row)] ?? null;
      }
    } else if (event.key === "Home" || event.key === "End") {
      if (event.ctrlKey) {
        const body = rows.filter(one => one.parentElement?.tagName === "TBODY");
        next = (event.key === "Home" ? body[0] : body[body.length - 1]) ?? null;
      } else if (target !== row || !inBody) {
        next = event.key === "Home" ? controls[0] : controls[controls.length - 1];
      } else {
        return;
      }
    } else {
      return;
    }

    if (!next || next === target) return;
    event.preventDefault();
    this._gridStop = next;
    this.syncGrid();
    next.focus({
      preventScroll: false
    });
  }

  template() {
    // Building the template writes nothing to the page: what it reads of
    // the layout (the cap, whether the columns are cramped) is read once,
    // and so are the column settings (drawingWith).
    return this.drawingWith(() => this.readingLayout(() => (0,_js_templates_default__WEBPACK_IMPORTED_MODULE_7__.renderTableTemplate)(this.templateContext())));
  } // The column settings of one draw, read once (simai/ui-pro#1): every
  // column and every cell asked for them: counted over one setRows() draw,
  // 268 times for 8 rows and 343 for 60, now 4. Building the template,
  // measuring it after (afterRender, measurePinnedColumns) and preparing the rows
  // (normalizeRows) change no setting; a handler they bind runs later,
  // outside, and reads them afresh.


  drawingWith(draw) {
    const outer = this._drawColumnSettings;
    this._drawColumnSettings = outer ?? this.getColumnSettings();

    try {
      return draw();
    } finally {
      this._drawColumnSettings = outer;
    }
  }

}

(0,_js_manifest_actions_js__WEBPACK_IMPORTED_MODULE_2__.settingSetters)(SfTable, _component_json__WEBPACK_IMPORTED_MODULE_3__);
SfTable.define("sf-view-table");
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "17828be41e75"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   answerActions: () => (/* binding */ answerActions),
/* harmony export */   outcomeOf: () => (/* binding */ outcomeOf),
/* harmony export */   settingSetters: () => (/* binding */ settingSetters)
/* harmony export */ });
// The actions a manifest declares, on a class that already has the methods
// (standard simai.smart-component 1.3.8 §4.4). elementFromManifest makes a
// method per action, but a component whose class predates its manifest keeps
// its own methods, which shadow the generated ones. This wraps those methods
// once per class so that, as the standard asks, each:
//
// - takes its `with` parameters as one object, as well as positionally;
// - answers an outcome: {outcome: applied | refused | conflict | unavailable
//   | cancelled, reason?, message?}. A host port's answer ({answer, reason,
//   message}, vocabulary §3.1) is read as the outcome it is; a method that
//   answered nothing, or the element itself, answered applied.
//
// Helpers the class calls internally go through the same wrapper; nothing in
// the package reads their old return value (the element, or the port's
// answer under `answer`), and `answer` stays on the outcome for one that does.
const camel = name => String(name).replace(/-([a-z0-9])/gu, (_, letter) => letter.toUpperCase());

const isPlain = value => value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;

function outcomeOf(result, element) {
  if (result === undefined || result === null || result === true || result === element) return {
    outcome: "applied"
  };
  if (result === false) return {
    outcome: "refused",
    reason: "refused"
  };
  if (typeof result === "object" && typeof result.outcome === "string") return result;

  if (typeof result === "object" && typeof result.answer === "string") {
    const {
      answer,
      reason,
      message
    } = result;
    return { ...result,
      outcome: answer,
      ...(reason ? {
        reason
      } : {}),
      ...(message ? {
        message
      } : {})
    };
  }

  return {
    outcome: "applied",
    value: result
  };
}
function answerActions(Class, manifest) {
  const proto = Class.prototype;

  for (const [name, spec] of Object.entries(manifest.actions || {})) {
    const method = camel(name);
    const run = proto[method];
    if (typeof run !== "function" || run.sfAction) continue;
    const names = Object.keys(spec?.with || {});

    const wrapped = function manifestAction(...args) {
      // One object naming only declared parameters is the object form.
      if (args.length === 1 && isPlain(args[0])) {
        const given = Object.keys(args[0]);
        if (!names.length && !given.length) args = [];else if (names.length && given.length && given.every(key => names.includes(key) || names.map(camel).includes(key))) {
          args = names.map(key => args[0][key] ?? args[0][camel(key)]);
        }
      }

      const result = run.apply(this, args);
      if (result && typeof result.then === "function") return result.then(value => outcomeOf(value, this));
      return outcomeOf(result, this);
    };

    wrapped.sfAction = true;
    Object.defineProperty(proto, method, {
      configurable: true,
      writable: true,
      value: wrapped
    });
  }

  return Class;
} // A setting the class reads through a getter of its own (an attribute read
// with its parsing) is writable as a property too, as §4 makes every setting:
// an assembly binds by property when the element has one (SF.Assembly's
// adaptElement), and a getter alone threw «has only a getter» at the first
// binding. The setter writes the attribute the getter reads.

function settingSetters(Class, manifest) {
  const proto = Class.prototype;

  for (const [name, spec] of Object.entries(manifest.settings || {})) {
    if (["list", "object", "state"].includes(spec?.type)) continue;
    const property = camel(name);
    let owner = proto;
    let found = null;

    while (owner && owner !== globalThis.HTMLElement?.prototype && owner !== Object.prototype) {
      found = Object.getOwnPropertyDescriptor(owner, property);
      if (found) break;
      owner = Object.getPrototypeOf(owner);
    }

    if (!found || !found.get || found.set) continue;
    Object.defineProperty(owner, property, {
      configurable: true,
      get: found.get,

      set(value) {
        if (spec.type === "boolean") {
          if (value === true || value === "" || value === "true") this.setAttribute(name, "");else if (value === false && spec.default === true) this.setAttribute(name, "false");else this.removeAttribute(name);
        } else if (value === null || value === undefined) {
          this.removeAttribute(name);
        } else {
          this.setAttribute(name, String(value));
        }
      }

    });
  }

  return Class;
}

/***/ },

/***/ "9d9caaf4f796"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   columnStyle: () => (/* binding */ columnStyle),
/* harmony export */   renderTableTemplate: () => (/* binding */ renderTableTemplate),
/* harmony export */   resolvedDataState: () => (/* binding */ resolvedDataState)
/* harmony export */ });
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2a080a730149");
/* harmony import */ var lit_directive_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("0816a19adc72");
/* harmony import */ var lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("9d9903b87148");
/* harmony import */ var lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("efa66f8927d1");
/* harmony import */ var lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("8137feb490e0");
/* harmony import */ var lit_directive_helpers_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("80c480e5196c");
/* harmony import */ var _default_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("68a281c549b5");
/* harmony import */ var _link_cell_contract_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("5bfdd9ec12a1");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lit__WEBPACK_IMPORTED_MODULE_0__, lit_directive_js__WEBPACK_IMPORTED_MODULE_1__, lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__, lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_3__, lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__, lit_directive_helpers_js__WEBPACK_IMPORTED_MODULE_5__]);
([lit__WEBPACK_IMPORTED_MODULE_0__, lit_directive_js__WEBPACK_IMPORTED_MODULE_1__, lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__, lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_3__, lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__, lit_directive_helpers_js__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lit_directive_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lit_directive_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lit_directive_helpers_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lit_directive_helpers_js__WEBPACK_IMPORTED_MODULE_5__);









function getEventInputValue(event, fallback = '') {
  const pathTarget = event?.composedPath?.()?.[0];
  const candidates = [pathTarget, event?.target, event?.currentTarget];

  for (const candidate of candidates) {
    if (!candidate) continue;

    if (typeof candidate.value !== 'undefined') {
      return candidate.value;
    }

    const input = candidate.querySelector?.('input, textarea');

    if (input && typeof input.value !== 'undefined') {
      return input.value;
    }
  }

  return fallback;
} // The toolbar of the compact list: one line, the search taking the room and the
// filter and create as icons beside it -- the table's toolbar wrapped to three
// lines on a phone and took a quarter of the screen. Active filters follow as a
// row of chips that scrolls sideways, each removable, and the filter itself
// opens as a sheet over the whole screen.


function renderListToolbar(context) {
  const {
    state
  } = context.component;
  const {
    value
  } = state.search;
  const filterTags = context.component.getCurrentFilterTags();
  const filterValues = context.component.getCurrentFilterValues();
  const active = Object.entries(filterTags || {}).filter(([, tag]) => tag?.active !== false);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-table-toolbar sf-table-toolbar--list flex flex-col gap-1/3 flex-none"
             data-sf-filter-tags="${active.length ? '1' : '0'}">
            <div class="sf-table-list-search flex items-cross-center gap-1 min-w-0">
                <sf-input
                        size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        root-class="sf-search-input flex-1 min-w-0"
                        appearance="bordered"
                        value="${value}"
                        placeholder=${context.searchPlaceholder}
                        name="sf_table_search"
                        input-type="search"
                        icon-start="search"
                        clearable
                        aria-label=${context.searchPlaceholder}
                        @input=${e => context.component.searchChange({
    value: getEventInputValue(e, value)
  })}
                        @keydown=${e => context.component.handleSearchKeyDown(e)}
                        @keyup=${e => context.component.handleSearchKeyUp(e)}
                ></sf-input>
                <!-- C144: filter and sort are one group of neighbours (H5,
                     --sf-space-1/3); the field before them and «Создать»
                     after them stand a group apart (H6, --sf-space-1). -->
                ${context.component.offersFilter(active.length) || context.component.getColumns().some(column => column?.sortable && !column.system) ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-list-view-buttons flex items-cross-center gap-1/3">
                ${context.component.offersFilter(active.length) ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-list-filter">
                    <!-- The count of active conditions is the icon's own badge
                         (sf-button-icon badge-count, simai/ui-source#12): it
                         joins the button's name in the page language. -->
                    <sf-button-icon
                            size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            appearance=${active.length ? 'default' : 'outline'}
                            scheme="primary"
                            icon="filter_list"
                            badge-count=${active.length || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            badge-label=${active.length ? context.component.text('filterBadgeLabel') : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-label=${context.filterText}
                            @click=${e => context.component.openContextMenu(e, {
    type: 'bottom',
    menu: 'filter-settings'
  })}
                    ></sf-button-icon>
                </span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ${context.component.getColumns().some(column => column?.sortable && !column.system) ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-button-icon
                            size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            appearance=${state.sort?.key ? 'default' : 'outline'}
                            scheme=${state.sort?.key ? 'primary' : 'on-surface'}
                            icon="swap_vert"
                            aria-label=${context.component.text('sortLabel')}
                            aria-haspopup="menu"
                            @click=${e => context.component.openContextMenu(e, {
    type: 'bottom',
    menu: 'list-sort'
  })}
                    ></sf-button-icon>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                </div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ${context.actions && context.creatable ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-button-icon
                            size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            appearance="outline"
                            scheme="on-surface"
                            icon="add"
                            aria-label=${context.createText}
                            @click=${e => state.createItems?.length ? context.component.openContextMenu(e, {
    type: 'bottom',
    menu: 'create'
  }) : context.component.requestCreateIntent(null)}
                    ></sf-button-icon>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
            </div>
            ${active.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <!-- Chips are neighbours 4 apart (C105 H5, --sf-space-1/4); the
                     «Сбросить» after them is a button, 8 from the chips. -->
                <div class="sf-table-list-tags flex items-cross-center gap-1/3">
                    <div class="sf-table-chips flex items-cross-center gap-1/4">
                    ${active.map(([k, written]) => {
    // A date chip says its condition (C293 DF-4).
    const tag = { ...written,
      label: context.component.filterChipText(k, written)
    };
    const filterValue = filterValues?.[k] || {};
    const count = Array.isArray(filterValue.values) ? filterValue.values.length : tag.count || '';
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <sf-tag kind="default" size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing} text='${tag.label}' interactive closable :key=${k}
                                    active count='${count}'
                                    @sf-tag-close="${() => context.component.removeFilterTag(k)}"
                                    @click=${e => context.component.openContextMenu(e, {
      type: 'bottom',
      menu: 'tag-settings',
      fieldKey: k,
      anchorSelector: '.sf-tag'
    })}
                            ></sf-tag>`;
  })}
                    </div>
                    <sf-button size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing} appearance="ghost" scheme="on-surface" text=${context.clearText}
                               @click="${() => context.component.removeFilterTag()}"></sf-button>
                </div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        </div>
    `;
}

function renderToolbar(context) {
  const {
    state
  } = context.component;
  const {
    value
  } = state.search;
  const filterTags = context.component.getCurrentFilterTags();
  const filterValues = context.component.getCurrentFilterValues();
  const hasUnsavedFilterDataChanges = context.component.hasUnsavedFilterDataChanges();
  const activeFilterTags = Object.entries(filterTags || {}).filter(([, tag]) => tag?.active !== false);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div
                class="sf-table-toolbar flex gap-1/2 content-main-between flex-none"
                data-sf-filter-tags="${activeFilterTags.length ? '1' : '0'}"
        >
            <div class="sf-table-toolbar-start flex items-cross-center gap-1/3 flex-wrap min-w-0">
                ${context.component.offersFilter(activeFilterTags.length) ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="flex items-cross-center">
                    <sf-button
                            size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            appearance="default"
                            scheme="primary"
                            text=${context.filterText}
                            segment=${context.filterTemplates ? 'start' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            icon-start="filter_list"
                            @click=${e => {
    context.component.openContextMenu(e, {
      type: 'bottom',
      menu: 'filter-settings'
    });
  }}
                    ></sf-button>
                    ${context.filterTemplates ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-button-icon
                            size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            appearance="default"
                            scheme="primary"
                            aria-label=${context.component.text('saveFilterTemplateLabel')}
                            ?disabled=${!activeFilterTags.length}
                            segment="end"
                            icon="bookmark_add"
                            @click=${e => {
    context.component.openContextMenu(e, {
      type: 'bottom',
      menu: 'filter-favorites',
      parent: true
    });
  }}
                    ></sf-button-icon>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                </div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ${activeFilterTags.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <!-- Chips are neighbours 4 apart (C105 H5, --sf-space-1/4); the
                     buttons around them keep the toolbar's 8. -->
                <div class="sf-table-chips flex items-cross-center gap-1/4 flex-wrap min-w-0">
                ${activeFilterTags.map(([k, written]) => {
    // A date chip says its condition (C293 DF-4).
    const tag = { ...written,
      label: context.component.filterChipText(k, written)
    };
    const filterValue = filterValues?.[k] || {};
    const hasFilteredValues = Object.prototype.hasOwnProperty.call(filterValues || {}, k);
    const count = Array.isArray(filterValue.values) ? filterValue.values.length : tag.count || '';
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <div class="sf-table-tags">
                            <sf-tag
                                    kind="default"
                                    size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                    text='${tag.label}'
                                    interactive
                                    closable
                                    :key=${k}
                                    ?active=${hasFilteredValues}
                                    @sf-tag-close="${() => {
      context.component.removeFilterTag(k);
    }}"
                                    @click=${e => {
      context.component.openContextMenu(e, {
        type: 'bottom',
        menu: 'tag-settings',
        fieldKey: k,
        anchorSelector: '.sf-tag'
      });
    }}
                                    count='${count}'
                            ></sf-tag>
                        </div>`;
  })}
                </div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ${activeFilterTags.length || hasUnsavedFilterDataChanges ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    ${hasUnsavedFilterDataChanges ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-button
                                size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                appearance="default"
                                scheme="primary"
                                text=${context.component.text('saveText')}
                                @click="${() => context.component.saveCurrentFilterTemplateData()}"
                        ></sf-button>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    ${activeFilterTags.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <sf-button
                                size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                appearance="outline"
                                scheme="on-surface"
                                text=${context.clearText}
                                @click="${() => context.component.removeFilterTag()}"
                        ></sf-button>
                    ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
            </div>

            <div class="sf-table-toolbar-end flex items-cross-center gap-1/3 flex-wrap flex-auto min-w-0">
                <sf-input
                        size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        root-class="sf-search-input m-inline-start-auto"
                        appearance="bordered"
                        value="${value}"
                        placeholder=${context.searchPlaceholder}
                        name="sf_table_search"
                        input-type="search"
                        icon-start="search"
                        clearable
                        aria-label=${context.searchPlaceholder}
                        @input=${e => {
    context.component.searchChange({
      value: getEventInputValue(e, value)
    });
  }}
                        @keydown=${e => {
    context.component.handleSearchKeyDown(e);
  }}
                        @keyup=${e => {
    context.component.handleSearchKeyUp(e);
  }}
                ></sf-input>

                ${context.layoutSwitch ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <sf-segmented class="sf-table-layout-switch" size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-label=${context.component.text('layoutSwitchLabel')}
                            value=${context.shownLayout}
                            .items=${context.component.layoutSwitchItems()}
                            @change=${e => {
    const chosen = e.detail?.value;
    if (chosen === 'list' || chosen === 'table') context.component.setLayoutChoice(chosen);
  }}></sf-segmented>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}

                ${context.actions && context.creatable ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <div class="flex items-cross-center">
                                <sf-button
                                        size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                        appearance="outline"
                                        scheme="on-surface"
                                        text=${context.createText}
                                        segment=${state.createItems?.length ? 'start' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                        @click=${() => context.component.requestCreateIntent(null)}
                                ></sf-button>
                                ${state.createItems?.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                                    <sf-button-icon
                                            size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                            appearance="outline"
                                            scheme="on-surface"
                                            segment="end"
                                            icon="keyboard_arrow_down"
                                            aria-label=${context.component.text('createMoreLabel')}
                                            aria-haspopup="menu"
                                            @click=${e => {
    context.component.openContextMenu(e, {
      type: 'bottom',
      menu: 'create'
    });
  }}
                                    ></sf-button-icon>
                                ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            </div>
                        ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}

                <!-- The extra actions of the view, from the host. Column
                     settings are not here: they are the gear in the table's own
                     head, where they have always been. Without actions there is
                     no control, because an empty menu is a dead end. -->
                ${context.settings && state.toolbarActions?.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <sf-button-icon
                                    size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                    appearance="outline"
                                    scheme="on-surface"
                                    icon="more_horiz"
                                    aria-label=${context.component.text('contextViewActionsLabel')}
                                    aria-haspopup="menu"
                                    @click=${e => {
    context.component.openContextMenu(e, {
      menu: 'toolbar-actions'
    });
  }}
                            ></sf-button-icon>
                        ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
            </div>
        </div>
    `;
} // The state the region is actually in: the author's data-state, or what the
// rows resolve to. It is declared on the region, not guessed from the markup.
// What the table says when it has no rows, one brick for every reason
// (owner, 2026-10-14): sf-empty-state at the table's size, the reason and its
// one action from what the table and its data view know -- no access, could
// not load (Повторить), nothing found (what the reset clears), no data
// (Создать when the table may create). A slot `empty` replaces it whole.


function renderEmptyState(context, dataState) {
  const component = context.component; // The page's own state (C296): slot="empty" for no records, slot="error"
  // for a failed load; an error without one falls back to the empty slot
  // as before, then to the Framework's sf-empty-state.

  const slot = dataState === 'error' && component?.hasSlotContent?.('error') ? 'error' : 'empty';
  if (component?.hasSlotContent?.(slot)) return component.getSlotContent(slot);
  const brick = component.emptyBrick(dataState);
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-empty-state kind=${brick.kind} size=${brick.size} heading-level=${brick.headingLevel}
                                icon=${brick.icon || lit__WEBPACK_IMPORTED_MODULE_0__.nothing} heading=${brick.title || lit__WEBPACK_IMPORTED_MODULE_0__.nothing} text=${brick.text || lit__WEBPACK_IMPORTED_MODULE_0__.nothing} live=${brick.live || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                .actions=${brick.actions}></sf-empty-state>`;
}

function resolvedDataState(context) {
  if (context.dataState !== 'auto') return context.dataState;
  const data = context.component?.getTableData?.() ?? {};
  if ((data.rows || []).length) return 'populated'; // Nothing given yet -- no columns, no rows -- is a table waiting for its
  // first answer, drawn as its skeleton: «Пока ничего нет» stood there
  // before any answer came (owner, 2026-10-15, frame by frame).

  if (!(data.columns || []).length) return 'loading';
  return 'empty';
}

function renderHeadLabel(context, column) {
  // The actions column is as wide as its icons, and its heading broke in two
  // over them («Дей / ствия»): it is named for assistive technology only.
  if (column.key === 'actions' && !column.component) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-visually-hidden">${column.label}</span>`;
  } // The gear opens the column settings; without them (settings-menu="false",
  // a host that saves no personal settings) the column keeps its row menus and
  // its heading is only a name.
  // settings="false" with row actions keeps the column for the «≡» alone.


  if (column.key === 'settings' && (context.settingsMenu === false || context.settings === false)) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-visually-hidden">${context.component.text('settingsColumnLabel')}</span>`;
  }

  const content = column.component ? context.component.renderSmartElement(column.component.type, column.component.props) : column.label;

  if (column.sortable !== true || column.system) {
    return content;
  }

  const sort = context.component.state.sort || {};
  const direction = sort.key === column.key ? sort.direction : null; // The mark stands only at the sorted column (owner decision C146 (6));
  // the others show, on hover and focus, the arrow a press would give.

  const icon = direction === 'desc' ? 'arrow_downward' : 'arrow_upward';
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <button type="button" class="sf-table-sort-button flex items-cross-center gap-1/4 min-w-0"
                data-direction=${direction || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>
            <span class="truncate">${content}</span>
            <i class="sf-icon sf-table-sort-icon" aria-hidden="true">${icon}</i>
        </button>
    `;
}

function ariaSort(context, column) {
  if (column.sortable !== true || column.system) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const sort = context.component.state.sort || {};
  if (sort.key !== column.key) return 'none';
  return sort.direction === 'asc' ? 'ascending' : 'descending';
}

function renderHead(context) {
  if (context.component?.hasSlotContent?.("head")) {
    return context.component.getSlotContent("head");
  }

  const columns = context.component?.getColumns?.() || [];
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <thead class="sticky top-0 z-5">
        <tr>
            ${columns.map((column, k) => {
    return (0,lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__.keyed)(`head:${column.key}`, (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <th
                                    class="relative"
                                    data-key="${column.key}"
                                    data-label="${column.label || column.key || ''}"
                                    data-sf-cell=${cellKind(context.component, column, columns)}
                                    data-sf-pinned=${context.component.isPinnedColumn(column) ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                    style=${context.component.getStickyCellStyle(columns, k) || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                                    aria-sort=${ariaSort(context, column)}
                                    @click=${column.sortable === true ? event => context.component.handleHeaderSortClick(event, column) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            >
                                ${column.system || k === columns.length - 1 ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`${renderHeadLabel(context, column)}${k === columns.length - 1 ? renderTipSurfaces(context) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div
                                        class="sidebar-resizer flex items-cross-center h-full select-none"
                                >
                                    ${renderHeadLabel(context, column)}
                                    <!-- The width is taken by the line between
                                         two headers. There is no handle to find
                                         first: this is the line's own hit strip,
                                         invisible, astride the separator, and
                                         still a button with its name and its
                                         arrows. It is no Tab stop of its own
                                         (owner decision C146 (8), the resizer
                                         study RS-10): the table is one stop;
                                         the keyboard reaches it from the head's
                                         menu, «Изменить ширину» (C158 (5)). -->
                                    <button type="button"
                                            tabindex="-1"
                                            role="separator"
                                            aria-orientation="vertical"
                                            class="sf-table-column-resizer"
                                            id=${context.component.getColumnResizerId(column.key)}
                                            data-sf-column-resizer=${column.key}
                                            aria-label="${context.component.text('columnResizeLabel')}: ${column.label || column.key}"
                                            aria-keyshortcuts="ArrowLeft ArrowRight Home End Enter Escape"
                                    ></button>
                                </div>`}
                            </th>`);
  })}
        </tr>
        </thead>
    `;
} // The tooltip of a cut name (owner decision C146 (7)): one surface for the
// table, in the head of the last column, which every cut name names by id
// (data-tooltip). A surface in each row cost about ten nodes a row and broke
// the thirty nodes a row of a long list (standard 1.3.8 gate 17).


function renderTipSurfaces(context) {
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-tooltip sf-tooltip--dark sf-tooltip--size-1/3 sf-tooltip--arrow-bottom-inline-start" hidden id=${context.component.tipId('title')}><span class="sf-tooltip-content"><span class="sf-tooltip-text"></span></span></span>`;
}

function toColumnSize(value) {
  if (value === null || typeof value === "undefined" || value === "") {
    return "";
  }

  return typeof value === "number" ? `${value}px` : String(value);
} // How narrow a data column may become before it stops being readable.
//
// A fixed-layout table divides whatever room it has between its columns and
// will divide it to nothing: at 620px with five columns they came out 61px
// each, which shreds «Код решения» over three lines and cannot hold a date at
// all. The consumer asked for a floor and for the table to scroll instead
// (Larena, 2026-10-06; measured on the admin reference, 2026-10-09).
//
// It is the table's own min-width rather than the columns', because
// `table-layout: fixed` ignores a minimum on a cell -- the widths come from
// the first row. So the floor is summed here and the table carries the total;
// the scroll box around it already scrolls, and starts doing so the moment the
// sum does not fit.
//
// System columns are not in it: select, settings and actions are sized for what
// they hold and are not text anyone reads.
// Field types whose values are prose rather than a name or a code: drawn on one
// line in a row (see renderCellValue).


const LONG_TEXT_TYPES = new Set(['text', 'textarea', 'markdown', 'html']);
const SYSTEM_COLUMNS = new Set(['select', 'settings', 'actions']); // The first load draws the rows it is waiting for, in the Framework's skeleton
// (owner, 2026-10-12): the shape of the list is on screen before its records,
// instead of one spinner in an empty table. Widths vary by row and column so
// the placeholder reads as text, not as a grid of bars. The words are for a
// reader and stay in a status; the bars are hidden from one.

const SKELETON_ROWS = 6;
const SKELETON_WIDTHS = ['w-3/4', 'w-1/2', 'w-2/3', 'w-1/3', 'w-2/5', 'w-3/5']; // Where a loaded row has a box, a menu or a gear, a loading row keeps a block
// as tall as that control, so the row is as tall before the data as after it
// (owner, 2026-10-14: the rows jumped when the data came).

const skeletonControl = (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-skeleton-control" aria-hidden="true"></div>`;

const skeletonBar = (row, column) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-skeleton sf-skeleton--animation-pulse" aria-hidden="true">
    <div class="sf-skeleton-text sf-skeleton-text--size-1/2 ${SKELETON_WIDTHS[(row + column * 2) % SKELETON_WIDTHS.length]}"></div>
</div>`; // The floor is the component's measurement, not a declaration here: it is
// applied to a column only while there is not room for every column to be
// readable. Written always it would be the width rather than a minimum -- a
// cell that needs more would wrap and a typed row would grow, measured at 81px
// against 57 (owner, 2026-10-09).
// A column's width, floor and cap as its <col> style: the template draws it,
// and the table writes it straight onto the <col> after measuring its content,
// rather than rendering itself again for it (owner, 2026-10-15: a sort was five
// renders of four hundred elements).


function columnStyle(component, column) {
  const width = toColumnSize(column.colWidth ?? column.width ?? column.size) || (column.key === 'actions' ? component?.actionsColumnWidth || 'var(--sf-table--actions-column-width, var(--sf-f0))' : '') || component?.contentWidth?.(column) // A content-sized table takes no floor: each data column gets its
  // content width and the one that takes the spare room its content
  // width at least (the table's least width), as the unmeasured
  // first paint lays them out. Floored before the widths were
  // measured, or the spare room's column after, the columns stood at
  // 160 on a phone for a frame and every printed cell moved.
  || (component?.columnsAreCramped && !component?.contentSized && component?.columnTakesFloor?.(column) ? 'var(--sf-table--column-min-inline-size)' : '');
  const minWidth = toColumnSize(column.min_width ?? column.minWidth);
  const maxWidth = toColumnSize(column.maxWidth);
  return [width ? `width: ${width}` : "", minWidth ? `min-width: ${minWidth}` : "", maxWidth ? `max-width: ${maxWidth}` : ""].filter(Boolean).join("; ");
}

function renderColgroup(context) {
  const columns = context.component?.getColumns?.() || []; // A keyed table on a phone (C259) lays its few cells out by their
  // content: the name takes what the others leave (default.css).

  if (!columns.length || context.keyedNarrow) {
    return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  }

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <colgroup>
            ${columns.map(column => {
    // In a fixed layout the column widths come from here, and a
    // column with none is given whatever is left -- divided to
    // nothing when there is little. The floor is written as the
    // width: fixed layout shares any surplus between the columns
    // that have one, so they grow together above it and stop
    // shrinking below it, and the scroll box takes over.
    // `||` and not `??`: toColumnSize answers with an empty string
    // for a column nobody sized, and an empty string is neither
    // null nor undefined. The same shape cost sf-button its icon
    // shortcut for as long as that component existed.
    // The actions column is sized for its buttons. Without a width it
    // took whatever room was left -- a thousand pixels on a wide
    // page -- and the data columns were measured as cramped beside
    // it and held at their floor.
    const style = columnStyle(context.component, column); // The column that takes the spare room is marked, so a first
    // paint the code has not measured yet gives it the spare room
    // too (default.css, the unmeasured content-sized table).

    const spare = column.key && column.key === context.component?.spareRoomColumnKey?.();
    return (0,lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__.keyed)(`col:${column.key}`, (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <col
                            data-key=${column.key || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-sf-spare-room=${spare ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            style=${style || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    />
                `);
  })}
        </colgroup>
    `;
} // Several values in a cell -- tags for each choice, badges for each language --
// stay on one line: what does not fit folds into «+N», whose title names the
// rest (owner, 2026-10-13). Wrapped, three tags made a row three lines tall in
// a list of one-line rows. The folded values stay in the text, visually hidden,
// so a screen reader still reads them all; the table's afterRender does the
// folding (fitCellValues), because only the laid-out row knows what fits.


function renderCellValues(items, owner) {
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <div class="sf-table-cell-values flex items-cross-center gap-1/3">
            ${items.map(item => renderCellItem(item, owner))}
            <span class="sf-table-cell-more" aria-hidden="true" hidden></span>
        </div>
    `;
}

function renderComponent(component, owner) {
  if (!component?.type) {
    return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  }

  const props = { ...(component.props || {})
  };
  return owner.renderCellElement ? owner.renderCellElement(component.type, props) : owner.renderSmartElement(component.type, props);
}

function renderCellItem(item, owner) {
  if (item === null || typeof item === "undefined") {
    return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  } // What the shared renderer set answers with is markup, not a descriptor.
  // Nine of its eleven cell renderers happen to answer with a descriptor --
  // a badge, a tag, an avatar, a reference link -- and the two that answer
  // with markup, the colour and the included block, fell through the object
  // branch below and were dropped: every colour cell and every code cell in
  // every table drew nothing at all. A unit calling the renderer saw correct
  // markup, so only a table could show it (admin polygon, 2026-10-10).


  if ((0,lit_directive_helpers_js__WEBPACK_IMPORTED_MODULE_5__.isTemplateResult)(item)) {
    return item;
  }

  if (typeof item === "object") {
    const {
      component,
      props: itemProps,
      ...itemMeta
    } = item;

    if (!component?.type) {
      return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    }

    return renderComponent({ ...component,
      props: { ...itemMeta,
        ...(itemProps || {}),
        ...(component.props || {})
      }
    }, owner);
  }

  return item;
}

function renderLinkCell(value) {
  const cell = (0,_link_cell_contract_js__WEBPACK_IMPORTED_MODULE_7__.normalizeTableLinkCell)(value);

  if (!cell) {
    return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  } // The link is the SIMAI Framework's sf-reference-link on the cell's text
  // line, as the field renderers draw a reference in a cell (VF-10); the
  // supporting line under it stays the list's own text. Without a safe href
  // the words are plain text: a link that leads nowhere is not drawn as one.


  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <span class="sf-table-link-cell flex flex-col min-w-0">
            ${cell.href ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-reference-link
                    line="1/2"
                    appearance="plain"
                    icon=""
                    label=${cell.text}
                    href=${cell.href}></sf-reference-link>` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-link-cell-text">${cell.text}</span>`}
            ${cell.subtext === null ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <span class="sf-table-link-cell-subtext sf-text-1/2">${cell.subtext}</span>
            `}
        </span>
    `;
} // A row's markup, composed per arrangement of its cells (standard 1.3.8
// §18.4, simai/ui-pro#2). A row of plain cells is one Lit template with no
// part per cell: its strings are made once for each sequence of cell kinds
// (a box, the row menu, a text, an empty cell, a full cell) and kept, so Lit
// parses each arrangement once and a drawn row holds no marker per cell --
// about twenty-five nodes where a template per cell held forty-six. The
// fragments are fixed; a cell's values are bound, never written as HTML.
// This is the migration form (§16) until template.html is compiled.


const ROW_HOLE = Symbol("row-hole"); // What a column's cells are to the look (owner decision C146): `number`,
// end-aligned with digits of one width and never wrapped (3); `title`, the
// record's name, up to two lines and then an ellipsis with the whole name
// in a tooltip (7). Other cells keep one line.

function cellKind(component, column, columns) {
  if (!column?.key) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  if (component?.isNumberColumn?.(column)) return 'number';
  if (!column.system && column.role === 'title') return 'title';
  if (!column.system && !columns?.some(one => one?.role === 'title') && columns?.find(one => one?.key && !SYSTEM_COLUMNS.has(one.key) && !one.system) === column) return 'title';
  return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
}

const ROW_STRINGS = new Map(); // The actions cell (view 1.6.1, simai/ui-pro#2): its buttons stand only in
// the row a person is on, and an idle row's cell is the bare <td>. It was a
// child part with an empty box in it (a marker and a <div>, 31 nodes a row
// where 29 do). The cell keeps one kind whether its buttons show or not,
// bound on the cell itself (an element part has no marker): a row whose
// strings change is drawn anew, and the focus that brought the buttons in
// would leave with the old row.

class ActionsCellDirective extends lit_directive_js__WEBPACK_IMPORTED_MODULE_1__.Directive {
  constructor(part) {
    super(part);
    if (part.type !== lit_directive_js__WEBPACK_IMPORTED_MODULE_1__.PartType.ELEMENT) throw new Error("actionsCell binds an element");
  }

  render() {
    return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  }

  update(part, [content, host]) {
    // A cell never drawn into stays bare; once drawn, Lit's own part
    // empties it.
    if (content !== lit__WEBPACK_IMPORTED_MODULE_0__.nothing || part.element.childNodes.length) (0,lit__WEBPACK_IMPORTED_MODULE_0__.render)(content, part.element, {
      host
    });
    return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  }

}

const actionsCell = (0,lit_directive_js__WEBPACK_IMPORTED_MODULE_1__.directive)(ActionsCellDirective);

function rowStrings(kinds) {
  const signature = kinds.join("|");
  const known = ROW_STRINGS.get(signature);
  if (known) return known;
  const pieces = ['<tr data-selected=', ROW_HOLE, ' aria-selected=', ROW_HOLE, ' draggable=', ROW_HOLE, ' aria-level=', ROW_HOLE, ' aria-expanded=', ROW_HOLE, ' aria-setsize=', ROW_HOLE, ' aria-posinset=', ROW_HOLE, ' aria-busy=', ROW_HOLE, ' aria-rowindex=', ROW_HOLE, ' data-row-id=', ROW_HOLE, ' data-current=', ROW_HOLE, ' aria-current=', ROW_HOLE, ' tabindex="-1" @mousedown=', ROW_HOLE, ' @click=', ROW_HOLE, ' @dblclick=', ROW_HOLE, ' @keydown=', ROW_HOLE, '>'];

  for (const kind of kinds) {
    pieces.push('<td data-key=', ROW_HOLE, ' data-item=', ROW_HOLE, ' data-sf-cell=', ROW_HOLE, ' data-sf-pinned=', ROW_HOLE, ' style=', ROW_HOLE); // The actions cell's buttons are bound on the cell (actionsCell).

    pieces.push(...(kind === 'actions' ? [' ', ROW_HOLE, '>'] : ['>']));

    if (kind === 'box') {
      pieces.push('<label class=', ROW_HOLE, '><span class="sf-checkbox-box transition flex"><input type="checkbox" data-sf-row-box value=', ROW_HOLE, ' .checked=', ROW_HOLE, ' aria-label=', ROW_HOLE, ' @change=', ROW_HOLE, // The tick: checkbox class markup draws the glyph of the
      // .sf-icon inside the box (sf-checkbox's own template does the
      // same with sf-icon); without it a checked row showed a filled
      // box and no tick (DEV recipes p1, 2026-11-15).
      '><i class="sf-icon sf-icon--weight-regular pointer-event-none" aria-hidden="true" .textContent=', ROW_HOLE, '></i></span></label>');
    } else if (kind === 'menu') {
      pieces.push('<button type="button" class=', ROW_HOLE, ' aria-label=', ROW_HOLE, ' value="menu" data-sf-row-menu @click=', ROW_HOLE, '><i class="sf-icon sf-icon--weight-regular pointer-event-none" aria-hidden="true">menu</i></button>');
    } else if (kind === 'text') {
      pieces.push('<span class=', ROW_HOLE, ' title=', ROW_HOLE, ' .textContent=', ROW_HOLE, '></span>');
    } else if (kind === 'time') {
      // A date (C40, PD-9): a time element with the record's own day.
      pieces.push('<time class=', ROW_HOLE, ' datetime=', ROW_HOLE, ' .textContent=', ROW_HOLE, '></time>');
    } else if (kind === 'node') {
      pieces.push(ROW_HOLE);
    }

    pieces.push('</td>');
  }

  pieces.push('</tr>');
  const strings = [''];

  for (const piece of pieces) {
    if (piece === ROW_HOLE) strings.push('');else strings[strings.length - 1] += piece;
  }

  const made = Object.freeze(Object.assign(strings, {
    raw: Object.freeze(strings.slice())
  }));
  ROW_STRINGS.set(signature, made);
  return made;
}

function renderTableTemplate(context) {
  const {
    state
  } = context.component;

  function renderBody() {
    if (context.component?.hasSlotContent?.("body")) {
      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <tbody>
                ${context.component.getSlotContent("body")}
                </tbody>`;
    }

    const {
      state
    } = context.component;
    const columns = context.component?.getColumns?.() || [];
    const {
      rows = []
    } = state.data || {};
    const dataState = resolvedDataState(context); // A re-query over rows that are already on screen leaves them there,
    // dimmed, with one small spinner in the middle of what the person can
    // see. Replacing them with a loader — which is what happened before —
    // threw away the place they were reading and moved the answer to the top
    // left corner of an empty table.

    if (dataState === 'loading' && rows.length) {
      return renderRows(context, columns, rows, {
        busy: true
      });
    }

    if (dataState !== 'populated') {
      const stateContent = {
        // One indicator, the same one a re-query shows, centred in the
        // body rather than lined up at its start. The spinner paints its
        // own `label` as text and defaults it to "Loading...", so it is
        // given an empty one: the words are for a reader, in the
        // language the host set, and the circle is for everyone else.
        // Before this there were two indicators here, one of them in
        // English on a Russian page.
        loading: null,
        error: renderEmptyState(context, 'error'),
        empty: renderEmptyState(context, 'empty')
      }[dataState] || renderEmptyState(context, 'empty');

      if (dataState === 'loading') {
        return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <tbody data-state="loading" class="sf-table-skeleton">
                        ${Array.from({
          length: SKELETON_ROWS
        }, (_, row) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<tr aria-hidden="true">
                            ${columns.some(column => !SYSTEM_COLUMNS.has(column?.key)) ? columns.map((column, at) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<td>${SYSTEM_COLUMNS.has(column?.key) ? skeletonControl : skeletonBar(row, at)}</td>`) // Before the host's first answer the columns are not
        // known yet: three bars across the whole row.
        : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<td colspan=${String(Math.max(columns.length, 1))}>
                                        <div class="flex gap-2">${[0, 1, 2].map(at => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="flex-1">${skeletonBar(row, at)}</div>`)}</div>
                                    </td>`}
                        </tr>`)}
                    </tbody>
                    <tbody><tr><td colspan=${String(Math.max(columns.length, 1))} class="sf-table-visually-hidden">
                        <span role="status">${context.loadingText}</span>
                    </td></tr></tbody>
                `;
      }

      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                <tbody data-state=${dataState}>
                    <tr>
                        <td colspan=${String(Math.max(columns.length, 1))}>
                            <div class="sf-table-state">${stateContent}</div>
                        </td>
                    </tr>
                </tbody>
            `;
    }

    return renderRows(context, columns, rows);
  } // The compact list: each record as a block -- its box, its title (with the
  // tree's indent and button when it is a tree), the few fields the columns'
  // priority puts first, and its row menu. Opening and selecting are the
  // row's, so a record does in the list what it does in the table. The rest
  // of the record is the record panel's, opened the way a row opens it.


  function renderList() {
    const columns = context.component?.getColumns?.() || [];
    const {
      rows = []
    } = state.data || {};
    const dataState = resolvedDataState(context);

    if (dataState !== 'populated' && !(dataState === 'loading' && rows.length)) {
      if (dataState === 'loading') {
        return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-list sf-table-skeleton flex flex-col" data-state="loading">
                    ${Array.from({
          length: SKELETON_ROWS
        }, (_, row) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-list-item flex flex-col gap-1/3 p-1" aria-hidden="true">
                        ${skeletonBar(row, 0)}${skeletonBar(row, 1)}
                    </div>`)}
                    <span class="sf-table-visually-hidden" role="status">${context.loadingText}</span>
                </div>`;
      }

      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-state" data-state=${dataState}>${renderEmptyState(context, dataState)}</div>`;
    }

    const select = columns.find(column => column.key === 'select');
    const menu = columns.find(column => column.key === 'settings');
    const roles = context.component.listRoles?.(columns);
    if (roles?.any) return renderResourceList(columns, rows, dataState, roles, select, menu);
    const data = columns.filter(column => column?.key && !['select', 'settings', 'actions'].includes(column.key) && !column.system && column.visible !== false);
    const title = data.find(column => column.role === 'title') ?? data[0]; // The title the host marked opens its record with one click here as
    // in the table's title column; a list on a laptop is the same admin.

    const listTitle = row => title.role === 'title' ? renderTitleLink(context, row, renderCellValue(row, title)) : renderCellValue(row, title);

    const limit = Math.max(0, Number(context.component.getProp?.('listFields') ?? 3) || 0);
    const fields = data.filter(column => column !== title).map((column, order) => ({
      column,
      order
    })).sort((a, b) => (a.column.priority ?? 1e6) - (b.column.priority ?? 1e6) || a.order - b.order).slice(0, limit).map(({
      column
    }) => column);

    const filled = value => !(value === null || value === undefined || value === '' || Array.isArray(value) && !value.length); // A record list (C259, VT-2): «≡» right after the box, where the
    // table has it; the quick actions of a resource list (C31) keep the end.


    const record = !context.quickActionIds?.length;
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`${renderListHead(select)}
            <ul class="sf-table-list" role="list" id=${`${context.rowAreaId}-list`} aria-label=${context.ariaLabel || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-busy=${dataState === 'loading' ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>
                ${rows.map((row, rowIndex) => row.__tree?.more ? (0,lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__.keyed)(`item:${row.id}`, (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <li class="sf-table-list-more" style=${`--sf-table-tree--level: ${row.__tree.level}`}>
                            <sf-button appearance="ghost" size="1/2" text=${context.component.text('treeMore')}
                                       @click=${() => context.component.requestTreeMore(row)}></sf-button>
                        </li>`) : (0,lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__.keyed)(`item:${context.component.rowsGeneration?.() ?? 0}:${row.id ?? rowIndex}`, (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <li class="sf-table-list-item"
                            data-sf-record=${record && menu ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-row-id=${context.component.getRowKey(row, rowIndex)}
                            data-selected=${row.select?.component?.props?.checked === true ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-current=${context.component.isCursorRow(row, rowIndex) ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-current=${context.component.isCurrentRow(row, rowIndex) ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-level=${row.__tree ? String(row.__tree.level + 1) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-expanded=${row.__tree?.hasChildren ? String(row.__tree.expanded === true) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            tabindex="-1"
                            @mousedown=${event => context.component.handleRowPointerDown(event)}
                            @click=${event => context.component.handleRowClick(event, row, rowIndex)}
                            @dblclick=${event => context.component.handleRowOpen(event, row)}
                            @keydown=${event => context.component.handleRowKeydown(event, row)}>
                            ${select ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-list-select">${renderCellValue(row, select)}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            ${record && menu ? renderListMenu(row) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            <div class="sf-table-list-main">
                                <div class="sf-table-list-title">${title ? row.__tree || row.path ? renderTreeCell(context, row, listTitle(row)) : listTitle(row) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}</div>
                                ${fields.some(column => filled(row[column.key])) ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                                    <div class="sf-table-list-fields">
                                        ${fields.filter(column => filled(row[column.key])).map(column => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                                            <span class="sf-table-list-field">
                                                <span class="sf-table-list-label">${column.label ?? column.key}</span>
                                                <span class="sf-table-list-value">${renderCellValue(row, column)}</span>
                                            </span>`)}
                                    </div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            </div>
                            ${context.quickActionIds?.length ? renderListActions(row, menu) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                        </li>`))}
            </ul>`;
  } // The page's box over a phone list (VT-2, BA-6): the head's box, with its
  // words, so a whole page is marked in one press as in the table.


  function renderListHead(select) {
    if (!select) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-list-head" data-sf-list-all>
            ${renderHeadLabel(context, select)}
            <span class="sf-table-list-head-text" aria-hidden="true">${context.component.text('listSelectPage')}</span>
        </div>`;
  } // A record row's «≡» (C259 (3), C146 (5)): the row's one menu, every
  // action of the row; the same menu the right button and a long press open.


  function renderListMenu(row) {
    const component = context.component;
    if (!component.listRowActions(row).rest.length && !component.listRowActions(row).quick.length) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    const size = context.size === '1/2' ? '1/2' : '1';
    const name = component.getRowNameText(row);
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-list-menu"><button type="button"
                class=${`sf-icon-button sf-icon-button--size-${size} sf-icon-button--icon sf-icon-button--ghost sf-icon-button--on-surface flex items-cross-center`}
                aria-label=${name ? `${component.text('contextRowActionsLabel')}: ${name}` : component.text('contextRowActionsLabel')}
                aria-haspopup="menu" data-sf-row-menu
                @click=${event => {
      event.stopPropagation();
      component.openRowMenu(event, row);
    }}><i class="sf-icon sf-icon--weight-regular pointer-event-none" aria-hidden="true">menu</i></button></span>`;
  } // The amount of a record row (C259): the first money (else number)
  // column's value, as its cell shows it.


  function listAmountColumn(columns) {
    const data = columns.filter(column => column?.key && !SYSTEM_COLUMNS.has(column.key) && !column.system && column.visible !== false);

    const type = column => column.propertyType ?? column.property_type ?? column.type;

    return data.find(column => type(column) === 'money') ?? data.find(column => context.component.isNumberColumn?.(column) && column.list !== 'hidden') ?? null;
  } // ─── the list of resources (owner decision C31) ─────────────────────────
  // A row is the status dot, the title over a supporting line («domain ·
  // kind»), the facts as badges without labels in columns of one width,
  // and the quick actions with the «more» menu. The roles are the columns'
  // (columns[].list); a column without one is the record panel's.


  function renderResourceList(columns, rows, dataState, roles, select, menu) {
    const component = context.component;

    const visible = column => column && column.visible !== false;

    const status = visible(roles.status) ? roles.status : null;
    const data = columns.filter(column => column?.key && !['select', 'settings', 'actions'].includes(column.key) && !column.system);
    const title = roles.title ?? data.find(column => column.role === 'title' && column.list !== 'hidden') ?? data.find(column => !column.list) ?? data[0];
    const supporting = roles.supporting.filter(visible);
    const facts = roles.facts.filter(visible);
    const opensRow = component.getAttribute('row-open') === 'row'; // A record list (C259, VT-2): no quick actions -- «≡» after the box,
    // the title over its second line, then every fact and the amount.

    const record = !context.quickActionIds?.length;
    const amount = record ? listAmountColumn(columns) : null;

    const titleOf = row => {
      const text = component.listText(title, row[title?.key]);
      return title?.role === 'title' || roles.title || opensRow ? renderTitleLink(context, row, text) : text;
    };

    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`${renderListHead(select)}
            <ul class="sf-table-list sf-table-list--resource" role="list" id=${`${context.rowAreaId}-list`} aria-label=${context.ariaLabel || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                aria-busy=${dataState === 'loading' ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                style=${`--sf-table-resource--actions: ${Math.max(1, (context.quickActionIds?.length ?? 0) + (menu ? 1 : 0))}`}>
                ${rows.map((row, rowIndex) => {
      if (row.__tree?.more) return (0,lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__.keyed)(`item:${row.id}`, (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <li class="sf-table-list-more" style=${`--sf-table-tree--level: ${row.__tree.level}`}>
                            <sf-button appearance="ghost" size="1/2" text=${component.text('treeMore')}
                                       @click=${() => component.requestTreeMore(row)}></sf-button>
                        </li>`);
      const state = status ? component.listStatus(status, row) : null;
      const shown = facts.map(column => ({
        column,
        fact: component.listFact(column, row)
      })); // The most worrying fact, the one a narrow list keeps.

      const worst = shown.reduce((found, item) => (item.fact?.level ?? 0) > (found?.fact?.level ?? 0) ? item : found, null);
      const words = supporting.map(column => component.listText(column, row[column.key])).filter(Boolean);
      const lead = state?.dot === 'neutral' ? state.word : '';
      return (0,lit_directives_keyed_js__WEBPACK_IMPORTED_MODULE_2__.keyed)(`item:${component.rowsGeneration?.() ?? 0}:${row.id ?? rowIndex}`, (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                        <li class="sf-table-list-item sf-table-resource"
                            data-sf-record=${record && menu ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-row-id=${component.getRowKey(row, rowIndex)}
                            data-selected=${row.select?.component?.props?.checked === true ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-current=${component.isCursorRow(row, rowIndex) ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-current=${component.isCurrentRow(row, rowIndex) ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-status=${state?.dot ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            data-open=${opensRow && component.canOpenRow?.(row) ? 'row' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-level=${row.__tree ? String(row.__tree.level + 1) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-expanded=${row.__tree?.hasChildren ? String(row.__tree.expanded === true) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            tabindex="-1"
                            @mousedown=${event => component.handleRowPointerDown(event)}
                            @click=${event => component.handleRowClick(event, row, rowIndex)}
                            @dblclick=${event => component.handleRowOpen(event, row)}
                            @keydown=${event => component.handleRowKeydown(event, row)}>
                            ${select ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-list-select">${renderCellValue(row, select)}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            ${record && menu ? renderListMenu(row) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            ${status ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-status">${state ? tooltip((0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                                <span class="sf-dot sf-dot--${state.dot}" data-tooltip="" data-status=${state.value}>
                                    <span class="sf-dot-item"></span>
                                    <span class="sf-table-visually-hidden">${state.word}</span>
                                </span>`, state.word) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            <span class="sf-table-resource-main">
                                <span class="sf-table-resource-title">${title ? row.__tree || row.path ? renderTreeCell(context, row, titleOf(row)) : titleOf(row) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}</span>
                                ${lead || words.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-supporting">${lead ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-lead">${lead}</span>${words.length ? ' · ' : ''}` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}${words.join(' · ')}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            </span>
                            ${record && menu ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-list-end">
                                ${shown.filter(({
        fact
      }) => fact).map(({
        column,
        fact
      }) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-fact">${renderFact(column, fact)}</span>`)}
                                ${amount && row[amount.key] !== undefined && row[amount.key] !== null && row[amount.key] !== '' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-list-amount"><span class="sf-table-visually-hidden">${amount.label ?? amount.key}: </span>${renderCellValue(row, amount)}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            </span>` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            ${facts.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-facts">${shown.map(({
        column,
        fact
      }) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                                <span class="sf-table-resource-fact" data-worst=${fact && worst?.column === column && fact.level > 0 ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>${fact ? renderFact(column, fact) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}</span>`)}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            ${renderListActions(row, menu)}`}
                        </li>`);
    })}
            </ul>`;
  } // A fact: a badge without its column's label, which a screen reader
  // still hears; quiet when all is well, warning or error when not.


  function renderFact(column, fact) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-visually-hidden">${column.label ?? column.key}: </span>${renderFactBadge(fact)}`;
  } // The badge of a fact, in a list row and in a table cell alike.


  function renderFactBadge(fact) {
    const size = context.size === '1/2' ? '1/3' : '1/2';
    const badge = (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-badge size=${size} appearance="tonal"
                scheme=${fact.status ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : fact.scheme || 'neutral'} status=${fact.status || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                text=${fact.text} data-tooltip=${fact.tip ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}></sf-badge>`;
    return fact.tip ? tooltip(badge, fact.tip) : badge;
  } // The Framework's tooltip: the trigger and its surface in one anchor
  // (component tooltip), shown on hover and on keyboard focus.


  function tooltip(trigger, text) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-tooltip-anchor">${trigger}<span class="sf-tooltip sf-tooltip--dark sf-tooltip--size-1/3 sf-tooltip--arrow-bottom-center" hidden><span class="sf-tooltip-content"><span class="sf-tooltip-text">${text}</span></span></span></span>`;
  } // A list row's actions (C31): up to three quick ones as icon buttons,
  // always shown (folded away on a narrow list), then «more» (more_horiz),
  // whose menu holds every action of the row (C259 (3)).


  function renderListActions(row, menu) {
    const component = context.component; // The rest is the row menu's, and a table without its menu column
    // (settings="false") has none: then only the quick ones are drawn.

    const split = component.listRowActions(row);
    const quick = split.quick;
    const rest = menu ? split.rest : [];
    if (!quick.length && !rest.length) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    const size = context.size === '1/2' ? '1/2' : '1';
    const button = 'sf-icon-button sf-icon-button--icon sf-icon-button--ghost sf-icon-button--on-surface-variant flex items-cross-center';

    const iconOf = action => action?.icon ?? action?.component?.props?.icon ?? '';

    const press = action => event => {
      event.stopPropagation();
      const handler = action?.component?.props?.['@click'] ?? action?.component?.props?.onClick;
      if (typeof handler === 'function') handler(event);else component.requestActionIntent(action.id, [row.id]);
    };

    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-actions" data-only-quick=${rest.length ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : ''}>
            ${quick.length ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-resource-quick">${quick.map(action => iconOf(action) ? tooltip((0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<button type="button" class=${`${button} sf-icon-button--size-${size}`} data-tooltip=""
                        data-quick-action=${action.id} aria-label=${action.name ?? action.id}
                        @click=${press(action)}><i class="sf-icon" aria-hidden="true">${iconOf(action)}</i></button>`, action.name ?? action.id) : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-button size=${size} appearance="ghost" scheme="on-surface-variant" data-quick-action=${action.id}
                        text=${action.name ?? action.id} @click=${press(action)}></sf-button>`)}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
            <button type="button" class=${`${button} sf-icon-button--size-${size} sf-table-resource-more`}
                    aria-label=${component.getRowNameText(row) ? `${component.text('moreActionsLabel')}: ${component.getRowNameText(row)}` : component.text('moreActionsLabel')} aria-haspopup="menu" data-sf-row-menu
                    @click=${event => {
      event.stopPropagation(); // Every action of the row, the quick ones too (C259 (3),
      // C164 (2)): the list the right button opens.

      component.openRowMenu(event, row);
    }}><i class="sf-icon" aria-hidden="true">more_horiz</i></button>
        </span>`;
  } // The title opens its record with one click (owner, 2026-10-14): the
  // column the host marked as the title is a link to the record's view when
  // the row offers it, so a record is a click away rather than a double
  // click or a trip through the row's menu.


  function renderTitleLink(context, row, value) {
    if (!context.component.canOpenRow?.(row) || row?.id == null) return value;
    const address = row.href ?? row.url ?? ''; // A record without an address opens through the view and is a button:
    // a link to «#» opened the same page in a new tab (VT-9).

    if (!address) {
      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<button type="button" class="sf-table-title-link"
                @click=${event => {
        event.preventDefault();
        event.stopPropagation();
        if (event.detail > 1) return;
        context.component.requestOpen?.(row, false);
        context.component.requestActionIntent('view', [row.id]);
      }}>${value}</button>`;
    }

    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<a class="sf-table-title-link" href=${address}
                @click=${event => {
      if (event.button > 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
        if (row.href ?? row.url) {
          context.component.requestOpen?.(row, true);
          return;
        }
      }

      event.preventDefault();
      event.stopPropagation(); // The second click of a double click is the same wish:
      // opened once, not twice.

      if (event.detail > 1) return;
      context.component.requestOpen?.(row, false);
      context.component.requestActionIntent('view', [row.id]);
    }}>${value}</a>`;
  } // repeat, not keyed: a sort moves the rows it already drew. keyed at each
  // position redrew every row and every value in it when the order changed --
  // four hundred elements for one click (owner, 2026-10-15).
  //
  // Many entries (standard simai.smart-component 1.3.8 §18.4, gate 17;
  // simai/ui-pro#2). From the quality profile's threshold on (300 rows) the
  // table draws only the rows in view and a margin, with one spacer row
  // above and one below holding the height of the rest; the component keeps
  // the range (windowSlice) and moves it with the scroll. A cell that only
  // shows a value is class markup: the row's box is the checkbox's class
  // markup over a native input, the row's menu the icon button's class
  // markup over a native button, and text a span -- no Smart element per
  // cell, so a row is about twenty-five nodes instead of a hundred and eight.


  function renderRows(context, columns, rows, {
    busy = false
  } = {}) {
    const component = context.component;
    const treeColumn = component.treeColumnKey?.(columns); // The main field is the link that opens the record (owner decision
    // C146 (5), variant В): the column the host marked as the title, else
    // the first data column when it shows a plain value (a column with a
    // renderer or a component of its own keeps it).

    const firstData = columns.find(column => column?.key && !SYSTEM_COLUMNS.has(column.key) && !column.system);
    const titleColumn = columns.find(column => column?.role === 'title' && !column.system)?.key ?? (firstData && !firstData.renderer && !firstData.component && !component.isNumberColumn?.(firstData) ? firstData.key : null);
    const slice = component.windowSlice?.(rows) ?? null;
    const shown = slice ? rows.slice(slice.first, slice.last + 1) : rows;
    const offset = slice ? slice.first : 0;
    const span = String(Math.max(columns.length, 1));
    const draggable = component.hasAttribute('drag-rows') || component.getAttribute('row-reorder') === 'true';
    const selectable = columns.some(column => column?.key === 'select');
    const sticky = columns.map((column, index) => component.getStickyCellStyle(columns, index) || lit__WEBPACK_IMPORTED_MODULE_0__.nothing);
    const cellKinds = columns.map(column => cellKind(component, column, columns));
    const pinned = columns.map(column => component.isPinnedColumn(column) ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing);
    const lined = columns.map(column => Boolean(component.keyLineOf?.(column))); // The stripes are nth-child: a spacer of no height keeps the parity of
    // the drawn rows the parity they have in the whole list.

    const spacer = (height, key) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<tr class="sf-table-window-spacer" aria-hidden="true" data-sf-window-spacer=${key}><td colspan=${span} style=${`block-size: ${Math.max(0, Math.round(height))}px`}></td></tr>`;

    const fullCell = (row, column, kind) => {
      const value = column.key === titleColumn ? renderTitleLink(context, row, renderCellValue(row, column)) : renderCellValue(row, column); // A key cell's second line on a phone (C259): the value of the
      // column the host names in key_line, quiet, one line.

      const line = component.keyLineOf?.(column);

      if (line) {
        const raw = row?.[line];
        const text = String((raw !== null && typeof raw === 'object' ? raw.text ?? raw.label ?? raw.value : raw) ?? '');
        return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-key-name">${value}</span>${text ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-key-line">${text}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}`;
      } // The name's two lines (C146 (7)) are its cell's text, by the
      // cell's data-sf-cell="title": no element around it.


      if (column.key === treeColumn) return renderTreeCell(context, row, value);
      return value;
    };

    const renderRow = (row, at) => {
      const index = at + offset;
      const current = component.isCurrentRow(row, index);
      const cursor = component.isCursorRow(row, index);
      const kinds = [];
      const marked = row.select?.component?.props?.checked === true;
      const values = [row.select?.component?.props?.checked === true ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, // The grid's selection, read by a screen reader (VT-4): every
      // row of a selectable grid says whether it is marked.
      selectable ? String(marked) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, draggable && !row.__tree?.more ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, row.__tree ? String(row.__tree.level + 1) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, row.__tree?.hasChildren ? String(row.__tree.expanded === true) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, row.__tree ? String(row.__tree.setsize) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, row.__tree ? String(row.__tree.posinset) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, row.__tree?.loading ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, component.ariaRowIndex?.(index, Boolean(slice)) ?? (slice ? String(index + 2) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing), component.getRowKey(row, index), cursor ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, current ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing, component.rowPointerDown, event => component.handleRowClick(event, row, index), event => component.handleRowOpen(event, row), event => component.handleRowKeydown(event, row)];
      columns.forEach((column, cellIndex) => {
        // The main field of a row that opens is its link, not markup.
        const opens = column.key === titleColumn && component.canOpenRow?.(row) && row?.id != null;
        const mark = opens || lined[cellIndex] ? null : component.rowMarkupCell?.(row, column) ?? null;
        values.push(column.key, `${row.id}_${column.key}`, cellKinds[cellIndex], pinned[cellIndex], sticky[cellIndex]);

        if (cellKinds[cellIndex] === 'title' && mark?.kind === 'text') {
          // The name as text: two lines by its cell (C146 (7)).
          kinds.push('text');
          values.push('sf-table-cell-text', lit__WEBPACK_IMPORTED_MODULE_0__.nothing, mark.text);
        } else if (mark?.kind === 'box') {
          kinds.push('box');
          values.push(`sf-checkbox sf-checkbox--size-${mark.size} flex content-main-between cursor-pointer`, mark.value, mark.checked, mark.label, mark.change, mark.checked ? 'check' : '');
        } else if (mark?.kind === 'menu') {
          kinds.push('menu');
          values.push(`sf-icon-button sf-icon-button--size-${mark.size} sf-icon-button--icon sf-icon-button--ghost flex items-cross-center sf-icon-button--on-surface`, mark.label, mark.click);
        } else if (mark?.kind === 'text') {
          kinds.push('text');
          values.push(mark.className, mark.title ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing, mark.text);
        } else if (mark?.kind === 'time') {
          kinds.push('time');
          values.push(mark.className, mark.datetime, mark.text);
        } else if (mark?.kind === 'empty') {
          kinds.push('empty');
        } else if (column.key === 'actions') {
          kinds.push('actions');
          values.push(actionsCell(fullCell(row, column), component));
        } else {
          kinds.push('node');
          values.push(fullCell(row, column, cellKinds[cellIndex]));
        }
      });
      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)(rowStrings(kinds), ...values);
    };

    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<tbody data-busy=${busy ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing} data-sf-window=${slice ? `${slice.first}-${slice.last}` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>${slice ? spacer(slice.before, 'before') : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}${slice && slice.first % 2 === 0 ? spacer(0, 'parity') : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}${(0,lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_3__.repeat)(shown, (row, at) => row.__tree?.more ? `more:${row.id}` : `row:${component.rowsGeneration?.() ?? 0}:${row.id ?? row.value ?? at + offset}`, (row, at) => row.__tree?.more ? renderMoreRow(context, columns, row) : renderRow(row, at))}${slice ? spacer(slice.after, 'after') : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}</tbody>`;
  } // The first cell of a tree row: indented by its level, with the button that
  // opens or closes it when the host said it has children, and -- in a search
  // over a tree -- the path it lives under, so a found row says where it is.


  function renderTreeCell(context, row, value) {
    const tree = row.__tree;
    const path = Array.isArray(row.path) && row.path.length ? row.path.map(item => item?.label ?? item).join(' / ') : '';
    if (!tree && !path) return value;
    const level = tree?.level ?? 0;
    const toggle = tree?.hasChildren ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<button type="button" class="sf-table-tree-toggle"
                           data-expanded=${tree.expanded ? '' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                           aria-label=${context.component.text(tree.expanded ? 'treeCollapse' : 'treeExpand')}
                           @click=${event => {
      event.stopPropagation();
      context.component.toggleTreeRow(row);
    }}><i class="sf-icon" aria-hidden="true">chevron_right</i></button>` : tree ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-tree-toggle" aria-hidden="true"></span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing; // The node's icon, the host's to choose (port 1.9.0): a page with pages
    // under it is still a page. Without one, a folder for a node with
    // children -- open when it is open -- and a document for a leaf.

    const icon = tree ? (tree.expanded ? row.icon_expanded ?? row.icon : row.icon) ?? (tree.hasChildren ? tree.expanded ? 'folder_open' : 'folder' : 'description') : row.icon;
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <span class="sf-table-tree-cell" style=${`--sf-table-tree--level: ${level}`}>
                ${toggle}
                ${icon ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<i class="sf-icon sf-table-tree-icon" aria-hidden="true">${icon}</i>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                <span class="sf-table-tree-value flex flex-col min-w-0">
                    <span class="min-w-0">${value}</span>
                    ${path ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-tree-path">${path}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                </span>
            </span>`;
  } // The next page of one level, as a row of its own at that level.


  function renderMoreRow(context, columns, row) {
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
            <tr class="sf-table-tree-more" aria-level=${String(row.__tree.level + 1)}>
                <td colspan=${String(columns.length)}>
                    <span class="sf-table-tree-cell" style=${`--sf-table-tree--level: ${row.__tree.level}`}>
                        <span class="sf-table-tree-toggle" aria-hidden="true"></span>
                        <sf-button appearance="ghost" size="1/2" text=${context.component.text('treeMore')}
                                   @click=${() => context.component.requestTreeMore(row)}></sf-button>
                    </span>
                </td>
            </tr>`;
  }

  function renderCellValue(row, column) {
    if (!column || !row) {
      return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    }

    let value = row[column.key];

    if (column.renderer === "link") {
      return renderLinkCell(value);
    } // `row.actions` is read here in two vocabularies. From a host it is ids
    // -- `["view"]`, the data view port's word for which of the list's
    // actions apply to this record -- and from a consumer that builds its
    // own controls it is the items themselves. Ids select from the table's
    // list; items are the list.
    //
    // Both went through the second branch before, so an array of ids was
    // handed to the filter AS the action list, where `action.id` is
    // undefined for a string: everything was filtered out and the
    // «Действия» column drew an empty container in every row of every list.
    // A consumer reported it on an embedded one, which is only where they
    // were looking (owner, 2026-10-09).
    // The cell is built from whichever vocabulary the row holds, and built
    // once. From a host `row.actions` is ids -- the data view port's word
    // for which of the list's actions apply to this record -- and after
    // normalizeRow it is the built items.
    //
    // Items are not rebuilt here. Passing them back through the builder
    // made new objects on every render, and a table that hands lit new
    // objects rebuilds the cells rather than keeping them, which costs
    // whatever the cells hold. The round-3 probe measures exactly that.
    // `row.actions` is the host's ids -- the data view port's word for which
    // of the list's actions apply to this record -- or, from a consumer that
    // builds its own controls, the items themselves. Ids select from the
    // list; items are the list. Handing ids to the builder AS the list was
    // the defect: `action.id` is undefined for a string, so everything was
    // filtered out and the «Действия» column drew an empty container in
    // every row of every list (owner, 2026-10-09).
    //
    // The built items are kept on the row, because a render that builds new
    // objects makes lit rebuild the cells rather than keep them, and the
    // cells hold things worth keeping. A re-query brings new row objects,
    // so the cache is fresh exactly when the data is.


    if (column.key === 'actions' && context.component?.getActionRowItems) {
      const built = Array.isArray(value) && value.length && value.every(item => item && typeof item === 'object');
      if (!built) value = context.component.rowActionItems(row);
    } // A column with a list role (C31) draws its value the same way in a
    // table cell as in a list row: a status is the dot with its word, a
    // fact the badge, quiet or warning/error. Without this, the switch to
    // «Таблица» showed a status's raw value (ok, stopped) and dropped a
    // fact given as {text, status, tip} altogether.


    if (column.list === 'status') {
      const state = context.component.listStatus(column, row);
      return state ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-status flex items-cross-center gap-1/3" data-status=${state.dot}>
                <span class="sf-dot sf-dot--${state.dot}" aria-hidden="true"><span class="sf-dot-item"></span></span>
                <span>${state.word}</span></span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    }

    if (column.list === 'fact') {
      const fact = context.component.listFact(column, row);
      return fact ? renderFactBadge(fact) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    } // A boolean the host lets this person write is a checkbox in the cell;
    // it is disabled while the host answers.


    if (context.component?.cellEditable?.(row, column)) {
      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-checkbox size=${context.size === '1/2' ? '1/2' : '1'} data-cell-edit=${column.key}
                ?checked=${value === true} ?disabled=${context.component.cellPending(row, column)}
                aria-label=${column.label ?? column.key}
                @change=${event => context.component.setCellValue(row, column, Boolean(event.target?.checked ?? event.detail?.checked))}></sf-checkbox>`;
    }

    if (column.component) {
      if (value !== null && typeof value !== "undefined" && (!Array.isArray(value) || value.length)) {
        return renderCellItem(value, context.component);
      }

      if (column.key === "settings" && (!value || Array.isArray(value) && !value.length)) {
        return renderComponent({
          type: "button-icon",
          props: {
            size: "1",
            appearance: "ghost",
            scheme: "on-surface",
            icon: "menu",
            ariaLabel: context.component.text('menuLabel'),
            value: "menu"
          }
        }, context.component);
      }

      return renderComponent(column.rowComponent || column.component, context.component);
    }

    if (value === null || typeof value === "undefined") {
      return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    } // A long text -- a description, a note -- is one line in a row, cut
    // with an ellipsis; the whole of it is in the title for the pointer and
    // in the text for a screen reader. Wrapped, one description made its row
    // three lines tall in a list of one-line rows (owner, 2026-10-13).


    if (LONG_TEXT_TYPES.has(column.propertyType ?? column.property_type ?? column.type) && (typeof value === "string" || typeof value === "number")) {
      const text = context.component?.cellText?.(column, value) ?? String(value);
      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-cell-clip" title=${text}>${text}</span>`;
    } // The renderer set is asked before the shapes below, because a typed
    // cell's value is often an object -- a user or a related record arrives
    // as {value, label, href} -- and the object branch would render nothing
    // for it: it looks for a component the host put there. A cell that does
    // carry the host's own component still wins, which is the check here.


    const carriesHostComponent = typeof value === "object" && !Array.isArray(value) && Boolean(value.component?.type);

    if (!carriesHostComponent) {
      const typed = context.component?.cellValue?.(column, value);

      if (typed !== null && typeof typed !== "undefined") {
        // Badges and tags from the renderer set wrap onto the next line,
        // as the host's own values do: this branch drew them in one
        // line that ran out of the cell (owner, 2026-10-12).
        if (Array.isArray(typed)) {
          // A person -- the avatar, then the name -- stays on one
          // line: wrapping put the avatar above a two-line name. The
          // name wraps beside it instead.
          if (typed[0]?.component?.type === 'avatar') {
            return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <div class="flex flex-nowrap items-cross-center gap-1/3">
                                ${renderCellItem(typed[0], context.component)}
                                <span style="min-inline-size: 0">
                                    ${typed.slice(1).map(item => renderCellItem(item, context.component))}
                                </span>
                            </div>
                        `;
          }

          return renderCellValues(typed, context.component);
        }

        const datetime = typeof typed === "string" ? context.component?.cellDateTime?.(column, value) : "";
        if (datetime) return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<time datetime=${datetime}>${typed}</time>`;
        return renderCellItem(typed, context.component);
      }
    }

    if (Array.isArray(value)) {
      if (column.key === 'actions') {
        value = value.filter(el => {
          const {
            actions
          } = state;
          const actionId = el.id || el.component?.props?.value;
          const action = actions.find(action => action.id === actionId); // The host's own actions (its row_actions) live in the row
          // menu: a page has a dozen of them, which drawn in a row of
          // buttons wrapped it to three lines.

          if (el.inline === false) return false;
          return action?.visible ?? true;
        });
      } // Several values -- badges for each language, tags for each choice
      // -- wrap onto the next line when the column is narrower than
      // they are, instead of running out of the cell under the next one.
      // The row of actions stays on one line: it is sized for it.


      if (column.key === 'actions') {
        // A row's buttons stand in the row a person is on -- under the
        // pointer, with the focus, or current -- and the column keeps its
        // width in the others (owner, 2026-10-15): drawn in every row they
        // were most of a page's elements.
        if (!context.component.actionsShownFor?.(row)) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
        return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <div class="sf-table-row-actions flex items-cross-center gap-1/3">
                        ${value.map(item => renderCellItem(item, context.component))}
                    </div>
                `;
      }

      return renderCellValues(value, context.component);
    }

    if (typeof value === "object") {
      return renderCellItem(value, context.component);
    } // Plain text stops at three lines with an ellipsis: a long description
    // in a list made one row as tall as the screen (owner, 2026-10-12). The
    // whole text is the record's, and a long one reads in full on hover.


    const text = String(value);
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-cell-text" title=${text.length > 80 ? text : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>${text}</span>`;
  } // The totals at the foot (owner decision C296, q-totals B): a row for the
  // page and one for everything under the filter, each when the host gives
  // it; the numbers are the host's (totals), drawn as their cells are, in
  // the columns marked `total`; the words stand in the first data column.


  function renderFoot() {
    const component = context.component;
    const totals = component.totals;
    if (!totals || resolvedDataState(context) !== 'populated') return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    const columns = component.getColumns?.() || [];
    const sides = [['page', 'totalsPage'], ['all', 'totalsAll']].filter(([side]) => totals[side]);
    const marked = columns.filter(column => column?.total === true);
    if (!sides.length || !marked.length) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
    const labelAt = columns.findIndex(column => column?.key && !SYSTEM_COLUMNS.has(column.key) && !column.system && column.total !== true);
    return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<tfoot class="sf-table-totals">${sides.map(([side, word]) => (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<tr data-sf-totals=${side}>${columns.map((column, index) => {
      const sticky = component.getStickyCellStyle(columns, index) || lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
      if (index === labelAt) return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<th scope="row" data-key=${column.key} style=${sticky}>${component.text(word)}</th>`;
      const value = column.total === true ? totals[side]?.[column.key] : undefined;
      if (value === undefined || value === null || value === '') return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<td data-key=${column.key} style=${sticky}></td>`;
      const typed = component.cellValue?.(column, value) ?? String(value);
      return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<td data-key=${column.key} data-sf-cell=${cellKind(component, column, columns)} style=${sticky}>${typeof typed === 'string' || typeof typed === 'number' ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-table-cell-bare">${typed}</span>` : renderCellItem(typed, component)}</td>`;
    })}</tr>`)}</tfoot>`;
  } // The name is the table's (or the list's) alone: a named section is a
  // region, and the data view around the table names its own region by the
  // list's heading, so a second one of the same name only repeats it to a
  // screen reader (Larena storage review, 2026-10-28).


  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
        <section
                class="sf-table ${context.list ? 'sf-table--list' : ''} min-w-0 flex flex-col gap-1/3 flex-1 min-h-0 ${context.rootClass || ""}"
                style=${context.rootStyle || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                data-sf-instance=${context.component.getInstanceId()}
                data-state=${resolvedDataState(context)}
                aria-busy=${resolvedDataState(context) === 'loading' ? 'true' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        >
            ${context.toolbar ? context.compactToolbar ? renderListToolbar(context) : renderToolbar(context) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
            ${context.component.renderBulkActions()}

            <div class="table-wrap min-w-0 max-w-full flex flex-col flex-1 min-h-0">
                <div class="sf-table-scroll min-h-0 min-w-0 overflow-auto flex-1 relative"
                     ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__.ref)(context.component.refs.scroll)}
                     data-sf-vertical-scroll=${context.verticalScroll}>
                    <div class="sf-table-resize-guide" aria-hidden="true" hidden
                         ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__.ref)(context.component.refs.resizeGuide)}></div>
                    ${resolvedDataState(context) === 'loading' && (context.component.getTableData()?.rows?.length ?? 0) > 0 ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <div class="sf-table-busy" role="status">
                                <!-- The words are the spinner's label, kept for a screen reader
                                     and hidden from the eye (label-hidden, owner decision C138,
                                     SP-06): the spinner keeps one name mechanism and the status
                                     region says them once. -->
                                <sf-spinner size=${context.controlSize ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing} label=${context.loadingText} label-hidden></sf-spinner>
                            </div>
                        ` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    ${context.list ? renderList() : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                    <table
                            ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__.ref)(context.component.refs.table)}
                            id=${context.rowAreaId}
                            class="table border-separate border-spacing-0 min-w-full ${context.keyedNarrow ? 'sf-table-keyed' : `${context.component?.contentSized ? 'sf-table-content-sized' : 'w-max'} table-fixed`} transition"
                            role=${context.component.isTree?.() ? 'treegrid' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-label=${context.ariaLabel || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                            aria-rowcount=${context.component.ariaRowCount?.() ?? context.component.windowRowCount?.() ?? lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                    >
                        ${renderColgroup(context)}
                        ${renderHead(context)}
                        ${renderBody(context)}
                        ${renderFoot()}
                    </table>`}
                </div>
                ${context.verticalScroll === 'page' && !context.list ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<div class="sf-table-rail" aria-hidden="true" hidden ${(0,lit_directives_ref_js__WEBPACK_IMPORTED_MODULE_4__.ref)(context.component.refs.rail)}>
                            <div class="sf-table-rail-track"></div></div>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                ${context.component.renderBulkActions('after')}

                ${context.pagin ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
                            <sf-pagination
                                    current="1"
                                    total=${String(context.paginationTotal)}
                                    bottom="true"
                                    show-action-for-all
                                    page-size=${String(context.paginationPageSize)}
                                    page-sizes=${context.pageSizes}
                                    show-page-size
                                    top-class="content-main-center"
                                    main-class="items-cross-center content-main-between"
                                    bottom-class="items-cross-center gap-2"
                            ></sf-pagination>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
            </div>
        </section>
        ${state.contextMenu?.open ? context.component.renderContextMenu(context.state.contextMenu) : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
        <!-- A demo panel used to stand here, open to nothing, titled after a
             ticket. Closed, it still took a box of its own, and in a card that
             spaces its parts that box became the gap above Show more: three
             spacings instead of one. -->
    `;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "5bfdd9ec12a1"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   normalizeTableLinkCell: () => (/* binding */ normalizeTableLinkCell),
/* harmony export */   normalizeTableLinkHref: () => (/* binding */ normalizeTableLinkHref)
/* harmony export */ });
const SAFE_RELATIVE_PREFIXES = ["/", "./", "../", "#", "?"];
function normalizeTableLinkHref(value) {
  if (typeof value !== "string") {
    return null;
  }

  const href = value.trim();

  if (!href) {
    return null;
  }

  if (href.startsWith("//")) {
    return null;
  }

  if (SAFE_RELATIVE_PREFIXES.some(prefix => href.startsWith(prefix))) {
    return href;
  }

  try {
    const url = new URL(href);
    return url.protocol === "http:" || url.protocol === "https:" ? href : null;
  } catch {
    return null;
  }
}
function normalizeTableLinkCell(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return null;
  }

  const text = value.text === null || typeof value.text === "undefined" ? "" : String(value.text);
  const subtext = value.subtext === null || typeof value.subtext === "undefined" ? null : String(value.subtext);
  return {
    href: normalizeTableLinkHref(value.href),
    subtext,
    text
  };
}

/***/ },

/***/ "68a281c549b5"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ },

/***/ "d3818183b14c"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("deprecations", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("deprecations", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "5b7d7695b41b"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("element-manifest", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("element-manifest", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "18003344cff0"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("layer-stack", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("layer-stack", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "80c480e5196c"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directive-helpers.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directive-helpers.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "0816a19adc72"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directive.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directive.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "9d9903b87148"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directives/keyed.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directives/keyed.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "8137feb490e0"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directives/ref.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directives/ref.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "efa66f8927d1"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directives/repeat.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directives/repeat.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "073f05ff1a81"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directives/unsafe-html.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directives/unsafe-html.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "2a080a730149"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "bf0cea966575"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("open-surface-mark", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("open-surface-mark", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "43090d1c8307"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("page-language", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("page-language", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "116963e5e31b"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("position", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("position", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "deb1a4d61565"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("smart-base", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("smart-base", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "e19611ff78cb"
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PASTE_BLOCKS: () => (/* binding */ PASTE_BLOCKS),
/* harmony export */   RICH_TEXT_BLOCKS: () => (/* binding */ RICH_TEXT_BLOCKS),
/* harmony export */   RICH_TEXT_ELEMENTS: () => (/* binding */ RICH_TEXT_ELEMENTS),
/* harmony export */   RICH_TEXT_PROFILES: () => (/* binding */ RICH_TEXT_PROFILES),
/* harmony export */   RICH_TEXT_SCHEMES: () => (/* binding */ RICH_TEXT_SCHEMES),
/* harmony export */   cleanTree: () => (/* binding */ cleanTree),
/* harmony export */   decodeEntities: () => (/* binding */ decodeEntities),
/* harmony export */   parseHtml: () => (/* binding */ parseHtml),
/* harmony export */   plainText: () => (/* binding */ plainText),
/* harmony export */   richTextFromPlainText: () => (/* binding */ richTextFromPlainText),
/* harmony export */   richTextHref: () => (/* binding */ richTextHref),
/* harmony export */   sanitizeRichText: () => (/* binding */ sanitizeRichText),
/* harmony export */   serialize: () => (/* binding */ serialize),
/* harmony export */   treeFromDom: () => (/* binding */ treeFromDom)
/* harmony export */ });
// The HTML subset of sf-rich-text: what the value may hold, and how anything
// else is brought into it. Larena stores page text as a property of type
// html@1, and this module is that type's rule in the browser: the editor
// cleans the value it is given, every paste and drop, and its own DOM after
// every edit and command, through the one function here.
//
// The subset:
//
//   p  h2  h3  h4  strong  em  a[href]  ul  ol  li  blockquote  br
//
// - no attribute is kept but href on <a>;
// - href is kept for https:, mailto: and tel: URLs and for a site path
//   ("/docs/a"), judged after removing control characters and white space, so
//   "java\tscript:" does not pass; "//host" and "/\host" leave the site and
//   are not kept; a link whose href is not kept becomes its text;
// - script, style and the other containers whose content is not text for a
//   reader (DROPPED) go with their content; any other element is unwrapped,
//   and its text stays; one that stands as a block (div, section, table, a
//   cell, h1, pre) still separates its text from its neighbours';
// - b and i are strong and em, and a span whose style is bold or italic is
//   too (a word processor's paste); a b whose style says normal is not;
// - text outside a block is wrapped in p, a block inside a paragraph splits
//   it, a block inside a list item becomes a line of it (br), a list holds
//   only items, adjacent lists of one kind are one list;
// - the value has no empty block, no line break at a block's edge and no
//   white space between blocks; an editor with no text is "".
//
// Two readers feed one cleaner: `treeFromDom` reads a DOM (the editor, or a
// paste parsed by the browser in an inert <template>), `parseHtml` reads a
// string without a DOM (a server, a test). Neither ever assigns the input to
// a live element. What comes out is written by `serialize` from the cleaned
// model, every text escaped, so it holds nothing the subset does not allow
// whatever the reader understood.
//
// No imports and no state: the element and the contract tests use the same
// functions.
//
// The paste profile (simai/ui-source#66). html@1 is a stored type, so it does
// not grow: a value never holds pre or table. A structured-content editor
// reads a paste with cleanTree(tree, {profile: 'paste'}), which is html@1
// plus two blocks the profile maps to its own types instead of flattening
// them into paragraphs:
//
//   {type: 'pre', text}            a code block: its text with its line
//                                  breaks and indentation (-> content.code)
//   {type: 'table', caption, rows} a simple table: rows of {head, cells},
//                                  each cell {header, leaves} with the
//                                  subset's inline leaves (-> content.table)
//
// Everything inside them is cleaned by the same rule: the same marks, the
// same href check, DROPPED goes with its content. A pre or a table inside a
// list item, and a table inside a cell, are read as html@1 reads them.
// serialize writes the two in html@1 terms (lines of a paragraph, a
// paragraph per cell), so whatever comes out of it is still the subset.
//
// The module lives in the core runtime since content.html 1.0.0: the
// Composition renderer sanitises a content.html block through it at render,
// so a page that only renders a Document needs no Smart component.
// src/smart/input-rich/js/rich-text-html.mjs re-exports it for sf-rich-text and
// the field renderers; there is one rule, here.

const RICH_TEXT_ELEMENTS = Object.freeze(['p', 'h2', 'h3', 'h4', 'strong', 'em', 'a', 'ul', 'ol', 'li', 'blockquote', 'br']);
const RICH_TEXT_BLOCKS = Object.freeze(['p', 'h2', 'h3', 'h4']);
const RICH_TEXT_SCHEMES = Object.freeze(['https:', 'mailto:', 'tel:']);
// The profiles cleanTree reads by: html@1 itself, and the paste profile of a
// structured-content editor, which keeps PASTE_BLOCKS as blocks of their own.
const RICH_TEXT_PROFILES = Object.freeze(['html', 'paste']);
const PASTE_BLOCKS = Object.freeze(['pre', 'table']);

// Dropped with everything inside: their content is code, a document's head,
// a drawing, or a control's own data, not text for a reader.
const DROPPED = new Set([
  'script', 'style', 'template', 'head', 'title', 'meta', 'link', 'base', 'noscript',
  'iframe', 'frame', 'frameset', 'noembed', 'noframes', 'object', 'embed', 'applet',
  'svg', 'math', 'canvas', 'video', 'audio', 'img', 'picture', 'source', 'track',
  'input', 'select', 'textarea', 'xmp', 'plaintext',
]);

// Elements off the subset that stand as blocks: unwrapped, but their text is
// not run together with the text around them.
const BREAKING = new Set([
  'address', 'article', 'aside', 'body', 'caption', 'center', 'dd', 'details', 'dialog', 'dir', 'div',
  'dl', 'dt', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h5', 'h6', 'header',
  'hgroup', 'hr', 'html', 'legend', 'listing', 'main', 'menu', 'nav', 'optgroup', 'option', 'pre',
  'section', 'summary', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr',
]);

const LISTS = new Set(['ul', 'ol']);
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
// Raw text: what follows the start tag up to its end tag is not markup.
const RAW = new Set(['script', 'style', 'textarea', 'title', 'xmp', 'iframe', 'noembed', 'noframes', 'noscript']);
// Where an implied </p> stops looking for the paragraph (the parser's button scope).
const P_SCOPE = new Set(['td', 'th', 'table', 'caption', 'button']);

// C0 controls, DEL and C1 controls: a browser ignores them inside a scheme.
// eslint-disable-next-line no-control-regex -- matching control characters is the point
const CONTROLS = /[\u0000-\u001f\u007f-\u009f]/gu;
// ...and white space, which a browser also skips around and inside a scheme.
// eslint-disable-next-line no-control-regex -- matching control characters is the point
const CONTROLS_AND_SPACE = /[\u0000- \u007f-\u009f\u00a0\u1680\u2000-\u200b\u2028\u2029\u202f\u205f\u3000\ufeff]/gu;
const HREF_MAX = 2048;

/**
 * The href sf-rich-text keeps, or null: https:, mailto: and tel: URLs and a
 * path on the site ("/docs/a", "/docs?q=1#a"). "//host", "/\host", http:,
 * javascript:, data: and anything else are not kept.
 * @param {unknown} value
 * @returns {string|null}
 */
function richTextHref(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > HREF_MAX) return null;
  const compact = trimmed.replace(CONTROLS_AND_SPACE, '');
  if (!compact) return null;
  if (compact.startsWith('/')) {
    // A site path, but not "//host" or "/\host", which leave the site.
    if (/^\/[/\\]/u.test(compact)) return null;
    const path = trimmed.replace(CONTROLS, '');
    return /^\/[/\\]/u.test(path) ? null : path;
  }
  const scheme = /^([a-z][a-z0-9+.-]*):/iu.exec(compact)?.[1]?.toLowerCase();
  if (!scheme || !RICH_TEXT_SCHEMES.includes(`${scheme}:`)) return null;
  let url;
  try {
    url = new globalThis.URL(trimmed.replace(CONTROLS, ''));
  } catch {
    return null;
  }
  if (url.protocol !== `${scheme}:`) return null;
  if (url.protocol === 'https:' && !url.hostname) return null;
  if (url.protocol !== 'https:' && url.href.length <= url.protocol.length) return null;
  return url.href;
}

// ---------------------------------------------------------------- entities

const NAMED = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: '\u00a0', shy: '\u00ad',
  hellip: '\u2026', mdash: '\u2014', ndash: '\u2013', minus: '\u2212', laquo: '\u00ab', raquo: '\u00bb',
  lsquo: '\u2018', rsquo: '\u2019', sbquo: '\u201a', ldquo: '\u201c', rdquo: '\u201d', bdquo: '\u201e',
  bull: '\u2022', middot: '\u00b7', copy: '\u00a9', reg: '\u00ae', trade: '\u2122', deg: '\u00b0',
  times: '\u00d7', divide: '\u00f7', plusmn: '\u00b1', euro: '\u20ac', pound: '\u00a3', yen: '\u00a5',
  cent: '\u00a2', sect: '\u00a7', para: '\u00b6', thinsp: '\u2009', ensp: '\u2002', emsp: '\u2003',
  zwj: '\u200d', zwnj: '\u200c', larr: '\u2190', rarr: '\u2192', uarr: '\u2191', darr: '\u2193',
  numero: '\u2116', prime: '\u2032', Prime: '\u2033',
};

function decodeEntities(text) {
  return String(text).replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z][a-z0-9]*);?/giu, (whole, body) => {
    if (body[0] === '#') {
      const code = body[1] === 'x' || body[1] === 'X' ? Number.parseInt(body.slice(2), 16) : Number.parseInt(body.slice(1), 10);
      if (!Number.isFinite(code) || code <= 0 || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return '\ufffd';
      return String.fromCodePoint(code);
    }
    return Object.hasOwn(NAMED, body) && whole.endsWith(';') ? NAMED[body] : whole;
  });
}

// ---------------------------------------------------------------- readers

// The raw tree both readers give: {type: 'element', name, attrs, children}
// and {type: 'text', value}. Only href and style are read from attributes.

/**
 * Reads an HTML string into the raw tree, without a DOM. Tolerant the way a
 * browser is for what matters here: implied ends of p and li, void elements,
 * raw-text elements, comments, entities in text and attributes.
 * @param {string} html
 */
function parseHtml(html) {
  const source = typeof html === 'string' ? html : '';
  const root = {type: 'element', name: '#root', attrs: {}, children: []};
  const stack = [root];
  const top = () => stack[stack.length - 1];
  const append = (node) => top().children.push(node);
  const appendText = (value) => {
    if (!value) return;
    const last = top().children.at(-1);
    if (last?.type === 'text') last.value += value;
    else append({type: 'text', value});
  };
  const closeTo = (name, stopAt = null) => {
    for (let index = stack.length - 1; index > 0; index -= 1) {
      const open = stack[index].name;
      if (stopAt && stopAt.has(open)) return false;
      if (open === name) {
        stack.length = index;
        return true;
      }
    }
    return false;
  };
  let at = 0;
  const length = source.length;
  while (at < length) {
    const lt = source.indexOf('<', at);
    if (lt < 0) {
      appendText(decodeEntities(source.slice(at)));
      break;
    }
    if (lt > at) appendText(decodeEntities(source.slice(at, lt)));
    at = lt;
    if (source.startsWith('<!--', at)) {
      const end = source.indexOf('-->', at + 4);
      at = end < 0 ? length : end + 3;
      continue;
    }
    const next = source[at + 1] ?? '';
    if (next === '!' || next === '?') {
      const end = source.indexOf('>', at + 2);
      at = end < 0 ? length : end + 1;
      continue;
    }
    if (next === '/') {
      const match = /^<\/([a-z][a-z0-9-]*)[^>]*>?/iu.exec(source.slice(at));
      if (!match) {
        // "</" not followed by a name is a bogus comment.
        const end = source.indexOf('>', at + 2);
        at = end < 0 ? length : end + 1;
        continue;
      }
      at += match[0].length;
      const name = match[1].toLowerCase();
      if (name === 'br') append({type: 'element', name: 'br', attrs: {}, children: []});
      else if (name === 'p' && !closeTo('p', P_SCOPE)) {
        // A </p> without a <p> is an empty paragraph, as a browser reads it.
        append({type: 'element', name: 'p', attrs: {}, children: []});
      } else closeTo(name);
      continue;
    }
    const tag = /^<([a-z][a-z0-9-]*)/iu.exec(source.slice(at));
    if (!tag) {
      appendText('<');
      at += 1;
      continue;
    }
    at += tag[0].length;
    const name = tag[1].toLowerCase();
    const attrs = {};
    let selfClosing = false;
    // Attributes, up to the closing ">".
    while (at < length) {
      const space = /^[\s/]+/u.exec(source.slice(at));
      if (space) {
        if (space[0].includes('/') && source[at + space[0].length] === '>') selfClosing = true;
        at += space[0].length;
        continue;
      }
      if (source[at] === '>') {
        at += 1;
        break;
      }
      const attr = /^([^\s/>"'=][^\s/>"'=]*)(?:\s*=\s*(?:"([^"]*)"?|'([^']*)'?|([^\s>]*)))?/u.exec(source.slice(at));
      if (!attr) {
        at += 1;
        continue;
      }
      at += attr[0].length;
      const key = attr[1].toLowerCase();
      if (!Object.hasOwn(attrs, key)) attrs[key] = decodeEntities(attr[2] ?? attr[3] ?? attr[4] ?? '');
    }
    const element = {type: 'element', name, attrs, children: []};
    if (name === 'li') closeTo('li', LISTS);
    // A block start ends an open paragraph (the browser's implied </p>).
    if (RICH_TEXT_BLOCKS.includes(name) || LISTS.has(name) || name === 'blockquote' || BREAKING.has(name)) closeTo('p', P_SCOPE);
    append(element);
    if (name === 'plaintext') {
      at = length;
      break;
    }
    if (RAW.has(name)) {
      const close = new RegExp(`</${name}[\\s/>]`, 'iu').exec(source.slice(at));
      const end = close ? at + close.index : length;
      if (name === 'textarea' || name === 'title') element.children.push({type: 'text', value: decodeEntities(source.slice(at, end))});
      else element.children.push({type: 'text', value: source.slice(at, end)});
      const gt = close ? source.indexOf('>', end) : -1;
      at = gt < 0 ? length : gt + 1;
      continue;
    }
    if (!VOID.has(name) && !selfClosing) stack.push(element);
  }
  return root;
}

const HTML_NS = 'http://www.w3.org/1999/xhtml';

/**
 * Reads a DOM subtree (an element, a fragment, a template's content) into the
 * raw tree. Elements outside the HTML namespace are dropped.
 * @param {Node} node
 */
function treeFromDom(node) {
  const read = (current) => {
    if (current.nodeType === 3) return {type: 'text', value: current.data};
    if (current.nodeType === 11) return {type: 'element', name: '#root', attrs: {}, children: [...current.childNodes].map(read).filter(Boolean)};
    if (current.nodeType !== 1) return null;
    if (current.namespaceURI && current.namespaceURI !== HTML_NS) return null;
    const name = current.localName;
    if (DROPPED.has(name)) return null;
    const attrs = {};
    const href = current.getAttribute('href');
    if (href !== null) attrs.href = href;
    const style = current.getAttribute('style');
    if (style !== null) attrs.style = style;
    const children = name === 'template' ? [] : [...current.childNodes].map(read).filter(Boolean);
    return {type: 'element', name, attrs, children};
  };
  const tree = read(node);
  if (!tree || tree.type !== 'element') return {type: 'element', name: '#root', attrs: {}, children: tree ? [tree] : []};
  return {...tree, name: '#root'};
}

// ---------------------------------------------------------------- the cleaner

// What a style says of the marks: {strong: true|false|undefined, em: ...}.
function styleMarks(style) {
  const out = {};
  if (!style) return out;
  const weight = /(?:^|;)\s*font-weight\s*:\s*([^;!]+)/iu.exec(style)?.[1]?.trim().toLowerCase();
  if (weight) {
    if (weight === 'bold' || weight === 'bolder' || Number(weight) >= 600) out.strong = true;
    else if (weight === 'normal' || weight === 'lighter' || Number(weight) < 600) out.strong = false;
  }
  const fontStyle = /(?:^|;)\s*font-style\s*:\s*([^;!]+)/iu.exec(style)?.[1]?.trim().toLowerCase();
  if (fontStyle) {
    if (fontStyle === 'italic' || fontStyle.startsWith('oblique')) out.em = true;
    else if (fontStyle === 'normal') out.em = false;
  }
  return out;
}

function marksOf(element, marks) {
  const next = {...marks};
  if (element.name === 'strong' || element.name === 'b') next.strong = true;
  if (element.name === 'em' || element.name === 'i') next.em = true;
  const styled = styleMarks(element.attrs?.style);
  if (styled.strong !== undefined) next.strong = styled.strong;
  if (styled.em !== undefined) next.em = styled.em;
  return next;
}

// A leaf of inline content: {kind: 'text', value, strong, em, href} or
// {kind: 'br', strong, em, href}.
const leaf = (kind, value, context) => ({kind, value, strong: Boolean(context.marks.strong), em: Boolean(context.marks.em), href: context.href || null});

// A flow (the root, a quote) collects blocks; a list item collects its own
// content. Text comes in as leaves into the current run; a block ends the
// run.
class Flow {
  constructor(kind) {
    this.kind = kind;
    this.blocks = [];
    this.run = [];
    this.types = ['p'];
    this.starts = [0];
    this.needBreak = false;
  }

  inline(item) {
    if (this.kind === 'item' && this.needBreak && this.run.length > 0) {
      if (!(item.kind === 'text' && !item.value.trim())) {
        this.run.push({kind: 'br', strong: false, em: false, href: null});
        this.needBreak = false;
      }
    }
    this.run.push(item);
  }

  flush() {
    if (!this.run.length) return;
    if (this.kind === 'item') {
      this.blocks.push({type: 'inline', leaves: this.run});
    } else {
      this.blocks.push({type: this.types[this.types.length - 1], leaves: this.run});
    }
    this.run = [];
  }

  // A paragraph or heading starts (or a block off the subset): the text so
  // far is one block, and what follows belongs to the new one.
  open(type) {
    if (this.kind === 'item') {
      this.needBreak = true;
      return;
    }
    this.flush();
    this.types.push(type);
    this.starts.push(this.blocks.length);
  }

  // keepEmpty: a paragraph or heading of the subset that held nothing is
  // still a block (the editing surface keeps it; the value drops it).
  close(keepEmpty = false) {
    if (this.kind === 'item') {
      this.needBreak = true;
      return;
    }
    const start = this.starts[this.starts.length - 1];
    if (keepEmpty && !this.run.length && this.blocks.length === start) this.blocks.push({type: this.types[this.types.length - 1], leaves: []});
    this.flush();
    if (this.types.length > 1) {
      this.types.pop();
      this.starts.pop();
    }
  }

  block(block) {
    this.flush();
    this.blocks.push(block);
    this.needBreak = false;
  }
}

function walkText(value, flow, context) {
  if (context.pre) {
    const lines = value.replace(/\r\n?/gu, '\n').split('\n');
    lines.forEach((line, index) => {
      if (index > 0) flow.inline(leaf('br', '', context));
      if (line) flow.inline(leaf('text', line.replace(/[\t\f]/gu, ' '), context));
    });
    return;
  }
  const text = value.replace(/[\t\n\r\f ]+/gu, ' ');
  if (!text) return;
  // White space between blocks is formatting of the source, not text.
  if (text === ' ' && !flow.run.length) return;
  flow.inline(leaf('text', text, context));
}

function walkChildren(children, flow, context) {
  for (const child of children) walk(child, flow, context);
}

function walk(node, flow, context) {
  if (node.type === 'text') {
    walkText(node.value, flow, context);
    return;
  }
  const name = node.name;
  if (DROPPED.has(name)) return;
  if (name === 'br') {
    flow.inline(leaf('br', '', context));
    return;
  }
  const inner = {...context, marks: marksOf(node, context.marks)};
  if (name === 'a') {
    const href = richTextHref(node.attrs?.href);
    walkChildren(node.children, flow, href && !context.href ? {...inner, href} : inner);
    return;
  }
  if (RICH_TEXT_BLOCKS.includes(name)) {
    flow.open(name);
    walkChildren(node.children, flow, inner);
    flow.close(true);
    return;
  }
  if (LISTS.has(name)) {
    const list = readList(node, inner, name);
    if (list.items.length) flow.block(list);
    return;
  }
  if (name === 'blockquote') {
    if (flow.kind === 'item') {
      flow.open('p');
      walkChildren(node.children, flow, inner);
      flow.close();
      return;
    }
    const quote = new Flow('flow');
    walkChildren(node.children, quote, inner);
    quote.flush();
    flow.block({type: 'blockquote', blocks: quote.blocks});
    return;
  }
  if (name === 'li') {
    // An item outside a list is a paragraph of its own.
    flow.open('p');
    walkChildren(node.children, flow, inner);
    flow.close();
    return;
  }
  if (context.paste && flow.kind !== 'item' && (name === 'pre' || name === 'listing')) {
    flow.block({type: 'pre', text: preText(node)});
    return;
  }
  if (context.paste && flow.kind !== 'item' && name === 'table') {
    flow.block(readTable(node, inner));
    return;
  }
  if (BREAKING.has(name)) {
    flow.open('p');
    walkChildren(node.children, flow, name === 'pre' || name === 'listing' ? {...inner, pre: true} : inner);
    flow.close();
    return;
  }
  // Any other element: its text, in place.
  walkChildren(node.children, flow, inner);
}

// The text of a pre as it stands: line breaks and indentation kept, a <br> a
// line break, what DROPPED names gone. The newline right after <pre> is the
// markup's, as a browser reads it; trailing blank lines are not code.
function preText(node) {
  const read = (current) => {
    if (current.type === 'text') return current.value;
    if (DROPPED.has(current.name)) return '';
    if (current.name === 'br') return '\n';
    return current.children.map(read).join('');
  };
  return node.children.map(read).join('')
    .replace(/\r\n?/gu, '\n')
    .replace(/\u00a0/gu, ' ')
    .replace(/^\n/u, '')
    .replace(/\s+$/u, '');
}

// A simple table: thead, tbody, tfoot and rows straight in the table, cells
// th and td; a cell's content is inline leaves, its paragraphs and list items
// lines of it. colspan and rowspan are not read: a cell is one cell.
function readTable(node, context) {
  const table = {type: 'table', caption: [], rows: []};
  const readRow = (row, head) => {
    const cells = [];
    for (const cell of row.children) {
      if (cell.type !== 'element' || (cell.name !== 'td' && cell.name !== 'th')) continue;
      const flow = new Flow('item');
      walkChildren(cell.children, flow, {...context, marks: marksOf(cell, context.marks)});
      flow.flush();
      cells.push({header: cell.name === 'th', leaves: flatLeaves(flow.blocks)});
    }
    if (cells.length) table.rows.push({head, cells});
  };
  const readSection = (section, head) => {
    for (const child of section.children) {
      if (child.type === 'element' && child.name === 'tr') readRow(child, head);
    }
  };
  for (const child of node.children) {
    if (child.type !== 'element') continue;
    if (child.name === 'caption') {
      const flow = new Flow('item');
      walkChildren(child.children, flow, context);
      flow.flush();
      table.caption = flatLeaves(flow.blocks);
    } else if (child.name === 'thead') readSection(child, true);
    else if (child.name === 'tbody' || child.name === 'tfoot') readSection(child, false);
    else if (child.name === 'tr') readRow(child, false);
  }
  return table;
}

// An item's parts as one line of leaves: a nested list's items are lines too.
function flatLeaves(parts) {
  const out = [];
  const add = (leaves) => {
    if (!leaves.length) return;
    if (out.length) out.push({kind: 'br', strong: false, em: false, href: null});
    out.push(...leaves);
  };
  const visit = (part) => {
    if (part.type === 'inline') add(part.leaves);
    else for (const item of part.items) item.children.forEach(visit);
  };
  parts.forEach(visit);
  return out;
}

function readItem(node, context) {
  const flow = new Flow('item');
  walkChildren(node.children, flow, context);
  flow.flush();
  return {children: flow.blocks};
}

function readList(node, context, type) {
  const list = {type, items: []};
  let loose = null;
  const endLoose = () => {
    if (loose) {
      loose.flush();
      list.items.push({children: loose.blocks});
      loose = null;
    }
  };
  for (const child of node.children) {
    if (child.type === 'element' && child.name === 'li') {
      endLoose();
      list.items.push(readItem(child, context));
      continue;
    }
    if (child.type === 'element' && LISTS.has(child.name)) {
      endLoose();
      // A list right inside a list (what an indent command leaves) belongs to
      // the item before it.
      const nested = readList(child, {...context, marks: marksOf(child, context.marks)}, child.name);
      if (!nested.items.length) continue;
      const previous = list.items.at(-1);
      if (previous) previous.children.push(nested);
      else list.items.push({children: [nested]});
      continue;
    }
    if (child.type === 'text' && !child.value.trim()) continue;
    if (child.type === 'element' && DROPPED.has(child.name)) continue;
    // Loose content in a list is an item.
    loose ??= new Flow('item');
    walk(child, loose, context);
  }
  endLoose();
  return list;
}

// ---------------------------------------------------------------- tidying

const SPACE = ' ';
const sameFormat = (a, b) => a.strong === b.strong && a.em === b.em && a.href === b.href;

// Inline leaves made canonical: adjacent text of one format joined, runs of
// spaces made one, spaces at the edges and around a line break removed, a link
// with nothing but spaces made text.
//
// The steps run again until a pass changes nothing (2026-11-11 acceptance,
// M2): dropping a space or an empty run makes new neighbours, so one pass left
// "<p>a <em><br>n</em></p>" for the next load-and-save to make
// "<p>a<em><br>n</em></p>". The stored value is the fixed point at once.
function tidyLeaves(leaves, mode) {
  let current = leaves;
  let key = null;
  for (let pass = 0; pass < 64; pass += 1) {
    current = tidyLeavesOnce(current, mode);
    const next = JSON.stringify(current);
    if (next === key) break;
    key = next;
  }
  return current;
}

function tidyLeavesOnce(leaves, mode) {
  const out = [];
  for (const item of leaves) {
    if (item.kind === 'text' && !item.value) continue;
    const last = out.at(-1);
    if (item.kind === 'text' && last?.kind === 'text' && sameFormat(last, item)) {
      last.value += item.value;
    } else {
      out.push({...item});
    }
  }
  // One space between words, whatever the leaves.
  for (let index = 0; index < out.length; index += 1) {
    const item = out[index];
    if (item.kind !== 'text') continue;
    item.value = item.value.replace(/ {2,}/gu, SPACE);
    const previous = out[index - 1];
    if (item.value.startsWith(SPACE) && (!previous || previous.kind === 'br' || (previous.kind === 'text' && previous.value.endsWith(SPACE)))) {
      item.value = item.value.slice(1);
    }
    const next = out[index + 1];
    if (item.value.endsWith(SPACE) && (!next || next.kind === 'br')) item.value = item.value.slice(0, -1);
  }
  let kept = out.filter((item) => item.kind === 'br' || item.value);
  if (mode === 'value') {
    // Edge breaks and edge white space go together, until neither is left: a
    // run of only white space (&nbsp;) at an edge hid the break behind it, so
    // the first pass kept "<p>&nbsp;<br>a</p>" as "<p><br>a</p>" and only the
    // next load-and-save gave "<p>a</p>" (2026-11-10 review, Q6). The value is
    // now what that second pass gave, at once, and cleaning it again keeps it.
    let length = -1;
    while (length !== kept.length) {
      length = kept.length;
      while (kept[0]?.kind === 'br') kept.shift();
      while (kept.at(-1)?.kind === 'br') kept.pop();
      if (kept[0]?.kind === 'text') kept[0].value = kept[0].value.replace(/^[\s\u00a0]+/u, '');
      const end = kept.at(-1);
      if (end?.kind === 'text') end.value = end.value.replace(/[\s\u00a0]+$/u, '');
      kept = kept.filter((item) => item.kind === 'br' || item.value);
    }
  }
  // A link of nothing but spaces is not a link.
  const groups = new Map();
  for (const item of kept) {
    if (!item.href) continue;
    groups.set(item.href, (groups.get(item.href) || '') + (item.kind === 'text' ? item.value : 'x'));
  }
  for (const item of kept) if (item.href && !groups.get(item.href).trim()) item.href = null;
  // Join again: dropping spaces and links may have made neighbours alike.
  const joined = [];
  for (const item of kept) {
    const last = joined.at(-1);
    if (item.kind === 'text' && last?.kind === 'text' && sameFormat(last, item)) last.value += item.value;
    else joined.push(item);
  }
  return joined;
}

const hasText = (leaves) => leaves.some((item) => item.kind === 'text' && item.value.replace(/[\s\u00a0]+/gu, '') !== '');

function tidyItem(item, mode) {
  const children = [];
  for (const part of item.children) {
    if (part.type === 'inline') {
      const leaves = tidyLeaves(part.leaves, mode);
      if (!leaves.length) continue;
      const last = children.at(-1);
      if (last?.type === 'inline') last.leaves = tidyLeaves([...last.leaves, {kind: 'br', strong: false, em: false, href: null}, ...leaves], mode);
      else children.push({type: 'inline', leaves});
    } else {
      const list = tidyList(part, mode);
      if (!list) continue;
      const last = children.at(-1);
      if (last && last.type === list.type) last.items.push(...list.items);
      else children.push(list);
    }
  }
  if (mode === 'value') {
    const filtered = children.filter((part) => part.type !== 'inline' || hasText(part.leaves));
    return filtered.length ? {children: filtered} : null;
  }
  if (!children.length || children[0].type !== 'inline') children.unshift({type: 'inline', leaves: [{kind: 'br', strong: false, em: false, href: null}]});
  return {children};
}

function tidyList(list, mode) {
  const items = list.items.map((item) => tidyItem(item, mode)).filter(Boolean);
  return items.length ? {type: list.type, items} : null;
}

function tidyBlocks(blocks, mode) {
  const out = [];
  for (const block of blocks) {
    let tidy = null;
    if (block.type === 'blockquote') {
      const inner = tidyBlocks(block.blocks, mode);
      if (inner.length) tidy = {type: 'blockquote', blocks: inner};
      else if (mode === 'editor') tidy = {type: 'blockquote', blocks: [{type: 'p', leaves: [{kind: 'br', strong: false, em: false, href: null}]}]};
    } else if (LISTS.has(block.type)) {
      tidy = tidyList(block, mode);
    } else if (block.type === 'pre') {
      if (block.text.trim()) tidy = {type: 'pre', text: block.text};
    } else if (block.type === 'table') {
      // A row with no text in any cell is not kept, as an empty paragraph is not.
      const rows = block.rows.map((row) => ({head: row.head, cells: row.cells.map((cell) => ({header: cell.header, leaves: tidyLeaves(cell.leaves, 'value')}))}))
        .filter((row) => row.cells.some((cell) => hasText(cell.leaves)));
      if (rows.length) tidy = {type: 'table', caption: tidyLeaves(block.caption, 'value'), rows};
    } else {
      const leaves = tidyLeaves(block.leaves, mode);
      if (mode === 'value') {
        if (hasText(leaves)) tidy = {type: block.type, leaves};
      } else {
        tidy = {type: block.type, leaves: leaves.length ? leaves : [{kind: 'br', strong: false, em: false, href: null}]};
      }
    }
    if (!tidy) continue;
    const last = out.at(-1);
    // Adjacent lists of one kind are one list.
    if (last && LISTS.has(tidy.type) && last.type === tidy.type) last.items.push(...tidy.items);
    else out.push(tidy);
  }
  return out;
}

/**
 * The raw tree cleaned into blocks.
 * mode "value": the stored form -- no empty block, no break at an edge.
 * mode "editor": what the editing surface holds -- an empty block keeps a
 *   <br> so the caret has a line, breaks the person typed stay.
 */
function cleanTree(tree, {mode = 'value', profile = 'html'} = {}) {
  if (!RICH_TEXT_PROFILES.includes(profile)) throw new TypeError(`rich_text_profile_unknown: ${profile}`);
  const flow = new Flow('flow');
  walkChildren(tree.children ?? [], flow, {marks: {}, href: null, pre: false, paste: profile === 'paste'});
  flow.flush();
  const blocks = tidyBlocks(flow.blocks, mode);
  if (mode === 'editor' && !blocks.length) return [{type: 'p', leaves: [{kind: 'br', strong: false, em: false, href: null}]}];
  return blocks;
}

// ---------------------------------------------------------------- writing

const escapeText = (text) => text.replace(/&/gu, '&amp;').replace(/</gu, '&lt;').replace(/>/gu, '&gt;').replace(/\u00a0/gu, '&nbsp;');
const escapeAttribute = (text) => text.replace(/&/gu, '&amp;').replace(/"/gu, '&quot;').replace(/</gu, '&lt;').replace(/>/gu, '&gt;').replace(/\u00a0/gu, '&nbsp;');

// Leaves to markup, nested a > strong > em, each run of one format once.
function writeLeaves(leaves) {
  const writeGroup = (items, level) => {
    let out = '';
    let at = 0;
    const key = ['href', 'strong', 'em'][level];
    while (at < items.length) {
      const value = key ? items[at][key] : null;
      let end = at + 1;
      while (end < items.length && key && items[end][key] === value) end += 1;
      const group = items.slice(at, end);
      if (!key) {
        out += group.map((item) => (item.kind === 'br' ? '<br>' : escapeText(item.value))).join('');
      } else if (key === 'href' && value) {
        out += `<a href="${escapeAttribute(value)}">${writeGroup(group, level + 1)}</a>`;
      } else if (key !== 'href' && value) {
        out += `<${key}>${writeGroup(group, level + 1)}</${key}>`;
      } else {
        out += writeGroup(group, level + 1);
      }
      at = end;
    }
    return out;
  };
  return writeGroup(leaves, 0);
}

function writeList(list) {
  return `<${list.type}>${list.items.map((item) => `<li>${item.children.map((part) => (part.type === 'inline' ? writeLeaves(part.leaves) : writeList(part))).join('')}</li>`).join('')}</${list.type}>`;
}

/** Cleaned blocks to the HTML string. */
function serialize(blocks) {
  return blocks.map((block) => {
    if (block.type === 'blockquote') return `<blockquote>${serialize(block.blocks)}</blockquote>`;
    if (LISTS.has(block.type)) return writeList(block);
    // The paste profile's blocks in html@1 terms: never a pre or a table.
    if (block.type === 'pre') {
      const leaves = block.text.split('\n').flatMap((line, index) => [
        ...(index ? [{kind: 'br', strong: false, em: false, href: null}] : []),
        {kind: 'text', value: line.replace(/[\t\f]/gu, ' '), strong: false, em: false, href: null},
      ]);
      return `<p>${writeLeaves(tidyLeaves(leaves, 'value'))}</p>`;
    }
    if (block.type === 'table') {
      const cells = [{leaves: block.caption}, ...block.rows.flatMap((row) => row.cells)];
      return cells.filter((cell) => hasText(cell.leaves)).map((cell) => `<p>${writeLeaves(cell.leaves)}</p>`).join('');
    }
    return `<${block.type}>${writeLeaves(block.leaves)}</${block.type}>`;
  }).join('');
}

/** The text of cleaned blocks, for counting and emptiness. */
function plainText(html) {
  const blocks = cleanTree(parseHtml(html), {mode: 'value'});
  const text = (leaves) => leaves.map((item) => (item.kind === 'br' ? '\n' : item.value)).join('');
  const list = (block) => block.items.map((item) => item.children.map((part) => (part.type === 'inline' ? text(part.leaves) : list(part))).join('\n')).join('\n');
  const all = (items) => items.map((block) => (block.type === 'blockquote' ? all(block.blocks) : LISTS.has(block.type) ? list(block) : text(block.leaves))).join('\n\n');
  return all(blocks);
}

/**
 * Untrusted HTML into the subset. With a document (the browser) the string
 * is parsed by the browser in an inert <template>; without one, by
 * parseHtml. A DOM node may be given instead of a string.
 * @param {string|Node|null|undefined} input
 * @param {{mode?: 'value'|'editor', document?: Document|null}} [options]
 * @returns {string}
 */
function sanitizeRichText(input, {mode = 'value', document: documentRef} = {}) {
  let tree;
  if (input && typeof input === 'object' && typeof input.nodeType === 'number') {
    tree = treeFromDom(input);
  } else {
    const html = typeof input === 'string' ? input : '';
    const doc = documentRef === undefined ? globalThis.document : documentRef;
    if (html && doc?.createElement) {
      const template = doc.createElement('template');
      template.innerHTML = html;
      tree = treeFromDom(template.content);
    } else {
      tree = parseHtml(html);
    }
  }
  return serialize(cleanTree(tree, {mode}));
}

/**
 * Plain text into the subset: paragraphs split on blank lines, a single line
 * break a <br>.
 * @param {string} text
 * @param {{mode?: 'value'|'editor'}} [options]
 */
function richTextFromPlainText(text, {mode = 'value'} = {}) {
  const source = String(text ?? '').replace(/\r\n?/gu, '\n');
  const blocks = source.split(/\n[ \t\f\v\u00a0]*\n+/u).map((paragraph) => {
    const leaves = [];
    paragraph.split('\n').forEach((line, index) => {
      if (index > 0) leaves.push({kind: 'br', strong: false, em: false, href: null});
      const value = line.replace(/[\t\f\v ]+/gu, ' ');
      if (value) leaves.push({kind: 'text', value, strong: false, em: false, href: null});
    });
    return {type: 'p', leaves};
  });
  return serialize(tidyBlocks(blocks, mode));
}


/***/ },

/***/ "354525e80715"
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   files: () => (/* binding */ files)
/* harmony export */ });
/* harmony import */ var _en_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f050502c25f8");
// Written by scripts/build-language-packs.mjs from src/core/lang/built-in.json
// (owner decision C282); do not edit. The words this bundle carries: the
// built-in languages' (en); every other language comes from
// a language file (core/lang/<code>.js or its parts).


const files = { en: { runtime: _en_json__WEBPACK_IMPORTED_MODULE_0__.runtime } };

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({ en: _en_json__WEBPACK_IMPORTED_MODULE_0__.runtime });


/***/ },

/***/ "4f56033a1eae"
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PASTE_BLOCKS: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.PASTE_BLOCKS),
/* harmony export */   RICH_TEXT_BLOCKS: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.RICH_TEXT_BLOCKS),
/* harmony export */   RICH_TEXT_ELEMENTS: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.RICH_TEXT_ELEMENTS),
/* harmony export */   RICH_TEXT_PROFILES: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.RICH_TEXT_PROFILES),
/* harmony export */   RICH_TEXT_SCHEMES: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.RICH_TEXT_SCHEMES),
/* harmony export */   cleanTree: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.cleanTree),
/* harmony export */   decodeEntities: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.decodeEntities),
/* harmony export */   parseHtml: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.parseHtml),
/* harmony export */   plainText: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.plainText),
/* harmony export */   richTextFromPlainText: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.richTextFromPlainText),
/* harmony export */   richTextHref: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.richTextHref),
/* harmony export */   sanitizeRichText: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.sanitizeRichText),
/* harmony export */   serialize: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.serialize),
/* harmony export */   treeFromDom: () => (/* reexport safe */ _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__.treeFromDom)
/* harmony export */ });
/* harmony import */ var _core_js_composition_html_subset_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e19611ff78cb");
// The html@1 subset of sf-input-rich. The rule moved to the core runtime with
// content.html 1.0.0, so the Composition renderer and this element share one
// cleaner: src/core/js/composition/html-subset.mjs.



/***/ },

/***/ "f050502c25f8"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"runtime":{"yes":"Yes","no":"No","searchInList":"Find in the list","containsText":"Contains…","fileKind_image":"Images","fileKind_document":"Documents","fileKind_archive":"Archives","fileKind_other":"Other files","operator":"Operator","rangeFrom":"From","rangeTo":"To","condition":"Condition","numberOperator_eq":"Equals","numberOperator_neq":"Not equal","numberOperator_gt":"Greater than","numberOperator_gte":"At least","numberOperator_lt":"Less than","numberOperator_lte":"At most","numberOperator_between":"Between","numberOperator_empty":"Empty","numberOperator_not-empty":"Not empty","filterNumber":"Number","filterAmount":"Amount","filterPercent":"Percent","dateCondition":"Condition","dateByDayIn":"Compared by day, time zone {zone}","dateGroup_date":"Date","dateGroup_period":"Period","dateGroup_filled":"Filled","dateGroup_range":"The record\'s period","dateCondition_eq":"Exact date","dateCondition_between":"Between","dateCondition_lt":"Before","dateCondition_gt":"After","dateCondition_gte":"On or after","dateCondition_lte":"On or before","dateCondition_lastDays":"Last N days","dateCondition_nextDays":"Next N days","dateCondition_empty":"Empty","dateCondition_notEmpty":"Not empty","dateCondition_overlaps":"Runs in","dateCondition_within":"Entirely in","dateCondition_starts":"Starts in","dateCondition_ends":"Ends in","dateCondition_contains":"Runs on the day","datePeriod_today":"Today","datePeriod_yesterday":"Yesterday","datePeriod_thisWeek":"This week","datePeriod_lastWeek":"Last week","datePeriod_last7Days":"Last 7 days","datePeriod_thisMonth":"This month","datePeriod_lastMonth":"Last month","datePeriod_thisYear":"This year","datePeriod_tomorrow":"Tomorrow","datePeriod_nextWeek":"Next week","datePeriod_nextMonth":"Next month","datePeriodIn_today":"today","datePeriodIn_yesterday":"yesterday","datePeriodIn_thisWeek":"this week","datePeriodIn_lastWeek":"last week","datePeriodIn_last7Days":"in the last 7 days","datePeriodIn_thisMonth":"this month","datePeriodIn_lastMonth":"last month","datePeriodIn_thisYear":"this year","datePeriodIn_tomorrow":"tomorrow","datePeriodIn_nextWeek":"next week","datePeriodIn_nextMonth":"next month","dateChip":"{field}: {condition}","dateChip_lt":"before {date}","dateChip_gt":"after {date}","dateChip_gte":"on or after {date}","dateChip_lte":"on or before {date}","dateChip_lastDays":{"one":"in the last day","other":"in the last {n} days"},"dateChip_nextDays":{"one":"in the next day","other":"in the next {n} days"},"dateChip_empty":"empty","dateChip_notEmpty":"not empty","dateChip_overlaps":"runs {when}","dateChip_within":"entirely {when}","dateChip_withinDays":"entirely within {when}","dateChip_starts":"starts {when}","dateChip_ends":"ends {when}","dateChip_contains":"runs on {date}","dateCountLast":"Days, today included","dateCountNext":"Days ahead, today included","dateCountUnit":"days","dateValueDate":"Date","dateValueDay":"Day","dateValuePeriod":"Period","dateWhen":"When","dateOwnDays":"Own dates","loadingOptions":"Loading the options","optionsError":"The options could not be loaded","pickRecord":"Choose a record","pickFromList":"Choose from the list","searchRecords":"Find a record","loadingRecords":"Loading records","recordsError":"The records could not be loaded","retry":"Try again","loadMore":"Load more","removeFile":"Remove","fileRemoved":"File removed","undo":"Undo","passwordSet":"Set","passwordUnset":"Not set","phoneExtension":"ext.","passwordKeep":"Set; type a new one to replace it","maskIncomplete":"Complete the field","notNumber":"Enter a number","precisionMax":{"one":"At most {n} digit after the point","other":"At most {n} digits after the point"},"fractionNone":"A whole amount, no digits after the point","boundBetween":"From {min} to {max}","boundAtLeast":"At least {min}","boundAtMost":"At most {max}","currency":"Currency","chooseCurrency":"Choose a currency","rowCount":{"one":"{n} row","other":"{n} rows"},"type-string":"String","variant-string-phone":"Phone","variant-string-password":"Password","type-text":"Text","type-html":"Formatted text","type-integer":"Integer","variant-integer-stepper":"With steppers","type-number":"Number","variant-number-scale":"Scale 0–100","variant-number-meter":"Share of a limit","variant-number-stepper":"With steppers","type-date":"Date","type-datetime":"Date and time","type-time":"Time","type-boolean":"Yes or no","type-choice":"One of a list","variant-choice-buttons":"As buttons","type-choices":"Several of a list","variant-choices-badges":"As badges","variant-choices-checklist":"As a checklist","variant-choices-select":"As a dropdown","type-user":"User","type-record":"Record","type-relation":"Relation","type-lookup":"From a reference list","type-file":"File","variant-file-image":"Image","variant-file-image-card":"Image card","variant-file-image-list":"Image list","type-color":"Colour","type-include":"Code","type-money":"Money","type-percent":"Percent","type-items":"Rows","type-compound":"Compound","type-ru.requisites":"Requisites (Russia)"}}');

/***/ },

/***/ "f8651e83c6c6"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"$comment":"Dated aliases of sf-view-table for the shim (core/js/aliases.js, standard §16 item 20, vocabulary §9). mode: same-detail (the shim sends the new and the old name), detail-adds (the old name gets the larger new detail), split (the old detail from the element\'s adapter, sfAliasAdapters), host-attribute (no shim).","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","aliases":[{"from":"aria-label","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"host-attribute","section":"§3.1, §4.8","note":"stays a host attribute, read for the accessible name; no shim"},{"from":"sf-table-action-intent","to":"sf-table-apply","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"split","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 apply {action, scope, ids, revisions}; the old detail {action_id, record_ids} is made by the element\'s adapter (vocabulary §9: sf-table-action-intent → sf-table-apply)"},{"from":"sf-table-create-intent","to":"sf-table-create","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 create; the detail {item} is unchanged"},{"from":"sf-port-output","to":"sf-table-select","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"split","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 select {ids}; the composition port\'s old detail {port: selection, value} is made by the element\'s adapter"},{"from":"sf-table-query-intent","to":"sf-table-query","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5.1: sf-table-query-intent → sf-table-query; the detail {reason, context, sequence} is unchanged"},{"from":"sf-table-retry","to":"sf-table-refresh","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 refresh (table-retry)"},{"from":"sf-table-tree-toggle","to":"sf-table-expand","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 expand; the detail {id, expanded} is unchanged"},{"from":"sf-table-tree-more","to":"sf-table-load-more","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"detail-adds","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 load-more; the new detail adds direction: after to {parent, cursor}"},{"from":"sf-table-rows-reorder","to":"sf-table-move","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 move; the detail {ids, before, order} is unchanged"},{"from":"sf-table-column-settings-change","to":"sf-table-save","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"detail-adds","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5 save {kind: columns}; the new detail adds kind to {reason, columnSettings, tableSettingsKey}","when":{"kind":"columns"}},{"from":"sf-table:column-settings-change","to":"sf-table-save","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"detail-adds","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"vocabulary §5.1: sf-table:column-settings-change → sf-table-save {kind: columns}; a colon name (§8)","when":{"kind":"columns"}},{"from":"onColumnSettingsChange","to":"sf-table-save","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"detail-adds","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"a camelCase name outside §8 (simai/ui-pro#1); ui-admin listens to it (src/main.ts, src/smart-component-catalog.ts)","when":{"kind":"columns"}},{"from":"onSearchEnd","to":"sf-table-search-change","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"split","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"a camelCase name outside §8 (simai/ui-pro#1); its detail was the search text itself, made by the element\'s adapter; ui-admin listens to it (src/main.ts, src/smart-component-catalog.ts)"},{"from":"onTemplateSave","to":"sf-view-table-template-save","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"split","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"a camelCase name outside §8 (simai/ui-pro#1); ui-admin listens to it; its detail was the template object or the array of them, made by the element\'s adapter since template-save carries {templates} (1.16.0)"},{"from":"onFilterUpdate","to":"sf-table-filter-change","kind":"event","component":"sf-view-table","since":"2026-10-27","remove_after":"2027-01-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 20, vocabulary §9","note":"a camelCase name outside §8 (simai/ui-pro#1); ui-admin listens to it"},{"from":"sf-table","to":"sf-view-table","kind":"tag","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","section":"rename plan R2 (ui-control RENAME-PLAN-2026-11-03), naming decision 2026-11-02","note":"the element is sf-view-table; sf-table is a subclass defined beside it until the date"},{"from":"sf-table-select","to":"sf-view-table-select","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-apply","to":"sf-view-table-apply","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-save","to":"sf-view-table-save","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-column-settings-reset","to":"sf-view-table-column-settings-reset","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-create","to":"sf-view-table-create","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-filter-change","to":"sf-view-table-filter-change","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-query","to":"sf-view-table-query","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-refresh","to":"sf-view-table-refresh","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-search-change","to":"sf-view-table-search-change","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-sort-change","to":"sf-view-table-sort-change","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-template-delete","to":"sf-view-table-template-delete","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-template-save","to":"sf-view-table-template-save","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"split","section":"§8","note":"the event name carries the tag; its detail was the template object or the array of them, made by the element\'s adapter since template-save carries {templates} (1.16.0)"},{"from":"sf-table-template-select","to":"sf-view-table-template-select","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-toolbar-action","to":"sf-view-table-toolbar-action","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-reference-open","to":"sf-view-table-reference-open","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-expand","to":"sf-view-table-expand","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-load-more","to":"sf-view-table-load-more","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-rows-drag","to":"sf-view-table-rows-drag","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-move","to":"sf-view-table-move","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-cell-set","to":"sf-view-table-cell-set","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-view-change","to":"sf-view-table-view-change","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"sf-table-window","to":"sf-view-table-window","kind":"event","component":"sf-view-table","since":"2026-11-03","remove_after":"2027-01-01","mode":"same-detail","section":"§8","note":"the event name carries the tag"},{"from":"toolbar","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"pagin","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"filter-templates","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"filter-text","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"clear-text","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"search-placeholder","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"create-text","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"creatable","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"pagination-total","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"pagination-page-size","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"page-sizes","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"filter-apply-text","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"},{"from":"layout-switch","to":null,"kind":"attribute","component":"sf-view-table","since":"2026-11-18","remove_after":"2027-01-01","mode":"host-attribute","section":"C296, C295 (VT-13)","note":"the container\'s job (sf-view, sf-pagination, sf-bulk-actions); read by the table as before until the date, noted in SF.deprecations once on a table standing alone; no shim"}]}');

/***/ },

/***/ "c1f17ed5a348"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"id":"smart.view-table","tag":"sf-view-table","version":"1.25.1","kind":"leaf","settings":{"selectable":{"type":"boolean","default":true},"settings":{"type":"boolean","default":true},"actions":{"type":"boolean","default":true},"row-actions":{"type":"boolean","default":true},"creatable":{"type":"boolean","default":true},"filter-templates":{"type":"boolean","default":true},"settings-menu":{"type":"boolean","default":true},"pagin":{"type":"boolean","default":false},"filter-text":{"type":"string","default-from":"runtime.filter-text"},"clear-text":{"type":"string","default-from":"runtime.clear-text"},"search-placeholder":{"type":"string","default-from":"runtime.search-placeholder"},"create-text":{"type":"string","default-from":"runtime.create-text"},"pagination-total":{"type":"number","default":10,"integer":true,"min":0},"pagination-page-size":{"type":"number","default":10,"integer":true,"min":1,"max":100},"page-sizes":{"type":"string","default":"10,20,30,40"},"context-menu-columns":{"type":"number","default":1,"integer":true,"min":1,"max":4},"remember-widths":{"type":"boolean","default":false},"table-settings-key":{"type":"string","default":""},"data-state":{"type":"enum","values":["auto","loading","ready","populated","empty","error"],"default":"auto","x-alias":{"populated":"ready"}},"loading-text":{"type":"string","default-from":"runtime.loading-text"},"empty-text":{"type":"string","default-from":"runtime.empty-text"},"empty-description":{"type":"string"},"error-text":{"type":"string","default-from":"runtime.error-text"},"retry-text":{"type":"string","default-from":"runtime.retry-text"},"toolbar":{"type":"boolean","default":true},"stripes":{"type":"boolean","default":false},"pin-column-label":{"type":"string","default-from":"runtime.pin-column-label"},"unpin-column-label":{"type":"string","default-from":"runtime.unpin-column-label"},"column-move-label":{"type":"string","default-from":"runtime.column-move-label"},"column-search-placeholder":{"type":"string","default-from":"runtime.column-search-placeholder"},"column-search-empty-text":{"type":"string","default-from":"runtime.column-search-empty-text"},"vertical-scroll":{"type":"enum","values":["self","page"],"default":"self"},"filter-apply-text":{"type":"string","default-from":"runtime.filter-apply-text"},"layout":{"type":"enum","values":["auto","table","list"],"default":"auto"},"layout-switch":{"type":"boolean","default":false},"list-below":{"type":"number","default":600},"list-fields":{"type":"number","default":3},"quick-actions":{"type":"string","default":""},"row-open":{"type":"enum","values":["title","row"],"default":"title"},"size":{"type":"enum","values":["1/2","1"],"default":"1"},"preferences-key":{"type":"string","default":""},"row-actions-visible":{"type":"enum","values":["hover","always"],"default":"hover"},"drag-rows":{"type":"boolean","default":false},"row-reorder":{"type":"boolean","default":false},"inline-edit":{"type":"boolean","default":false},"total":{"type":"number","default":0},"row-offset":{"type":"number","default":0},"active-filter-fields":{"type":"list","entries":{"key":"id"}},"bulk-actions":{"type":"list"},"columns":{"type":"list","of":{"key":"string","label":"string"}},"create-items":{"type":"list"},"filter-fields":{"type":"list"},"rows":{"type":"list","entries":{"key":"id","changes":"revision"},"of":{"id":"id","revision":{"type":"string","optional":true}}},"table-data":{"type":"object"},"table-settings":{"type":"object"},"templates":{"type":"list"},"toolbar-actions":{"type":"list"},"sort":{"type":"list","of":{"key":"string","direction":{"type":"enum","values":["asc","desc"]}},"controlled":true},"totals":{"type":"object"},"current":{"type":"string","default":""}},"values":{"selected":{"type":"id","optional":true},"selection":{"type":"list","default":[]}},"events":{"select":{"carries":{"ids":"list"}},"apply":{"carries":{"action":"string","scope":{"type":"enum","values":["entry","selection","filter"]},"ids":"list","revisions":{"type":"object","optional":true}}},"save":{"carries":{"kind":{"type":"enum","values":["columns"]},"reason":"string","column-settings":{"type":"object"},"table-settings-key":{"type":"string"}}},"column-settings-reset":{"carries":{"target":{"type":"enum","values":["personal"]},"table-settings-key":{"type":"string","nullable":true}},"own-verb":true},"create":{"carries":{"item":{"type":"string","nullable":true,"optional":true}}},"filter-change":{"carries":{"template-key":{"type":"string"},"template-label":{"type":"string"},"values":{"type":"object"},"tags":{"type":"object"}},"own-verb":true},"query":{"carries":{"reason":"string","context":"object","sequence":{"type":"number","integer":true}}},"refresh":{"carries":{}},"search-change":{"carries":{"search":"string"},"own-verb":true},"sort-change":{"carries":{"key":{"type":"string","schema":{"minLength":1}},"direction":{"type":"enum","values":["asc","desc",null],"nullable":true}},"own-verb":true},"template-delete":{"carries":{"key":{"type":"string","schema":{"minLength":1}}},"own-verb":true},"template-save":{"carries":{"templates":{"type":"list","of":{"key":"string","label":"string","selected":"boolean","data":"object","settings":"object"},"schema":{"items":{"type":"object","required":["key","label","settings"],"properties":{"key":{"type":"string"},"label":{"type":"string"},"selected":{"type":"boolean"},"data":{"type":"object"},"settings":{"type":"object","properties":{"filter_fields":{"type":"array","items":{"type":"string"}}}}}},"minItems":1}}},"own-verb":true},"template-select":{"carries":{"key":{"type":"string","schema":{"minLength":1}}},"own-verb":true},"toolbar-action":{"carries":{"action":"string","href":{"type":"string","nullable":true,"optional":true}},"cancelable":true,"own-verb":true},"reference-open":{"carries":{"field":"string","value":"object","href":"string"},"cancelable":true,"own-verb":true},"expand":{"carries":{"id":"id","expanded":{"type":"boolean","optional":true}}},"load-more":{"carries":{"direction":{"type":"enum","values":["after"]},"parent":{"type":"id","nullable":true},"cursor":{"type":"string","nullable":true}}},"rows-drag":{"carries":{"ids":{"type":"list","schema":{"items":{"type":"string"},"minItems":1}},"source":{"type":"string","nullable":true}},"own-verb":true},"move":{"carries":{"ids":"list","before":{"type":"id","nullable":true},"order":"list"}},"cell-set":{"carries":{"id":"object","key":"string","value":"object","revision":"object"},"own-verb":true},"view-change":{"carries":{"view":"object","everywhere":"boolean"},"own-verb":true},"window":{"carries":{"first":{"type":"number","integer":true},"last":{"type":"number","integer":true}},"own-verb":true},"layout-change":{"carries":{"layout":{"type":"enum","values":["list","table"]}},"own-verb":true},"open":{"carries":{"id":"id","newTab":"boolean"},"own-verb":true}},"actions":{"add-rows":{"with":{"rows":"list"}},"apply-query-result":{"with":{"sequence":{"type":"number","integer":true,"schema":{"minimum":1}},"rows":"list"}},"clear-selection":{},"request-action-intent":{"with":{"action-id":{"type":"string","schema":{"minLength":1}},"record-ids":{"type":"list","schema":{"items":{"type":["string","integer"],"minLength":1},"minItems":1}}},"emits":"apply"},"request-create-intent":{"with":{"item-id":{"type":"string","optional":true,"nullable":true}},"emits":"create"},"request-retry":{"emits":"refresh"},"set-sort":{"with":{"key":{"type":"string","nullable":true},"direction":{"type":"enum","values":["asc","desc"],"nullable":true}}},"toggle-tree-row":{"with":{"row":"object"},"emits":"expand"},"request-tree-more":{"with":{"row":"object"},"emits":"load-more"},"focus-row":{"with":{"id":"id"}},"set-layout":{"with":{"layout":{"type":"enum","values":["list","table"]}},"emits":"layout-change"},"scroll-to-row":{"with":{"id":"id"}}},"port":{"id":"simai.dataview-port","version":"1.0.0","contract":"src/core/contracts/ports/simai.dataview-port/1.0.0/port.json"},"presentation":{"skeleton":{"late":["rows"]}},"host-states":{"data-sf-view-stripes":"boolean","data-sf-page-scroll":"boolean"},"css-variables":{"--sf-view-table-row-block-size":{"type":"length","state":"default"},"--sf-view-table-head-block-size":{"type":"length","state":"default"},"--sf-view-table-edge":{"type":"length","state":"default"},"--sf-view-table-line-color":{"type":"color","state":"default"},"--sf-view-table-head-color":{"type":"color","state":"default"},"--sf-view-table-row-background-color":{"type":"color","state":"default"},"--sf-view-table-selected-background-color":{"type":"color","state":"default"},"--sf-view-table-title-lines":{"type":"integer","state":"default"},"--sf-table-row-block-size-1/2":{"type":"length","state":"default"},"--sf-table-row-block-size-1":{"type":"length","state":"default"},"--sf-table-row-2-lines-block-size-1/2":{"type":"length","state":"default"},"--sf-table-row-2-lines-block-size-1":{"type":"length","state":"default"},"--sf-table-head-block-size-1/2":{"type":"length","state":"default"},"--sf-table-head-block-size-1":{"type":"length","state":"default"},"--sf-table-toolbar-block-size-1/2":{"type":"length","state":"default"},"--sf-table-toolbar-block-size-1":{"type":"length","state":"default"},"--sf-table-toolbar-gap":{"type":"length","state":"default"},"--sf-table-head--background-color":{"type":"color","state":"default"},"--sf-table-row--background-color":{"type":"color","state":"default"},"--sf-table--cell-spacing":{"type":"length","state":"default"},"--sf-table-cell--line-clamp":{"type":"number","state":"default"},"--sf-table-context-menu--z-index":{"type":"number","state":"open"},"--sf-table-context-menu--max-width":{"type":"length","state":"open"}}}');

/***/ },

/***/ "678dc07d76bf"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"title":"Table","events":{"column-settings-reset":{"label":"Column settings reset"},"filter-change":{"label":"Filter changed"},"search-change":{"label":"Search changed"},"sort-change":{"label":"Order changed"},"template-delete":{"label":"Template deleted"},"template-save":{"label":"Template saved"},"template-select":{"label":"Template chosen"},"toolbar-action":{"label":"Toolbar action"},"reference-open":{"label":"Open the linked record"},"rows-drag":{"label":"Rows dragged"},"cell-set":{"label":"Cell value changed"},"view-change":{"label":"Table view changed"},"window":{"label":"Rows shown"}},"runtime":{"actions-column-label":"Actions","apply-text":"Apply","cell-edit-apply":"Save","cell-edit-cancel":"Cancel","cell-edit-label":"Change","cell-edit-no":"No","cell-edit-yes":"Yes","clear-text":"Clear","close-text":"Close","column-all":"All columns…","column-hide":"Hide the column","column-menu-label":"Column","column-move-label":"Move the column","column-pin":"Pin","column-resize-label":"Resize the column","column-search-empty-text":"No field matches","column-search-placeholder":"Search the fields","column-sort-asc":"Sort ascending","column-sort-desc":"Sort descending","column-unpin":"Unpin","column-width-change-text":"Change the width","column-width-default-text":"Default width","column-width-fit-text":"Fit to content","column-width-value":"{n}%","context-create-options-label":"Ways to create","context-field-filter-label":"Filtering by","context-filter-settings-label":"Filter settings","context-row-actions-label":"Row actions","context-save-template-label":"Saving the filter as a template","context-table-settings-label":"Table settings","context-template-actions-label":"Template actions","context-view-actions-label":"View actions","create-more-label":"More ways to create","create-options-label":"Ways to create","create-text":"Create","default-template-text":"Default","delete-action-text":"Delete","edit-action-text":"Edit","empty-text":"No data","error-text":"The data could not be loaded","field-word-text":"field","fields-tab-text":"Fields","filter-apply-text":"Apply","filter-badge-label":"{count} condition|{count} conditions","filter-settings-label":"Filter settings","filter-text":"Filter","layout-list":"List","layout-switch-label":"Layout","layout-table":"Table","list-select-page":"All on the page","loading-text":"Loading","make-default-label":"Make it the default","menu-label":"Menu","more-actions-label":"More actions","operator-after":"After","operator-any":"Any date","operator-before":"Before","operator-between":"Range","operator-contains":"Contains","operator-eq":"Exactly","operator-gt":"Greater than","operator-gte":"Greater or equal","operator-in":"In the list","operator-lt":"Less than","operator-lte":"Less or equal","operator-month":"This month","operator-on-or-after":"On or after","operator-on-or-before":"On or before","operator-starts-with":"Starts with","operator-today":"Today","operator-week":"This week","pin-column-label":"Pin the column","rename-text":"Rename","reset-both-text":"Reset the search and filters","reset-filters-text":"Reset the filters","reset-search-text":"Clear the search","reset-text":"Reset","restore-text":"Restore","retry-text":"Try again","row-actions-label":"Row actions","save-filter-template-label":"Save the filter as a template","save-for-everyone-label":"Save for everyone","save-template-label":"Save the filter as a template","save-text":"Save","search-placeholder":"Search","select-all-label":"Select every row","select-row-label":"Select the row","selected-rows-heading":"Selected","settings-column-label":"Settings","settings-fields-tab":"Fields","settings-view-tab":"View","sort-ascending":"ascending","sort-descending":"descending","sort-label":"Sort","sort-none":"As the host orders it","status-error":"Error","status-ok":"Working","status-stopped":"Stopped","status-warning":"Needs attention","template-actions-label":"Template actions","template-move-label":"Move the template","template-name-placeholder":"Name","template-pin-label":"Keep the template at the top","templates-tab-text":"Templates","totals-all":"Total","totals-page":"On this page","tree-collapse":"Collapse","tree-expand":"Expand","tree-more":"Show more","unpin-column-label":"Unpin the column","untitled-template-text":"All records","view-action-text":"View","view-density":"Rows","view-density-compact":"Compact","view-density-normal":"Normal","view-density-spacious":"Spacious","view-everywhere":"For all my tables","view-lines":"Lines between columns","view-reset":"Reset the view","view-single-line":"Text on one line","view-sticky-head":"Keep the filter and the head in view","view-stripes":"Alternate rows"}}');

/***/ },

/***/ "32294b89604f"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"title":"Таблица","events":{"column-settings-reset":{"label":"Настройки столбцов сброшены"},"filter-change":{"label":"Фильтр изменён"},"search-change":{"label":"Поиск изменён"},"sort-change":{"label":"Порядок изменён"},"template-delete":{"label":"Шаблон удалён"},"template-save":{"label":"Шаблон сохранён"},"template-select":{"label":"Шаблон выбран"},"toolbar-action":{"label":"Действие панели"},"reference-open":{"label":"Открыть связанную запись"},"rows-drag":{"label":"Строки перетащены"},"cell-set":{"label":"Значение в ячейке изменено"},"view-change":{"label":"Вид таблицы изменён"},"window":{"label":"Показаны строки"}},"runtime":{"actions-column-label":"Действия","apply-text":"Применить","cell-edit-apply":"Сохранить","cell-edit-cancel":"Отмена","cell-edit-label":"Изменить","cell-edit-no":"Нет","cell-edit-yes":"Да","clear-text":"Очистить","close-text":"Закрыть","column-all":"Все колонки…","column-hide":"Скрыть колонку","column-menu-label":"Колонка","column-move-label":"Переместить столбец","column-pin":"Закрепить","column-resize-label":"Изменить ширину столбца","column-search-empty-text":"Поля не найдены","column-search-placeholder":"Поиск по полям","column-sort-asc":"По возрастанию","column-sort-desc":"По убыванию","column-unpin":"Открепить","column-width-change-text":"Изменить ширину","column-width-default-text":"По умолчанию","column-width-fit-text":"По содержимому","column-width-value":"{n} %","context-create-options-label":"Варианты создания","context-field-filter-label":"Настройка фильтра","context-filter-settings-label":"Настройки фильтра","context-row-actions-label":"Действия со строкой","context-save-template-label":"Сохранение шаблона фильтра","context-table-settings-label":"Настройки таблицы","context-template-actions-label":"Действия с шаблоном","context-view-actions-label":"Действия с представлением","create-more-label":"Дополнительные действия создания","create-options-label":"Варианты создания","create-text":"Создать","default-template-text":"По умолчанию","delete-action-text":"Удалить","edit-action-text":"Редактировать","empty-text":"Нет данных","error-text":"Не удалось загрузить данные","field-word-text":"поле","fields-tab-text":"Поля","filter-apply-text":"Применить","filter-badge-label":"{count} условие|{count} условия|{count} условий","filter-settings-label":"Настройки фильтра","filter-text":"Фильтр","layout-list":"Список","layout-switch-label":"Вид","layout-table":"Таблица","list-select-page":"Все на странице","loading-text":"Загрузка данных","make-default-label":"Сделать по умолчанию","menu-label":"Меню","more-actions-label":"Ещё действия","operator-after":"Позже","operator-any":"Любая дата","operator-before":"Раньше","operator-between":"Диапазон","operator-contains":"Содержит","operator-eq":"Точно","operator-gt":"Больше чем","operator-gte":"Больше или равно","operator-in":"В списке","operator-lt":"Меньше чем","operator-lte":"Меньше или равно","operator-month":"Месяц","operator-on-or-after":"Не раньше","operator-on-or-before":"Не позже","operator-starts-with":"Начинается с","operator-today":"Сегодня","operator-week":"Неделя","pin-column-label":"Закрепить столбец","rename-text":"Переименовать","reset-both-text":"Сбросить поиск и фильтры","reset-filters-text":"Сбросить фильтры","reset-search-text":"Очистить поиск","reset-text":"Сбросить","restore-text":"Восстановить","retry-text":"Повторить","row-actions-label":"Действия со строкой","save-filter-template-label":"Сохранить шаблон фильтра","save-for-everyone-label":"Сохранить для всех","save-template-label":"Сохранение шаблона фильтра","save-text":"Сохранить","search-placeholder":"Поиск","select-all-label":"Выбрать все строки","select-row-label":"Выбрать строку","selected-rows-heading":"Выбрано","settings-column-label":"Настройки","settings-fields-tab":"Поля","settings-view-tab":"Вид","sort-ascending":"по возрастанию","sort-descending":"по убыванию","sort-label":"Сортировка","sort-none":"Как задано источником","status-error":"Ошибка","status-ok":"Работает","status-stopped":"Остановлен","status-warning":"Есть замечания","template-actions-label":"Действия с шаблоном","template-move-label":"Переместить шаблон","template-name-placeholder":"Название","template-pin-label":"Закрепить шаблон сверху","templates-tab-text":"Шаблоны","totals-all":"Всего по фильтру","totals-page":"На странице","tree-collapse":"Свернуть","tree-expand":"Развернуть","tree-more":"Показать ещё","unpin-column-label":"Открепить столбец","untitled-template-text":"Все записи","view-action-text":"Посмотреть","view-density":"Строки","view-density-compact":"Компактно","view-density-normal":"Обычно","view-density-spacious":"Просторно","view-everywhere":"Для всех моих таблиц","view-lines":"Линии между столбцами","view-reset":"Сбросить вид","view-single-line":"Текст в одну строку","view-sticky-head":"Закреплять фильтр и шапку","view-stripes":"Чередовать строки"}}');

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/************************************************************************/
/******/ 	/* webpack/runtime/async module */
/******/ 	(() => {
/******/ 		const hasSymbol = typeof Symbol === "function";
/******/ 		const webpackQueues = hasSymbol ? Symbol("webpack queues") : "__webpack_queues__";
/******/ 		const webpackExports = hasSymbol ? Symbol("webpack exports") : "__webpack_exports__";
/******/ 		const webpackError = hasSymbol ? Symbol("webpack error") : "__webpack_error__";
/******/
/******/ 		const resolveQueue = (queue) => {
/******/ 			if(queue?.d < 1) {
/******/ 				queue.d = 1;
/******/ 				queue.forEach((fn) => (fn.r--));
/******/ 				queue.forEach((fn) => (fn.r-- ? fn.r++ : fn()));
/******/ 			}
/******/ 		}
/******/ 		const wrapDeps = (deps) => (deps.map((dep) => {
/******/ 			if(dep !== null && typeof dep === "object") {
/******/
/******/ 				if(dep[webpackQueues]) return dep;
/******/ 				if(dep.then) {
/******/ 					const queue = [];
/******/ 					queue.d = 0;
/******/ 					dep.then((r) => {
/******/ 						obj[webpackExports] = r;
/******/ 						resolveQueue(queue);
/******/ 					}, (e) => {
/******/ 						obj[webpackError] = e;
/******/ 						resolveQueue(queue);
/******/ 					});
/******/ 					const obj = {};
/******/
/******/ 					obj[webpackQueues] = (fn) => (fn(queue));
/******/ 					return obj;
/******/ 				}
/******/ 			}
/******/ 			const ret = {};
/******/ 			ret[webpackQueues] = x => {};
/******/ 			ret[webpackExports] = dep;
/******/ 			return ret;
/******/ 		}));
/******/ 		__webpack_require__.a = (module, body, hasAwait) => {
/******/ 			let queue;
/******/ 			hasAwait && ((queue = []).d = -1);
/******/ 			const depQueues = new Set();
/******/ 			const exports = module.exports;
/******/ 			let currentDeps;
/******/ 			let outerResolve;
/******/ 			let reject;
/******/ 			const promise = new Promise((resolve, rej) => {
/******/ 				reject = rej;
/******/ 				outerResolve = resolve;
/******/ 			});
/******/ 			promise[webpackExports] = exports;
/******/ 			promise[webpackQueues] = (fn) => (queue && fn(queue), depQueues.forEach(fn), promise["catch"](x => {}));
/******/ 			module.exports = promise;
/******/ 			const handle = (deps) => {
/******/ 				currentDeps = wrapDeps(deps);
/******/ 				let fn;
/******/ 				const getResult = () => (currentDeps.map((d) => {
/******/
/******/ 					if(d[webpackError]) throw d[webpackError];
/******/ 					return d[webpackExports];
/******/ 				}))
/******/ 				const promise = new Promise((resolve) => {
/******/ 					fn = () => (resolve(getResult));
/******/ 					fn.r = 0;
/******/ 					const fnQueue = (q) => (q !== queue && !depQueues.has(q) && (depQueues.add(q), q && !q.d && (fn.r++, q.push(fn))));
/******/ 					currentDeps.map((dep) => (dep[webpackQueues](fnQueue)));
/******/ 				});
/******/ 				return fn.r ? promise : getResult();
/******/ 			}
/******/ 			const done = (err) => ((err ? reject(promise[webpackError] = err) : outerResolve(exports)), resolveQueue(queue))
/******/ 			body(handle, done);
/******/ 			queue?.d < 0 && (queue.d = 0);
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/
/************************************************************************/
/******/
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module used 'module' so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("94d60d3691b5");
/******/
/******/ })()
;