import {html, nothing, render} from "lit";
import {Directive, directive, PartType} from "lit/directive.js";
import {keyed} from "lit/directives/keyed.js";
import {repeat} from "lit/directives/repeat.js";
import {ref} from "lit/directives/ref.js";
import {isTemplateResult} from "lit/directive-helpers.js";
import "./default.css";
import {normalizeTableLinkCell} from "./link-cell-contract.js";

function getEventInputValue(event, fallback = '') {
    const pathTarget = event?.composedPath?.()?.[0];
    const candidates = [pathTarget, event?.target, event?.currentTarget];

    for (const candidate of candidates) {
        if (!candidate) continue;

        if (typeof candidate.value !== 'undefined') {
            return candidate.value;
        }

        const input = candidate.querySelector?.('input, textarea');
        if (input && typeof input.value !== 'undefined') {
            return input.value;
        }
    }

    return fallback;
}

// The toolbar of the compact list: one line, the search taking the room and the
// filter and create as icons beside it -- the table's toolbar wrapped to three
// lines on a phone and took a quarter of the screen. Active filters follow as a
// row of chips that scrolls sideways, each removable, and the filter itself
// opens as a sheet over the whole screen.
function renderListToolbar(context) {
    const {state} = context.component;
    const {value} = state.search;
    const filterTags = context.component.getCurrentFilterTags();
    const filterValues = context.component.getCurrentFilterValues();
    const active = Object.entries(filterTags || {}).filter(([, tag]) => tag?.active !== false);
    // The column settings on a phone (view round 5, LV-6): the desktop's gear
    // stands in the head of the row-menu column, which a list has not, so the
    // same gear stands here with the filter and the sort -- the view's own
    // controls (C301 (1): settings of the view over the list, not by «Создать»).
    const gear = context.settings !== false && context.settingsMenu !== false;
    const sortable = context.component.getColumns().some((column) => column?.sortable && !column.system);
    return html`
        <div class="sf-table-toolbar sf-table-toolbar--list flex flex-col gap-1/3 flex-none"
             data-sf-filter-tags="${active.length ? '1' : '0'}">
            <div class="sf-table-list-search flex items-cross-center gap-1 min-w-0">
                <sf-input
                        size=${context.controlSize ?? nothing}
                        root-class="sf-search-input flex-1 min-w-0"
                        appearance="bordered"
                        value="${value}"
                        placeholder=${context.searchPlaceholder}
                        name="sf_table_search"
                        input-type="search"
                        icon-start="search"
                        clearable
                        aria-label=${context.searchPlaceholder}
                        @input=${(e) => context.component.searchChange({value: getEventInputValue(e, value)})}
                        @keydown=${(e) => context.component.handleSearchKeyDown(e)}
                        @keyup=${(e) => context.component.handleSearchKeyUp(e)}
                ></sf-input>
                <!-- C144: filter and sort are one group of neighbours (H5,
                     --sf-space-1/3); the field before them and «Создать»
                     after them stand a group apart (H6, --sf-space-1). -->
                ${context.component.offersFilter(active.length) || sortable || gear ? html`<div class="sf-table-list-view-buttons flex items-cross-center gap-1/3">
                ${context.component.offersFilter(active.length) ? html`<span class="sf-table-list-filter">
                    <!-- The count of active conditions is the icon's own badge
                         (sf-button-icon badge-count, simai/ui-source#12): it
                         joins the button's name in the page language. -->
                    <sf-button-icon
                            size=${context.controlSize ?? nothing}
                            appearance=${active.length || context.filterHeld ? 'tonal' : 'outline'}
                            scheme=${active.length || context.filterHeld ? 'primary' : 'on-surface'}
                            icon="filter_list"
                            badge-count=${active.length || nothing}
                            badge-label=${active.length ? context.component.text('filterBadgeLabel') : nothing}
                            aria-label=${context.filterName ? `${context.filterText}: ${context.filterName}` : context.filterText}
                            @click=${(e) => context.component.openContextMenu(e, {type: 'bottom', menu: 'filter-settings'})}
                    ></sf-button-icon>
                </span>` : nothing}
                ${sortable ? html`
                    <sf-button-icon
                            size=${context.controlSize ?? nothing}
                            appearance=${state.sort?.key ? 'tonal' : 'outline'}
                            scheme=${state.sort?.key ? 'primary' : 'on-surface'}
                            icon="swap_vert"
                            aria-label=${context.component.text('sortLabel')}
                            aria-haspopup="menu"
                            @click=${(e) => context.component.openContextMenu(e, {type: 'bottom', menu: 'list-sort'})}
                    ></sf-button-icon>` : nothing}
                ${gear ? html`
                    <sf-button-icon
                            class="sf-table-list-settings"
                            size=${context.controlSize ?? nothing}
                            appearance="outline"
                            scheme="on-surface"
                            icon="settings"
                            aria-label=${context.component.text('settingsColumnLabel')}
                            aria-haspopup="dialog"
                            @click=${(e) => context.component.toggleTableSettings(e)}
                    ></sf-button-icon>` : nothing}
                </div>` : nothing}
                ${context.actions && context.creatable ? html`
                    <sf-button-icon
                            size=${context.controlSize ?? nothing}
                            appearance="default"
                            scheme="primary"
                            icon="add"
                            aria-label=${context.createText}
                            @click=${(e) => (state.createItems?.length
                                ? context.component.openContextMenu(e, {type: 'bottom', menu: 'create'})
                                : context.component.requestCreateIntent(null))}
                    ></sf-button-icon>` : nothing}
            </div>
            ${active.length ? html`
                <!-- Chips are neighbours 4 apart (C105 H5, --sf-space-1/4); the
                     «Сбросить» after them is a button, 8 from the chips. -->
                <div class="sf-table-list-tags flex items-cross-center gap-1/3">
                    <div class="sf-table-chips flex items-cross-center gap-1/4">
                    ${active.map(([k, written]) => {
                        // A date chip says its condition (C293 DF-4).
                        const tag = {...written, label: context.component.filterChipText(k, written)};
                        const filterValue = filterValues?.[k] || {};
                        const count = Array.isArray(filterValue.values) ? filterValue.values.length : tag.count || '';
                        return html`
                            <sf-tag kind="default" size=${context.controlSize ?? nothing} text='${tag.label}' interactive closable :key=${k}
                                    active count='${count}'
                                    @sf-tag-close="${() => context.component.removeFilterTag(k)}"
                                    @click=${(e) => context.component.openContextMenu(e, {type: 'bottom', menu: 'tag-settings', fieldKey: k, anchorSelector: '.sf-tag'})}
                            ></sf-tag>`;
                    })}
                    </div>
                    <sf-button size=${context.controlSize ?? nothing} appearance="ghost" scheme="on-surface" text=${context.clearText}
                               @click="${() => context.component.removeFilterTag()}"></sf-button>
                </div>` : nothing}
        </div>
    `;
}

function renderToolbar(context) {
    const {state} = context.component;
    const {value} = state.search;
    const filterTags = context.component.getCurrentFilterTags();
    const filterValues = context.component.getCurrentFilterValues();
    const hasUnsavedFilterDataChanges =
        context.component.hasUnsavedFilterDataChanges();
    const activeFilterTags = Object.entries(filterTags || {}).filter(
        ([, tag]) => tag?.active !== false,
    );
    return html`
        <div
                class="sf-table-toolbar flex gap-1/2 content-main-between flex-none"
                data-sf-filter-tags="${activeFilterTags.length ? '1' : '0'}"
        >
            <div class="sf-table-toolbar-start flex items-cross-center gap-1/3 flex-wrap min-w-0">
                ${context.component.offersFilter(activeFilterTags.length) ? html`<div class="flex items-cross-center">
                    <!-- C301 (3): only «Создать» is filled; «Фильтр» has an
                         outline, and a tone while conditions are set. -->
                    <sf-button
                            size=${context.controlSize ?? nothing}
                            appearance=${activeFilterTags.length || context.filterHeld ? 'tonal' : 'outline'}
                            scheme=${activeFilterTags.length || context.filterHeld ? 'primary' : 'on-surface'}
                            text=${context.filterName || context.filterText}
                            segment=${context.filterTemplates ? 'start' : nothing}
                            icon-start="filter_list"
                            @click=${(e) => {
                                context.component.openContextMenu(e, {
                                    type: 'bottom',
                                    menu: 'filter-settings',
                                })
                            }}
                    ></sf-button>
                    ${context.filterTemplates ? html`
                    <sf-button-icon
                            size=${context.controlSize ?? nothing}
                            appearance=${activeFilterTags.length || context.filterHeld ? 'tonal' : 'outline'}
                            scheme=${activeFilterTags.length || context.filterHeld ? 'primary' : 'on-surface'}
                            aria-label=${context.component.text('saveFilterTemplateLabel')}
                            ?disabled=${!activeFilterTags.length}
                            segment="end"
                            icon="bookmark_add"
                            @click=${(e) => {
                                context.component.openContextMenu(e, {
                                    type: 'bottom',
                                    menu: 'filter-favorites',
                                    parent: true
                                })
                            }}
                    ></sf-button-icon>` : nothing}
                </div>` : nothing}
                ${activeFilterTags.length ? html`
                <!-- Chips are neighbours 4 apart (C105 H5, --sf-space-1/4); the
                     buttons around them keep the toolbar's 8. -->
                <div class="sf-table-chips flex items-cross-center gap-1/4 flex-wrap min-w-0">
                ${activeFilterTags.map(([k, written]) => {
                    // A date chip says its condition (C293 DF-4).
                    const tag = {...written, label: context.component.filterChipText(k, written)};
                    const filterValue = filterValues?.[k] || {};
                    const hasFilteredValues = Object.prototype.hasOwnProperty.call(
                            filterValues || {},
                            k,
                    );
                    const count = Array.isArray(filterValue.values)
                            ? filterValue.values.length
                            : tag.count || '';

                    return html`
                        <div class="sf-table-tags">
                            <sf-tag
                                    kind="default"
                                    size=${context.controlSize ?? nothing}
                                    text='${tag.label}'
                                    interactive
                                    closable
                                    :key=${k}
                                    ?active=${hasFilteredValues}
                                    @sf-tag-close="${() => {
                                        context.component.removeFilterTag(k);
                                    }}"
                                    @click=${(e) => {
                                        context.component.openContextMenu(e, {
                                            type: 'bottom',
                                            menu: 'tag-settings',
                                            fieldKey: k,
                                            anchorSelector: '.sf-tag',
                                        })
                                    }}
                                    count='${count}'
                            ></sf-tag>
                        </div>`
                })}
                </div>` : nothing}
                ${activeFilterTags.length || hasUnsavedFilterDataChanges ? html`
                    ${hasUnsavedFilterDataChanges ? html`
                        <sf-button
                                size=${context.controlSize ?? nothing}
                                appearance="tonal"
                                scheme="primary"
                                text=${context.component.text('saveText')}
                                @click="${() => context.component.saveCurrentFilterTemplateData()}"
                        ></sf-button>
                    ` : nothing}
                    ${activeFilterTags.length ? html`
                        <sf-button
                                size=${context.controlSize ?? nothing}
                                appearance="outline"
                                scheme="on-surface"
                                text=${context.clearText}
                                @click="${() => context.component.removeFilterTag()}"
                        ></sf-button>
                    ` : nothing}
                ` : nothing}
            </div>

            <div class="sf-table-toolbar-end flex items-cross-center gap-1/3 flex-wrap flex-auto min-w-0">
                <sf-input
                        size=${context.controlSize ?? nothing}
                        root-class="sf-search-input m-inline-start-auto"
                        appearance="bordered"
                        value="${value}"
                        placeholder=${context.searchPlaceholder}
                        name="sf_table_search"
                        input-type="search"
                        icon-start="search"
                        clearable
                        aria-label=${context.searchPlaceholder}
                        @input=${(e) => {
                            context.component.searchChange({
                                value: getEventInputValue(e, value)
                            });
                        }}
                        @keydown=${(e) => {
                            context.component.handleSearchKeyDown(e);
                        }}
                        @keyup=${(e) => {
                            context.component.handleSearchKeyUp(e);
                        }}
                ></sf-input>

                ${context.layoutSwitch ? html`
                    <sf-segmented class="sf-table-layout-switch" size=${context.controlSize ?? nothing}
                            aria-label=${context.component.text('layoutSwitchLabel')}
                            value=${context.shownLayout}
                            .items=${context.component.layoutSwitchItems()}
                            @change=${(e) => {
                                const chosen = e.detail?.value;
                                if (chosen === 'list' || chosen === 'table') context.component.setLayoutChoice(chosen);
                            }}></sf-segmented>` : nothing}

                ${context.actions && context.creatable
                        ? html`
                            <div class="flex items-cross-center">
                                <sf-button
                                        size=${context.controlSize ?? nothing}
                                        appearance="default"
                                        scheme="primary"
                                        text=${context.createText}
                                        segment=${state.createItems?.length ? 'start' : nothing}
                                        @click=${() => context.component.requestCreateIntent(null)}
                                ></sf-button>
                                ${state.createItems?.length ? html`
                                    <sf-button-icon
                                            size=${context.controlSize ?? nothing}
                                            appearance="default"
                                            scheme="primary"
                                            segment="end"
                                            icon="keyboard_arrow_down"
                                            aria-label=${context.component.text('createMoreLabel')}
                                            aria-haspopup="menu"
                                            @click=${(e) => {
                                                context.component.openContextMenu(e, {
                                                    type: 'bottom',
                                                    menu: 'create',
                                                });
                                            }}
                                    ></sf-button-icon>
                                ` : nothing}
                            </div>
                        `
                        : nothing}

                <!-- The extra actions of the view, from the host. Column
                     settings are not here: they are the gear in the table's own
                     head, where they have always been. Without actions there is
                     no control, because an empty menu is a dead end. -->
                ${context.settings && state.toolbarActions?.length
                        ? html`
                            <sf-button-icon
                                    size=${context.controlSize ?? nothing}
                                    appearance="outline"
                                    scheme="on-surface"
                                    icon="more_horiz"
                                    aria-label=${context.component.text('contextViewActionsLabel')}
                                    aria-haspopup="menu"
                                    @click=${e => {
                                        context.component.openContextMenu(e, { menu: 'toolbar-actions' });
                                    }}
                            ></sf-button-icon>
                        `
                        : nothing}
            </div>
        </div>
    `;
}


// The state the region is actually in: the author's data-state, or what the
// rows resolve to. It is declared on the region, not guessed from the markup.
// What the table says when it has no rows, one brick for every reason
// (owner, 2026-10-14): sf-empty-state at the table's size, the reason and its
// one action from what the table and its data view know -- no access, could
// not load (Повторить), nothing found (what the reset clears), no data
// (Создать when the table may create). A slot `empty` replaces it whole.
function renderEmptyState(context, dataState) {
    const component = context.component;
    // The page's own state (C296): slot="empty" for no records, slot="error"
    // for a failed load; an error without one falls back to the empty slot
    // as before, then to the Framework's sf-empty-state.
    const slot = dataState === 'error' && component?.hasSlotContent?.('error') ? 'error' : 'empty';
    if (component?.hasSlotContent?.(slot)) return component.getSlotContent(slot);
    const brick = component.emptyBrick(dataState);
    return html`<sf-empty-state kind=${brick.kind} size=${brick.size} heading-level=${brick.headingLevel}
                                icon=${brick.icon || nothing} heading=${brick.title || nothing} text=${brick.text || nothing} live=${brick.live || nothing}
                                .actions=${brick.actions}></sf-empty-state>`;
}

export function resolvedDataState(context) {
    if (context.dataState !== 'auto') return context.dataState;
    const data = context.component?.getTableData?.() ?? {};
    if ((data.rows || []).length) return 'populated';
    // Nothing given yet -- no columns, no rows -- is a table waiting for its
    // first answer, drawn as its skeleton: «Пока ничего нет» stood there
    // before any answer came (owner, 2026-10-15, frame by frame).
    if (!(data.columns || []).length) return 'loading';
    return 'empty';
}

function renderHeadLabel(context, column) {
    // The actions column is as wide as its icons, and its heading broke in two
    // over them («Дей / ствия»): it is named for assistive technology only.
    if (column.key === 'actions' && !column.component) {
        return html`<span class="sf-table-visually-hidden">${column.label}</span>`;
    }
    // The gear opens the column settings; without them (settings-menu="false",
    // a host that saves no personal settings) the column keeps its row menus and
    // its heading is only a name.
    // settings="false" with row actions keeps the column for the «≡» alone.
    if (column.key === 'settings' && (context.settingsMenu === false || context.settings === false)) {
        return html`<span class="sf-table-visually-hidden">${context.component.text('settingsColumnLabel')}</span>`;
    }
    const content = column.component
        ? context.component.renderSmartElement(column.component.type, column.component.props)
        : column.label;
    if (column.sortable !== true || column.system) {
        return content;
    }
    const sort = context.component.state.sort || {};
    const direction = sort.key === column.key ? sort.direction : null;
    // The mark stands only at the sorted column (owner decision C146 (6));
    // the others show, on hover and focus, the arrow a press would give.
    const icon = direction === 'desc' ? 'arrow_downward' : 'arrow_upward';

    return html`
        <button type="button" class="sf-table-sort-button flex items-cross-center gap-1/4 min-w-0"
                data-direction=${direction || nothing}>
            <span class="truncate">${content}</span>
            <i class="sf-icon sf-table-sort-icon" aria-hidden="true">${icon}</i>
        </button>
    `;
}

function ariaSort(context, column) {
    if (column.sortable !== true || column.system) return nothing;
    const sort = context.component.state.sort || {};
    if (sort.key !== column.key) return 'none';
    return sort.direction === 'asc' ? 'ascending' : 'descending';
}

function renderHead(context) {
    if (context.component?.hasSlotContent?.("head")) {
        return context.component.getSlotContent("head");
    }
    const columns = context.component?.getColumns?.() || [];

    return html`
        <thead class="sticky top-0 z-5">
        <tr>
            ${columns.map((column, k) => {
                        return keyed(`head:${column.key}`, html`
                            <th
                                    class="relative"
                                    data-key="${column.key}"
                                    data-label="${column.label || column.key || ''}"
                                    data-sf-cell=${cellKind(context.component, column, columns)}
                                    data-sf-pinned=${context.component.isPinnedColumn(column) ? '' : nothing}
                                    style=${context.component.getStickyCellStyle(columns, k) || nothing}
                                    aria-sort=${ariaSort(context, column)}
                                    @click=${column.sortable === true
                                            ? (event) => context.component.handleHeaderSortClick(event, column)
                                            : nothing}
                            >
                                ${column.system || k === columns.length - 1 ?
                                        html`${renderHeadLabel(context, column)}${k === columns.length - 1 ? renderTipSurfaces(context) : nothing}` :
                                html`<div
                                        class="sidebar-resizer flex items-cross-center h-full select-none"
                                >
                                    ${renderHeadLabel(context, column)}
                                    <!-- The width is taken by the line between
                                         two headers. There is no handle to find
                                         first: this is the line's own hit strip,
                                         invisible, astride the separator, and
                                         still a button with its name and its
                                         arrows. It is no Tab stop of its own
                                         (owner decision C146 (8), the resizer
                                         study RS-10): the table is one stop;
                                         the keyboard reaches it from the head's
                                         menu, «Изменить ширину» (C158 (5)). -->
                                    <button type="button"
                                            tabindex="-1"
                                            role="separator"
                                            aria-orientation="vertical"
                                            class="sf-table-column-resizer"
                                            id=${context.component.getColumnResizerId(column.key)}
                                            data-sf-column-resizer=${column.key}
                                            aria-label="${context.component.text('columnResizeLabel')}: ${column.label || column.key}"
                                            aria-keyshortcuts="ArrowLeft ArrowRight Home End Enter Escape"
                                    ></button>
                                </div>`}
                            </th>`
                        )
                    }
            )}
        </tr>
        </thead>
    `
}

// The tooltip of a cut name (owner decision C146 (7)): one surface for the
// table, in the head of the last column, which every cut name names by id
// (data-tooltip). A surface in each row cost about ten nodes a row and broke
// the thirty nodes a row of a long list (standard 1.3.8 gate 17).
function renderTipSurfaces(context) {
    return html`<span class="sf-tooltip sf-tooltip--dark sf-tooltip--size-1/3 sf-tooltip--arrow-bottom-inline-start" hidden id=${context.component.tipId('title')}><span class="sf-tooltip-content"><span class="sf-tooltip-text"></span></span></span>`;
}

function toColumnSize(value) {
    if (value === null || typeof value === "undefined" || value === "") {
        return "";
    }

    return typeof value === "number" ? `${value}px` : String(value);
}

// How narrow a data column may become before it stops being readable.
//
// A fixed-layout table divides whatever room it has between its columns and
// will divide it to nothing: at 620px with five columns they came out 61px
// each, which shreds «Код решения» over three lines and cannot hold a date at
// all. The consumer asked for a floor and for the table to scroll instead
// (Larena, 2026-10-06; measured on the admin reference, 2026-10-09).
//
// It is the table's own min-width rather than the columns', because
// `table-layout: fixed` ignores a minimum on a cell -- the widths come from
// the first row. So the floor is summed here and the table carries the total;
// the scroll box around it already scrolls, and starts doing so the moment the
// sum does not fit.
//
// System columns are not in it: select, settings and actions are sized for what
// they hold and are not text anyone reads.
// Field types whose values are prose rather than a name or a code: drawn on one
// line in a row (see renderCellValue).
const LONG_TEXT_TYPES = new Set(['text', 'textarea', 'markdown', 'html']);

const SYSTEM_COLUMNS = new Set(['select', 'settings', 'actions']);

// The first load draws the rows it is waiting for, in the Framework's skeleton
// (owner, 2026-10-12): the shape of the list is on screen before its records,
// instead of one spinner in an empty table. Widths vary by row and column so
// the placeholder reads as text, not as a grid of bars. The words are for a
// reader and stay in a status; the bars are hidden from one.
const SKELETON_ROWS = 6;
const SKELETON_WIDTHS = ['w-3/4', 'w-1/2', 'w-2/3', 'w-1/3', 'w-2/5', 'w-3/5'];
// Where a loaded row has a box, a menu or a gear, a loading row keeps a block
// as tall as that control, so the row is as tall before the data as after it
// (owner, 2026-10-14: the rows jumped when the data came).
const skeletonControl = html`<div class="sf-table-skeleton-control" aria-hidden="true"></div>`;
const skeletonBar = (row, column) => html`<div class="sf-skeleton sf-skeleton--animation-pulse" aria-hidden="true">
    <div class="sf-skeleton-text sf-skeleton-text--size-1/2 ${SKELETON_WIDTHS[(row + column * 2) % SKELETON_WIDTHS.length]}"></div>
</div>`;

// The floor is the component's measurement, not a declaration here: it is
// applied to a column only while there is not room for every column to be
// readable. Written always it would be the width rather than a minimum -- a
// cell that needs more would wrap and a typed row would grow, measured at 81px
// against 57 (owner, 2026-10-09).

// A column's width, floor and cap as its <col> style: the template draws it,
// and the table writes it straight onto the <col> after measuring its content,
// rather than rendering itself again for it (owner, 2026-10-15: a sort was five
// renders of four hundred elements).
export function columnStyle(component, column) {
    // A width the host declared gives back what it holds above the column's
    // content before the box scrolls (fittedWidth); the person's own width
    // (colWidth) stays as set.
    const width = (column.colWidth == null ? component?.fittedWidth?.(column) : '')
            || toColumnSize(column.colWidth ?? column.width ?? column.size)
            || (column.key === 'actions' ? (component?.actionsColumnWidth || 'var(--sf-table--actions-column-width, var(--sf-f0))') : '')
            || component?.contentWidth?.(column)
            // A content-sized table takes no floor: each data column gets its
            // content width and the one that takes the spare room its content
            // width at least (the table's least width), as the unmeasured
            // first paint lays them out. Floored before the widths were
            // measured, or the spare room's column after, the columns stood at
            // 160 on a phone for a frame and every printed cell moved.
            || (component?.columnsAreCramped
                    && !component?.contentSized
                    && component?.columnTakesFloor?.(column)
                ? 'var(--sf-table--column-min-inline-size)'
                : '');
    const minWidth = toColumnSize(column.min_width ?? column.minWidth);
    const maxWidth = toColumnSize(column.maxWidth);
    return [
        width ? `width: ${width}` : "",
        minWidth ? `min-width: ${minWidth}` : "",
        maxWidth ? `max-width: ${maxWidth}` : "",
    ].filter(Boolean).join("; ");
}

function renderColgroup(context) {
    const columns = context.component?.getColumns?.() || [];

    // A keyed table on a phone (C259) lays its few cells out by their
    // content: the name takes what the others leave (default.css).
    if (!columns.length || context.keyedNarrow) {
        return nothing;
    }

    return html`
        <colgroup>
            ${columns.map((column) => {
                // In a fixed layout the column widths come from here, and a
                // column with none is given whatever is left -- divided to
                // nothing when there is little. The floor is written as the
                // width: fixed layout shares any surplus between the columns
                // that have one, so they grow together above it and stop
                // shrinking below it, and the scroll box takes over.
                // `||` and not `??`: toColumnSize answers with an empty string
                // for a column nobody sized, and an empty string is neither
                // null nor undefined. The same shape cost sf-button its icon
                // shortcut for as long as that component existed.
                // The actions column is sized for its buttons. Without a width it
                // took whatever room was left -- a thousand pixels on a wide
                // page -- and the data columns were measured as cramped beside
                // it and held at their floor.
                const style = columnStyle(context.component, column);

                // The column that takes the spare room is marked, so a first
                // paint the code has not measured yet gives it the spare room
                // too (default.css, the unmeasured content-sized table).
                const spare = column.key && column.key === context.component?.spareRoomColumnKey?.();
                return keyed(`col:${column.key}`, html`
                    <col
                            data-key=${column.key || nothing}
                            data-sf-spare-room=${spare ? '' : nothing}
                            style=${style || nothing}
                    />
                `);
            })}
        </colgroup>
    `;
}

// Several values in a cell -- tags for each choice, badges for each language --
// stay on one line: what does not fit folds into «+N», whose title names the
// rest (owner, 2026-10-13). Wrapped, three tags made a row three lines tall in
// a list of one-line rows. The folded values stay in the text, visually hidden,
// so a screen reader still reads them all; the table's afterRender does the
// folding (fitCellValues), because only the laid-out row knows what fits.
function renderCellValues(items, owner) {
    return html`
        <div class="sf-table-cell-values flex items-cross-center gap-1/3">
            ${items.map((item) => renderCellItem(item, owner))}
            <span class="sf-table-cell-more" aria-hidden="true" hidden></span>
        </div>
    `;
}

function renderComponent(component, owner) {
    if (!component?.type) {
        return nothing;
    }
    const props = {...(component.props || {})};
    return owner.renderCellElement ? owner.renderCellElement(component.type, props) : owner.renderSmartElement(component.type, props);
}

function renderCellItem(item, owner) {
    if (item === null || typeof item === "undefined") {
        return nothing;
    }

    // What the shared renderer set answers with is markup, not a descriptor.
    // Nine of its eleven cell renderers happen to answer with a descriptor --
    // a badge, a tag, an avatar, a reference link -- and the two that answer
    // with markup, the colour and the included block, fell through the object
    // branch below and were dropped: every colour cell and every code cell in
    // every table drew nothing at all. A unit calling the renderer saw correct
    // markup, so only a table could show it (admin polygon, 2026-10-10).
    if (isTemplateResult(item)) {
        return item;
    }

    if (typeof item === "object") {
        const {
            component,
            props: itemProps,
            ...itemMeta
        } = item;

        if (!component?.type) {
            return nothing;
        }

        return renderComponent({
            ...component,
            props: {
                ...itemMeta,
                ...(itemProps || {}),
                ...(component.props || {}),
            },
        }, owner);
    }

    return item;
}

function renderLinkCell(value) {
    const cell = normalizeTableLinkCell(value);
    if (!cell) {
        return nothing;
    }

    // The link is the SIMAI Framework's sf-reference-link on the cell's text
    // line, as the field renderers draw a reference in a cell (VF-10); the
    // supporting line under it stays the list's own text. Without a safe href
    // the words are plain text: a link that leads nowhere is not drawn as one.
    return html`
        <span class="sf-table-link-cell flex flex-col min-w-0">
            ${cell.href ? html`<sf-reference-link
                    line="1/2"
                    appearance="plain"
                    icon=""
                    label=${cell.text}
                    href=${cell.href}></sf-reference-link>` : html`<span class="sf-table-link-cell-text">${cell.text}</span>`}
            ${cell.subtext === null ? nothing : html`
                <span class="sf-table-link-cell-subtext sf-text-1/2">${cell.subtext}</span>
            `}
        </span>
    `;
}


// A row's markup, composed per arrangement of its cells (standard 1.3.8
// §18.4, simai/ui-pro#2). A row of plain cells is one Lit template with no
// part per cell: its strings are made once for each sequence of cell kinds
// (a box, the row menu, a text, an empty cell, a full cell) and kept, so Lit
// parses each arrangement once and a drawn row holds no marker per cell --
// about twenty-five nodes where a template per cell held forty-six. The
// fragments are fixed; a cell's values are bound, never written as HTML.
// This is the migration form (§16) until template.html is compiled.
const ROW_HOLE = Symbol("row-hole");

// What a column's cells are to the look (owner decision C146): `number`,
// end-aligned with digits of one width and never wrapped (3); `title`, the
// record's name, up to two lines and then an ellipsis with the whole name
// in a tooltip (7). Other cells keep one line.
function cellKind(component, column, columns) {
    if (!column?.key) return nothing;
    if (component?.isNumberColumn?.(column)) return 'number';
    if (!column.system && column.role === 'title') return 'title';
    if (!column.system && !columns?.some((one) => one?.role === 'title')
            && columns?.find((one) => one?.key && !SYSTEM_COLUMNS.has(one.key) && !one.system) === column) return 'title';
    return nothing;
}
const ROW_STRINGS = new Map();

// The actions cell (view 1.6.1, simai/ui-pro#2): its buttons stand only in
// the row a person is on, and an idle row's cell is the bare <td>. It was a
// child part with an empty box in it (a marker and a <div>, 31 nodes a row
// where 29 do). The cell keeps one kind whether its buttons show or not,
// bound on the cell itself (an element part has no marker): a row whose
// strings change is drawn anew, and the focus that brought the buttons in
// would leave with the old row.
class ActionsCellDirective extends Directive {
    constructor(part) {
        super(part);
        if (part.type !== PartType.ELEMENT) throw new Error("actionsCell binds an element");
    }

    render() {
        return nothing;
    }

    update(part, [content, host]) {
        // A cell never drawn into stays bare; once drawn, Lit's own part
        // empties it.
        if (content !== nothing || part.element.childNodes.length) render(content, part.element, {host});
        return nothing;
    }
}
const actionsCell = directive(ActionsCellDirective);
function rowStrings(kinds) {
    const signature = kinds.join("|");
    const known = ROW_STRINGS.get(signature);
    if (known) return known;
    const pieces = ['<tr data-selected=', ROW_HOLE, ' aria-selected=', ROW_HOLE, ' draggable=', ROW_HOLE, ' aria-level=', ROW_HOLE,
        ' aria-expanded=', ROW_HOLE, ' aria-setsize=', ROW_HOLE, ' aria-posinset=', ROW_HOLE, ' aria-busy=', ROW_HOLE,
        ' aria-rowindex=', ROW_HOLE, ' data-row-id=', ROW_HOLE, ' data-current=', ROW_HOLE, ' aria-current=', ROW_HOLE,
        ' tabindex="-1" @mousedown=', ROW_HOLE, ' @click=', ROW_HOLE, ' @dblclick=', ROW_HOLE, ' @keydown=', ROW_HOLE, '>'];
    for (const kind of kinds) {
        pieces.push('<td data-key=', ROW_HOLE, ' data-item=', ROW_HOLE, ' data-sf-cell=', ROW_HOLE, ' data-sf-pinned=', ROW_HOLE, ' style=', ROW_HOLE);
        // The actions cell's buttons are bound on the cell (actionsCell).
        pieces.push(...(kind === 'actions' ? [' ', ROW_HOLE, '>'] : ['>']));
        if (kind === 'box') {
            pieces.push('<label class=', ROW_HOLE, '><span class="sf-checkbox-box transition flex"><input type="checkbox" data-sf-row-box value=', ROW_HOLE,
                ' .checked=', ROW_HOLE, ' aria-label=', ROW_HOLE, ' @change=', ROW_HOLE,
                // The tick: checkbox class markup draws the glyph of the
                // .sf-icon inside the box (sf-checkbox's own template does the
                // same with sf-icon); without it a checked row showed a filled
                // box and no tick (DEV recipes p1, 2026-11-15).
                '><i class="sf-icon sf-icon--weight-regular pointer-event-none" aria-hidden="true" .textContent=', ROW_HOLE, '></i></span></label>');
        } else if (kind === 'menu') {
            pieces.push('<button type="button" class=', ROW_HOLE, ' aria-label=', ROW_HOLE, ' value="menu" data-sf-row-menu @click=', ROW_HOLE,
                '><i class="sf-icon sf-icon--weight-regular pointer-event-none" aria-hidden="true">menu</i></button>');
        } else if (kind === 'text') {
            pieces.push('<span class=', ROW_HOLE, ' title=', ROW_HOLE, ' .textContent=', ROW_HOLE, '></span>');
        } else if (kind === 'time') {
            // A date (C40, PD-9): a time element with the record's own day.
            pieces.push('<time class=', ROW_HOLE, ' datetime=', ROW_HOLE, ' title=', ROW_HOLE, ' .textContent=', ROW_HOLE, '></time>');
        } else if (kind === 'node') {
            pieces.push(ROW_HOLE);
        }
        pieces.push('</td>');
    }
    pieces.push('</tr>');
    const strings = [''];
    for (const piece of pieces) {
        if (piece === ROW_HOLE) strings.push('');
        else strings[strings.length - 1] += piece;
    }
    const made = Object.freeze(Object.assign(strings, {raw: Object.freeze(strings.slice())}));
    ROW_STRINGS.set(signature, made);
    return made;
}

export function renderTableTemplate(context) {
    const {state} = context.component;

    function renderBody() {
        if (context.component?.hasSlotContent?.("body")) {
            return html`
                <tbody>
                ${context.component.getSlotContent("body")}
                </tbody>`;
        }

        const {state} = context.component;
        const columns = context.component?.getColumns?.() || [];
        const {rows = []} = state.data || {};
        const dataState = resolvedDataState(context);

        // A re-query over rows that are already on screen leaves them there,
        // dimmed, with one small spinner in the middle of what the person can
        // see. Replacing them with a loader — which is what happened before —
        // threw away the place they were reading and moved the answer to the top
        // left corner of an empty table.
        if (dataState === 'loading' && rows.length) {
            return renderRows(context, columns, rows, {busy: true});
        }

        if (dataState !== 'populated') {
            const stateContent = {
                // One indicator, the same one a re-query shows, centred in the
                // body rather than lined up at its start. The spinner paints its
                // own `label` as text and defaults it to "Loading...", so it is
                // given an empty one: the words are for a reader, in the
                // language the host set, and the circle is for everyone else.
                // Before this there were two indicators here, one of them in
                // English on a Russian page.
                loading: null,
                error: renderEmptyState(context, 'error'),
                empty: renderEmptyState(context, 'empty'),
            }[dataState] || renderEmptyState(context, 'empty');

            if (dataState === 'loading') {
                return html`
                    <tbody data-state="loading" class="sf-table-skeleton">
                        ${Array.from({length: SKELETON_ROWS}, (_, row) => html`<tr aria-hidden="true">
                            ${columns.some((column) => !SYSTEM_COLUMNS.has(column?.key))
                                    ? columns.map((column, at) => html`<td>${SYSTEM_COLUMNS.has(column?.key) ? skeletonControl : skeletonBar(row, at)}</td>`)
                                    // Before the host's first answer the columns are not
                                    // known yet: three bars across the whole row.
                                    : html`<td colspan=${String(Math.max(columns.length, 1))}>
                                        <div class="flex gap-2">${[0, 1, 2].map((at) => html`<div class="flex-1">${skeletonBar(row, at)}</div>`)}</div>
                                    </td>`}
                        </tr>`)}
                    </tbody>
                    <tbody><tr><td colspan=${String(Math.max(columns.length, 1))} class="sf-table-visually-hidden">
                        <span role="status">${context.loadingText}</span>
                    </td></tr></tbody>
                `;
            }
            return html`
                <tbody data-state=${dataState}>
                    <tr>
                        <td colspan=${String(Math.max(columns.length, 1))}>
                            <div class="sf-table-state">${stateContent}</div>
                        </td>
                    </tr>
                </tbody>
            `;
        }

        return renderRows(context, columns, rows);
    }

    // The compact list: each record as a block -- its box, its title (with the
    // tree's indent and button when it is a tree), the few fields the columns'
    // priority puts first, and its row menu. Opening and selecting are the
    // row's, so a record does in the list what it does in the table. The rest
    // of the record is the record panel's, opened the way a row opens it.
    function renderList() {
        const columns = context.component?.getColumns?.() || [];
        const {rows = []} = state.data || {};
        const dataState = resolvedDataState(context);
        if (dataState !== 'populated' && !(dataState === 'loading' && rows.length)) {
            if (dataState === 'loading') {
                return html`<div class="sf-table-list sf-table-skeleton flex flex-col" data-state="loading">
                    ${Array.from({length: SKELETON_ROWS}, (_, row) => html`<div class="sf-table-list-item flex flex-col gap-1/3 p-1" aria-hidden="true">
                        ${skeletonBar(row, 0)}${skeletonBar(row, 1)}
                    </div>`)}
                    <span class="sf-table-visually-hidden" role="status">${context.loadingText}</span>
                </div>`;
            }
            return html`<div class="sf-table-state" data-state=${dataState}>${renderEmptyState(context, dataState)}</div>`;
        }
        const select = columns.find((column) => column.key === 'select');
        // A list whose host offers no row actions draws no «≡» on a phone
        // either, as the desktop table (VR14-4; rowMenuHasUse).
        const menu = context.component.rowMenuHasUse?.() === false ? null : columns.find((column) => column.key === 'settings');
        const roles = context.component.listRoles?.(columns);
        if (roles?.any) return renderResourceList(columns, rows, dataState, roles, select, menu);
        const data = columns.filter((column) => column?.key && !['select', 'settings', 'actions'].includes(column.key)
            && !column.system && column.visible !== false);
        const title = data.find((column) => column.role === 'title') ?? data[0];
        // The title the host marked opens its record with one click here as
        // in the table's title column; a list on a laptop is the same admin.
        const listTitle = (row) => (title.role === 'title'
            ? renderTitleLink(context, row, renderCellValue(row, title))
            : renderCellValue(row, title));
        // The person's «На телефоне» fields, else the first list-fields by
        // priority (LV3-11; phoneShownKeys).
        const phoneKeys = context.component.phoneShownKeys?.(columns);
        const limit = Math.max(0, Number(context.component.getProp?.('listFields') ?? 3) || 0);
        const fields = phoneKeys
            ? phoneKeys.map((key) => data.find((column) => String(column.key) === key && column !== title)).filter(Boolean)
            : data.filter((column) => column !== title)
                .map((column, order) => ({column, order}))
                .sort((a, b) => ((a.column.priority ?? 1e6) - (b.column.priority ?? 1e6)) || (a.order - b.order))
                .slice(0, limit)
                .map(({column}) => column);
        const filled = (value) => !(value === null || value === undefined || value === '' || (Array.isArray(value) && !value.length));
        // A record list (C259, VT-2): «≡» right after the box, where the
        // table has it; the quick actions of a resource list (C31) keep the end.
        const record = !context.quickActionIds?.length;
        return html`${renderListHead(select)}
            <ul class="sf-table-list" role="list" id=${`${context.rowAreaId}-list`} aria-label=${context.ariaLabel || nothing}
                aria-busy=${dataState === 'loading' ? 'true' : nothing}>
                ${rows.map((row, rowIndex) => row.__tree?.more
                    ? keyed(`item:${row.id}`, html`
                        <li class="sf-table-list-more" style=${`--sf-table-tree--level: ${row.__tree.level}`}>
                            <sf-button appearance="ghost" size="1/2" text=${context.component.text('treeMore')}
                                       @click=${() => context.component.requestTreeMore(row)}></sf-button>
                        </li>`)
                    : keyed(`item:${context.component.rowsGeneration?.() ?? 0}:${row.id ?? rowIndex}`, html`
                        <li class="sf-table-list-item"
                            data-sf-record=${record && menu ? '' : nothing}
                            data-row-id=${context.component.getRowKey(row, rowIndex)}
                            data-selected=${row.select?.component?.props?.checked === true ? '' : nothing}
                            data-current=${context.component.isCursorRow(row, rowIndex) ? '' : nothing}
                            aria-current=${context.component.isCurrentRow(row, rowIndex) ? 'true' : nothing}
                            aria-level=${row.__tree ? String(row.__tree.level + 1) : nothing}
                            aria-expanded=${row.__tree?.hasChildren ? String(row.__tree.expanded === true) : nothing}
                            tabindex="-1"
                            @mousedown=${(event) => context.component.handleRowPointerDown(event)}
                            @click=${(event) => context.component.handleRowClick(event, row, rowIndex)}
                            @dblclick=${(event) => context.component.handleRowOpen(event, row)}
                            @keydown=${(event) => context.component.handleRowKeydown(event, row)}>
                            ${select ? html`<span class="sf-table-list-select">${renderCellValue(row, select)}</span>` : nothing}
                            ${record && menu ? renderListMenu(row) : nothing}
                            <div class="sf-table-list-main">
                                <div class="sf-table-list-title">${title
                                    ? (row.__tree || row.path ? renderTreeCell(context, row, listTitle(row)) : listTitle(row))
                                    : nothing}</div>
                                ${fields.some((column) => filled(row[column.key])) ? html`
                                    <div class="sf-table-list-fields">
                                        ${fields.filter((column) => filled(row[column.key])).map((column) => html`
                                            <span class="sf-table-list-field">
                                                <span class="sf-table-list-label">${column.label ?? column.key}</span>
                                                <span class="sf-table-list-value">${renderCellValue(row, column)}</span>
                                            </span>`)}
                                    </div>` : nothing}
                            </div>
                            ${context.quickActionIds?.length ? renderListActions(row, menu) : nothing}
                        </li>`))}
            </ul>`;
    }

    // The page's box over a phone list (VT-2, BA-6): the head's box, with its
    // words, so a whole page is marked in one press as in the table.
    function renderListHead(select) {
        if (!select) return nothing;
        return html`<div class="sf-table-list-head" data-sf-list-all>
            ${renderHeadLabel(context, select)}
            <span class="sf-table-list-head-text" aria-hidden="true">${context.component.text('listSelectPage')}</span>
        </div>`;
    }

    // A record row's «≡» (C259 (3), C146 (5)): the row's one menu, every
    // action of the row; the same menu the right button and a long press open.
    function renderListMenu(row) {
        const component = context.component;
        if (!component.listRowActions(row).rest.length && !component.listRowActions(row).quick.length) return nothing;
        const size = context.size === '1/2' ? '1/2' : '1';
        const name = component.getRowNameText(row);
        return html`<span class="sf-table-list-menu"><button type="button"
                class=${`sf-icon-button sf-icon-button--size-${size} sf-icon-button--icon sf-icon-button--ghost sf-icon-button--on-surface flex items-cross-center`}
                aria-label=${name ? `${component.text('contextRowActionsLabel')}: ${name}` : component.text('contextRowActionsLabel')}
                aria-haspopup="menu" data-sf-row-menu
                @click=${(event) => {
                    event.stopPropagation();
                    component.openRowMenu(event, row);
                }}><i class="sf-icon sf-icon--weight-regular pointer-event-none" aria-hidden="true">menu</i></button></span>`;
    }

    // The amount of a record row (C259): the first money (else number)
    // column's value, as its cell shows it.
    function listAmountColumn(columns) {
        const data = columns.filter((column) => column?.key && !SYSTEM_COLUMNS.has(column.key) && !column.system && column.visible !== false);
        const type = (column) => column.propertyType ?? column.property_type ?? column.type;
        const kept = (column) => (context.component.phoneRole?.(column, columns) ?? column.list) !== 'hidden';
        return data.find((column) => type(column) === 'money' && kept(column)) ?? data.find((column) => context.component.isNumberColumn?.(column) && kept(column)) ?? null;
    }

    // ─── the list of resources (owner decision C31) ─────────────────────────
    // A row is the status dot, the title over a supporting line («domain ·
    // kind»), the facts as badges without labels in columns of one width,
    // and the quick actions with the «more» menu. The roles are the columns'
    // (columns[].list); a column without one is the record panel's.
    function renderResourceList(columns, rows, dataState, roles, select, menu) {
        const component = context.component;
        const visible = (column) => column && column.visible !== false;
        const status = visible(roles.status) ? roles.status : null;
        const data = columns.filter((column) => column?.key && !['select', 'settings', 'actions'].includes(column.key) && !column.system);
        const title = roles.title ?? data.find((column) => column.role === 'title' && column.list !== 'hidden')
            ?? data.find((column) => !column.list) ?? data[0];
        const supporting = roles.supporting.filter(visible);
        const facts = roles.facts.filter(visible);
        const opensRow = component.getAttribute('row-open') === 'row';
        // A record list (C259, VT-2): no quick actions -- «≡» after the box,
        // the title over its second line, then every fact and the amount.
        const record = !context.quickActionIds?.length;
        // The amount once: a money column the facts already show is not drawn again.
        const amountColumn = record ? listAmountColumn(columns) : null;
        const amount = amountColumn && !facts.includes(amountColumn) ? amountColumn : null;
        const titleOf = (row) => {
            const text = component.listText(title, row[title?.key]);
            return title?.role === 'title' || roles.title || opensRow
                ? renderTitleLink(context, row, text)
                : text;
        };
        return html`${renderListHead(select)}
            <ul class="sf-table-list sf-table-list--resource" role="list" id=${`${context.rowAreaId}-list`} aria-label=${context.ariaLabel || nothing}
                aria-busy=${dataState === 'loading' ? 'true' : nothing}
                style=${`--sf-table-resource--actions: ${Math.max(1, (context.quickActionIds?.length ?? 0) + (menu ? 1 : 0))}`}>
                ${rows.map((row, rowIndex) => {
                    if (row.__tree?.more) return keyed(`item:${row.id}`, html`
                        <li class="sf-table-list-more" style=${`--sf-table-tree--level: ${row.__tree.level}`}>
                            <sf-button appearance="ghost" size="1/2" text=${component.text('treeMore')}
                                       @click=${() => component.requestTreeMore(row)}></sf-button>
                        </li>`);
                    const state = status ? component.listStatus(status, row) : null;
                    const shown = facts.map((column) => ({column, fact: component.listFact(column, row)}));
                    // The most worrying fact, the one a narrow list keeps.
                    const worst = shown.reduce((found, item) => ((item.fact?.level ?? 0) > (found?.fact?.level ?? 0) ? item : found), null);
                    const words = supporting.map((column) => component.listText(column, row[column.key])).filter(Boolean);
                    // The state's word leads the line for every state (LV3-24); a
                    // wide list keeps it for a stopped one only (C31).
                    const lead = state?.word ?? '';
                    const coloured = state && state.dot !== 'neutral';
                    return keyed(`item:${component.rowsGeneration?.() ?? 0}:${row.id ?? rowIndex}`, html`
                        <li class="sf-table-list-item sf-table-resource"
                            data-sf-record=${record && menu ? '' : nothing}
                            data-sf-quick-list=${record ? nothing : ''}
                            data-row-id=${component.getRowKey(row, rowIndex)}
                            data-selected=${row.select?.component?.props?.checked === true ? '' : nothing}
                            data-current=${component.isCursorRow(row, rowIndex) ? '' : nothing}
                            aria-current=${component.isCurrentRow(row, rowIndex) ? 'true' : nothing}
                            data-status=${state?.dot ?? nothing}
                            data-open=${opensRow && component.canOpenRow?.(row) ? 'row' : nothing}
                            aria-level=${row.__tree ? String(row.__tree.level + 1) : nothing}
                            aria-expanded=${row.__tree?.hasChildren ? String(row.__tree.expanded === true) : nothing}
                            tabindex="-1"
                            @mousedown=${(event) => component.handleRowPointerDown(event)}
                            @click=${(event) => component.handleRowClick(event, row, rowIndex)}
                            @dblclick=${(event) => component.handleRowOpen(event, row)}
                            @keydown=${(event) => component.handleRowKeydown(event, row)}>
                            ${select ? html`<span class="sf-table-list-select">${renderCellValue(row, select)}</span>` : nothing}
                            ${record && menu ? renderListMenu(row) : nothing}
                            ${status ? html`<span class="sf-table-resource-status">${state ? tooltip(html`
                                <span class="sf-dot sf-dot--${state.dot}" data-tooltip="" data-status=${state.value}>
                                    <span class="sf-dot-item"></span>
                                    <span class="sf-table-visually-hidden">${state.word}</span>
                                </span>`, state.word) : nothing}</span>` : nothing}
                            <span class="sf-table-resource-main">
                                <span class="sf-table-resource-title">${title
                                    ? (row.__tree || row.path ? renderTreeCell(context, row, titleOf(row)) : titleOf(row))
                                    : nothing}</span>
                                ${lead || words.length ? html`<span class="sf-table-resource-supporting">${lead
                                    ? html`<span class="sf-table-resource-lead" data-coloured=${coloured ? '' : nothing}>${lead}${words.length ? ' · ' : ''}</span>`
                                    : nothing}${words.join(' · ')}</span>` : nothing}
                            </span>
                            ${record && menu ? html`<span class="sf-table-list-end">
                                ${shown.filter(({fact}) => fact).map(({column, fact}) => html`<span class="sf-table-resource-fact">${renderFact(column, fact)}</span>`)}
                                ${amount && row[amount.key] !== undefined && row[amount.key] !== null && row[amount.key] !== ''
                                    ? html`<span class="sf-table-list-amount"><span class="sf-table-visually-hidden">${amount.label ?? amount.key}: </span>${renderCellValue(row, amount)}</span>`
                                    : nothing}
                            </span>` : html`
                            ${facts.length ? html`<span class="sf-table-resource-facts">${shown.map(({column, fact}) => html`
                                <span class="sf-table-resource-fact" data-worst=${fact && worst?.column === column && fact.level > 0 ? '' : nothing}>${fact
                                    ? renderFact(column, fact)
                                    : nothing}</span>`)}</span>` : nothing}
                            ${renderListActions(row, menu)}`}
                        </li>`);
                })}
            </ul>`;
    }

    // A fact: a badge without its column's label, which a screen reader
    // still hears; quiet when all is well, warning or error when not.
    // In a list row the badge stands on the row's second line (register
    // VL-75, owner remarks 9 and 13): the line's own text size and height,
    // which is the row text on a phone, secondary by ink only.
    function renderFact(column, fact) {
        return html`<span class="sf-table-visually-hidden">${column.label ?? column.key}: </span>${renderFactBadge(fact, 'text')}`;
    }

    // The badge of a fact, in a list row and in a table cell alike.
    function renderFactBadge(fact, line = null) {
        const size = context.size === '1/2' ? '1/3' : '1/2';
        const badge = html`<sf-badge size=${size} line=${line || nothing} appearance="tonal"
                scheme=${fact.status ? nothing : (fact.scheme || 'neutral')} status=${fact.status || nothing}
                text=${fact.text} data-tooltip=${fact.tip ? '' : nothing}></sf-badge>`;
        return fact.tip ? tooltip(badge, fact.tip) : badge;
    }

    // The Framework's tooltip: the trigger and its surface in one anchor
    // (component tooltip), shown on hover and on keyboard focus.
    function tooltip(trigger, text) {
        return html`<span class="sf-tooltip-anchor">${trigger}<span class="sf-tooltip sf-tooltip--dark sf-tooltip--size-1/3 sf-tooltip--arrow-bottom-center" hidden><span class="sf-tooltip-content"><span class="sf-tooltip-text">${text}</span></span></span></span>`;
    }

    // A list row's actions (C31): up to three quick ones as icon buttons,
    // always shown (folded away on a narrow list), then «more» (more_horiz),
    // whose menu holds every action of the row (C259 (3)).
    function renderListActions(row, menu) {
        const component = context.component;
        // The rest is the row menu's, and a table without its menu column
        // (settings="false") has none: then only the quick ones are drawn.
        const split = component.listRowActions(row);
        const quick = split.quick;
        const rest = menu ? split.rest : [];
        if (!quick.length && !rest.length) return nothing;
        const size = context.size === '1/2' ? '1/2' : '1';
        const button = 'sf-icon-button sf-icon-button--icon sf-icon-button--ghost sf-icon-button--on-surface-variant flex items-cross-center';
        const iconOf = (action) => action?.icon ?? action?.component?.props?.icon ?? '';
        const press = (action) => (event) => {
            event.stopPropagation();
            const handler = action?.component?.props?.['@click'] ?? action?.component?.props?.onClick;
            if (typeof handler === 'function') handler(event);
            else component.requestActionIntent(action.id, [row.id]);
        };
        return html`<span class="sf-table-resource-actions" data-only-quick=${rest.length ? nothing : ''}>
            ${quick.length ? html`<span class="sf-table-resource-quick">${quick.map((action) => (iconOf(action)
                ? tooltip(html`<button type="button" class=${`${button} sf-icon-button--size-${size}`} data-tooltip=""
                        data-quick-action=${action.id} aria-label=${action.name ?? action.id}
                        @click=${press(action)}><i class="sf-icon" aria-hidden="true">${iconOf(action)}</i></button>`, action.name ?? action.id)
                : html`<sf-button size=${size} appearance="ghost" scheme="on-surface-variant" data-quick-action=${action.id}
                        text=${action.name ?? action.id} @click=${press(action)}></sf-button>`))}</span>` : nothing}
            <button type="button" class=${`${button} sf-icon-button--size-${size} sf-table-resource-more`}
                    aria-label=${component.getRowNameText(row) ? `${component.text('moreActionsLabel')}: ${component.getRowNameText(row)}` : component.text('moreActionsLabel')} aria-haspopup="menu" data-sf-row-menu
                    @click=${(event) => {
                        event.stopPropagation();
                        // Every action of the row, the quick ones too (C259 (3),
                        // C164 (2)): the list the right button opens.
                        component.openRowMenu(event, row);
                    }}><i class="sf-icon" aria-hidden="true">more_horiz</i></button>
        </span>`;
    }

    // The title opens its record with one click (owner, 2026-10-14): the
    // column the host marked as the title is a link to the record's view when
    // the row offers it, so a record is a click away rather than a double
    // click or a trip through the row's menu.
    function renderTitleLink(context, row, value) {
        if (!context.component.canOpenRow?.(row) || row?.id == null) return value;
        const address = row.href ?? row.url ?? '';
        // A record without an address opens through the view and is a button:
        // a link to «#» opened the same page in a new tab (VT-9).
        if (!address) {
            return html`<button type="button" class="sf-table-title-link"
                @click=${(event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    if (event.detail > 1) return;
                    context.component.requestOpen?.(row, false);
                    context.component.requestActionIntent('view', [row.id]);
                }}>${value}</button>`;
        }
        return html`<a class="sf-table-title-link" href=${address}
                @click=${(event) => {
                    if (event.button > 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                        if (row.href ?? row.url) {
                            context.component.requestOpen?.(row, true);
                            return;
                        }
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    // The second click of a double click is the same wish:
                    // opened once, not twice.
                    if (event.detail > 1) return;
                    context.component.requestOpen?.(row, false);
                    context.component.requestActionIntent('view', [row.id]);
                }}>${value}</a>`;
    }

    // repeat, not keyed: a sort moves the rows it already drew. keyed at each
    // position redrew every row and every value in it when the order changed --
    // four hundred elements for one click (owner, 2026-10-15).
    //
    // Many entries (standard simai.smart-component 1.3.8 §18.4, gate 17;
    // simai/ui-pro#2). From the quality profile's threshold on (300 rows) the
    // table draws only the rows in view and a margin, with one spacer row
    // above and one below holding the height of the rest; the component keeps
    // the range (windowSlice) and moves it with the scroll. A cell that only
    // shows a value is class markup: the row's box is the checkbox's class
    // markup over a native input, the row's menu the icon button's class
    // markup over a native button, and text a span -- no Smart element per
    // cell, so a row is about twenty-five nodes instead of a hundred and eight.
    function renderRows(context, columns, rows, {busy = false} = {}) {
        const component = context.component;
        const treeColumn = component.treeColumnKey?.(columns);
        // The main field is the link that opens the record (owner decision
        // C146 (5), variant В): the column the host marked as the title, else
        // the first data column when it shows a plain value (a column with a
        // renderer or a component of its own keeps it).
        const firstData = columns.find((column) => column?.key && !SYSTEM_COLUMNS.has(column.key) && !column.system);
        const titleColumn = columns.find((column) => column?.role === 'title' && !column.system)?.key
            ?? (firstData && !firstData.renderer && !firstData.component && !component.isNumberColumn?.(firstData) ? firstData.key : null);
        const slice = component.windowSlice?.(rows) ?? null;
        const shown = slice ? rows.slice(slice.first, slice.last + 1) : rows;
        const offset = slice ? slice.first : 0;
        const span = String(Math.max(columns.length, 1));
        const draggable = (component.hasAttribute('drag-rows') || component.getAttribute('row-reorder') === 'true');
        const selectable = columns.some((column) => column?.key === 'select');
        const sticky = columns.map((column, index) => component.getStickyCellStyle(columns, index) || nothing);
        const cellKinds = columns.map((column) => cellKind(component, column, columns));
        const pinned = columns.map((column) => (component.isPinnedColumn(column) ? '' : nothing));
        const lined = columns.map((column) => Boolean(component.keyLineOf?.(column)));
        // The stripes are nth-child: a spacer of no height keeps the parity of
        // the drawn rows the parity they have in the whole list.
        const spacer = (height, key) => html`<tr class="sf-table-window-spacer" aria-hidden="true" data-sf-window-spacer=${key}><td colspan=${span} style=${`block-size: ${Math.max(0, Math.round(height))}px`}></td></tr>`;
        const fullCell = (row, column, kind) => {
            const value = column.key === titleColumn ? renderTitleLink(context, row, renderCellValue(row, column)) : renderCellValue(row, column);
            // A key cell's second line on a phone (C259): the value of the
            // column the host names in key_line, quiet, one line.
            const line = component.keyLineOf?.(column);
            if (line) {
                const raw = row?.[line];
                const text = String((raw !== null && typeof raw === 'object' ? (raw.text ?? raw.label ?? raw.value) : raw) ?? '');
                return html`<span class="sf-table-key-name">${value}</span>${text ? html`<span class="sf-table-key-line">${text}</span>` : nothing}`;
            }
            // The name's two lines (C146 (7)) are its cell's text, by the
            // cell's data-sf-cell="title": no element around it.
            if (column.key === treeColumn) return renderTreeCell(context, row, value);
            return value;
        };
        const renderRow = (row, at) => {
            const index = at + offset;
            const current = component.isCurrentRow(row, index);
            const cursor = component.isCursorRow(row, index);
            const kinds = [];
            const marked = row.select?.component?.props?.checked === true;
            const values = [
                row.select?.component?.props?.checked === true ? '' : nothing,
                // The grid's selection, read by a screen reader (VT-4): every
                // row of a selectable grid says whether it is marked.
                selectable ? String(marked) : nothing,
                draggable && !row.__tree?.more ? 'true' : nothing,
                row.__tree ? String(row.__tree.level + 1) : nothing,
                row.__tree?.hasChildren ? String(row.__tree.expanded === true) : nothing,
                row.__tree ? String(row.__tree.setsize) : nothing,
                row.__tree ? String(row.__tree.posinset) : nothing,
                row.__tree?.loading ? 'true' : nothing,
                component.ariaRowIndex?.(index, Boolean(slice)) ?? (slice ? String(index + 2) : nothing),
                component.getRowKey(row, index),
                cursor ? '' : nothing,
                current ? 'true' : nothing,
                component.rowPointerDown,
                (event) => component.handleRowClick(event, row, index),
                (event) => component.handleRowOpen(event, row),
                (event) => component.handleRowKeydown(event, row),
            ];
            columns.forEach((column, cellIndex) => {
                // The main field of a row that opens is its link, not markup.
                const opens = column.key === titleColumn && component.canOpenRow?.(row) && row?.id != null;
                const mark = opens || lined[cellIndex] ? null : (component.rowMarkupCell?.(row, column) ?? null);
                values.push(column.key, `${row.id}_${column.key}`, cellKinds[cellIndex], pinned[cellIndex], sticky[cellIndex]);
                if (cellKinds[cellIndex] === 'title' && mark?.kind === 'text') {
                    // The name as text: two lines by its cell (C146 (7)).
                    kinds.push('text');
                    values.push('sf-table-cell-text', nothing, mark.text);
                } else if (mark?.kind === 'box') {
                    kinds.push('box');
                    values.push(`sf-checkbox sf-checkbox--size-${mark.size} flex content-main-between cursor-pointer`, mark.value, mark.checked, mark.label, mark.change, mark.checked ? 'check' : '');
                } else if (mark?.kind === 'menu') {
                    kinds.push('menu');
                    values.push(`sf-icon-button sf-icon-button--size-${mark.size} sf-icon-button--icon sf-icon-button--ghost flex items-cross-center sf-icon-button--on-surface`, mark.label, mark.click);
                } else if (mark?.kind === 'text') {
                    kinds.push('text');
                    values.push(mark.className, mark.title ?? nothing, mark.text);
                } else if (mark?.kind === 'time') {
                    kinds.push('time');
                    values.push(mark.className, mark.datetime, mark.title ?? nothing, mark.text);
                } else if (mark?.kind === 'empty') {
                    kinds.push('empty');
                } else if (column.key === 'actions') {
                    kinds.push('actions');
                    values.push(actionsCell(fullCell(row, column), component));
                } else {
                    kinds.push('node');
                    values.push(fullCell(row, column, cellKinds[cellIndex]));
                }
            });
            return html(rowStrings(kinds), ...values);
        };
        return html`<tbody data-busy=${busy ? '' : nothing} data-sf-window=${slice ? `${slice.first}-${slice.last}` : nothing}>${slice ? spacer(slice.before, 'before') : nothing}${slice && slice.first % 2 === 0 ? spacer(0, 'parity') : nothing}${repeat(shown, (row, at) => (row.__tree?.more ? `more:${row.id}` : `row:${component.rowsGeneration?.() ?? 0}:${row.id ?? row.value ?? (at + offset)}`), (row, at) => (row.__tree?.more ? renderMoreRow(context, columns, row) : renderRow(row, at)))}${slice ? spacer(slice.after, 'after') : nothing}</tbody>`;
    }

    // The first cell of a tree row: indented by its level, with the button that
    // opens or closes it when the host said it has children, and -- in a search
    // over a tree -- the path it lives under, so a found row says where it is.
    function renderTreeCell(context, row, value) {
        const tree = row.__tree;
        const path = Array.isArray(row.path) && row.path.length
            ? row.path.map((item) => item?.label ?? item).join(' / ')
            : '';
        if (!tree && !path) return value;
        const level = tree?.level ?? 0;
        const toggle = tree?.hasChildren
            ? html`<button type="button" class="sf-table-tree-toggle"
                           data-expanded=${tree.expanded ? '' : nothing}
                           aria-label=${context.component.text(tree.expanded ? 'treeCollapse' : 'treeExpand')}
                           @click=${(event) => {
                               event.stopPropagation();
                               context.component.toggleTreeRow(row);
                           }}><i class="sf-icon" aria-hidden="true">chevron_right</i></button>`
            : tree ? html`<span class="sf-table-tree-toggle" aria-hidden="true"></span>` : nothing;
        // The node's icon, the host's to choose (port 1.9.0): a page with pages
        // under it is still a page. Without one, a folder for a node with
        // children -- open when it is open -- and a document for a leaf.
        const icon = tree
            ? (tree.expanded ? (row.icon_expanded ?? row.icon) : row.icon)
                ?? (tree.hasChildren ? (tree.expanded ? 'folder_open' : 'folder') : 'description')
            : row.icon;
        return html`
            <span class="sf-table-tree-cell" style=${`--sf-table-tree--level: ${level}`}>
                ${toggle}
                ${icon ? html`<i class="sf-icon sf-table-tree-icon" aria-hidden="true">${icon}</i>` : nothing}
                <span class="sf-table-tree-value flex flex-col min-w-0">
                    <span class="min-w-0">${value}</span>
                    ${path ? html`<span class="sf-table-tree-path">${path}</span>` : nothing}
                </span>
            </span>`;
    }

    // The next page of one level, as a row of its own at that level.
    function renderMoreRow(context, columns, row) {
        return html`
            <tr class="sf-table-tree-more" aria-level=${String(row.__tree.level + 1)}>
                <td colspan=${String(columns.length)}>
                    <span class="sf-table-tree-cell" style=${`--sf-table-tree--level: ${row.__tree.level}`}>
                        <span class="sf-table-tree-toggle" aria-hidden="true"></span>
                        <sf-button appearance="ghost" size="1/2" text=${context.component.text('treeMore')}
                                   @click=${() => context.component.requestTreeMore(row)}></sf-button>
                    </span>
                </td>
            </tr>`;
    }

    function renderCellValue(row, column) {
        if (!column || !row) {
            return nothing;
        }

        let value = row[column.key];

        if (column.renderer === "link") {
            return renderLinkCell(value);
        }
        // `row.actions` is read here in two vocabularies. From a host it is ids
        // -- `["view"]`, the data view port's word for which of the list's
        // actions apply to this record -- and from a consumer that builds its
        // own controls it is the items themselves. Ids select from the table's
        // list; items are the list.
        //
        // Both went through the second branch before, so an array of ids was
        // handed to the filter AS the action list, where `action.id` is
        // undefined for a string: everything was filtered out and the
        // «Действия» column drew an empty container in every row of every list.
        // A consumer reported it on an embedded one, which is only where they
        // were looking (owner, 2026-10-09).
        // The cell is built from whichever vocabulary the row holds, and built
        // once. From a host `row.actions` is ids -- the data view port's word
        // for which of the list's actions apply to this record -- and after
        // normalizeRow it is the built items.
        //
        // Items are not rebuilt here. Passing them back through the builder
        // made new objects on every render, and a table that hands lit new
        // objects rebuilds the cells rather than keeping them, which costs
        // whatever the cells hold. The round-3 probe measures exactly that.
        // `row.actions` is the host's ids -- the data view port's word for which
        // of the list's actions apply to this record -- or, from a consumer that
        // builds its own controls, the items themselves. Ids select from the
        // list; items are the list. Handing ids to the builder AS the list was
        // the defect: `action.id` is undefined for a string, so everything was
        // filtered out and the «Действия» column drew an empty container in
        // every row of every list (owner, 2026-10-09).
        //
        // The built items are kept on the row, because a render that builds new
        // objects makes lit rebuild the cells rather than keep them, and the
        // cells hold things worth keeping. A re-query brings new row objects,
        // so the cache is fresh exactly when the data is.
        if (column.key === 'actions' && context.component?.getActionRowItems) {
            const built = Array.isArray(value) && value.length
                && value.every((item) => item && typeof item === 'object');
            if (!built) value = context.component.rowActionItems(row);
        }


        // A column with a list role (C31) draws its value the same way in a
        // table cell as in a list row: a status is the dot with its word, a
        // fact the badge, quiet or warning/error. Without this, the switch to
        // «Таблица» showed a status's raw value (ok, stopped) and dropped a
        // fact given as {text, status, tip} altogether.
        if (column.list === 'status') {
            const state = context.component.listStatus(column, row);
            return state ? html`<span class="sf-table-status flex items-cross-center gap-1/3" data-status=${state.dot}>
                <span class="sf-dot sf-dot--${state.dot}" aria-hidden="true"><span class="sf-dot-item"></span></span>
                <span>${state.word}</span></span>` : nothing;
        }
        // A plain value of a fact column draws as its type does (LV3-12: the
        // phone row's roles put money and dates raw in pills in the table).
        if (column.list === 'fact' && context.component.factMarked?.(column, row)) {
            return renderFactBadge(context.component.listFact(column, row));
        }

        // A boolean the host lets this person write is a checkbox in the cell;
        // it is disabled while the host answers.
        if (context.component?.cellEditable?.(row, column)) {
            return html`<sf-checkbox size=${context.size === '1/2' ? '1/2' : '1'} data-cell-edit=${column.key}
                ?checked=${value === true} ?disabled=${context.component.cellPending(row, column)}
                aria-label=${column.label ?? column.key}
                @change=${(event) => context.component.setCellValue(row, column, Boolean(event.target?.checked ?? event.detail?.checked))}></sf-checkbox>`;
        }

        if (column.component) {
            if (
                value !== null &&
                typeof value !== "undefined" &&
                (!Array.isArray(value) || value.length)
            ) {
                return renderCellItem(value, context.component);
            }
            if (
                column.key === "settings" &&
                (!value || (Array.isArray(value) && !value.length))
            ) {
                return renderComponent({
                    type: "button-icon",
                    props: {
                        size: "1",
                        appearance: "ghost",
                        scheme: "on-surface",
                        icon: "menu",
                        ariaLabel: context.component.text('menuLabel'),
                        value: "menu",
                    },
                }, context.component);
            }

            return renderComponent(column.rowComponent || column.component, context.component);
        }

        if (value === null || typeof value === "undefined") {
            return nothing;
        }

        // A long text -- a description, a note -- is one line in a row, cut
        // with an ellipsis; the whole of it is in the title for the pointer and
        // in the text for a screen reader. Wrapped, one description made its row
        // three lines tall in a list of one-line rows (owner, 2026-10-13).
        if (LONG_TEXT_TYPES.has(column.propertyType ?? column.property_type ?? column.type)
                && (typeof value === "string" || typeof value === "number")) {
            const text = context.component?.cellText?.(column, value) ?? String(value);
            return html`<span class="sf-table-cell-clip" title=${text}>${text}</span>`;
        }

        // The renderer set is asked before the shapes below, because a typed
        // cell's value is often an object -- a user or a related record arrives
        // as {value, label, href} -- and the object branch would render nothing
        // for it: it looks for a component the host put there. A cell that does
        // carry the host's own component still wins, which is the check here.
        const carriesHostComponent = typeof value === "object" && !Array.isArray(value)
            && Boolean(value.component?.type);
        if (!carriesHostComponent) {
            const typed = context.component?.cellValue?.(column, value);
            if (typed !== null && typeof typed !== "undefined") {
                // Badges and tags from the renderer set wrap onto the next line,
                // as the host's own values do: this branch drew them in one
                // line that ran out of the cell (owner, 2026-10-12).
                if (Array.isArray(typed)) {
                    // A person -- the avatar, then the name -- stays on one
                    // line: wrapping put the avatar above a two-line name. The
                    // name wraps beside it instead.
                    if (typed[0]?.component?.type === 'avatar') {
                        return html`
                            <div class="flex flex-nowrap items-cross-center gap-1/3">
                                ${renderCellItem(typed[0], context.component)}
                                <span style="min-inline-size: 0">
                                    ${typed.slice(1).map((item) => renderCellItem(item, context.component))}
                                </span>
                            </div>
                        `;
                    }
                    return renderCellValues(typed, context.component);
                }

                const datetime = typeof typed === "string" ? context.component?.cellDateTime?.(column, value) : "";
                if (datetime) return html`<time datetime=${datetime} title=${context.component?.cellTitle?.(column, value) ?? nothing}>${typed}</time>`;
                return renderCellItem(typed, context.component);
            }
        }

        if (Array.isArray(value)) {
            if (column.key === 'actions') {
                value = value.filter(el => {
                    const {actions} = state;
                    const actionId = el.id || el.component?.props?.value;
                    const action = actions.find(action => action.id === actionId);
                    // The host's own actions (its row_actions) live in the row
                    // menu: a page has a dozen of them, which drawn in a row of
                    // buttons wrapped it to three lines.
                    if (el.inline === false) return false;

                    return action?.visible ?? true
                });
            }
            // Several values -- badges for each language, tags for each choice
            // -- wrap onto the next line when the column is narrower than
            // they are, instead of running out of the cell under the next one.
            // The row of actions stays on one line: it is sized for it.
            if (column.key === 'actions') {
                // A row's buttons stand in the row a person is on -- under the
                // pointer, with the focus, or current -- and the column keeps its
                // width in the others (owner, 2026-10-15): drawn in every row they
                // were most of a page's elements.
                if (!context.component.actionsShownFor?.(row)) return nothing;
                return html`
                    <div class="sf-table-row-actions flex items-cross-center gap-1/3">
                        ${value.map((item) => renderCellItem(item, context.component))}
                    </div>
                `;
            }
            return renderCellValues(value, context.component);
        }

        if (typeof value === "object") {
            return renderCellItem(value, context.component);
        }

        // Plain text stops at three lines with an ellipsis: a long description
        // in a list made one row as tall as the screen (owner, 2026-10-12). The
        // whole text is the record's, and a long one reads in full on hover.
        const text = String(value);
        return html`<span class="sf-table-cell-text" title=${text.length > 80 ? text : nothing}>${text}</span>`;
    }

    // The totals at the foot (owner decision C296, q-totals B): a row for the
    // page and one for everything under the filter, each when the host gives
    // it; the numbers are the host's (totals), drawn as their cells are, in
    // the columns marked `total`; the words stand in the first data column.
    function renderFoot() {
        const component = context.component;
        const totals = component.totals;
        if (!totals || resolvedDataState(context) !== 'populated') return nothing;
        const columns = component.getColumns?.() || [];
        const sides = [['page', 'totalsPage'], ['all', 'totalsAll']].filter(([side]) => totals[side]);
        const marked = columns.filter((column) => column?.total === true);
        if (!sides.length || !marked.length) return nothing;
        const labelAt = columns.findIndex((column) => column?.key && !SYSTEM_COLUMNS.has(column.key) && !column.system && column.total !== true);
        return html`<tfoot class="sf-table-totals">${sides.map(([side, word]) => html`<tr data-sf-totals=${side}>${columns.map((column, index) => {
            const sticky = component.getStickyCellStyle(columns, index) || nothing;
            if (index === labelAt) return html`<th scope="row" data-key=${column.key} style=${sticky}>${component.text(word)}</th>`;
            const value = column.total === true ? totals[side]?.[column.key] : undefined;
            if (value === undefined || value === null || value === '') return html`<td data-key=${column.key} style=${sticky}></td>`;
            const typed = component.cellValue?.(column, value) ?? String(value);
            return html`<td data-key=${column.key} data-sf-cell=${cellKind(component, column, columns)} style=${sticky}>${typeof typed === 'string' || typeof typed === 'number'
                ? html`<span class="sf-table-cell-bare">${typed}</span>`
                : renderCellItem(typed, component)}</td>`;
        })}</tr>`)}</tfoot>`;
    }

    // The name is the table's (or the list's) alone: a named section is a
    // region, and the data view around the table names its own region by the
    // list's heading, so a second one of the same name only repeats it to a
    // screen reader (Larena storage review, 2026-10-28).
    return html`
        <section
                class="sf-table ${context.list ? 'sf-table--list' : ''} min-w-0 flex flex-col gap-1/3 flex-1 min-h-0 ${context.rootClass ||
                ""}"
                style=${context.rootStyle || nothing}
                data-sf-instance=${context.component.getInstanceId()}
                data-state=${resolvedDataState(context)}
                aria-busy=${resolvedDataState(context) === 'loading' ? 'true' : nothing}
        >
            ${context.toolbar ? (context.compactToolbar ? renderListToolbar(context) : renderToolbar(context)) : nothing}
            ${context.component.renderBulkActions()}

            <div class="table-wrap min-w-0 max-w-full flex flex-col flex-1 min-h-0">
                <div class="sf-table-scroll min-h-0 min-w-0 overflow-auto flex-1 relative"
                     ${ref(context.component.refs.scroll)}
                     data-sf-vertical-scroll=${context.verticalScroll}>
                    <div class="sf-table-resize-guide" aria-hidden="true" hidden
                         ${ref(context.component.refs.resizeGuide)}></div>
                    ${resolvedDataState(context) === 'loading' && (context.component.getTableData()?.rows?.length ?? 0) > 0
                        ? html`
                            <div class="sf-table-busy" role="status">
                                <!-- The words are the spinner's label, kept for a screen reader
                                     and hidden from the eye (label-hidden, owner decision C138,
                                     SP-06): the spinner keeps one name mechanism and the status
                                     region says them once. -->
                                <sf-spinner size=${context.controlSize ?? nothing} label=${context.loadingText} label-hidden></sf-spinner>
                            </div>
                        `
                        : nothing}
                    ${context.list ? renderList() : html`
                    <table
                            ${ref(context.component.refs.table)}
                            id=${context.rowAreaId}
                            class="table border-separate border-spacing-0 min-w-full ${context.keyedNarrow ? 'sf-table-keyed' : `${context.component?.contentSized ? 'sf-table-content-sized' : 'w-max'} table-fixed`} transition"
                            role=${context.component.isTree?.() ? 'treegrid' : nothing}
                            aria-label=${context.ariaLabel || nothing}
                            aria-rowcount=${context.component.ariaRowCount?.() ?? context.component.windowRowCount?.() ?? nothing}
                    >
                        ${renderColgroup(context)}
                        ${renderHead(context)}
                        ${renderBody(context)}
                        ${renderFoot()}
                    </table>`}
                </div>
                ${context.verticalScroll === 'page' && !context.list
                        ? html`<div class="sf-table-rail" aria-hidden="true" hidden ${ref(context.component.refs.rail)}>
                            <div class="sf-table-rail-track"></div></div>`
                        : nothing}
                ${context.component.renderBulkActions('after')}

                ${context.pagin
                        ? html`
                            <sf-pagination
                                    current="1"
                                    total=${String(context.paginationTotal)}
                                    bottom="true"
                                    show-action-for-all
                                    page-size=${String(context.paginationPageSize)}
                                    page-sizes=${context.pageSizes}
                                    show-page-size
                                    top-class="content-main-center"
                                    main-class="items-cross-center content-main-between"
                                    bottom-class="items-cross-center gap-2"
                            ></sf-pagination>`
                        : nothing}
            </div>
        </section>
        ${state.contextMenu?.open ? context.component.renderContextMenu(context.state.contextMenu) : nothing}
        <!-- A demo panel used to stand here, open to nothing, titled after a
             ticket. Closed, it still took a box of its own, and in a card that
             spaces its parts that box became the gap above Show more: three
             spacings instead of one. -->
    `;
}
